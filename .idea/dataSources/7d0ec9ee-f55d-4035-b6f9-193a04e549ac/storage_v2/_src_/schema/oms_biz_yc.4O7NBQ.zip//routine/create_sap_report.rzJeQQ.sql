create
    definer = jusre4557wkn@`%` procedure create_sap_report(IN beginTime datetime, IN endTime datetime)
BEGIN
	

	truncate table aty_sap_report_detail;
	truncate table aty_sap_report_check;
	truncate table qn_execute_record;
	
	Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('Begin ', 1, 'Begin', now());
	
  call create_sap_report_b2c_sales(beginTime,endTime);
	
	call create_sap_report_b2c_return(beginTime,endTime);
	
	
	Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('End ', 10, 'End', now());
	
	
-- 	 Select * From  qn_execute_record
	
END;

