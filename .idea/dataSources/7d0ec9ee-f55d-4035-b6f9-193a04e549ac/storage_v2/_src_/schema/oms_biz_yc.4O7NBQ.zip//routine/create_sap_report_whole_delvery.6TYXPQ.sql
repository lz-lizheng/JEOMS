create
    definer = jusre4557wkn@`%` procedure create_sap_report_whole_delvery(IN beginTime datetime, IN endTime datetime)
BEGIN
	INSERT IGNORE INTO `aty_sap_report_detail` (
		`created_time`,
		`oms_order_id`,
		`oms_order_code`,
		`oms_order_detail_id`,
		`order_type`,
		`product_id`,
		`product_code`,
		`product_name`,
		`quantity`,
		`sku_id`,
		`sku_code`,
		`sku_name`,
		`settlement_price`,
		`settlement_amount`,
		`distribution_price`,
		`selling_amount`,
		`warehouse_operation_point`,
		`delivery_return_time`,
		`virtual_warehouse_id` 
	) SELECT
	now(),
	ows.whole_sales_delivery_order_id AS oms_order_id,
	ows.whole_sales_delivery_order_code AS oms_order_code,
	owsd.whole_sales_delivery_order_detail_id AS oms_order_detail_id,
	805,
	owsd.product_id AS product_id,
	owsd.product_code AS product_code,
	owsd.product_name AS product_name,
	owsd.out_quantity AS quantity,
	owsd.sku_id AS sku_id,
	owsd.sku_code AS sku_code,
	owsd.sku_name AS sku_name,
	owsd.discount_price AS settlement_price,
	owsd.discount_price * owsd.out_quantity AS settlement_amount,
	owsd.discount_price AS distribution_price,
	owsd.discount_price * owsd.out_quantity AS settlement_amount,
		0 AS warehouse_operation_point,
	ows.last_outer_time,
	ows.virtual_warehouse_id AS virtual_warehouse_id 
	FROM
		oms_whole_sales_delivery_order ows
		INNER JOIN oms_whole_sales_delivery_order_detail owsd ON ows.whole_sales_delivery_order_id = owsd.whole_sales_delivery_order_id 
	WHERE
		ows.out_status IN ( 2, 3 ) 
		AND ows.last_outer_time >= beginTime 
	AND ows.last_outer_time < endTime;
END;

