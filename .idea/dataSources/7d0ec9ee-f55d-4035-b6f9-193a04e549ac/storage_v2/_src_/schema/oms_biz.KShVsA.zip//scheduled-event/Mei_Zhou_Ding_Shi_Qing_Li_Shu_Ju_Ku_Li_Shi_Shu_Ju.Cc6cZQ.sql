create definer = jusre4557wkn@`%` event 每周定时清理数据库历史数据 on schedule
    every '1' WEEK
        starts '2022-03-27 03:00:00'
    on completion preserve
    enable
    do
    call `数据库定时清理历史数据`;

