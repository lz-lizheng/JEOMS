create
    definer = jusre4557wkn@`%` procedure create_sap_report_vip_return(IN beginTime datetime, IN endTime datetime)
BEGIN
	INSERT IGNORE INTO `aty_sap_report_detail` (
		`created_time`,
		`oms_order_id`,
		`oms_order_code`,
		`trade_id`,
		`store_id`,
		`oms_order_detail_id`,
		`order_type`,
		`product_id`,
		`product_code`,
		`product_name`,
		`quantity`,
		`sku_id`,
		`sku_code`,
		`sku_name`,
		`settlement_price`,
		`settlement_amount`,
		`distribution_price`,
		`selling_amount`,
		`warehouse_operation_point`,
		`delivery_return_time`,
		`virtual_warehouse_id`,
		`unique_code` 
	) SELECT
	now(),
	ovr.vip_return_id AS oms_order_id,
  ovr.vip_return_code AS oms_order_code,
	ovr.outer_code as trade_id,
	ovr.store_id,
	vrd.vip_return_detail_id AS oms_order_detail_id,
	403,
	vrd.product_id AS product_id,
	vrd.product_code AS product_code,
	vrd.product_name AS product_name,
	vrnd.in_quantity + vrnd.in_substandard_quantity AS quantity,
	vrd.sku_id AS sku_id,
	vrd.sku_code AS sku_code,
	vrd.sku_name AS sku_name,
	vrd.selling_price AS settlement_price,
	-vrd.selling_price * (vrnd.in_quantity + vrnd.in_substandard_quantity) AS settlement_amount,
	0 AS distribution_price,
	-vrd.selling_price * (vrnd.in_quantity + vrnd.in_substandard_quantity) AS selling_amount,
	0 AS warehouse_operation_point,
	vrn.last_in_time as delivery_return_time,
	ovr.virtual_warehouse_id AS virtual_warehouse_id,
	    CONCAT('VIP_RETURN_ORDER',vrnd.vip_return_notice_detail_id ) as unique_code 
	FROM
		oms_vip_return_notice vrn
    INNER JOIN oms_vip_return_notice_detail vrnd ON vrn.vip_return_notice_id = vrnd.vip_return_notice_id
    INNER JOIN oms_vip_return ovr ON vrnd.vip_return_id = ovr.vip_return_id
    INNER JOIN oms_vip_return_detail vrd ON vrd.vip_return_detail_id = vrnd.vip_return_detail_id
    INNER JOIN oms_product_sku sku ON sku.sku_id = vrd.sku_id
	WHERE
		vrn.in_status IN (2,3)
		AND vrn.last_in_time >= beginTime 
	  AND vrn.last_in_time < endTime;
	
	INSERT IGNORE INTO aty_sap_report_check
	SELECT
	a.order_type `单据类型`,
	a.oms_order_id `单据ID`,
	a.oms_order_code `单据编码`,
	a.oms_order_detail_id `单据明细ID`,
	a.sku_code 规格编码,
	b.store_name 店铺,
	d.warehouse_name 仓库,
  null as 店铺分销类型,
CASE
		w_company.distribute_type 
		WHEN 1 THEN
		'直营' 
		WHEN 2 THEN
		'联营' ELSE '分销' 
	END 仓库分销类型,
	d.sales_type 仓库销售类型,
	null  分销销售类型,
	s_company.company_name AS 店铺公司,
	w_company.company_name AS 仓库公司,
	a.warehouse_operation_point 仓库扣点,
  null as 平台类型,
	a.delivery_return_time as 业务确认时间,
	a.quantity 数量,
	a.distribution_price 分销价,
	a.distribution_price * a.quantity 分销金额,
	a.settlement_price 电商结算价,
	-a.settlement_price * a.quantity 电商结算金额,
	a.settlement_price AS 仓库结算价,
	-a.settlement_price * a.quantity AS 仓库结算金额,
	-a.settlement_price * a.quantity AS 销售金额,
	a.unique_code
FROM
	aty_sap_report_detail a,
	oms_store b,
	oms_virtual_warehouse c,
	oms_warehouse d,
	oms_company s_company,
	oms_company w_company
WHERE
  a.store_id=b.store_id
	AND a.virtual_warehouse_id = c.virtual_warehouse_id 
	AND c.warehouse_id = d.warehouse_id 	
	AND b.company_id = s_company.company_id 
	AND d.company_id = w_company.company_id 
	AND order_type = 403;
END;

