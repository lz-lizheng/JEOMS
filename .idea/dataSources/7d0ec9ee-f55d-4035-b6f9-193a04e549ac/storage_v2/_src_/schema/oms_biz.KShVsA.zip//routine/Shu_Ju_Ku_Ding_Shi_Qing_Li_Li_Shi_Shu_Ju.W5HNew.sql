create
    definer = jusre4557wkn@`%` procedure 数据库定时清理历史数据()
BEGIN
	DECLARE COUNT_TR INT DEFAULT 1;
 DECLARE COUNT_MS INT DEFAULT 1;
 DECLARE COUNT_MR INT DEFAULT 1;
 DECLARE COUNT_SS INT DEFAULT 1;
 DECLARE COUNT_S INT DEFAULT 1;
 DECLARE pageSize INT DEFAULT 100000;
 DECLARE THRESS_MONTH_BEFORE_TIME datetime DEFAULT DATE_SUB(NOW(),INTERVAL 3 month);
 DECLARE TWO_MONTH_BEFORE_TIME datetime DEFAULT DATE_SUB(NOW(),INTERVAL 2 month);

		-- oms_third_part_transfer_record Delete Start 
    WHILE  COUNT_TR > 0 DO
		if COUNT_TR>0 then
		set  COUNT_TR = (select count(1)  from oms_third_part_transfer_record where modified_time<THRESS_MONTH_BEFORE_TIME);
		END IF;
		if COUNT_TR>0 then 
       delete from oms_third_part_transfer_record where modified_time<THRESS_MONTH_BEFORE_TIME limit pageSize;
		set	 COUNT_TR = CEILING(COUNT_TR/pageSize)-1;
		END IF;
		END WHILE;
		-- oms_third_part_transfer_record Delete End  

		-- oms_mall_sales_order Delete Start 
		WHILE  COUNT_MS > 0 DO
		if COUNT_MS>0 then
		set	COUNT_MS = (select count(1)  from oms_mall_sales_order where created_time<THRESS_MONTH_BEFORE_TIME);
		END IF;
		if COUNT_MS>0 then 
       delete from oms_mall_sales_order where created_time<THRESS_MONTH_BEFORE_TIME limit pageSize;
		set	 COUNT_MS = CEILING(COUNT_MS/pageSize)-1;
		END IF;
		END WHILE;
		-- oms_mall_sales_order Delete End  

		-- oms_mall_refund_order Delete Start 
		WHILE  COUNT_MR > 0 DO
		if COUNT_MR>0 then
		set	COUNT_MR = (select count(1)  from oms_mall_refund_order where created_time<THRESS_MONTH_BEFORE_TIME);
		END IF;
		if COUNT_MR>0 then 
       delete from oms_mall_refund_order where created_time<THRESS_MONTH_BEFORE_TIME limit pageSize;
		set	 COUNT_MR = CEILING(COUNT_MR/pageSize)-1;
		END IF;
		END WHILE;
		-- oms_mall_refund_order Delete End
		
		-- oms_stock_snapshot_order Delete Start
		WHILE  COUNT_SS > 0 DO
		if COUNT_SS>0 then
		set	COUNT_SS = (select count(1)  from oms_stock_snapshot_order where created_time<TWO_MONTH_BEFORE_TIME);
		END IF;
		if COUNT_SS>0 then 
       delete from oms_stock_snapshot_order where created_time<TWO_MONTH_BEFORE_TIME limit pageSize;
		set	 COUNT_SS = CEILING(COUNT_SS/pageSize)-1;
		END IF;
		END WHILE;
		-- oms_stock_snapshot_order Delete End
		
		-- oms_stock Delete Start
		WHILE  COUNT_S > 0 DO
		if COUNT_S>0 then
		set	COUNT_S = (select count(1) from oms_stock where quantity=0 and transit_quantity=0);
		END IF;
		if COUNT_S>0 then 
       delete from oms_stock where quantity=0 and transit_quantity=0 limit pageSize;
		set	 COUNT_S = CEILING(COUNT_S/pageSize)-1;
    END IF; 
		END WHILE;
		-- oms_stock Delete End

END;

