create
    definer = jusre4557wkn@`%` function calc_warehouse_settlement_price(f_sales_type int, d_sales_type int,
                                                                        s_distribute_type int, w_distribute_type int,
                                                                        s_company_id bigint, w_company_id bigint,
                                                                        warehouse_operation_point int, mall_type int,
                                                                        settlement_price decimal(15, 4),
                                                                        cost_price decimal(15, 4),
                                                                        distribution_price decimal(15, 4)) returns decimal(15, 4)
BEGIN
RETURN (
  SELECT case w_distribute_type
when 1 then 
    case 
      when d_sales_type!=f_sales_type then distribution_price*(100-warehouse_operation_point)/100
      else 
        case 
          when s_distribute_type=1 then cost_price
          else distribution_price*(100-warehouse_operation_point)/100 
        end
    end
when 2 then
  case 
    when s_company_id=w_company_id then settlement_price*(100-warehouse_operation_point)/100
  else
    case 
      when s_distribute_type=3 then distribution_price*(100-warehouse_operation_point)/100
      else
        case 
          when mall_type=1201 then settlement_price*(100-warehouse_operation_point)/100
          else distribution_price*(100-warehouse_operation_point)/100
        end
    end
  end
when 3 then 
   distribution_price*(100-warehouse_operation_point)/100
 END
);
END;

