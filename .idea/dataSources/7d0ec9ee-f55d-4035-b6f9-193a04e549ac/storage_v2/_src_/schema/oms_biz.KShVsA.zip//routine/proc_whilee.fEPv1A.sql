create
    definer = jusre4557wkn@`%` procedure proc_whilee()
BEGIN
    
		Select 1 ;
		
END;

