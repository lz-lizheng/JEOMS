create
    definer = jusre4557wkn@`%` procedure proc_while()
BEGIN
 DECLARE COUNT INT DEFAULT 0;
   SET COUNT = (select count(1) from oms_product_mall_mapping where store_id in ( select store_id from oms_store where mall_type=2402 and store_code not in ('10022', '10021')));
    WHILE         COUNT > 0 DO
       delete from oms_product_mall_mapping where store_id in ( select store_id from oms_store where mall_type=2402 and store_code not in ('10022', '10021')) limit 500000;
                         SET COUNT =(select count(1) from oms_product_mall_mapping where store_id in ( select store_id from oms_store where mall_type=2402 and store_code not in ('10022', '10021')));
    END WHILE ;
END;

