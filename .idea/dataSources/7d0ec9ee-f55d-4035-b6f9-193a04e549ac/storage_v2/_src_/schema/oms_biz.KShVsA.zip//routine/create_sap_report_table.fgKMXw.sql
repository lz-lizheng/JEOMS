create
    definer = jusre4557wkn@`%` procedure create_sap_report_table(IN beginTime datetime, IN endTime datetime)
BEGIN
DROP TABLE
IF
	EXISTS `aty_sap_report_detail`;
CREATE TABLE `aty_sap_report_detail` (
	`report_id` BIGINT ( 20 )  UNSIGNED NOT NULL auto_increment COMMENT 'SAP销售订单明细ID',
	`created_time` datetime NOT NULL COMMENT '创建时间',
	`oms_order_code` VARCHAR ( 50 ) NOT NULL COMMENT 'oms发退单号',
	`oms_order_id` BIGINT ( 20 ) UNSIGNED NOT NULL COMMENT 'oms单据id',
	`trade_id` VARCHAR ( 50 ) NOT NULL COMMENT '交易号',
	`oms_order_detail_id` BIGINT ( 25 ) UNSIGNED NOT NULL COMMENT 'oms单据明细id',
	`order_type` INT ( 3 ) NOT NULL COMMENT '单据类型',
	`delivery_return_time` datetime NOT NULL COMMENT '发退货时间',
	`distribute_price_adjust_order_code` VARCHAR ( 50 ) DEFAULT NULL COMMENT '分销调价单编码',
	`distribute_price_adjust_order_name` VARCHAR ( 50 ) DEFAULT NULL COMMENT '分销调价单名称',
	`product_id` BIGINT ( 20 ) UNSIGNED NOT NULL COMMENT '商品ID',
	`product_code` VARCHAR ( 50 ) NOT NULL COMMENT '商品编码',
	`product_name` VARCHAR ( 50 ) NOT NULL COMMENT '商品名称',
	`quantity` INT ( 20 ) NOT NULL COMMENT '数量',
	`sku_id` BIGINT ( 20 ) UNSIGNED NOT NULL COMMENT '规格Id',
	`sku_code` VARCHAR ( 50 ) NOT NULL COMMENT '规格编码',
	`sku_name` VARCHAR ( 50 ) NOT NULL COMMENT '规格名称',
	`size` VARCHAR ( 100 ) DEFAULT NULL COMMENT '尺码',
	`color` VARCHAR ( 50 ) DEFAULT NULL COMMENT '颜色',
	`brand_code` VARCHAR ( 50 ) DEFAULT NULL COMMENT '品牌编码',
	`brand_name` VARCHAR ( 50 ) DEFAULT NULL COMMENT '品牌名称',
	`listing_year` VARCHAR ( 50 ) DEFAULT NULL COMMENT '年份',
	`category_name` VARCHAR ( 50 ) DEFAULT NULL COMMENT '二级分类',
	`season` VARCHAR ( 50 ) DEFAULT NULL COMMENT '季节',
	`marked_price` DECIMAL ( 15, 4 ) NOT NULL COMMENT '吊牌价',
	`manufacturer_item_number` VARCHAR ( 50 ) DEFAULT NULL COMMENT '厂家货号',
	`settlement_price` DECIMAL ( 15, 4 ) NOT NULL COMMENT '结算价',
	`settlement_amount` DECIMAL ( 15, 4 ) NOT NULL COMMENT '结算金额',
	`distribution_price` DECIMAL ( 15, 4 ) NOT NULL COMMENT '分销价',
	`cost_price` DECIMAL ( 15, 4 ) NOT NULL COMMENT '成本价',
	`selling_amount` DECIMAL ( 15, 4 ) NOT NULL COMMENT '销售金额',
	`warehouse_operation_point` DECIMAL ( 5, 2 ) DEFAULT '0.00' COMMENT '仓库扣点/多一度扣点',
	`platform_operation_point` DECIMAL ( 5, 2 ) DEFAULT NULL COMMENT '平台扣点/店铺扣点',
	`warehouse_operation_amount` DECIMAL ( 15, 2 ) DEFAULT '0.00' COMMENT '仓库扣点金额',
	`income_amount` DECIMAL ( 15, 4 ) NOT NULL COMMENT '收入金额',
	`warehouse_settlement_price` DECIMAL ( 15, 4 ) NOT NULL COMMENT '仓库结算价',
	`warehouse_settlement_amount` DECIMAL ( 15, 4 ) NOT NULL COMMENT '仓库结算金额',
	`store_express_fee` DECIMAL ( 15, 4 ) NOT NULL COMMENT '网店运费',
	`warehouse_express_fee` DECIMAL ( 15, 4 ) DEFAULT NULL COMMENT '仓库运费',
	`express_id` BIGINT ( 20 ) DEFAULT NULL COMMENT '快递id',
	`express_code` VARCHAR ( 50 ) DEFAULT NULL COMMENT '快递编码',
	`express_name` VARCHAR ( 50 ) DEFAULT NULL COMMENT '快递名称',
	`express_number` VARCHAR ( 50 ) DEFAULT NULL COMMENT '快递单号',
	`virtual_warehouse_id` BIGINT ( 20 ) DEFAULT NULL COMMENT '虚拟仓ID',
	PRIMARY KEY (`report_id`) USING BTREE,
	UNIQUE KEY `idx_oms_order_detail` ( `oms_order_detail_id`, `order_type` ) USING BTREE,
	KEY `idx_oms_code` ( `oms_order_code` ),
KEY `idx_oms_order_id` ( `oms_order_id` ) 
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMMENT = 'SAP销售单汇总明细信息';
END;

