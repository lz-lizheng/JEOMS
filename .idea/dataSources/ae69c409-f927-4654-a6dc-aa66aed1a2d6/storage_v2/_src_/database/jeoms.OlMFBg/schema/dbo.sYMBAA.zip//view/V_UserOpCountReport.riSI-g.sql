
CREATE VIEW [dbo].[V_UserOpCountReport]
AS
SELECT CreateUserName,c.StoreId,OpDate,SUM(订单操作数) AS 订单操作数,SUM(退款申请操作数) AS 退款申请操作数,SUM(付款单操作数) AS 付款单操作数,SUM(退款单操作数) AS 退款单操作数,SUM(退换货单单操作数) AS 退换货单单操作数 
FROM (
	SELECT sl.CreateUserName,ro.StoreId,CONVERT(VARCHAR(10),sl.createdate,121) AS OpDate,COUNT(DISTINCT SalesOrderId) AS 订单操作数,0 AS 退款申请操作数,0 AS 付款单操作数,0 AS 退换货单单操作数,0 AS 退款单操作数 FROM SalesOrderLog sl JOIN dbo.SalesOrder ro ON ro.OrderId=SalesOrderId WHERE sl.CreateUserName NOT LIKE '%system%' AND sl.CreateUserName NOT LIKE '%系统%' GROUP BY sl.CreateUserName,ro.StoreId,CONVERT(VARCHAR(10),sl.createdate,121)
	UNION ALL
	SELECT rl.CreateUser AS CreateUserName,ro.StoreId,CONVERT(VARCHAR(10),rl.createdate,121) AS OpDate,0 AS 订单操作数,COUNT(DISTINCT OrderId) AS 退款申请操作数,0 AS 付款单操作数,0 AS 退换货单单操作数,0 AS 退款单操作数 FROM ApplyRefundOrderLog rl JOIN dbo.ApplyRefundOrder ro ON ro.Id = rl.OrderId WHERE rl.CreateUser NOT LIKE '%system%' AND rl.CreateUser NOT LIKE '%系统%' GROUP BY rl.CreateUser,ro.StoreId,CONVERT(VARCHAR(10),rl.createdate,121)
	UNION ALL
	SELECT pl.CreateUserName,ro.StoreId,CONVERT(VARCHAR(10),pl.createdate,121) AS OpDate,0 AS 订单操作数,0 AS 退款申请操作数,COUNT(DISTINCT PaymentOrderId) AS 付款单操作数,0 AS 退换货单单操作数,0 AS 退款单操作数 FROM PaymentOrderlog pl JOIN dbo.PaymentOrder ro ON ro.Id = pl.PaymentOrderId WHERE pl.CreateUserName NOT LIKE '%system%' AND pl.CreateUserName NOT LIKE '%系统%' GROUP BY pl.CreateUserName,ro.StoreId,CONVERT(VARCHAR(10),pl.createdate,121)
	UNION ALL
	SELECT rl.CreateUserName,ro.StoreId,CONVERT(VARCHAR(10),rl.createdate,121) AS OpDate,0 AS 订单操作数,0 AS 退款申请操作数,0 AS 付款单操作数,COUNT(DISTINCT ReturnOrderId) AS 退换货单单操作数,0 AS 退款单操作数 FROM ReturnOrderLog rl JOIN dbo.ReturnOrder ro ON ro.Id = rl.ReturnOrderId WHERE rl.CreateUserName NOT LIKE '%system%' AND rl.CreateUserName NOT LIKE '%系统%' GROUP BY rl.CreateUserName,ro.StoreId,CONVERT(VARCHAR(10),rl.createdate,121)
	UNION ALL
	SELECT * FROM (
		SELECT b.username AS CreateUserName,ro.StoreId,CONVERT(VARCHAR(10),b.createdate,121) AS 操作日期,0 AS 订单操作数,0 AS 退款申请操作数,0 AS 付款单操作数,0 AS 退换货单单操作数,COUNT(DISTINCT b.objectid) AS 退款单操作数 FROM systemlog AS b JOIN dbo.RefundOrder ro ON ro.Id = b.ObjectId
		WHERE b.username NOT LIKE '%system%' AND b.username NOT LIKE '%系统%' AND b.ModuleType =  '303'
		GROUP BY b.username,CONVERT(VARCHAR(10),b.createdate,121),ro.StoreId
	) A
) AS c GROUP BY CreateUserName,OpDate,c.StoreId
go

