


CREATE FUNCTION [dbo].[F_CalcSkuUploadQuantity]
(
  @skuId       UNIQUEIDENTIFIER,
  @storeId     UNIQUEIDENTIFIER,
  @presellPlanId UNIQUEIDENTIFIER,
  @quantity    INT
)
RETURNS INT
AS
BEGIN
  DECLARE @sumQuantity INT = -99999;
  DECLARE @sumInventory INT;
  DECLARE @sumOccupation INT;
  IF @presellPlanId IS NOT NULL
    SET @sumQuantity = dbo.F_GetPreSellBeUploadQty(@SkuId, @StoreId);
  IF @sumQuantity = -99999
    BEGIN

	  IF @StoreId <> '5039EE76-834D-4507-99FA-A8C457FB3E83' and @StoreId <> '6CED2F38-65CA-465F-87B3-4D67A4C10CE6' and @StoreId <> '77A28F97-B96C-4D0C-B071-01F77F04EFE7'
		begin
		  SELECT @sumInventory = ISNULL(SUM(Quantity), 0)
		  FROM InventoryVirtual
		  WHERE WarehouseId IN (SELECT WHP.Id AS WarehouseId
								FROM InventoryUploadWarehouse iuw
								JOIN InventoryUploadConfig iuc ON iuw.StoreId = iuc.StoreId AND (iuc.IsUpload = 1 OR iuc.IsManualUpload=1) AND iuc.StoreId = @storeId
								JOIN Warehouse wh ON wh.Id = iuw.WarehouseId
								JOIN Warehouse WHP ON wh.ParentId = WHP.ParentId 
				) 
				AND SkuId = @skuId;

		  SELECT @sumOccupation = ISNULL(SUM(Quantity), 0)
		  FROM InventoryOccupation
		  WHERE WarehouseId IN (
								SELECT WHP.Id AS WarehouseId
								FROM InventoryUploadWarehouse iuw
								JOIN InventoryUploadConfig iuc ON iuw.StoreId = iuc.StoreId AND (iuc.IsUpload = 1 OR iuc.IsManualUpload=1) AND iuc.StoreId = @storeId
								JOIN Warehouse wh ON wh.Id = iuw.WarehouseId
								JOIN Warehouse WHP ON wh.ParentId = WHP.ParentId 
								 ) 
				AND SkuId = @skuId AND Type <> 6
	   end
      ELSE
		begin
		  SELECT @sumInventory = ISNULL(SUM(Quantity), 0)
		  FROM InventoryVirtual
		  WHERE WarehouseId IN (SELECT wh.Id AS WarehouseId
								FROM InventoryUploadWarehouse iuw
								JOIN InventoryUploadConfig iuc ON iuw.StoreId = iuc.StoreId AND (iuc.IsUpload = 1 OR iuc.IsManualUpload=1) AND iuc.StoreId = @storeId
								JOIN Warehouse wh ON wh.Id = iuw.WarehouseId
				) 
				AND SkuId = @skuId;

		  SELECT @sumOccupation = ISNULL(SUM(Quantity), 0)
		  FROM InventoryOccupation
		  WHERE WarehouseId IN (
								SELECT wh.Id AS WarehouseId
								FROM InventoryUploadWarehouse iuw
								JOIN InventoryUploadConfig iuc ON iuw.StoreId = iuc.StoreId AND (iuc.IsUpload = 1 OR iuc.IsManualUpload=1) AND iuc.StoreId = @storeId
								JOIN Warehouse wh ON wh.Id = iuw.WarehouseId
								 ) 
				AND SkuId = @skuId AND Type <> 6
	   end

      SET @sumQuantity = @sumInventory - @sumOccupation
      IF @sumQuantity > @quantity
        RETURN @quantity;
      ELSE
        RETURN @sumQuantity;
    END
  ELSE
    RETURN @sumQuantity;
  RETURN @quantity;
END



go

