CREATE TRIGGER [dbo].[DI_TRIGGER_SalesOrderDetail_D]
   ON  [dbo].[SalesOrderDetail] 
   after  delete
AS 
	declare @DetailId bigint
	select @DetailId=DetailId from deleted
	insert into jeoms.dbo.DI_SalesOrderDetail_TRIG_LOG(DetailId,FLAG,INSERT_TIME) values (@DetailId,'D',GETDATE())
go

disable trigger DI_TRIGGER_SalesOrderDetail_D on SalesOrderDetail
go

