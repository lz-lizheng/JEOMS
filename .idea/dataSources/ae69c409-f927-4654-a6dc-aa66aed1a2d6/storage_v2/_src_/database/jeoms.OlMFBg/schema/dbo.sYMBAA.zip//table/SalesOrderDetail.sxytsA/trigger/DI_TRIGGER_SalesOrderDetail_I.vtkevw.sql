CREATE TRIGGER [dbo].[DI_TRIGGER_SalesOrderDetail_I]
   ON  [dbo].[SalesOrderDetail] 
   after  INSERT
AS 
	declare @DetailId bigint
	select @DetailId=DetailId from inserted
	insert into jeoms.dbo.DI_SalesOrderDetail_TRIG_LOG(DetailId,FLAG,INSERT_TIME) values (@DetailId,'I',GETDATE())
go

