
-----------------格普
/**********************
*create date : 2016-11-17
*create by：Byron 
*remark ：修改商品库存跟踪视图
***********************/
CREATE VIEW [dbo].[V_ApiProductInventoryTracking] AS 
SELECT APIT.Id,APIT.AdjustmentQuantity,APIT.ChangeDate,APIT.Memo,
APIT.OperatorDate,APIT.OperatorUser,APIT.OrderCode,APIT.OrderType,
APIT.OriginalQuantity,APIT.ProductSkuCode,APIT.Quantity,APIT.WareHouseCode,
w.Name WareHouseName, PS.ProductCode, ps.ProductName, ps.Description
FROM dbo.ApiProductInventoryTracking APIT(NOLOCK)
LEFT JOIN ProductSku PS(NOLOCK) ON APIT.ProductSkuCode = PS.Code
left join Warehouse w on w.Code = APIT.WareHouseCode
WHERE ps.Status = 1



go

