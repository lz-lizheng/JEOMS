CREATE VIEW V_ReturnOutCountReport
AS
SELECT a.storename,a.StoreId,a.tradeid,c.createdate,b.productcode,b.skucode outskucode,d.skucode from SalesOrder as a
inner join SalesOrderDetail as b on a.OrderId =b.SalesOrderId
inner join ReturnOrder as c on c.OutSalesOrderCode = a.code
inner join ReturnOrderDetail as d on c.Id = d.ReturnOrderId and b.productcode = d.productcode and b.skucode<>d.skucode

go

