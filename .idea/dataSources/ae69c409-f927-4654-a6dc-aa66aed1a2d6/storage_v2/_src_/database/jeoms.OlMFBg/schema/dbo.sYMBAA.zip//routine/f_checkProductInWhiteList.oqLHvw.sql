
  
CREATE FUNCTION [dbo].[f_checkProductInWhiteList]
(
	@P_WarehouseId uniqueidentifier,
	@P_ProductCode nvarchar(50)
)
RETURNS nvarchar(10)
AS
BEGIN
	if exists (Select 1 From Warehouse Where id = @P_WarehouseId And isnull(StorageType, 0) = 0)
		Begin
			Return 'Y';
		End;

	if exists (Select 1 From ProductWhiteList Where ProductCode = @P_ProductCode) 
		Begin
			Return 'Y';
		End

	RETURN 'N';
END



go

