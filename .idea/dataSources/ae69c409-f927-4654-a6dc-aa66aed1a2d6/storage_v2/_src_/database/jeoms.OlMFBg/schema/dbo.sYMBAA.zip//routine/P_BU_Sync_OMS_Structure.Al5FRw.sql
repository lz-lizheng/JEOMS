		--3.创建P_BU_Sync_OMS_Structure存储过程
		--执行存储过程 [dbo].[P_BU_Sync_OMS_Structure] 同步 表: OMS_Sync_Table_Structure 中所有表的表结构． 
		-- Proc1:
		Create Procedure [dbo].[P_BU_Sync_OMS_Structure] 
		As
		Begin   

		 Declare @AlterSql nVarchar(4000), @TblName nVarchar(200),@SQL nVarchar(max)
		 
		 Truncate Table OMS_Table_Not_Exists;

		 -- 已有字段结构调整, 新增字段, 删除字段
		 -- 遍历更新有变更的字段结构
		 Declare TabCur Cursor For
		Select Distinct TableName
		From OMS_Sync_Table_Structure
		Order By TableName
		 Open TabCur
		 Fetch next From TabCur Into @TblName;
		 While @@FETCH_STATUS = 0
		 Begin
		  -- 更新字段结构
		  Print @AlterSql;

		  If Not Exists(Select 1 From Sys.sysobjects Where xtype = 'U' And name = @TblName)
		  --Create New Table
			Begin
				   Select Top 1 @SQL = CreateSql
					From OMS_SYNC_TABLES WHERE TableName = @TblName
				Print 'Insert Into CreateTabelSql :'+@SQL;
				Exec SP_EXECUTESQL @SQL;
			End

		  If Exists (Select 1 From Sys.sysobjects Where xtype = 'U' And name = @TblName)
			Begin 
				Exec [dbo].[P_BU_Sync_OMS_Table_Structure] @TblName;
			End 
		  Fetch next From TabCur Into @TblName;
		 End;

		 Close TabCur;
		 Deallocate TabCur;
		End;

        go

