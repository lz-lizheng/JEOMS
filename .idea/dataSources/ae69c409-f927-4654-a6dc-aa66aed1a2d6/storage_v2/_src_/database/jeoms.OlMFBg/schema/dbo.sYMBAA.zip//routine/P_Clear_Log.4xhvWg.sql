CREATE Procedure [dbo].[P_Clear_Log] as 
Begin 
    Declare @V_Date_1 DateTime,@V_Date_5 DateTime,@V_Date_10 DateTime,@V_Date_15 DateTime, @V_Date_30 DateTime, @V_Date_60 DateTime, @V_Date_90 DateTime, @V_Date_120 DateTime, @V_Date_150 DateTime, @V_Date_180 DateTime,@V_Date_720 DateTime;
    Declare @V_rowcnt decimal(15, 0), @V_TotalRow decimal(15, 0)
    Set @V_Date_1 = DATEADD(Day, -1, GetDate()) Print Convert(Varchar(10), @V_Date_1, 20)
    Set @V_Date_5 = DATEADD(Day, -5, GetDate()) Print Convert(Varchar(10), @V_Date_5, 20)
    Set @V_Date_10 = DATEADD(Day, -10, GetDate()) Print Convert(Varchar(10), @V_Date_10, 20)
    Set @V_Date_15 = DATEADD(Day, -15, GetDate()) Print Convert(Varchar(10), @V_Date_15, 20)
    Set @V_Date_30 = DATEADD(Day, -30, GetDate()) Print Convert(Varchar(10), @V_Date_30, 20)
    Set @V_Date_60 = DATEADD(Day, -60, GetDate()) Print Convert(Varchar(10), @V_Date_60, 20)
    Set @V_Date_90 = DATEADD(Day, -90, GetDate()) Print Convert(Varchar(10), @V_Date_90, 20)
    Set @V_Date_120 = DATEADD(Day, -120, GetDate()) Print Convert(Varchar(10), @V_Date_120, 20)
    Set @V_Date_150 = DATEADD(Day, -150, GetDate()) Print Convert(Varchar(10), @V_Date_150, 20)
    Set @V_Date_180 = DATEADD(Day, -180, GetDate()) Print Convert(Varchar(10), @V_Date_180, 20)
  Set @V_Date_720 = DATEADD(YEAR, -2, GetDate()) Print Convert(Varchar(10), @V_Date_720, 20)  

   
    Print 'Clear Ods ---- ' + Convert(varchar(20), getdate(), 20) + '  PlatformRefund 5 '
    Set @V_rowcnt = 0
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.T_ODSRefund_Order WHERE RecordDate < @V_Date_5 And SyncStatus = 4
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.T_ODSRefund_Order WHERE RecordDate < @V_Date_5 And SyncStatus = 4
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--PlatformRefund--' + Convert(varchar(20), getdate(), 20)
      END

	  
    Print 'Clear Ods ---- ' + Convert(varchar(20), getdate(), 20) + '  PlatformOrder 10'
    Set @V_rowcnt = 0
    Select @V_TotalRow  = Count(1) FROM  jeoms.dbo.PlatformOrder WHERE RecordDate < @V_Date_10 And SyncStatus = 4
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.PlatformOrder WHERE RecordDate < @V_Date_10 And SyncStatus = 4
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--PlatformOrder--' + Convert(varchar(20), getdate(), 20)
      END

    Print 'Clear Ods ---- ' + Convert(varchar(20), getdate(), 20) + '  PlatformOrder_Created 90'
    Set @V_rowcnt = 0
    Select @V_TotalRow  = Count(1) FROM  jeoms.dbo.PlatformOrder_Created WHERE CreateDate < @V_Date_90  	
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.PlatformOrder_Created WHERE CreateDate < @V_Date_90  
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--PlatformOrder_Created--' + Convert(varchar(20), getdate(), 20)
      END
    
	 

    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     DistributionLog 30'   
    Set @V_rowcnt = 0
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.DistributionLog WHERE CreateDate < @V_Date_30
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.DistributionLog WHERE CreateDate < @V_Date_30
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--DistributionLog--' + Convert(varchar(20), getdate(), 20)
      END


    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     InventoryUploadLog 15'  
    Set @V_rowcnt = 0
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.InventoryUploadLog WHERE CreateDate < @V_Date_15
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.InventoryUploadLog WHERE CreateDate < @V_Date_15
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--InventoryUploadLog--' + Convert(varchar(20), getdate(), 20)
      END
    

	Print 'Insert PlatformOrder_Created ***** SyncStatus = 0'
	INSERT INTO PlatformOrder_Created(Id, CreateDate, StoreId, Tid)
	Select cast(Convert(Varchar(10), getDate(), 12) as decimal(10)) * 1000000 + ROW_NUMBER() over (order by pr.refund_order_id) as Id, getdate(), pr.Store_Id, pr.Tid   
	From T_ODSRefund_Order Pr
	Where Pr.SyncStatus = 0
	And Not Exists (Select 1 From PlatformOrder_Created Prc where pr.Store_Id = Prc.StoreId and pr.tid = Prc.Tid)
	And Exists (Select 1 From SalesOrder so where pr.Store_Id = so.StoreId and pr.Tid = so.TradeId and so.IsAutoDownload = 1 );
Print 'Insert PlatformOrder_Created ***** SyncStatus = 0'
	  INSERT INTO jeoms.dbo.PlatformOrder_Created(Id, CreateDate, StoreId, Tid)
	  select cast(Convert(Varchar(10), getDate(), 12) as decimal(10)) * 1000000 + ROW_NUMBER() over (order by rd.Id) as Id, getdate(), rd.StoreId, rd.Tid from (
			Select row_number() over (partition by pr.RefundCode order by RecordDate desc) RowId,pr.Id, pr.StoreId, pr.Tid, pr.RecordDate, pr.RefundCode, st.Name
			From jeoms.dbo.PlatformRefund Pr left join jeoms.dbo.Store st on pr.StoreId = st.Id
			Where Pr.SyncStatus = 0 and st.PlatformType in (2, 4, 22, 23, 61)
			And Not Exists (Select 1 From jeoms.dbo.PlatformOrder_Created Prc where pr.StoreId = Prc.StoreId and pr.tid = Prc.Tid)
			And Exists (Select 1 From jeoms.dbo.SalesOrder so where pr.StoreId = so.StoreId and pr.Tid = so.TradeId and so.IsAutoDownload = 1 )) rd
	  where rd.RowId = 1;
End;
go

