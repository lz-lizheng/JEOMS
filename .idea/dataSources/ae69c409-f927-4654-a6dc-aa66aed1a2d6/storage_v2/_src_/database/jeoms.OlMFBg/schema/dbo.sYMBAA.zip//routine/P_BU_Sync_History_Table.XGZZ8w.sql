
  
CREATE Procedure [dbo].[P_BU_Sync_History_Table] 
As
Begin 

Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] VirtualWarehouseTransferLog
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] VirtualWarehouseTransferDetail
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] VirtualWarehouseTransfer
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SystemLog
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderSub
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderPayMent
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderOutofStock
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderLog_backup191111
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderLog
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderInvoice
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderHold
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderDiscount
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderDetailPlatformProduct
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderDetail
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderDeliveryInfo
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrderActivity
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] SalesOrder
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ReturnSign
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ReturnOrderOutDetail
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ReturnOrderNoticeDetail
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ReturnOrderNotice
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ReturnOrderLog
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ReturnOrderDetail
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ReturnOrder
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] InventoryTrigger
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] DispatchOrderDetailExpress
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] DispatchOrderDetail
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] DispatchOrder
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ApplyRefundOrderLog

Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ApplyRefundOrder
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ApiShippingAddressUpdateRecord
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ApiProductInventoryTracking
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ApiDeliveryCompletedDetail
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] ApiDeliveryCompleted
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] AlipayRecord
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] AccountOrderDetail
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] AccountOrderAlipayRecordMap
Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20);          Exec [dbo].[P_BU_Check_History_Table] AccountOrder




End;



go

