

	CREATE VIEW [dbo].[V_ProductCategory] AS 
	SELECT pc1.Id AS OneCatId, pc1.Name AS OneCatName, pc2.id AS TwoCatId, pc2.Name AS TwoCatName, pc3.id AS ThreeCatId, pc3.Name AS ThreeCatName
	FROM ProductCategory PC1
	LEFT JOIN dbo.ProductCategory PC2 ON pc1.Id = pc2.ParentId
	LEFT JOIN dbo.ProductCategory PC3 ON pc2.Id = pc3.ParentId
	WHERE pc1.Level = 0



    go

