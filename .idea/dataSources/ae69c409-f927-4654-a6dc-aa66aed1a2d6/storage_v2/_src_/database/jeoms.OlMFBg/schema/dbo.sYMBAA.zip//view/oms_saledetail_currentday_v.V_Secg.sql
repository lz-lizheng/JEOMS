create view oms_saledetail_currentday_v
as
select t2.detailid   as order_id,
       t1.tradeid as order_code,
       '' as reorder_code,
       'OR' as order_type,
       t1.paydate as order_time,
       case
         when t1.storename = '卡宾微商城' then
          '30005'
         when t1.storename = '童装微商城' then
          '30074'
         when t1.storename = '官方商城' then
          '30113'
         when t1.storename = '官方特卖商城' then
          '30113'
         else
          ''
       end store_code,
       t2.skucode as merchandise_code, 
       t2.quantity as detail_retail_quantity,
       t2.amountactual as detail_retail_amount 
  from salesorder(nolock) t1
 inner join salesorderdetail(nolock) t2 on t1.orderid = t2.salesorderid
   where t1.storename in ('卡宾微商城', '童装微商城', '官方商城', '官方特卖商城')
   and t1.transtype = '0'
   and t1.isobsolete = '0'    
   and CONVERT(varchar(10),t1.paydate,120)= CONVERT(varchar(10),GETDATE(),120)
union all 
select  t7.id   as order_id,
       t1.tradeid as order_code,
       t7.tradeid as reorder_code,
       'RT' as order_type, 
       t7.auditdate as order_time,
       case
         when t1.storename = '卡宾微商城' then
          '30005'
         when t1.storename = '童装微商城' then
          '30074'
         when t1.storename = '官方商城' then
          '30113'
         when t1.storename = '官方特卖商城' then
          '30113'
         else
          ''
       end   store_code,
       t2.skucode as merchandise_code,  
       0 - t7.quantity as detail_retail_quantity,
       0 - t7.refundfee as detail_retail_amount 
  from salesorder(nolock) t1
 inner join salesorderdetail(nolock) t2 on t1.orderid = t2.salesorderid
 inner join applyrefundorder(nolock) t7 on t2.detailid =
                                               t7.salesorderdetailid
                                           and t7.auditstatus = '1'
 where t1.storename in ('卡宾微商城', '童装微商城', '官方商城', '官方特卖商城')
   and t1.transtype = '0'
   and t1.isobsolete = '0'
   and CONVERT(varchar(10),t7.auditdate,120) = CONVERT(varchar(10),GETDATE(),120)
go

