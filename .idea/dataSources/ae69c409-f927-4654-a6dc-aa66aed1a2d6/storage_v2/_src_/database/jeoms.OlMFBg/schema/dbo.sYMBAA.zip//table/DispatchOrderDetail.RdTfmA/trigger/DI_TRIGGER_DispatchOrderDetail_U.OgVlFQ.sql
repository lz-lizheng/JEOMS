CREATE TRIGGER [dbo].[DI_TRIGGER_DispatchOrderDetail_U]
   ON  [dbo].[DispatchOrderDetail] 
   after  update
AS 
	declare @DetailId bigint
	select @DetailId=id from inserted
	insert into jeoms.dbo.DI_DispatchOrderDetail_TRIG_LOG(DetailId,FLAG,INSERT_TIME) select id,'U',GETDATE() from DispatchOrderDetail where id = @DetailId
go

