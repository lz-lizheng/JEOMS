CREATE TRIGGER [dbo].[DI_TRIGGER_ApplyRefundOrder_D]
   ON  [dbo].[ApplyRefundOrder] 
   after  delete
AS 
	declare @Id bigint
	select @Id=Id from deleted
	insert into jeoms.dbo.DI_ApplyRefundOrder_TRIG_LOG(ID,FLAG,INSERT_TIME) values (@Id,'D',GETDATE())
go

disable trigger DI_TRIGGER_ApplyRefundOrder_D on ApplyRefundOrder
go

