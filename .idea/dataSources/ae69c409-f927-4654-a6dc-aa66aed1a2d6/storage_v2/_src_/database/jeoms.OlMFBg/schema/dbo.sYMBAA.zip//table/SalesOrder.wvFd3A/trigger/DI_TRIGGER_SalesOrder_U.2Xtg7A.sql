-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[DI_TRIGGER_SalesOrder_U]
   ON  [dbo].[SalesOrder] 
   AFTER  UPDATE
AS 
	declare @OrderId nvarchar(50)
	select @OrderId=code from inserted
	insert into DI_SalesOrder_TRIG_LOG(OrderId,FLAG,INSERT_TIME) select OrderId,'U', GETDATE() from SalesOrder where code = @OrderId
go

