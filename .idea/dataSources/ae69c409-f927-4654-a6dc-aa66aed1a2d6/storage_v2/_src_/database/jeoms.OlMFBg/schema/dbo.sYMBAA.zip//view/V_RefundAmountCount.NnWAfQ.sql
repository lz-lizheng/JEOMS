
CREATE VIEW [dbo].[V_RefundAmountCount] 
AS
SELECT P.*,SUM(CASE WHEN ar.RefundType=1 THEN ar.RefundFee END) RefundActualAmount,SUM(CASE WHEN ar.RefundType=1 THEN ar.RefundFee END) ReturnActualAmount FROM 
(SELECT * FROM (SELECT RefundReason,ro.StoreName,ro.StoreId,CONVERT(NVARCHAR(7),ro.CreateDate,120) CreateDate,SUM(ActualAmount) ActualAmount
FROM dbo.RefundOrder(NOLOCK) ro JOIN dbo.GeneralClassiFication(NOLOCK) gc ON ro.RefundReason=gc.Name 
WHERE ro.Status>=1 GROUP BY RefundReason,ro.StoreName,ro.StoreId,CONVERT(NVARCHAR(7),ro.CreateDate,120)) P pivot (sum(ActualAmount) 
FOR P.RefundReason in (福袋,仓库损失,应收损失,退运费,退差价,质量问题赔偿,交易纠纷赔偿,免单,物流丢件,系统优惠没减,零头差异调整)) as ourpivot) P
LEFT JOIN dbo.ApplyRefundOrder(NOLOCK) ar ON p.StoreId=ar.StoreId AND ar.AuditStatus=1 AND Convert(nvarchar(10),ar.CreateDate,120)=Convert(nvarchar(10),p.CreateDate,120)
GROUP BY P.StoreName,p.StoreId,P.CreateDate,P.福袋,P.仓库损失,P.退运费,P.退差价,P.质量问题赔偿,P.交易纠纷赔偿,P.免单,P.物流丢件,P.系统优惠没减,P.零头差异调整,P.应收损失

go

