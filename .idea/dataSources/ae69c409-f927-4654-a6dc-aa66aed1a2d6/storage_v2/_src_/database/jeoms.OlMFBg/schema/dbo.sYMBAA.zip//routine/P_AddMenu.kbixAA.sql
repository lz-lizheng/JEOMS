

/*
 * 添加菜单
 * 张秦 20151218
 */
CREATE PROCEDURE [dbo].[P_AddMenu]
(
    @id UNIQUEIDENTIFIER=NULL,
    @name AS VARCHAR(50),--名称
	@type INT=2,--类型，0模块，1分组，2菜单项
	@icon VARCHAR(100)=NULL,--大图标
	@style INT=1,--按钮样式
	@data VARCHAR(100)=NULL,
	@command VARCHAR(100)=NULL,
	@isSystem BIT=0,--是否系统操作项
	@parentId UNIQUEIDENTIFIER=NULL,--父ID
	@initPrivilege BIT=1--是否初始化管理员角色权限
)
AS
DECLARE @orderId INT
IF @id IS NULL 
SET @id=NEWID()
IF @parentId IS NULL
SELECT @orderId = ISNULL(MAX(OrderId),0)+1 FROM dbo.Menu  WHERE ParentId IS NULL 
ELSE 
SELECT @orderId = ISNULL(MAX(OrderId),0)+1 FROM dbo.Menu  WHERE ParentId=@parentId
--添加操作项
INSERT INTO dbo.Menu ( Id, Name, Type, Icon,  Style, Data,
                        Command, ParentId, IsSystem, OrderId )
VALUES  ( @id,@name,@type,@icon,@style,@data,@command,@parentId, @isSystem,@orderId)
IF	@initPrivilege=1
	BEGIN
	--添加权限
	INSERT INTO dbo.Privilege ( Id, OperaterId, ObjectId, Type )
	SELECT NEWID(),Id,@id,101 FROM dbo.Role WHERE IsSystem=1
	END



go

