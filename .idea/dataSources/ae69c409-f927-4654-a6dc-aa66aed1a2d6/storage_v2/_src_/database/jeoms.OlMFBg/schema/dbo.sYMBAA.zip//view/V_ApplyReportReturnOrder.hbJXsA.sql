

CREATE view [dbo].[V_ApplyReportReturnOrder]
as
select ab.OrderType,ar.TradeId,sum(ar.RefundFee) RefundFee,ab.RefundAmount AmountActual,ar.BuyerNick CustomerCode,ar.BuyerNick CustomerName,ar.StoreId,ar.StoreName,MIN(ar.LastDate) AuditDate
from ApplyRefundOrder(nolock) ar
left join 
(
select distinct '退货退款' OrderType,sum(ro.AmountActual) RefundAmount,ro.TradeId from 
ReturnOrder(nolock) ro where ro.IsReplace=0 and ro.IsObsolete=0 and ro.Status>=1 and ro.RefundWay=0 group by ro.TradeId
) ab on ab.TradeId=ar.TradeId
where  ar.Status=6 group by ar.TradeId,ab.OrderType,ar.BuyerNick,ar.StoreId,ar.StoreName,ab.RefundAmount
go

