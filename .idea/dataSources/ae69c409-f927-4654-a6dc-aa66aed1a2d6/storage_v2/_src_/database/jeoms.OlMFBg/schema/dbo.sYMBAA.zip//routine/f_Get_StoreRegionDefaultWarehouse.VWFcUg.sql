

/*
*create date : 2018-04-31
*create by：qiaoni 
*remark ：订单默认建议仓库 － 配货策略设置门店组时 转门店
*/
CREATE FUNCTION [dbo].[f_Get_StoreRegionDefaultWarehouse]
(
	@P_StoreID		UNIQUEIDENTIFIER,
	@P_ProvinceName NVARCHAR(50),
	@P_CityName		NVARCHAR(50),
	@P_CountyName	NVARCHAR(50)
)
RETURNS @V_Warehouse TABLE(WarehouseID UNIQUEIDENTIFIER, WarehouseCode NVARCHAR(20), WarehouseName NVARCHAR(50))
AS
BEGIN
	--2. 建议仓库获取 问题点：a. 如果不设置仓库范围则为全部都到， b. 如果店铺没设置配货模板取店铺默认快递下的共享仓
	-- 转换需要注意的点： 更新配货模板时需要重启

	--SQL 1:
	--SET STATISTICS IO ON  
	INSERT INTO @V_Warehouse(WarehouseID, WarehouseCode, WarehouseName) 
	SELECT TOP 1 a.WarehouseId, a.Code, a.WarehouseName
	FROM ( 
		SELECT Case When WH.WarehouseType = 4 Then WHC.Id Else DTW.warehouseid End as WarehouseId,
			   Case When WH.WarehouseType = 4 Then WHC.Code Else wh.Code End as Code,
			   Case When WH.WarehouseType = 4 Then WHC.Name Else wh.Name End as WarehouseName, 
			   DTW.OrderId
		FROM dbo.StoreSetting SS 
		INNER JOIN dbo.DispatchTemplate DT ON ss.DispatchTemplateId = DT.Id
		INNER JOIN dbo.DispatchTemplateWarehouse DTW ON DT.Id = DTW.TemplateId
		INNER JOIN dbo.Warehouse WH ON DTW.WarehouseId = WH.Id 
		JOin dbo.Warehouse WHC ON WH.ParentId = WHC.Id
		WHERE DTW.IsDisabled = 0
		AND DT.IsDisabled = 0
		AND SS.StoreId = @P_StoreID
		And whc.WarehouseType = 1
		and wh.IsDisabled = 0
		and whc.IsDisabled = 0
		AND (WHC.IsRegion = 0 or EXISTS (SELECT 1 FROM dbo.WarehouseRegion WR WHERE WR.ProvinceName = @P_ProvinceName 
					AND WR.CityName = @P_CityName AND WR.CountyName = @P_CountyName AND WH.ParentId = WR.WarehouseId))
		UNION ALL
		SELECT Case When WH.WarehouseType = 4 Then WHC.Id Else DTW.warehouseid End as WarehouseId,
			   Case When WH.WarehouseType = 4 Then WHC.Code Else wh.Code End as Code,
			   Case When WH.WarehouseType = 4 Then WHC.Name Else wh.Name End as WarehouseName, 
			   DTW.OrderId
		FROM dbo.StoreSetting SS 
		INNER JOIN dbo.DispatchTemplate DT ON ss.DispatchTemplateId = DT.Id
		INNER JOIN dbo.DispatchTemplateWarehouse DTW ON DT.Id = DTW.TemplateId
		INNER JOIN dbo.Warehouse WH ON DTW.WarehouseId = WH.Id 
		JOin dbo.Warehouse WHC ON WH.Id = WHC.ParentId
		WHERE DTW.IsDisabled = 0
		AND DT.IsDisabled = 0
		AND SS.StoreId = @P_StoreID
		and wh.WarehouseType = 4
		and wh.IsDisabled = 0
		and whc.IsDisabled = 0
		AND (WHC.IsRegion = 0 or  EXISTS (SELECT 1 FROM dbo.WarehouseRegion WR WHERE WR.ProvinceName = @P_ProvinceName 
					AND WR.CityName = @P_CityName AND WR.CountyName = @P_CountyName AND WH.ParentId = WR.WarehouseId))
		UNION ALL 
		SELECT Case When WH.WarehouseType = 4 Then WHC.Id Else WH.Id End as WarehouseId,
			   Case When WH.WarehouseType = 4 Then WHC.Code Else wh.Code End as Code,
			   Case When WH.WarehouseType = 4 Then WHC.Name Else wh.Name End as WarehouseName, 
			   DTW.OrderId
		FROM dbo.StoreSetting SS 
		INNER JOIN dbo.DispatchTemplate DT ON ss.DispatchTemplateId = DT.Id
		INNER JOIN dbo.DispatchTemplateWarehouse DTW ON DT.Id = DTW.TemplateId
		INNER JOIN dbo.Warehouse WH ON DTW.WarehouseId = WH.Id
		JOin dbo.Warehouse WHC ON WH.Id = WHC.ParentId
		WHERE DTW.IsDisabled = 0
		AND DT.IsDisabled = 0
		and wh.IsDisabled = 0
		and whc.IsDisabled = 0
		AND SS.StoreId = @P_StoreID
		AND NOT EXISTS (SELECT 1 FROM WarehouseRegion wr WHERE WH.ParentId = WR.WarehouseId)  
		) A
	ORDER BY A.OrderId;
	--SET STATISTICS IO OFF
   
	IF @@ROWCOUNT = 0
		BEGIN
			--SQL 2: -- 取店铺默认仓库
			INSERT INTO @V_Warehouse(WarehouseID, WarehouseCode, WarehouseName) 
			SELECT WH.Id, WH.Code, WH.Name AS WarehouseName
			FROM dbo.StoreSetting SS
			INNER JOIN dbo.Warehouse WH ON SS.DefaultWarehouseId = WH.Id
			WHERE WH.IsDisabled = 0 
			AND SS.StoreId = @P_StoreID;  
		END;   
	RETURN;
END;

go

