


CREATE PROCEDURE [dbo].[proc_SOM_EXECSQL]
       @Sql VARCHAR(MAX) 
AS
EXEC (@Sql)
go

