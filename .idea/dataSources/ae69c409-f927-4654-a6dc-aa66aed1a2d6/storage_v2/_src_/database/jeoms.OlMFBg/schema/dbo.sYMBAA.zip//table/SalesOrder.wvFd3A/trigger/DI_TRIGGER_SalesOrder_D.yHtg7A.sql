CREATE TRIGGER [dbo].[DI_TRIGGER_SalesOrder_D]
   ON  [dbo].[SalesOrder] 
   after  delete
AS 
	declare @OrderId bigint
	select @OrderId=OrderId from deleted
	insert into jeoms.dbo.DI_SalesOrder_TRIG_LOG(OrderId,FLAG,INSERT_TIME) values (@OrderId,'D',GETDATE())
go

disable trigger DI_TRIGGER_SalesOrder_D on SalesOrder
go

