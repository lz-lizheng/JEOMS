

  
/**********************
*create date : 2016-09-29
*create by：qiaoni 
*remark ：优化可配计算逻辑
***********************/

CREATE FUNCTION [dbo].[F_GetWarehousSkuBePickingQty_1020]
(
	@SkuId UNIQUEIDENTIFIER,		--规格ID
	@payTime DATETIME,				--支付时间
	@WarehousId UNIQUEIDENTIFIER	--仓库Id
)
RETURNS INT
AS
BEGIN
	DECLARE @V_BePickingQty INT
	Declare @V_inv int

	-- 获取现有仓库库存,  库存锁定，设置仓库商品排他后库存不参与计算.	  
	SELECT @V_inv = isnull(SUM(iv.Quantity), 0) FROM dbo.InventoryVirtual IV(NOLOCK) WHERE IV.WarehouseId = @WarehousId AND IV.SkuId=@SkuId and IsLock = 0
	And not exists (Select 1 From StoreProduct ST(nolock), ProductSku PS(Nolock)Where ST.ProductId = PS.ProductId And PS.SkuId = IV.SkuId And ST.WarehouseId = IV.WarehouseId); 

	  
	if @V_inv < 1 
		Begin
			Return @V_inv;
		End 


      
	SELECT @V_BePickingQty = ISNULL(SUM(a.Quantity), 0)
	FROM (
		-- 现有库存
		SELECT SUM(iv.Quantity) AS Quantity
		FROM dbo.InventoryVirtual IV(NOLOCK)
		WHERE IV.WarehouseId = @WarehousId
		AND IV.SkuId=@SkuId 
		-- 同实体仓下其他仓库的负库存
		--UNION ALL
		--SELECT SUM(IV.Quantity) AS Quantity
		--FROM dbo.InventoryVirtual IV(NOLOCK)
		--WHERE IV.WarehouseId IN (SELECT WH2.Id FROM dbo.Warehouse WH1(NOLOCK) LEFT JOIN dbo.Warehouse WH2(NOLOCK) ON wh1.ParentId = Wh2.ParentId WHERE wh1.Id = @WarehousId AND WH2.Id <> @WarehousId)
		--AND iv.SkuId = @SkuId
		--AND iv.Quantity < 0 
		--UNION ALL
		-- 订单占用(未配货占用 同实体仓下所有占用)  
		--SELECT SUM(iocc.Quantity) * -1 AS Quantity
		--FROM dbo.InventoryOccupation iocc(NOLOCK)
		--WHERE iocc.SkuId = @SkuId 
		--AND iocc.WarehouseId IN (SELECT WHNew.Id 
		--							FROM dbo.Warehouse WhOrig(NOLOCK), dbo.Warehouse WHNew(NOLOCK)
		--							WHERE WhOrig.Id = @WarehousId AND WhOrig.ParentId = WhNew.ParentId)
		--AND iocc.PayDate < @payTime AND iocc.Type = 1 AND IsDispatched = 0 AND iocc.Quantity > 0
		UNION ALL
		-- 换货订单占用(未配货占用)  
		SELECT SUM(iocc.Quantity) * -1 AS Quantity
		FROM dbo.InventoryOccupation iocc(NOLOCK)
		WHERE iocc.SkuId = @SkuId 
		AND iocc.WarehouseId = @WarehousId AND iocc.PayDate < @payTime AND iocc.Type in (1, 2) AND IsDispatched = 0 AND iocc.Quantity > 0
		-- 订单、换货订单占用(已配货占用)
		UNION ALL
		SELECT SUM(iocc.Quantity) * -1 AS Quantity
		FROM dbo.InventoryOccupation iocc(NOLOCK)
		WHERE iocc.SkuId = @SkuId AND iocc.WarehouseId = @WarehousId AND iocc.Type IN (1, 2) AND IsDispatched = 1 AND iocc.Quantity > 0
		UNION ALL
		-- 调拨占用
		SELECT SUM(iocc.Quantity) * -1 AS Quantity
		FROM dbo.InventoryOccupation iocc(NOLOCK)
		WHERE iocc.SkuId = @SkuId AND iocc.WarehouseId = @WarehousId AND iocc.Type IN (3, 4, 5) AND iocc.Quantity > 0
		) A; 
		 
	IF @V_BePickingQty <= 0
		Begin
			SELECT @V_BePickingQty = ISNULL(SUM(a.Quantity), 0)
			FROM (
				-- 现有库存
				SELECT SUM(iv.Quantity) AS Quantity
				FROM dbo.InventoryVirtual IV(NOLOCK)
				WHERE IV.WarehouseId = @WarehousId
				AND IV.SkuId=@SkuId 
				-- 同实体仓下其他仓库的负库存
				UNION ALL
				SELECT SUM(IV.Quantity) AS Quantity
				FROM dbo.InventoryVirtual IV(NOLOCK)
				WHERE IV.WarehouseId IN (SELECT WH2.Id FROM dbo.Warehouse WH1(NOLOCK) LEFT JOIN dbo.Warehouse WH2(NOLOCK) ON wh1.ParentId = Wh2.ParentId WHERE wh1.Id = @WarehousId AND WH2.Id <> @WarehousId)
				AND iv.SkuId = @SkuId
				AND iv.Quantity < 0 
				UNION ALL
				-- 订单占用(未配货占用 同实体仓下所有占用)  
				SELECT SUM(iocc.Quantity) * -1 AS Quantity
				FROM dbo.InventoryOccupation iocc(NOLOCK)
				WHERE iocc.SkuId = @SkuId 
				AND iocc.WarehouseId IN (
											Select @WarehousId
											Union
											SELECT WHNew.Id 
											FROM dbo.Warehouse WhOrig(NOLOCK), dbo.Warehouse WHNew(NOLOCK)
											WHERE WhOrig.Id = @WarehousId AND WhOrig.ParentId = WhNew.ParentId
											and WHNew.Id <> @WarehousId
											And exists (Select 1 From V_InventoryVirtualStock iv(NOLOCK) where WHNew.Id = iv.WarehouseId and SkuId = @SkuId And CanSaleQuantity < 0) 
											)
				AND iocc.PayDate < @payTime AND iocc.Type = 1 AND IsDispatched = 0 AND iocc.Quantity > 0
				UNION ALL
				-- 换货订单占用(未配货占用)  
				SELECT SUM(iocc.Quantity) * -1 AS Quantity
				FROM dbo.InventoryOccupation iocc(NOLOCK)
				WHERE iocc.SkuId = @SkuId 
				AND iocc.WarehouseId = @WarehousId AND iocc.PayDate < @payTime AND iocc.Type = 2 AND IsDispatched = 0 AND iocc.Quantity > 0
				-- 订单、换货订单占用(已配货占用)
				UNION ALL
				SELECT SUM(iocc.Quantity) * -1 AS Quantity
				FROM dbo.InventoryOccupation iocc(NOLOCK)
				WHERE iocc.SkuId = @SkuId AND iocc.WarehouseId = @WarehousId AND iocc.Type IN (1, 2) AND IsDispatched = 1 AND iocc.Quantity > 0
				UNION ALL
				-- 调拨占用
				SELECT SUM(iocc.Quantity) * -1 AS Quantity
				FROM dbo.InventoryOccupation iocc(NOLOCK)
				WHERE iocc.SkuId = @SkuId AND iocc.WarehouseId = @WarehousId AND iocc.Type IN (3, 4, 5) AND iocc.Quantity > 0
				) A; 
		END
	
	If @V_BePickingQty <= 0
		BEGIN
			DECLARE @V_OtherCanSaleQty INT
			-- 检查同实体仓下其他实体仓库的总可销是否为正，如果为正该仓库计算可配只看当前虚拟仓下的占用
			SELECT @V_OtherCanSaleQty = SUM(IV.CanSaleQuantity) 
			FROM dbo.V_InventoryVirtualStock IV(NOLOCK)
			WHERE IV.WarehouseId IN (SELECT WH2.Id FROM dbo.Warehouse WH1(NOLOCK) LEFT JOIN dbo.Warehouse WH2(NOLOCK) ON wh1.ParentId = Wh2.ParentId WHERE wh1.Id = @WarehousId AND WH2.Id <> @WarehousId)
			AND iv.SkuId = @SkuId

			IF @V_OtherCanSaleQty >= 0
				Begin
					SELECT @V_BePickingQty = ISNULL(SUM(a.Quantity), 0)
					FROM (
						-- 现有库存
						SELECT SUM(iv.Quantity) AS Quantity
						FROM dbo.InventoryVirtual IV(NOLOCK)
						WHERE IV.WarehouseId = @WarehousId
						AND IV.SkuId=@SkuId 
						UNION ALL
						-- 订单占用+换货占用
						SELECT SUM(iocc.Quantity) * -1 AS Quantity
						FROM dbo.InventoryOccupation iocc(NOLOCK)
						WHERE iocc.SkuId = @SkuId 
						AND iocc.WarehouseId = @WarehousId
						AND iocc.PayDate < @payTime AND iocc.Type IN (1, 2) AND IsDispatched = 0 AND iocc.Quantity > 0
						-- 订单、换货订单占用(已配货占用)
						UNION ALL
						SELECT SUM(iocc.Quantity) * -1 AS Quantity
						FROM dbo.InventoryOccupation iocc(NOLOCK)
						WHERE iocc.SkuId = @SkuId AND iocc.WarehouseId = @WarehousId AND iocc.Type IN (1, 2) AND IsDispatched = 1 AND iocc.Quantity > 0
						UNION ALL
						-- 调拨占用
						SELECT SUM(iocc.Quantity) * -1 AS Quantity
						FROM dbo.InventoryOccupation iocc(NOLOCK)
						WHERE iocc.SkuId = @SkuId AND iocc.WarehouseId = @WarehousId AND iocc.Type IN (3, 4, 5) AND iocc.Quantity > 0
						) A;

				 
				END; 
		END;

	Declare @V_TotalQty int, @V_TotalIOCC int;
	If @V_BePickingQty < 1
		Begin
			-- Entity Total StockQty 
			SELECT @V_TotalQty = SUM(iv.Quantity)
			FROM dbo.InventoryVirtual IV(NOLOCK)
			WHERE IV.WarehouseId IN (SELECT WHNew.Id 
									FROM dbo.Warehouse WhOrig(NOLOCK), dbo.Warehouse WHNew(NOLOCK)
									WHERE WhOrig.Id = @WarehousId AND WhOrig.ParentId = WhNew.ParentId)
			AND IV.SkuId=@SkuId;
			
			Select @V_TotalIOCC = SUM(Quantity)
			From InventoryOccupation IOCC
			Where IOCC.WarehouseId IN (SELECT WHNew.Id 
									FROM dbo.Warehouse WhOrig(NOLOCK), dbo.Warehouse WHNew(NOLOCK)
									WHERE WhOrig.Id = @WarehousId AND WhOrig.ParentId = WhNew.ParentId)
			And IOCC.SkuId = @SkuId; 
			
			If @V_TotalQty > @V_TotalIOCC 
				Begin
					-- Result One Virtual Wrehouse Can Use Qty
					Select @V_BePickingQty = Sum(CanUseQuantity) 
					From V_InventoryVirtualStock
					Where WarehouseId = @WarehousId
					and SkuId  = @SkuId; 
				End;
		End;
		
		RETURN @V_BePickingQty;
END



go

