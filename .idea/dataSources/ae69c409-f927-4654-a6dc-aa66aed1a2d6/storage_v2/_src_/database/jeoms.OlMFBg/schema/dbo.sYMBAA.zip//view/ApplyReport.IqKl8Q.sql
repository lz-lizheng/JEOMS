
CREATE view [dbo].[ApplyReport]
as
select distinct '未发货订单' OrderType,ar.AuditStatus,ar.RefundType,ar.TradeId,ar.RefundFee,sl.AmountActual,ar.BuyerNick CustomerCode,ar.BuyerNick CustomerName,ar.SkuCode,ar.ProductCode,ar.ProductName,ar.SkuName,ar.StoreId,ar.StoreName,ar.AuditDate
from ApplyRefundOrder(nolock) ar 
left join(
select sl.AmountActual,sl.DetailId from SalesOrderDetail sl 
inner join salesorder(nolock) so on so.OrderId=sl.SalesOrderId
inner join ApplyRefundOrder(nolock) aro on aro.SalesOrderDetailId=sl.DetailId
 where sl.IsDeleted=1 and aro.AuditStatus=1
) sl on sl.DetailId=ar.SalesOrderDetailId  
where ar.RefundType=1 and ar.Status=6
 and isnull(ar.IsObsoleted,0)=0
union all
select distinct '退货退款' OrderType,ar.AuditStatus,ar.RefundType,ar.TradeId,ar.RefundFee,sl.RefundAmount,ar.BuyerNick CustomerCode,ar.BuyerNick CustomerName,ar.SkuCode,ar.ProductCode,ar.ProductName,ar.SkuName,ar.StoreId,ar.StoreName,ar.AuditDate
from ApplyRefundOrder(nolock) ar left join ReturnOrderDetail(nolock) sl on sl.SalesOrderDetailId=ar.SalesOrderDetailId
left join ReturnOrder(nolock) so on sl.ReturnOrderId=so.Id and so.IsReplace=0 and so.IsObsolete=0 and so.Status=1
where  ar.Status=6
 and isnull(ar.IsObsoleted,0)=0 
union all
select distinct '退款单' OrderType,ar.AuditStatus,ar.RefundType,ar.TradeId,ar.RefundFee,sl.RefundAmount,ar.BuyerNick CustomerCode,ar.BuyerNick CustomerName,ar.SkuCode,ar.ProductCode,ar.ProductName,ar.SkuName,ar.StoreId,ar.StoreName,ar.AuditDate
from ApplyRefundOrder(nolock) ar left join RefundOrder(nolock) sl on sl.SalesOrderId=ar.SalesOrderId and sl.Status=3 and sl.RefundWay=0
where  ar.Status=6
go

