CREATE PROCEDURE IndexRebuild  
AS  
BEGIN  
 if object_id('tempdb..#index_physical') is not null    
 begin  
  drop table #index_physical;  
 end  
 -- 获取碎片大于50的索引  
 select avg_fragmentation_in_percent,object_id,index_id into #index_physical  
 from  sys.dm_db_index_physical_stats(DB_ID() , null , null,NULL,NULL)  
 where avg_fragmentation_in_percent >= 50 and index_id > 0;  
  
 -- 索引重建  
 BEGIN  
 DECLARE  
  @idx_table_name AS varchar(200),  
  @idx_table_index AS varchar(200);  
  
 -- 声明游标  
 DECLARE c_idx_clean CURSOR FAST_FORWARD FOR  
  -- 查询碎片大于50的索引对应的表和索引名称  
  SELECT t.[name] table_name,  
      i.[name] index_name  
  FROM sys.objects t  INNER JOIN sys.indexes i ON t.object_id = i.object_id  
  WHERE t.is_ms_shipped  <> 1  
    AND index_id > 0  
    and t.[type] = 'U' and exists (  
   select 1 from #index_physical idx  
   where idx.object_id = i.object_id and idx.index_id = i.index_id  
    );  
    
 OPEN c_idx_clean;  
  
 -- 取第一条记录  
 FETCH NEXT FROM c_idx_clean INTO @idx_table_name,@idx_table_index;  
  
 WHILE @@FETCH_STATUS=0  
 BEGIN  
  ---- 重建时间不大于早上6点  
  --if DATEDIFF(n, GETDATE(),convert(varchar, getdate(), 23) + ' 06:00:00') < 0  
  -- break;  

  -- alter index @idx_table_index on @idx_table_name rebuild;  
  begin try
  Print 'alter index ' +  @idx_table_index + ' on ' + @idx_table_name + ' rebuild'
  exec('alter index ' +  @idx_table_index + ' on ' + @idx_table_name + ' rebuild');  
  -- 取下一条记录  
  FETCH NEXT FROM c_idx_clean INTO @idx_table_name,@idx_table_index;  
  
  end try
  begin catch
	print Error_message()
  end catch
 END  
 -- 关闭游标  
 CLOSE c_idx_clean;  
 -- 释放游标  
 DEALLOCATE c_idx_clean;  
 END  
END  
  
-- execute IndexRebuild;
go

