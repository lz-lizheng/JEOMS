
CREATE VIEW [dbo].[V_RolePrivilege]
AS
SELECT  p.*,r.Id RoleId FROM dbo.Privilege p JOIN dbo.Role r ON p.OperaterId=r.Id


go

