

CREATE VIEW [dbo].[V_Distribution] AS 
SELECT   d.*,dp.*
      FROM      Distribution d(nolock)
      JOIN      DistributionProduct dp(nolock) ON d.Id=dp.DistributionId;



go

