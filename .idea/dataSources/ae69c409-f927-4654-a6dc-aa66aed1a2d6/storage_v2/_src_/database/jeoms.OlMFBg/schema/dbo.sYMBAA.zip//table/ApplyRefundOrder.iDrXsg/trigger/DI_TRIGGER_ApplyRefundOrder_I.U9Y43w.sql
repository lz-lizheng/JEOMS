CREATE TRIGGER [dbo].[DI_TRIGGER_ApplyRefundOrder_I]
   ON  [dbo].[ApplyRefundOrder] 
   after  insert
AS 
	declare @Id bigint
	select @Id=Id from inserted
	insert into jeoms.dbo.DI_ApplyRefundOrder_TRIG_LOG(ID,FLAG,INSERT_TIME) values (@Id,'I',GETDATE())
go

