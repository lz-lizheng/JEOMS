CREATE VIEW [dbo].[V_ReportProductSaleTotal] AS 
SELECT '销售订单' AS DateType, 
	   CAST(so.PayDate AS DATE) AS DateKey,  
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.SkuCode,
	   sod.SkuName, 
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color, 
	   SUM(sod.Quantity) AS Quantity,
	   SUM(sod.AmountActual) AS AmountActual,
	   SUM((sod.Quantity * sod.FirstCost)) AS FirstCost,
     SUM(sod.DistributionAmount)   DistributionAmount
FROM dbo.SalesOrder(NOLOCK) so
LEFT JOIN dbo.SalesOrderDetail(NOLOCK) sod ON so.OrderId = sod.SalesOrderId
LEFT JOIN Product(NOLOCK) pd ON sod.ProductId = pd.ProductId
LEFT JOIN dbo.ProductSku(NOLOCK) ps ON sod.ProductSkuId = ps.SkuId 
GROUP BY CAST(so.PayDate AS DATE),  
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.SkuCode,
	   sod.SkuName, 
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color

UNION ALL

SELECT '取消订单' AS DateType, 
	   CAST(sod.DeletedDate AS DATE) AS DateKey, 
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.SkuCode,
	   sod.SkuName, 
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color, 
	   SUM(sod.Quantity) AS Quantity,
	   SUM(sod.AmountActual ) AS AmountActual,
	   SUM((sod.Quantity * sod.FirstCost)) AS FirstCost,
     SUM(sod.DistributionAmount)   DistributionAmount  
FROM dbo.SalesOrder(NOLOCK) so
LEFT JOIN dbo.SalesOrderDetail(NOLOCK) sod ON so.OrderId = sod.SalesOrderId
LEFT JOIN Product(NOLOCK) pd ON sod.ProductId = pd.ProductId
LEFT JOIN dbo.ProductSku(NOLOCK) ps ON sod.ProductSkuId = ps.SkuId
WHERE sod.IsDeleted = 1
GROUP BY CAST(sod.DeletedDate AS DATE),  
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.SkuCode,
	   sod.SkuName, 
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color
     

UNION ALL

SELECT '退货订单' AS DateType,
	   CAST(ro.ApproveDate AS DATE) AS DateKey, 
	   ro.StoreId,
	   ro.StoreName,
	   rod.ProductCode,
	   rod.ProductName,
	   rod.SkuCode,
	   rod.SkuName,
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color, 
	   SUM(rod.Quantity) AS Quantity,
	   SUM(rod.ActualAmount) AS AmountActual,
	   SUM((sod.Quantity * sod.FirstCost)) AS FirstCost,
     SUM(sod.DistributionAmount)   DistributionAmount  
FROM dbo.ReturnOrder(NOLOCK) RO
LEFT JOIN dbo.ReturnOrderDetail(NOLOCK) ROD ON ro.Id = rod.ReturnOrderId
LEFT JOIN dbo.SalesOrderDetail(NOLOCK) sod ON sod.DetailId = rod.SalesOrderDetailId
LEFT JOIN dbo.SalesOrder(NOLOCK) so ON so.OrderId = sod.SalesOrderId 
LEFT JOIN Product(NOLOCK) pd ON rod.ProductId = pd.ProductId
LEFT JOIN dbo.ProductSku(NOLOCK) ps ON rod.SkuId = ps.SkuId
WHERE ro.IsObsolete = 0
GROUP BY CAST(ro.ApproveDate AS DATE),
	   CAST(so.PayDate AS DATE), 
	   ro.StoreId,
	   ro.StoreName,
	   rod.ProductCode,
	   rod.ProductName,
	   rod.SkuCode,
	   rod.SkuName, 
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color


go

