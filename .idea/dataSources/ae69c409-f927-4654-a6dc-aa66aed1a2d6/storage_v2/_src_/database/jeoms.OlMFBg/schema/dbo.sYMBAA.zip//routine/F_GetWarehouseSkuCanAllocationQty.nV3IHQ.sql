


------------------ 2014-04-27 --------------
CREATE FUNCTION [dbo].[F_GetWarehouseSkuCanAllocationQty]
(
	@P_WarehouseID	UNIQUEIDENTIFIER,	--实体仓库ID
	@P_SkuId		UNIQUEIDENTIFIER	--SKU ID
)
RETURNS INT
AS
BEGIN
	DECLARE @V_Rlt INT
	  
	SELECT @V_Rlt = SUM(AC.TotalQuantity)
	FROM (
		-- 仓库库存(共享仓:只能从共享仓调拨到其他仓库)
		SELECT SUM(IV.Quantity) AS TotalQuantity
		FROM dbo.InventoryVirtual IV(nolock), dbo.Warehouse WH(nolock)
		WHERE IV.WarehouseId = WH.Id
		AND WH.WarehouseType = 2
		AND WH.ParentId = @P_WarehouseID
		AND IV.SkuId = @P_SkuId 
		-- 1.1 已配货占用
		UNION
		SELECT SUM(IOCC.Quantity) * -1 AS DispatchLocked
		FROM dbo.InventoryOccupation IOCC(nolock), dbo.Warehouse WH(nolock)
		WHERE IOCC.WarehouseId = WH.Id
		AND Wh.ParentId = @P_WarehouseID
		AND IOCC.SkuId = @P_SkuId
		AND IOCC.Type IN (1, 2) and WH.WarehouseType=2
		AND IOCC.IsDispatched = 1 
		--1.2　实体调拨占用
		UNION
		SELECT SUM(IOCC.Quantity) * -1 AS AllocationLocked
		FROM dbo.InventoryOccupation IOCC(nolock), dbo.Warehouse WH(nolock)
		WHERE IOCC.WarehouseId = WH.Id
		AND Wh.ParentId = @P_WarehouseID
		AND IOCC.SkuId = @P_SkuId
		AND IOCC.Type IN (3, 4)
		--1.3 配货模板关联店铺未配货占用
		UNION
		Select SUM(IOCC.Quantity) * -1 AS UnDispatchLocked
		From dbo.InventoryOccupation IOCC(nolock)
		Where iocc.SkuId = @P_SkuId
		and iocc.IsDispatched = 0
		and iocc.Type in (1, 2)
		and iocc.WarehouseId in (Select DTW.WarehouseId
								FROM dbo.DispatchTemplate DT(nolock), dbo.DispatchTemplateWarehouse DTW(nolock), dbo.StoreSetting ss(nolock), dbo.Warehouse Wh(nolock)
								WHERE dt.Id = dtw.TemplateId  
								AND wh.ParentId = @P_WarehouseID
								AND dt.Id = ss.DispatchTemplateId
								AND DTW.WarehouseId = wh.Id
								AND dt.IsDisabled = 0)  
		) AC

		
	-- 返回可销
	if ISNULL(@V_Rlt, 0) < 0 
		begin
			set @V_Rlt = 0;
		end
		
	RETURN ISNULL(@V_Rlt, 0); 
END



go

