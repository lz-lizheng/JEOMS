
CREATE PROCEDURE [dbo].[sp_indexused] @tablename VARCHAR(50),@IsDisplayTableSchema INT  = 1
AS

DECLARE @SHOWCONTIG TABLE
(
	ObjectName VARCHAR(50),
	ObjectId VARCHAR(50),
	IndexName VARCHAR(50),
	IndexId INT,
	Level INT,
	Pages INT,
	Rows INT,
	MinimumRecordSize FLOAT,
	MaximumRecordSize FLOAT,
	AverageRecordSize FLOAT,
	ForwardedRecords INT,
	Extents INT,
	ExtentSwitches INT,
	AverageFreeBytes FLOAT,
	AveragePageDensity FLOAT,
	ScanDensity FLOAT,
	BestCount INT,
	ActualCount INT,
	LogicalFragmentation FLOAT,
	ExtentFragmentation FLOAT
);

INSERT INTO @SHOWCONTIG
EXECUTE('DBCC SHOWCONTIG('+@tablename +') WITH ALL_INDEXES,ALL_LEVELS,TABLERESULTS'); 

    WITH    TableIndexColumn
              AS ( SELECT   TableName ,
                            Index_Name ,
                            [ColumnNames] = STUFF(( SELECT  '，' + [Co_Name]
                                                    FROM    ( SELECT
                                                              tab.Name AS TableName ,
                                                              ind.Name AS Index_Name ,
                                                              key_ordinal ,
                                                              index_columns.index_column_id ,
                                                              ( CASE index_columns.is_included_column
                                                              WHEN 0
                                                              THEN Col.Name
                                                              ELSE Col.Name
                                                              + '[include]'
                                                              END ) AS Co_Name
                                                              FROM
                                                              sys.indexes ind
                                                              INNER JOIN sys.tables tab ON ind.Object_id = tab.object_id
                                                              AND ind.type IN (
                                                              1, 2 )
                                                              INNER JOIN sys.index_columns index_columns ON tab.object_id = index_columns.object_id
                                                              AND ind.index_id = index_columns.index_id
                                                              INNER JOIN sys.columns Col ON tab.object_id = Col.object_id
                                                              AND index_columns.column_id = Col.column_id
                                                            ) t
                                                    WHERE   TableName = tb.TableName
                                                            AND Index_Name = tb.Index_Name
                                                    ORDER BY t.TableName ,
                                                            t.Index_Name ,
                                                            t.index_column_id
                                                  FOR
                                                    XML PATH('')
                                                  ), 1, 1, '')
                   FROM     ( SELECT    tab.Name AS TableName ,
                                        ind.Name AS Index_Name ,
                                        Col.Name AS Co_Name
                              FROM      sys.indexes ind
                                        INNER JOIN sys.tables tab ON ind.Object_id = tab.object_id
                                                              AND ind.type IN (
                                                              1, 2 )
                                        INNER JOIN sys.index_columns index_columns ON tab.object_id = index_columns.object_id
                                                              AND ind.index_id = index_columns.index_id
                                        INNER JOIN sys.columns Col ON tab.object_id = Col.object_id
                                                              AND index_columns.column_id = Col.column_id
                            ) tb
                   WHERE    TableName = @tablename
                   GROUP BY TableName ,
                            Index_Name
                 ),

			--TableIndexFragmentation AS(
			--SELECT OBJECT_NAME(index_stats.object_id) TableName,sys.indexes.name,index_stats.avg_fragmentation_in_percent 
			--FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID(@tablename),NULL,NULL,NULL) index_stats,sys.indexes 
			--WHERE sys.indexes.index_id = index_stats.index_id AND sys.indexes.object_id = index_stats.object_id
			--),

			SHOWCONTIG AS(SELECT * FROM @SHOWCONTIG),
       --     TableSpaceUsage
       --       AS ( SELECT TOP 1  OBJECT_NAME(id) TableName ,
       --                     8 * reserved / 1024 reserved ,
       --                     Convert(decimal(18,2),CONVERT(INT,RTRIM(8 * dpages))/1024.0) data_used_MB , --RTRIM(8 * dpages) + 'kb',
       --                     8 * ( reserved - dpages ) / 1024 unused ,
       --                     8 * dpages / 1024 - rows / 1024 * minlen / 1024 free ,
       --                     rows
       --            FROM     sysindexes
       --            WHERE    indid <= 1
       --                     AND OBJECT_NAME(id) = @tablename
				   --ORDER BY indid DESC
       --          ),
			TableSpaceUsage
              AS ( SELECT   OBJECT_NAME(SHOWCONTIG.ObjectId) TableName ,
                            Convert(decimal(18,2),SUM(8 * SHOWCONTIG.Pages)/1024.0) index_used_MB
                   FROM     SHOWCONTIG
                   WHERE    SHOWCONTIG.IndexId <= 1
                   GROUP BY OBJECT_NAME(ObjectId)
                 ),
            --TableIndexSpaceUsage
            --  AS ( SELECT   OBJECT_NAME(id) TableName ,
            --                Convert(decimal(18,2),SUM(8 * dpages)/1024.0) index_used_MB
            --       FROM     sysindexes
            --       WHERE    indid > 1
            --                AND OBJECT_NAME(id) = @tablename
            --       GROUP BY OBJECT_NAME(id)
            --     )

			  TableIndexSpaceUsage
              AS ( SELECT   OBJECT_NAME(SHOWCONTIG.ObjectId) TableName ,
                            Convert(decimal(18,2),SUM(8 * SHOWCONTIG.Pages)/1024.0) index_used_MB
                   FROM     SHOWCONTIG
                   WHERE    SHOWCONTIG.IndexId > 1
                   GROUP BY OBJECT_NAME(ObjectId)
                 )

        SELECT  DB_NAME() AS dbName ,
                obj.name AS TableName ,
                TableSpaceUsage.index_used_MB AS table_data_used_MB,
				TableIndexSpaceUsage.index_used_MB AS table_index_used_MB,
                SHOWCONTIG.rows ,
                ind.name AS IndexName ,
				ind.index_id,
                ind.is_primary_key ,
                ind.is_unique ,
                ind.type_desc ,
                TableIndexColumn.ColumnNames ,
				--TableIndexFragmentation.avg_fragmentation_in_percent,
                indUsage.user_updates ,
                ( indUsage.user_seeks + indUsage.user_scans + indUsage.user_lookups ) AS [TotalUserUsage] ,
                indUsage.user_seeks ,
                indUsage.user_scans ,
                indUsage.user_lookups ,
                STATS_DATE(ind.object_id, ind.index_id) AS stats_date ,
				DB_ID() AS database_id,ind.object_id ,
				Pages,AverageRecordSize,Convert(decimal(18,2),AveragePageDensity) AS AveragePageDensity,Convert(decimal(18,2),LogicalFragmentation) AS LogicalFragmentation,Convert(decimal(18,2),ExtentFragmentation) AS ExtentFragmentation,
				Convert(decimal(18,2),8 * Pages /1024.0) AS index_used_MB,
				--NULL AS index_depth,NULL AS index_level,NULL AS avg_fragmentation_in_percent,NULL AS fragment_count,NULL AS avg_fragment_size_in_pages,NULL AS page_count,
				NULL AS data_compression_desc,NULL AS bufferPageSize_MB,NULL AS bufferPageCount,NULL AS avg_page_row_count,
				'ALTER INDEX [' + ind.name + '] ON [' + obj.name + '] REBUILD WITH ( DATA_COMPRESSION = PAGE)' AS RebulidIndexCommand ,
                'DROP INDEX [' + ind.name + '] ON [' + obj.name + ']' AS DropIndexCommand,
				indUsage.system_seeks + indUsage.system_scans + indUsage.system_lookups AS [TotalSystemUsage] ,
                indUsage.last_system_seek ,
                indUsage.last_system_scan ,
                indUsage.last_system_lookup ,
                indUsage.last_system_update ,
                indUsage.last_user_seek ,
                indUsage.last_user_scan ,
                indUsage.last_user_lookup ,
                indUsage.last_user_update
        FROM    sys.indexes AS ind
                INNER JOIN sys.objects AS obj ON ind.object_id = obj.object_id
                LEFT JOIN sys.dm_db_index_usage_stats indUsage ON ind.object_id = indUsage.object_id
                                                              AND ind.index_id = indUsage.index_id
                                                              AND database_id = DB_ID()
                LEFT JOIN TableIndexColumn ON TableIndexColumn.TableName = obj.name AND TableIndexColumn.Index_Name = ind.name
				--LEFT JOIN TableIndexFragmentation ON TableIndexFragmentation.TableName = obj.name AND TableIndexFragmentation.name = ind.name
                LEFT JOIN TableSpaceUsage ON TableSpaceUsage.TableName = obj.name
                LEFT JOIN TableIndexSpaceUsage ON TableIndexSpaceUsage.TableName = obj.name
				LEFT JOIN SHOWCONTIG ON SHOWCONTIG.objectid = obj.OBJECT_ID AND SHOWCONTIG.indexid = indUsage.index_id AND SHOWCONTIG.Level = 0
        WHERE   obj.name = @tablename
        ORDER BY is_primary_key DESC ,TableIndexColumn.ColumnNames; 

	IF(@IsDisplayTableSchema = 1)
    SELECT  --( CASE WHEN a.colorder = 1 THEN d.name  ELSE '' END ) AS 表名 ,--如果表名相同就返回空   syscolumns(表字段信息表) a  sysobjects d 
           a.colorder AS ColumnOrder ,
            a.Name ,
            ( CASE WHEN COLUMNPROPERTY(a.id, a.name, 'IsIdentity') = 1
                   THEN '√'
                   ELSE ''
              END ) AS [IsIdentity] ,   --返回IsIdentity的值，IsIdentity只有两个值：0、1
            ( CASE WHEN ( SELECT    COUNT(*)
                          FROM      sysobjects--查询主键   
                          WHERE     ( name IN (
                                      SELECT    name
                                      FROM      sysindexes
                                      WHERE     ( id = a.id )
                                                AND ( indid IN (
                                                      SELECT  indid
                                                      FROM    sysindexkeys
                                                      WHERE   ( id = a.id )
                                                              AND ( colid IN (
                                                              SELECT
                                                              colid
                                                              FROM
                                                              syscolumns
                                                              WHERE
                                                              ( id = a.id )
                                                              AND ( name = a.name ) ) ) ) ) ) )
                                    AND ( xtype = 'PK' )
                        ) > 0 THEN '√'
                   ELSE ''
              END ) AS IsPrimaryKey ,--查询主键END   
            b.name AS FieldType ,   --systypes b 
            a.Length ,
            COLUMNPROPERTY(a.id, a.name, 'PRECISION') AS [Precision] ,
            ISNULL(COLUMNPROPERTY(a.id, a.name, 'Scale'), 0) AS Scale ,
            ( CASE WHEN a.isnullable = 1 THEN '√'
                   ELSE ''
              END ) AS AllowNull ,
            ISNULL(e.text, '') AS [Default] ,   --syscomments e 
            ISNULL(g.[value], '') AS [Description]    --sys.extended_properties g (字段信息表)
    FROM    syscolumns a
            LEFT JOIN systypes b ON a.xtype = b.xusertype
            INNER JOIN sysobjects d ON a.id = d.id
                                       AND d.xtype = 'U'
                                       AND d.name <> 'dtproperties'
            LEFT JOIN syscomments e ON a.cdefault = e.id
            LEFT JOIN sys.extended_properties g ON a.id = g.major_id
                                                   AND a.colid = g.minor_id
    WHERE   d.name = @tablename
ORDER BY    a.id ,a.colorder
go

