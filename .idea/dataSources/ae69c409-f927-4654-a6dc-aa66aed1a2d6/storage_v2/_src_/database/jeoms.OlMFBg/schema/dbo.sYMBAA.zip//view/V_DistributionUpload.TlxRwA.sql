


CREATE View V_DistributionUpload as
 SELECT Distinct d.ProductSkuId, d.StoreId, d.Brand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, d.IsAutoUploadInventory, d.ProductType
 FROM    V_Distribution d

go

