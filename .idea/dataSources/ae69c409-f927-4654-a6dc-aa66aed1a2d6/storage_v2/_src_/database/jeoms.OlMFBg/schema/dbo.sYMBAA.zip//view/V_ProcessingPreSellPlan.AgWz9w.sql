





CREATE View [dbo].[V_ProcessingPreSellPlan] as 
Select psp.Id, psp.Code, PSPS.StoreId, PlatformSkuId, PSP.EndDate, PSPD.SkuCode
From PreSellPlan psp(nolock)
Left JOin PreSellPlanDetail PSPD(nolock) on psp.Id = PSPD.PreSellPlanId 
Left Join PreSellPlanStore PSPS(nolock) on PSP.Id = PSPS.PreSellPlanId
Where PSP.Status in(1,2)
And PlatformSkuId is not null
and psp.EndDate > GETDATE()

go

