-- =============================================
-- Author:		qiaoni
-- Create date: 2020-04-27
-- Description:	History Order Clear
-- =============================================
CREATE PROCEDURE P_BU_Del_HistoryOrder
	@P_CreateDate DateTime = '2019-01-01'
AS
BEGIN
	
	Print Convert(varchar(20), @P_CreateDate, 20);
		
	Declare @V_Date_1 DateTime,@V_Date_5 DateTime,@V_Date_10 DateTime,@V_Date_15 DateTime, @V_Date_30 DateTime, @V_Date_60 DateTime, @V_Date_90 DateTime, @V_Date_120 DateTime, @V_Date_150 DateTime, @V_Date_180 DateTime,@V_Date_720 DateTime;
	Declare @V_rowcnt decimal(15, 0), @V_TotalRow decimal(15, 0)
	Set @V_Date_1 = DATEADD(Day, -1, GetDate()) Print Convert(Varchar(10), @V_Date_1, 20)
	Set @V_Date_5 = DATEADD(Day, -5, GetDate()) Print Convert(Varchar(10), @V_Date_5, 20)
	Set @V_Date_10 = DATEADD(Day, -10, GetDate()) Print Convert(Varchar(10), @V_Date_10, 20)
	Set @V_Date_15 = DATEADD(Day, -15, GetDate()) Print Convert(Varchar(10), @V_Date_15, 20)
	Set @V_Date_30 = DATEADD(Day, -30, GetDate()) Print Convert(Varchar(10), @V_Date_30, 20)
	Set @V_Date_60 = DATEADD(Day, -60, GetDate()) Print Convert(Varchar(10), @V_Date_60, 20)
	Set @V_Date_90 = DATEADD(Day, -90, GetDate()) Print Convert(Varchar(10), @V_Date_90, 20)
	Set @V_Date_120 = DATEADD(Day, -120, GetDate()) Print Convert(Varchar(10), @V_Date_120, 20)
	Set @V_Date_150 = DATEADD(Day, -150, GetDate()) Print Convert(Varchar(10), @V_Date_150, 20)
	Set @V_Date_180 = DATEADD(Day, -180, GetDate()) Print Convert(Varchar(10), @V_Date_180, 20)
	Set @V_Date_720 = DATEADD(YEAR, -2, GetDate()) Print Convert(Varchar(10), @V_Date_720, 20)  


    Print 'Clear OMS ---- ' + Convert(varchar(20), getdate(), 20) + '  VirtualWarehouseTransfer 10 '
    Set @V_rowcnt = 0 
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.VirtualWarehouseTransfer WHERE CreateDate < @P_CreateDate
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.VirtualWarehouseTransfer WHERE CreateDate < @P_CreateDate
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + ' VirtualWarehouseTransfer ' + Convert(varchar(20), getdate(), 20)
      END

	   Print 'Clear OMS ---- ' + Convert(varchar(20), getdate(), 20) + '  VirtualWarehouseTransferDetail 10 '
    Set @V_rowcnt = 0 
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.VirtualWarehouseTransferDetail WHERE CreateDate < @P_CreateDate
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.VirtualWarehouseTransferDetail WHERE CreateDate < @P_CreateDate
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + ' VirtualWarehouseTransferDetail ' + Convert(varchar(20), getdate(), 20)
      END

	   Print 'Clear OMS ---- ' + Convert(varchar(20), getdate(), 20) + '  VirtualWarehouseTransferLog 10 '
    Set @V_rowcnt = 0 
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.VirtualWarehouseTransferLog WHERE CreateDate < @P_CreateDate
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.VirtualWarehouseTransferLog WHERE CreateDate < @P_CreateDate
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + ' VirtualWarehouseTransferLog ' + Convert(varchar(20), getdate(), 20)
      END

 Print 'Clear OMS ---- ' + Convert(varchar(20), getdate(), 20) + '  SystemLog 10 '
    Set @V_rowcnt = 0 
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.SystemLog WHERE CreateDate < @P_CreateDate
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.SystemLog WHERE CreateDate < @P_CreateDate
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + ' SystemLog ' + Convert(varchar(20), getdate(), 20)
      END

	 Print 'Clear OMS ---- ' + Convert(varchar(20), getdate(), 20) + '  ApiDeliveryCompleted 10 '
    Set @V_rowcnt = 0 
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiDeliveryCompleted WHERE CreateDate < @P_CreateDate
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.ApiDeliveryCompleted WHERE CreateDate < @P_CreateDate
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + ' ApiDeliveryCompleted ' + Convert(varchar(20), getdate(), 20)
      END

		 Print 'Clear OMS ---- ' + Convert(varchar(20), getdate(), 20) + '  ApiDeliveryCompletedDetail 10 '
    Set @V_rowcnt = 0 
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiDeliveryCompletedDetail WHERE CreateDate < @P_CreateDate
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.ApiDeliveryCompletedDetail WHERE CreateDate < @P_CreateDate
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + ' ApiDeliveryCompletedDetail ' + Convert(varchar(20), getdate(), 20)
      END

	 Print 'Clear OMS ---- ' + Convert(varchar(20), getdate(), 20) + '  ApiShippingAddressUpdateRecord 10 '
    Set @V_rowcnt = 0 
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiShippingAddressUpdateRecord WHERE CreateDate < @P_CreateDate
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.ApiShippingAddressUpdateRecord WHERE CreateDate < @P_CreateDate
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + ' ApiShippingAddressUpdateRecord ' + Convert(varchar(20), getdate(), 20)
      END

	Print 'Clear OMS ---- ' + Convert(varchar(20), getdate(), 20) + '  ApiProductInventoryTracking 10 '
    Set @V_rowcnt = 0 
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiProductInventoryTracking WHERE OperatorDate < @P_CreateDate 
    WHILE 1 = 1
      BEGIN
        DELETE TOP(1000) FROM jeoms.dbo.ApiProductInventoryTracking WHERE OperatorDate < @P_CreateDate
        if @@rowcount < 1000
          Begin
            print '-- Break'
            Break;
          End  
        Set @V_rowcnt +=  1000;
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + ' ApiProductInventoryTracking ' + Convert(varchar(20), getdate(), 20)
      END
	     

END
go

