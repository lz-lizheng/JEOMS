-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[DI_TRIGGER_ApplyRefundOrder_U]
   ON  [dbo].[ApplyRefundOrder] 
   after  update
AS 
	declare @Id nvarchar(50)
	select @Id=code from inserted
	insert into jeoms.dbo.DI_ApplyRefundOrder_TRIG_LOG(ID,FLAG,INSERT_TIME) select id,'U', GETDATE() from ApplyRefundOrder where code = @Id
go

