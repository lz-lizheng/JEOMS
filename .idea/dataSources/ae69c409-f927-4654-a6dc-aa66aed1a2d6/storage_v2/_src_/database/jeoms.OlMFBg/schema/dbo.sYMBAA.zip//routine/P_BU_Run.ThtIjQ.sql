
CREATE PROC [dbo].[P_BU_Run]
as
Begin 
		--开始时间 
		DECLARE @BeginDate DATETIME = '2018-01-01'
		--此处需要改为归档截止时间
		DECLARE @EndDate DATETIME = '2019-01-01 00:00:00'

		--此处时间为订单过滤时间，需要改为归档截止时间
		update StoreSetting set FilterDate=@EndDate


		Exec [dbo].[P_BU_Sync_History_Table];

		Declare @V_Int int
		Set @V_Int = 1
		WHILE  (@V_Int <= 400)--循环次数
		BEGIN 
		   PRINT '***************************************************************************************'
	 
			SET @BeginDate = DATEADD(hour, 24, @BeginDate)
          
			PRINT CONVERT(VARCHAR, @BeginDate, 20)
		   IF @BeginDate < @EndDate
			   BEGIN  
				   EXEC [dbo].[P_BU_Auto_History_Order] @BeginDate;
			   END
   
		   PRINT @V_Int
		   Set @V_Int = @V_Int + 1
		   waitfor delay '00:00:0.100' -- 休息10秒钟再处理 
		END

End;
go

