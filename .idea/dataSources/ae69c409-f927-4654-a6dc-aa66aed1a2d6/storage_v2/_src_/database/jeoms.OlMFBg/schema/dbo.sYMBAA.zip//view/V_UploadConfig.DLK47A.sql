CREATE VIEW [dbo].[V_UploadConfig] AS 
SELECT
	iuc.StoreId,
	iuc.BrandName StoreBrand,
	iuw.WarehouseId,
	iuw.Scale,
	iuc.IsUpload,
	IsManualUpload
FROM
	InventoryUploadConfig iuc
JOIN InventoryUploadWarehouse iuw ON iuc.StoreId = iuw.StoreId
AND iuw.WarehouseType IN (1, 2, 3)
UNION ALL
	SELECT
		iuc.StoreId,
		iuc.BrandName StoreBrand,
		w.id WarehouseId,
		iuw.Scale,
		iuc.IsUpload,
		IsManualUpload
	FROM
		InventoryUploadConfig iuc
	JOIN InventoryUploadWarehouse iuw ON iuc.StoreId = iuw.StoreId
	AND iuw.WarehouseType = 4
	JOIN Warehouse w ON iuw.warehouseId = w.parentId


go

