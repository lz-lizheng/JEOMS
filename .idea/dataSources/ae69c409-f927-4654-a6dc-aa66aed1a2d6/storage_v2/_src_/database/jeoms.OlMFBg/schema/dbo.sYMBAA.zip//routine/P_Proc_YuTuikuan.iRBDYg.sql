-- =============================================
-- Author: QiaoNi
-- Create date: 20201113
-- Description: Temp For No Clear Header ActType
-- =============================================
CREATE PROCEDURE P_Proc_YuTuikuan
AS
BEGIN
	
	Print 'YuTui Start '

	Select OrderId, code into #mpt01
	From SalesOrder a
	where 1 = 1  
	and not exists (Select 1 From SalesOrderDetail b where a.OrderId = b.SalesOrderId and b.ActionType = 1 )
	and a.ActionType = 1

 

	update SalesOrder set ActionType = 0 where orderid in (Select orderid from #mpt01)

	Print 'YuTuiEnd'

	drop table #mpt01;

	END
go

