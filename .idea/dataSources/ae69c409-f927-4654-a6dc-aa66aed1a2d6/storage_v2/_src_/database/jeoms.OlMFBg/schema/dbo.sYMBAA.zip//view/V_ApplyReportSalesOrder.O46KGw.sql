




CREATE view [dbo].[V_ApplyReportSalesOrder]
as
select ab.OrderType,ar.TradeId,sum(ar.RefundFee) RefundFee,ab.AmountActual AmountActual,ar.BuyerNick CustomerCode,ar.BuyerNick CustomerName,ar.StoreId,ar.StoreName,MIN(ar.LastDate) AuditDate
from ApplyRefundOrder(nolock) ar
left join 
(
select  '未发货订单' OrderType,case when so.IsObsolete=1 then sum(sl.AmountActual)+so.ExpressFee else sum(sl.AmountActual)end AmountActual,so.OrderId from SalesOrderDetail sl 
inner join salesorder(nolock) so on so.OrderId=sl.SalesOrderId
inner join ApplyRefundOrder(nolock) aro on aro.SalesOrderDetailId=sl.DetailId and aro.RefundType=1 and aro.Status=6
 and isnull(aro.IsObsoleted,0)=0
 where sl.IsDeleted=1 and aro.AuditStatus=1  group by OrderId,so.IsObsolete,so.ExpressFee 
) ab on ab.OrderId=ar.SalesOrderId
where  ar.Status=6 group by ar.TradeId,ab.OrderType,ar.BuyerNick,ar.StoreId,ar.StoreName,ab.AmountActual


go

