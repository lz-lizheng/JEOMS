
CREATE FUNCTION [dbo].[F_Get_RegionDispatchWarehouse]
( 
	@P_DispatchTemplateId		UNIQUEIDENTIFIER,
	@P_ProvinceName				NVARCHAR(50),
	@P_CityName					NVARCHAR(50),
	@P_CountyName				NVARCHAR(50)
)
RETURNS @V_Warehouse TABLE(WarehouseTemplateId UNIQUEIDENTIFIER, TemplateId UNIQUEIDENTIFIER, OrderId bigint, WarehouseID VARCHAR(36), 
						   WarehouseCode NVARCHAR(20), WarehouseName NVARCHAR(50), ParentId UNIQUEIDENTIFIER, ParentCode NVARCHAR(50), ParentName NVARCHAR(50),
						   WarehouseDispatchType INT, DefalutCodExpressId UNIQUEIDENTIFIER, DefaultNoCodExpressId UNIQUEIDENTIFIER
						   )
AS
BEGIN 
	Declare @P_OnePoint bigint, @P_TwoPoint bigint; -- 指数用来区分实体跟门店组, 门店组需要在门店的情况下区分区域层级，门店指数并以此来决定门店配货优先级
	Set @P_OnePoint = 10000;  -- 一级排序扩展
	Set @P_TwoPoint = 1000;   -- 二级排序扩展  
	 
	INSERT INTO @V_Warehouse(WarehouseTemplateId, TemplateId, OrderId, WarehouseID, WarehouseCode, WarehouseName, ParentId, ParentCode, ParentName,
							 WarehouseDispatchType, DefalutCodExpressID, DefaultNoCodExpressId)  
	SELECT DTW.TemplateWarehouseId, DTW.TemplateId, DTW.OrderId, DTW.WarehouseId, Code, WarehouseName, DTW.ParentId, DTW.ParentCode, DTW.ParentName,
		DTW.WarehouseDispatchType, DTW.DefaultCodExpressId, DTW.DefaultNoCodeExpressId
	From ( 
		 SELECT DTW.TemplateWarehouseId, DTW.TemplateId, 
				DTW.OrderId * @P_OnePoint + 
				Case When WHP.StorageType = 0 
					Then Case dbo.F_Get_CheckWarehouseIsArange(WHP.Id, @P_ProvinceName, @P_CityName, @P_CountyName) When 'Y' Then 0 Else 1 End
					Else
						Case When WHP.ProvinceName = @P_ProvinceName And WHP.CityName = @P_CityName And WHP.CountyName = @P_CountyName Then 1 * @P_TwoPoint
							 When WHP.ProvinceName = @P_ProvinceName And WHP.CityName = @P_CityName Then 2 * @P_TwoPoint
							 When WHP.ProvinceName = @P_ProvinceName Then 3 * @P_TwoPoint
							 Else 4 * @P_TwoPoint +  dbo.F_GetAddressDistance(WHP.ProvinceName, WHP.CityName, WHP.CountyName, @P_ProvinceName, @P_CityName, @P_CountyName)
						End
					End as OrderId,
				DTW.WarehouseId, wh.Code, wh.Name AS WarehouseName, wh.ParentId,
				WHP.Code AS ParentCode, WHP.Name AS ParentName, DTW.WarehouseDispatchType, DT.DefaultCodExpressId AS DefaultCodExpressId,
				DT.DefaultExpressId AS DefaultNoCodeExpressId,
				WHP.ProvinceName, WHP.CityName, WHP.CountyName 
		FROM dbo.DispatchTemplate DT
		INNER JOIN dbo.DispatchTemplateWarehouse DTW ON DT.Id = DTW.TemplateId
		INNER JOIN dbo.Warehouse WH ON DTW.WarehouseId = WH.Id
		INNER JOIN dbo.Warehouse WHP ON WH.ParentId = WHP.Id
		WHERE DTW.IsDisabled = 0
		AND DT.IsDisabled = 0
		AND WHP.WarehouseType = 1
		and wh.IsDisabled = 0 
		and whp.IsDisabled = 0
		AND DT.Id = @P_DispatchTemplateId
		And (WHP.StorageType > 0 or WHP.IsRegion = 0 Or EXISTS (SELECT 1 FROM dbo.WarehouseRegion WR WHERE WR.ProvinceName = @P_ProvinceName AND WR.CityName = @P_CityName 
			 AND WR.CountyName = @P_CountyName AND WH.ParentId = WR.WarehouseId))
		) DTW
		Order By OrderId 
	RETURN;
END;



go

