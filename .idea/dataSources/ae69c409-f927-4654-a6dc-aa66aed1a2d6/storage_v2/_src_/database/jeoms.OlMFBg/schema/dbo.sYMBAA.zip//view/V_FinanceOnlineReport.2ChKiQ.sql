CREATE VIEW V_FinanceOnlineReport
AS
SELECT ISNULL(A.SalesAmount,0)+ISNULL(A.ReturnAmount,0)+ISNULL(A.RefundAmount,0) SystemAmount,ISNULL(a.TradeId,APP.OrderNo) TradeId,ISNULL(OutAmount,0) OutAmount,ISNULL(APP.StoreId,A.StoreId) StoreId,A.PayDate FROM
(
	SELECT SUM(OutAmount) OutAmount,OrderNo,StoreId FROM dbo.AlipayRecord(NOLOCK) WHERE OutAmount>0 GROUP BY OrderNo,StoreId
) APP
FULL OUTER JOIN 
(
	SELECT ISNULL(ISNULL(A.TradeId,B.TradeId),C.TradeId) TradeId,SalesAmount,ReturnAmount,RefundAmount,ISNULL(ISNULL(A.StoreId,B.StoreId),C.StoreId) StoreId,A.PayDate FROM 
	(
		SELECT (
		CASE WHEN so.IsObsolete=1 then so.PayAmount ELSE SUM(sl.AmountActual) END) SalesAmount,so.OrderId,so.TradeId,so.StoreId,so.PayDate
		FROM dbo.SalesOrder(nolock) so 
		JOIN dbo.SalesOrderDetail(nolock) sl ON so.OrderId=sl.SalesOrderId 
		WHERE sl.IsDeleted=1 GROUP BY so.OrderId,so.PayAmount,so.IsObsolete,so.TradeId,StoreId,so.PayDate
	) A
	FULL OUTER JOIN 
	(
		SELECT SUM(AmountActual) ReturnAmount,SalesOrderId,TradeId,StoreId FROM dbo.ReturnOrder(nolock) WHERE Status>0 AND ISNULL(IsReplace,0)=0  AND ISNULL(SalesOrderId,0)>0 AND TradeId IS NOT NULL AND ISNULL(RefundWay,0)=0 GROUP BY SalesOrderId,TradeId,StoreId
	) B ON A.OrderId=B.SalesOrderId
	FULL OUTER JOIN 
	(
		SELECT SUM(ActualAmount) RefundAmount,SalesOrderId,TradeId,StoreId FROM dbo.RefundOrder(nolock) WHERE Status=3 AND ISNULL(RefundWay,0)=0 AND ISNULL(SalesOrderId,0)>0 AND TradeId IS NOT NULL GROUP BY SalesOrderId,TradeId,StoreId
	) C ON A.OrderId=C.SalesOrderId
) A ON APP.OrderNo=A.TradeId
go

