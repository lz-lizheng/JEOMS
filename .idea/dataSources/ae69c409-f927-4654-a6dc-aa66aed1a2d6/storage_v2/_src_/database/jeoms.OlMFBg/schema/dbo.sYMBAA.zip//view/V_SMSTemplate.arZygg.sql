

CREATE VIEW [dbo].[V_SMSTemplate]
--WITH ENCRYPTION, SCHEMABINDING, VIEW_METADATA
AS
    SELECT st.*,sa.Name AccountName FROM SmsTemplate st JOIN SmsAccount sa ON st.AccountId=sa.Id
-- WITH CHECK OPTION


go

