



/**
	预售链接不上传库存
*/
CREATE PROCEDURE [dbo].[P_QueryNeedUploadTrigger] (@top INT)
AS
      BEGIN	
            SELECT  d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, 
					dbo.F_CalcSkuUploadQuantity(d.ProductSkuId, uc.StoreId, d.PresellPlanId, 
												Sum(case when iv.IsLock = 1 then 0 
														 When st.PlatformType != 20 and [dbo].f_checkProductInWhiteList(iv.WarehouseId, d.ProductCode) = 'N' and uc.StoreId<>'52F94A7B-D6A2-4EE2-A791-71EE01E96E3F' and uc.StoreId<>'8DCBA7CE-FC07-4B0E-8CE9-7B1E638B6724' and uc.StoreId<>'70ECBEAC-02C1-4EB5-8222-01AF531B8F1F' and uc.StoreId<>'14CE9E67-DA01-4859-B4A7-853AE21A21AE' and uc.StoreId<>'FD58D203-37A4-40C9-83B1-73FC5B39FB80' and uc.StoreId<>'00FA5DBB-7D97-45A1-A16E-17FD56039F49' Then 0
														 else dbo.F_CalcSkuWarehouseUploadQuantity(iv.Quantity, ios.LockedQuantity, uc.Scale) end)) Quantity
            FROM    V_DistributionUpload d
            JOIN    V_UploadConfig uc ON d.StoreId=uc.StoreId
            LEFT JOIN dbo.InventoryVirtual iv(nolock) ON d.ProductSkuId=iv.SkuId AND uc.WarehouseId=iv.WarehouseId
            LEFT JOIN dbo.V_InventoryOccupationSum ios(nolock) ON uc.WarehouseId=ios.WarehouseId AND d.ProductSkuId=ios.SkuId
			LEFT JOin dbo.Store st(nolock) on uc.StoreId = st.Id
            WHERE   d.ProductSkuId IN (SELECT DISTINCT SkuId FROM     InventoryTrigger(nolock)  WHERE    [Status]=1) 
			AND d.IsAutoUploadInventory=1 AND uc.IsUpload=1 
			And Not Exists (Select * From V_ProcessingPreSellPlan ppsp(nolock) Where ppsp.StoreId = d.StoreId and ppsp.PlatformSkuId = d.PlatformId  And ppsp.SkuCode = d.ProductSkuCode)
            GROUP BY d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, uc.StoreId, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformOutCode, d.PlatformSkuCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId
             
			 --Select * From store where name = '广卡卡宾官方旗舰店'

			--UNION ALL

   --         SELECT  d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, 
			--		dbo.F_CalcSkuUploadQuantity(sku.SkuId, uc.StoreId, d.PresellPlanId, 
			--									Sum(case when iv.IsLock = 1 then 0 else dbo.F_CalcSkuWarehouseUploadQuantity(iv.Quantity, ios.LockedQuantity, uc.Scale) end))/sku.Quantity Quantity
   --         FROM    V_DistributionUpload d
   --         JOIN    V_UploadConfig uc ON d.StoreId=uc.StoreId
   --         JOIN    CombinedProductDetail sku ON d.ProductSkuId=sku.CombinedProductId
   --         LEFT JOIN dbo.InventoryVirtual iv ON sku.SkuId=iv.SkuId AND uc.WarehouseId=iv.WarehouseId
   --         LEFT JOIN dbo.V_InventoryOccupationSum ios ON uc.WarehouseId=ios.WarehouseId AND sku.SkuId=ios.SkuId
   --         WHERE   sku.SkuId IN (SELECT DISTINCT SkuId FROM      InventoryTrigger WHERE     [Status]=1) 
			--AND d.IsAutoUploadInventory=1 AND d.ProductType=1 AND sku.IsMainSku=1 AND uc.IsUpload=1
			--And Not Exists (Select * From V_ProcessingPreSellPlan ppsp Where ppsp.StoreId = d.StoreId and ppsp.PlatformSkuId = d.PlatformId  And ppsp.SkuCode = d.ProductSkuCode)
   --         GROUP BY d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, uc.StoreId, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformOutCode, d.PlatformSkuCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, sku.SkuId, sku.Quantity;
      END;



go

