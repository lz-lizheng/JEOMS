create view V_InventoryVirtualSync
as
select ivs.*,qiv.Quantity as OriginalQuantity from InventoryVirtualSync ivs
left join
(
select w.ParentId as WarehouseId,iv.SkuId,sum(iv.Quantity)Quantity from InventoryVirtual iv
join Warehouse w on iv.WarehouseId = w.Id
group by w.ParentId,iv.SkuId
)qiv on qiv.SkuId =ivs.SkuId and ivs.WarehouseId = qiv.WarehouseId
go

