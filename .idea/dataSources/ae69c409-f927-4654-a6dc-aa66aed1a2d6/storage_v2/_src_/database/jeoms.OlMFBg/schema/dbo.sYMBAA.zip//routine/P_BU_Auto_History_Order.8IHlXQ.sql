
--[dbo].[P_BU_Auto_History_Order] '2017-01-01'

CREATE PROC [dbo].[P_BU_Auto_History_Order] 
(
	@P_DayBefore DateTime = '2017-08-01'
)
AS
	-- 更新数据表结构
	--Exec [dbo].[P_BU_Sync_History_Table];

	PRINT '---------------**归档截止时间 : ' + Convert(Varchar, @P_DayBefore, 20)	
	
	DECLARE @V_RecordCount int=0
	DECLARE @V_SQL NVARCHAR(max); 
 	Print '--**订单归档开始 Start At: ' + Convert(Varchar, GetDate(), 20)	
 	  
	-- 已发货完成订单
	SELECT OrderId As SoOrderId into #TmpOrderId from SalesOrder(nolock) where CreateDate <= @P_DayBefore AND DeliveryTypeStatus = 2;
	 
	  
	-- 已作废订单
	INSERT into #TmpOrderId Select OrderId From SalesOrder where IsObsolete = 1 and CreateDate <= @P_DayBefore;
		 
	SELECT @V_RecordCount = COUNT(1) from #TmpOrderId
	Print '--**归档订单总量 :' + Cast(@V_RecordCount as varchar)

	If @V_RecordCount > 0
		Begin
			Begin Try 
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------				
				Print '>1. 订单日志(SalesOrderLog) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderLog Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderLog') + ' From SalesOrderLog Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL ; 
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 1.1 删除已经备份的数据开始时间 : ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderLog Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
			 
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>2. 订单缺货(SalesOrderOutofStock) Start At: ' + Convert(Varchar, GetDate(), 20)  
 				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderOutofStock Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderOutofStock') + ' From SalesOrderOutofStock Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL; 
				EXECUTE SP_EXECUTESQL @V_SQL; 
				Print ' 2.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderOutofStock Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);

				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>3. 订单发票(SalesOrderInvoice) Start At: ' + Convert(Varchar, GetDate(), 20) 
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderInvoice Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderInvoice') + ' From SalesOrderInvoice Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 3.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderInvoice Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
				 
				Print '>4. 订单优惠(SalesOrderDiscount) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderDiscount Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderDiscount') + ' From SalesOrderDiscount Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 4.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderDiscount Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
				  
				Print '>5. 订单支付(SalesOrderPayment) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderPayMent Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderPayMent') + ' From SalesOrderPayMent Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;   
				Print ' 5.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderPayMent Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
				 
				Print '>6. 订单活动信息(SalesOrderActivity) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderActivity Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderActivity') + ' From SalesOrderActivity Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 6.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderActivity Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
				 
				Print '>7. 订单发货信息(SalesOrderDeliveryInfo) Start At: ' + Convert(Varchar, GetDate(), 20) 
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderDeliveryInfo Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderDeliveryInfo') + ' From SalesOrderDeliveryInfo Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 7.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderDeliveryInfo Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
				 
				Print '>8. 订单平台商品信息(SalesOrderDetailPlatformProduct) Start At: ' + Convert(Varchar, GetDate(), 20) 
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderDetailPlatformProduct Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderDetailPlatformProduct') + ' From SalesOrderDetailPlatformProduct SODP Where Exists (Select 1 From SalesOrderDetail sod(nolock) Inner Join #TmpOrderId oi on sod.SalesOrderId = oi.SoOrderId Where SODP.Id = sod.DetailId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 8.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderDetailPlatformProduct Where Exists (Select 1 From SalesOrderDetail sod(nolock) Inner Join #TmpOrderId oi on sod.SalesOrderId = oi.SoOrderId Where SalesOrderDetailPlatformProduct.Id = sod.DetailId);
				  
				Print '>9. 订单商品信息（SalesOrderDetail) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderDetail Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderDetail') + ' From SalesOrderDetail Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 9.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderDetail Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);

				Print '>10. 订单子信息(SalesOrderSub) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderSub Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderSub') + ' From SalesOrderSub Where Exists (Select 1 From #TmpOrderId Where SubId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 10.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderSub Where Exists (Select 1 From #TmpOrderId Where SubId = SoOrderId);
					 
				Print '>11. 订单表(SalesOrder) Start At: ' + Convert(Varchar, GetDate(), 20) 
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrder Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrder') + ' FROM SalesOrder WHERE EXISTS (SELECT 1 FROM #TmpOrderId WHERE SoOrderId = OrderID);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL; 
				PRINT ' 11.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrder Where Exists (Select 1 From #TmpOrderId A Where SoOrderId = OrderID);

				Drop Table #TmpOrderId; 
				Print '--**订单归档完成 Commit At: ' + Convert(Varchar, GetDate(), 20)
			End Try
			Begin Catch			 			
				Print '--**订单归档出错 Rollback At: ' + Convert(Varchar, GetDate(), 20)												
				Print '--**Error Msg : ' +  error_message()
			End Catch
		End



	--========================================================================================================================--
	Print '=============================================================================================='
	Print '=============================================================================================='
	Print ''
	Print '--**配货通知单归档开始 Start At: ' + Convert(Varchar, GetDate(), 20)	
	Select Distinct dpod.DispatchOrderId As DpoId, dpod.Id DpoDetailid  Into #TmpDpoId FROM dbo.DispatchOrderDetail dpod(nolock) INNER Join [jehistory].dbo.SalesOrderDetail sod(nolock) on dpod.SalesOrderDetailId = sod.DetailId;
	 
	SELECT @V_RecordCount = COUNT(1) from #TmpDpoId
	Print '--**配货单明细量:' + Cast(@V_RecordCount as varchar)

	If @V_RecordCount > 0
		Begin
			Begin Try   
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>1. 配货快递信息(DispatchOrderDetailExpress) Start At: ' + Convert(Varchar, GetDate(), 20) 
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.DispatchOrderDetailExpress Select ' + dbo.F_BU_Generate_Auto_History_Sql('DispatchOrderDetailExpress') + ' From DispatchOrderDetailExpress dpod Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where dpod.detailid = DpoDetailid);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 1.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete DispatchOrderDetailExpress Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where DispatchOrderDetailExpress.DetailId = DpoDetailid);
				 
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>2. 配货商品信息(DispatchOrderDetail) Start At: ' + CONVERT(VARCHAR, GETDATE(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.DispatchOrderDetail Select ' + dbo.F_BU_Generate_Auto_History_Sql('DispatchOrderDetail') + ' From DispatchOrderDetail dpo Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where dpo.Id = DpoDetailid);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				PRINT ' 2.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From DispatchOrderDetail Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where DispatchOrderDetail.Id = DpoDetailid);


				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>3. 配货主信息(DispatchOrder) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.DispatchOrder Select ' + dbo.F_BU_Generate_Auto_History_Sql('DispatchOrder') + ' From DispatchOrder dpo Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where dpo.Id = DpoId) And Not Exists(Select 1 From [jehistory].dbo.DispatchOrder Hisdpo Where Dpo.Id = HisDpo.Id);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 3.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From DispatchOrder Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where DispatchOrder.Id = DpoId) AND NOT EXISTS (SELECT 1 FROM dbo.DispatchOrderDetail dod(NOLOCK) WHERE dbo.DispatchOrder.Id = dod.DispatchOrderId);
				 
				Drop Table #TmpDpoId 
				Print '--**配货通知单归档完成 Commit At: ' + Convert(Varchar, GetDate(), 20)
			End Try
			Begin Catch 
				Print '--**配货通知单归档出错 Rollback At: ' + Convert(Varchar, GetDate(), 20)				
				Print '--**Error Msg : ' +  error_message()				
			End Catch
		End


--========================================================================================================================--
	Print '=============================================================================================='
	Print '===	ReturnSign				======'
	Print '===	ReturnOrderOutDetail	======' 
	Print '===	ReturnOrderLog			======'
	Print '===	ReturnOrderDetail		======'
	Print '===	ReturnOrder				======'
	--
	Print '==============================================================================================' 
	Print '--**退换货单归档开始 Start At: ' + Convert(Varchar, GetDate(), 20)	
	Select RO.id as HdrId	Into #ROOrd 	From ReturnOrder RO where   RO.CreateDate < @P_DayBefore;
	
	SELECT @V_RecordCount = COUNT(1) from #ROOrd
	Print '--**退换货单明细量:' + Cast(@V_RecordCount as varchar)

	If @V_RecordCount > 0
		Begin
			Begin Try   
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				  
				Print '>4. 退换货单Log信息(ReturnOrderLog) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.ReturnOrderLog Select ' + dbo.F_BU_Generate_Auto_History_Sql('ReturnOrderLog') + ' From ReturnOrderLog ROL Where Exists (Select 1 From #ROOrd RO(nolock) Where ROL.ReturnOrderId = RO.HdrId);'
				PRINT @V_SQL; 
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 4.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From ReturnOrderLog Where Exists (Select 1 From #ROOrd RO(nolock) Where ReturnOrderLog.ReturnOrderId = RO.HdrId );
				 
				--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>4. 退换货单 信息(ReturnOrderOutDetail) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.ReturnOrderOutDetail Select ' + dbo.F_BU_Generate_Auto_History_Sql('ReturnOrderOutDetail') + ' From ReturnOrderOutDetail ROOD Where Exists (Select 1 From #ROOrd RO(nolock) Where ROOD.ReturnOrderId = RO.HdrId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 4.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From ReturnOrderOutDetail Where Exists (Select 1 From #ROOrd RO(nolock) Where ReturnOrderOutDetail.ReturnOrderId = RO.HdrId); 

				--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>4. 退换货单 信息(ReturnOrderDetail) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.ReturnOrderDetail Select ' + dbo.F_BU_Generate_Auto_History_Sql('ReturnOrderDetail') + ' From ReturnOrderDetail ROD Where Exists (Select 1 From #ROOrd RO(nolock) Where ROD.ReturnOrderId = RO.HdrId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 4.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From ReturnOrderDetail Where Exists (Select 1 From #ROOrd RO(nolock) Where ReturnOrderDetail.ReturnOrderId = RO.HdrId);


				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>4. 退换货单 信息(ReturnOrder) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.ReturnOrder Select ' + dbo.F_BU_Generate_Auto_History_Sql('ReturnOrder') + ' From ReturnOrder RO Where Exists (Select 1 From #ROOrd ROT(nolock) Where RO.Id = ROT.HdrId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 4.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From ReturnOrder Where Exists (Select 1 From #ROOrd ROT(nolock) Where ReturnOrder.Id = ROT.HdrId);


				Print '--**退换货单归档完成 Commit At: ' + Convert(Varchar, GetDate(), 20)

			End Try
			Begin Catch 
				Print '--**退换货单归档出错 Rollback At: ' + Convert(Varchar, GetDate(), 20)				
				Print '--**Error Msg : ' +  error_message()				
			End Catch
		End
	 
	

	Print '=============================================================================================='
	Print '===	ReturnOrderNoticeDetail	======' 
	Print '===	ReturnOrderNotice		======'  
	Print '==============================================================================================' 
	Print '--**退换货通知单归档开始 Start At: ' + Convert(Varchar, GetDate(), 20)	
	Select RO.id as HdrId	Into #RNOrd 	From ReturnOrderNotice RO where   RO.CreateDate < @P_DayBefore;
	SELECT @V_RecordCount = COUNT(1) from #RNOrd
	Print '--**退换货通知单明细量:' + Cast(@V_RecordCount as varchar)


	If @V_RecordCount > 0
		Begin
			Begin Try   
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				 
				Print '>4. 退换货通知单信息(ReturnOrderNoticeDetail) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.ReturnOrderNoticeDetail Select ' + dbo.F_BU_Generate_Auto_History_Sql('ReturnOrderNoticeDetail') + ' From ReturnOrderNoticeDetail ROND Where Exists (Select 1 From #RNOrd RNO(nolock) Where ROND.NoticeId = RNO.HdrId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 4.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From ReturnOrderNoticeDetail Where Exists (Select 1 From #RNOrd RNO(nolock) Where ReturnOrderNoticeDetail.NoticeId = RNO.HdrId );

				--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>4. 退换货通知单 信息(ReturnOrderNotice) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.ReturnOrderNotice Select ' + dbo.F_BU_Generate_Auto_History_Sql('ReturnOrderNotice') + ' From ReturnOrderNotice RON Where Exists (Select 1 From #RNOrd RNOT(nolock) Where RON.Id = RNOT.HdrId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 4.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From ReturnOrderNotice Where Exists (Select 1 From #RNOrd RNO(nolock) Where ReturnOrderNotice.Id = RNO.HdrId);


				Print '--**退换货通知单归档完成 Commit At: ' + Convert(Varchar, GetDate(), 20)

			End Try
			Begin Catch 
				Print '--**退换货通知单归档出错 Rollback At: ' + Convert(Varchar, GetDate(), 20)				
				Print '--**Error Msg : ' +  error_message()				
			End Catch
		End











	--========================================================================================================================--
	Print '=============================================================================================='
	Print '================================= ApplyRefundOrderLog		ApplyRefundOrder ================'
	Print '=============================================================================================='
	Print ''
	Print '--**退款申请归档开始 Start At: ' + Convert(Varchar, GetDate(), 20)	
	Select Distinct Aro.Id As aroId Into #AroTbl FROM jeoms.dbo.ApplyRefundOrder aro(nolock) Where CreateDate < @P_DayBefore; 
	SELECT @V_RecordCount = COUNT(1) from #AroTbl
	Print '--**退款申请明细量:' + Cast(@V_RecordCount as varchar)

	If @V_RecordCount > 0
		Begin
			Begin Try   
				
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>4. 退款申请 Mapping信息(ApplyRefundOrderLog) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.ApplyRefundOrderLog Select ' + dbo.F_BU_Generate_Auto_History_Sql('ApplyRefundOrderLog') + ' From ApplyRefundOrderLog AROL Where Exists (Select 1 From #AroTbl arot(nolock) Where AROL.OrderId = arot.aroId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 4.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From ApplyRefundOrderLog Where Exists (Select 1 From #AroTbl arot(nolock) Where arot.aroId = ApplyRefundOrderLog.Orderid );

				--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>4. 退款申请 ApplyRefundOrder信息(ApplyRefundOrder) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.ApplyRefundOrder Select ' + dbo.F_BU_Generate_Auto_History_Sql('ApplyRefundOrder') + ' From ApplyRefundOrder ARO Where Exists (Select 1 From #AroTbl arot(nolock) Where ARO.Id = arot.aroId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 4.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From ApplyRefundOrder Where Exists (Select 1 From #AroTbl arot(nolock) Where arot.aroId = ApplyRefundOrder.Id );
				
				Print '--**退款申请归档完成 Commit At: ' + Convert(Varchar, GetDate(), 20)
			End Try
			Begin Catch 
				Print '--**退款申请归档出错 Rollback At: ' + Convert(Varchar, GetDate(), 20)				
				Print '--**Error Msg : ' +  error_message()				
			End Catch
		End











	--========================================================================================================================--
	Print '=============================================================================================='
	Print '--AccountOrderDetail		AccountOrderAlipayRecordMap		AccountOrder'
	Print '=============================================================================================='
	Print ''
	Print '--**对帐单归档开始 Start At: ' + Convert(Varchar, GetDate(), 20)	
	Select Distinct Id As AccId  Into #AccTbl FROM dbo.AccountOrder (nolock) Where CreateDate < @P_DayBefore; 
	SELECT @V_RecordCount = COUNT(1) from #AccTbl
	Print '--**对帐单明细量:' + Cast(@V_RecordCount as varchar)

	If @V_RecordCount > 0
		Begin
			Begin Try     
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>5. 对帐单 Mapping信息(AccountOrderAlipayRecordMap) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.AccountOrderAlipayRecordMap Select ' + dbo.F_BU_Generate_Auto_History_Sql('AccountOrderAlipayRecordMap') + ' From AccountOrderAlipayRecordMap ACM Where Exists (Select 1 From #AccTbl Acc(nolock) Where ACM.AccountOrderId = Acc.AccId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 5.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From AccountOrderAlipayRecordMap Where Exists (Select 1 From #AccTbl ACC(nolock) Where ACC.AccId = AccountOrderAlipayRecordMap.AccountOrderId );
 

			--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>5. 对帐单 Detail信息(AccountOrderDetail) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.AccountOrderDetail Select ' + dbo.F_BU_Generate_Auto_History_Sql('AccountOrderDetail') + ' From AccountOrderDetail ACM Where Exists (Select 1 From #AccTbl Acc(nolock) Where ACM.AccountOrderId = Acc.AccId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 5.2 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From AccountOrderDetail Where Exists (Select 1 From #AccTbl ACC(nolock) Where ACC.AccId = AccountOrderDetail.AccountOrderId );

				--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>5. 对帐单 AccountOrder信息(AccountOrder) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.AccountOrder Select ' + dbo.F_BU_Generate_Auto_History_Sql('AccountOrder') + ' From AccountOrder ACM Where Exists (Select 1 From #AccTbl Acc(nolock) Where ACM.ID = Acc.AccId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 5.2 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From AccountOrder Where Exists (Select 1 From #AccTbl ACC(nolock) Where ACC.AccId = AccountOrder.ID );

				Print '--**对帐单归档完成 Commit At: ' + Convert(Varchar, GetDate(), 20)
				 

			End Try
			Begin Catch 
				Print '--**对帐单归档出错 Rollback At: ' + Convert(Varchar, GetDate(), 20)				
				Print '--**Error Msg : ' +  error_message()				
			End Catch
		End


go

