





CREATE view [dbo].[V_ApplyReportRefundOrder]
as
select ab.OrderType,ar.TradeId,sum(ar.RefundFee) RefundFee,ab.AmountActual AmountActual,ar.BuyerNick CustomerCode,ar.BuyerNick CustomerName,ar.StoreId,ar.StoreName,MIN(ar.LastDate) AuditDate
from ApplyRefundOrder(nolock) ar
left join 
(
select distinct '退款单' OrderType,sum(rf.ActualAmount) AmountActual,TradeId from RefundOrder(nolock) rf
where  rf.Status=3 and rf.RefundWay=0 group by TradeId
) ab on ab.TradeId=ar.TradeId
where ar.Status=6 group by ar.TradeId,ab.OrderType,ar.BuyerNick,ar.StoreId,ar.StoreName,ab.AmountActual

go

