


--[dbo].[P_SetStoreSkuSalesQty] '69018D14-EC32-483A-B670-81022AA8FBA0', '4E8BA195-F26F-4318-A39E-1E83B587F805'
 
CREATE PROC [dbo].[P_TestSetStoreSkuSalesQty]
(
	@SkuId VARCHAR(50), --规格ID
	@StoreId VARCHAR(50) --店铺Id
)
AS
BEGIN
		UPDATE dbo.InventoryVirtual SET Quantity = Quantity +1 WHERE WarehouseId = @StoreId AND SkuId = @SkuId

		UPDATE dbo.InventoryOccupation SET Quantity = Quantity +1 WHERE WarehouseId = @StoreId AND SkuId = @SkuId
END



go

