



	  
CREATE PROCEDURE [dbo].[P_QuerySkuQuantityUpload]
(
 @skuIds VARCHAR(MAX) ,
 @storeIds VARCHAR(MAX)
)
AS
 
      BEGIN
            DECLARE @skuList TABLE (id VARCHAR(100));
            DECLARE @storeList TABLE (id VARCHAR(100));
            INSERT  INTO @skuList
            SELECT  *
            FROM    dbo.F_SplitString(@skuIds, ','); 
            INSERT  INTO @storeList
            SELECT  *
            FROM    dbo.F_SplitString(@storeIds, ',');  
			
			IF UPPER(@storeIds) <> '52F94A7B-D6A2-4EE2-A791-71EE01E96E3F' and UPPER(@storeIds) <> '8DCBA7CE-FC07-4B0E-8CE9-7B1E638B6724' 			and UPPER(@storeIds) <> '70ECBEAC-02C1-4EB5-8222-01AF531B8F1F'
			and UPPER(@storeIds) <> 'FD58D203-37A4-40C9-83B1-73FC5B39FB80'
			and UPPER(@storeIds) <> '14CE9E67-DA01-4859-B4A7-853AE21A21AE'
			and UPPER(@storeIds) <> '70ECBEAC-02C1-4EB5-8222-01AF531B8F1F' and UPPER(@storeIds) <> '00FA5DBB-7D97-45A1-A16E-17FD56039F49'

				

            --库存锁住后， 不能再销售。 上传平台量为0
            SELECT  d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, uc.IsManualUpload&d.IsAutoUploadInventory IsAutoUploadInventory, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, 
					dbo.F_CalcSkuUploadQuantity(d.ProductSkuId, uc.StoreId, d.PresellPlanId, 
												SUM(case when iv.IsLock = 1 then 0 
														 When st.PlatformType != 20 and [dbo].f_checkProductInWhiteList(iv.WarehouseId, d.ProductCode) = 'N' Then 0 
														 else dbo.F_CalcSkuWarehouseUploadQuantity(iv.Quantity, ios.LockedQuantity, uc.Scale) end)) Quantity
            FROM    V_DistributionUpload d
            LEFT JOIN    V_UploadConfig uc ON d.StoreId=uc.StoreId
            LEFT JOIN dbo.InventoryVirtual iv(nolock) ON d.ProductSkuId=iv.SkuId AND uc.WarehouseId=iv.WarehouseId
            LEFT JOIN dbo.V_InventoryOccupationSum ios(nolock) ON uc.WarehouseId=ios.WarehouseId AND d.ProductSkuId=ios.SkuId
			LEFT JOin dbo.Store st(nolock) on uc.StoreId = st.Id
            WHERE   d.ProductSkuId IN (SELECT   *
                                       FROM     @skuList) AND d.StoreId IN (SELECT  *
                                                                            FROM    @storeList)
            GROUP BY d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, uc.StoreId, uc.StoreBrand, uc.IsManualUpload,d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformOutCode, d.PlatformSkuCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoUploadInventory, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId
     --       UNION ALL
     --       SELECT  d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, uc.IsManualUpload&d.IsAutoUploadInventory IsAutoUploadInventory, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, 
					--dbo.F_CalcSkuUploadQuantity(sku.SkuId, uc.StoreId, d.PresellPlanId, 
					--							SUM(case when iv.IsLock = 1 then 0 else dbo.F_CalcSkuWarehouseUploadQuantity(iv.Quantity, ios.LockedQuantity, uc.Scale) end))/sku.Quantity Quantity
     --       FROM    V_DistributionUpload d
     --       LEFT JOIN  V_UploadConfig uc ON d.StoreId=uc.StoreId
     --       LEFT JOIN CombinedProductDetail sku ON d.ProductSkuId=sku.CombinedProductId
     --       LEFT JOIN dbo.InventoryVirtual iv ON sku.SkuId=iv.SkuId AND uc.WarehouseId=iv.WarehouseId
     --       LEFT JOIN dbo.V_InventoryOccupationSum ios ON uc.WarehouseId=ios.WarehouseId AND sku.SkuId=ios.SkuId
     --       WHERE   sku.SkuId IN (SELECT    *
     --                             FROM      @skuList) AND d.StoreId IN (SELECT  *
     --                                                                   FROM    @storeList)  AND d.ProductType=1 AND sku.IsMainSku=1
     --       GROUP BY d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, uc.StoreId, uc.StoreBrand, uc.IsManualUpload,d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformOutCode, d.PlatformSkuCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoUploadInventory, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, sku.SkuId, sku.Quantity;
	 else
	 --库存锁住后， 不能再销售。 上传平台量为0
            SELECT  d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, uc.IsManualUpload&d.IsAutoUploadInventory IsAutoUploadInventory, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, 
					dbo.F_CalcSkuUploadQuantity(d.ProductSkuId, uc.StoreId, d.PresellPlanId, 
												SUM(case when iv.IsLock = 1 then 0 
														 When st.PlatformType = 20 Then 0 
														 else dbo.F_CalcSkuWarehouseUploadQuantity(iv.Quantity, ios.LockedQuantity, uc.Scale) end)) Quantity
            FROM    V_DistributionUpload d
            LEFT JOIN    V_UploadConfig uc ON d.StoreId=uc.StoreId
            LEFT JOIN dbo.InventoryVirtual iv(nolock) ON d.ProductSkuId=iv.SkuId AND uc.WarehouseId=iv.WarehouseId
            LEFT JOIN dbo.V_InventoryOccupationSum ios(nolock) ON uc.WarehouseId=ios.WarehouseId AND d.ProductSkuId=ios.SkuId
			LEFT JOin dbo.Store st(nolock) on uc.StoreId = st.Id
            WHERE   d.ProductSkuId IN (SELECT   *
                                       FROM     @skuList) AND d.StoreId IN (SELECT  *
                                                                            FROM    @storeList)
            GROUP BY d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, uc.StoreId, uc.StoreBrand, uc.IsManualUpload,d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformOutCode, d.PlatformSkuCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoUploadInventory, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId
      END;



go

