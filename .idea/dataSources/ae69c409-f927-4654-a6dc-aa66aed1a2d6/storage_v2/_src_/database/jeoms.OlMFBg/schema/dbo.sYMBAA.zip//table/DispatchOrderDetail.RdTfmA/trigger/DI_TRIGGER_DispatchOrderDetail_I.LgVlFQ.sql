create TRIGGER [dbo].[DI_TRIGGER_DispatchOrderDetail_I]
   ON  [dbo].DispatchOrderDetail 
   after  insert
AS 
	declare @OrderId bigint
	select @OrderId=id from inserted
	insert into jeoms.dbo.DI_DispatchOrderDetail_TRIG_LOG(DetailId,FLAG,INSERT_TIME) values (@OrderId,'I',GETDATE())
go

