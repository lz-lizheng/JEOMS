CREATE TRIGGER [dbo].[DI_TRIGGER_SalesOrderDetail_U]
   ON  [dbo].[SalesOrderDetail] 
   after  update
AS 
	declare @DetailId bigint
	select @DetailId=SalesOrderId from inserted
	insert into jeoms.dbo.DI_SalesOrderDetail_TRIG_LOG(DetailId,FLAG,INSERT_TIME) select DetailId,'U',GETDATE() from SalesOrderDetail where SalesOrderId = @DetailId
go

