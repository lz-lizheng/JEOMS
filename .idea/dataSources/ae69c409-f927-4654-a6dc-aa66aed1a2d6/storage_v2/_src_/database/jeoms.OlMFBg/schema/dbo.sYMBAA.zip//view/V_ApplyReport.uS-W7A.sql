

CREATE view [dbo].[V_ApplyReport]
as
select ab.OrderType,ar.AuditStatus,ar.RefundType,ar.TradeId,ar.RefundFee,ab.AmountActual,ar.BuyerNick CustomerCode,ar.BuyerNick CustomerName,ar.SkuCode,ar.ProductCode,ar.ProductName,ar.SkuName,ar.StoreId,ar.StoreName,ar.AuditDate 
from ApplyRefundOrder(nolock) ar
left join 
(
(
select  '未发货订单' OrderType,sl.AmountActual,sl.DetailId from SalesOrderDetail sl 
inner join salesorder(nolock) so on so.OrderId=sl.SalesOrderId
inner join ApplyRefundOrder(nolock) aro on aro.SalesOrderDetailId=sl.DetailId and aro.RefundType=1 and aro.Status=6
 and isnull(aro.IsObsoleted,0)=0
 where sl.IsDeleted=1 and aro.AuditStatus=1
)
union all (
select distinct '退货退款' OrderType,rl.RefundAmount,SalesOrderDetailId from ReturnOrderDetail(nolock) rl 
left join ReturnOrder(nolock) so on rl.ReturnOrderId=so.Id and so.IsReplace=0 and so.IsObsolete=0 and so.Status=1
)
union all
(
select distinct '退款单' OrderType,rf.RefundAmount,SalesOrderId from RefundOrder(nolock) rf
where  rf.Status=3 and rf.RefundWay=0
)
) ab on ab.DetailId=ar.SalesOrderDetailId or ab.DetailId=ar.SalesOrderId
where ar.AuditStatus=1


go

