-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER  [dbo].[DI_TRIGGER_a_a_a_U]
   ON  [dbo].[a_a_a]
   AFTER UPDATE
AS 

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	declare @DetailId char(10)
	select @DetailId=id from inserted
	insert into a_a_b(text) values (@DetailId)

    -- Insert statements for trigger here


go

