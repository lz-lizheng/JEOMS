

--[dbo].[P_GetStoreSkuSalesQty] '69018D14-EC32-483A-B670-81022AA8FBA0', '4E8BA195-F26F-4318-A39E-1E83B587F805'
 
CREATE PROC [dbo].[P_TestGetStoreSkuSalesQty]
(
	@SkuId VARCHAR(50), --规格ID
	@StoreId VARCHAR(50) --店铺Id
)
AS
BEGIN

	-- 所有库存 - 所有占用
	SELECT ISNULL(SUM(A.Quantity), 0) AS Quantity
	FROM (
		SELECT SUM(IV.Quantity) Quantity
		FROM dbo.InventoryVirtual IV
		WHERE IV.WarehouseId = @StoreId AND iv.SkuId = @SkuId
		UNION ALL
		SELECT SUM(IOC.Quantity) * -1
		FROM dbo.InventoryOccupation IOC
		WHERE IOC.WarehouseId = @StoreId AND ioc.SkuId = @SkuId
		) A;  
END



go

