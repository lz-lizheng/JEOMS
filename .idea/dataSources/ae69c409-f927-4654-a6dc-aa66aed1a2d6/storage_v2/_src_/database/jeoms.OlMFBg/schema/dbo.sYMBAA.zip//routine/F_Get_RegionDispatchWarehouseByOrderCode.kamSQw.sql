 
 
Create FUNCTION [dbo].[F_Get_RegionDispatchWarehouseByOrderCode]
(  
	@P_OrderCode				NVARCHAR(50)
)
RETURNS @V_Warehouse TABLE(WarehouseTemplateId UNIQUEIDENTIFIER, TemplateId UNIQUEIDENTIFIER, OrderId BigInt, WarehouseID VARCHAR(36), 
						   WarehouseCode NVARCHAR(20), WarehouseName NVARCHAR(50), ParentId UNIQUEIDENTIFIER, ParentCode NVARCHAR(50), ParentName NVARCHAR(50),
						   WarehouseDispatchType INT, DefalutCodExpressId UNIQUEIDENTIFIER, DefaultNoCodExpressId UNIQUEIDENTIFIER
						   )
AS
BEGIN 
	
 
	Declare @V_Code Varchar(100), @TempId uniqueidentifier
	Declare @V_ProvName varchar(100), @V_City varchar(100), @V_County Varchar(100)
	  
	Select @TempId = ss.DispatchTemplateId, @V_ProvName = sos.ProvinceName, @V_City = sos.CityName,@V_County = sos.CountyName
	From SalesOrder so left join SalesOrderSub sos on so.OrderId = sos.SubId left join  StoreSetting ss on so.StoreId = ss.StoreId
	where so.code = @P_OrderCode

	Insert into @V_Warehouse
	Select *
	From [dbo].[F_Get_RegionDispatchWarehouse](@TempId, @V_ProvName, @V_City, @V_County)

	Return;

END;

go

