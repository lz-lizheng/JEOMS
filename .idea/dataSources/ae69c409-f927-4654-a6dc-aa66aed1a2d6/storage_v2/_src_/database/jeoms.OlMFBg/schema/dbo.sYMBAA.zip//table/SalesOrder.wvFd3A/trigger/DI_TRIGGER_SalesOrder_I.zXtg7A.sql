CREATE TRIGGER [dbo].[DI_TRIGGER_SalesOrder_I]
   ON  [dbo].[SalesOrder] 
   after  insert
AS 
	declare @OrderId bigint
	select @OrderId=OrderId from inserted
	insert into jeoms.dbo.DI_SalesOrder_TRIG_LOG(OrderId,FLAG,INSERT_TIME) values (@OrderId,'I',GETDATE())
go

