



/**********************
*create date: 2016-12-14
*create by：乔尼
*remark ：唯品发货调整
***********************/  
CREATE VIEW [dbo].[V_VipDeliveryOrder] AS
Select 
	vdo.StoreId,
	vdo.StoreName,
	vdo.PoCode,
	vdo.DispatchOrderCode as DispatchOrderCode,
	vdo.Status,
	vdo.PickingCode,
	Vdo.WarehouseId as WarehouseId,
	Vdo.WarehouseName as WarehouseName, 
	vdod.ProductCode,
	vdod.ProductName,
	vdod.SkuCode,
	vdod.SkuName,
	vdod.VipSkuCode,
	vdod.NoticeQty,
	vdod.OutQty,
	vdo.SendWarehouseId,
	vdo.SendWarehouseName,
	isnull(vdod.WarehousingTime, vdod.WarehouseDeliveryTime) as WarehousingTime,
	vdo.CreateDate
From dbo.VipDispatchOrder Vdo(nolock)
left join VipDispatchOrderDetail vdod(nolock) on Vdo.Id = vdod.DispatchOrderId



go

