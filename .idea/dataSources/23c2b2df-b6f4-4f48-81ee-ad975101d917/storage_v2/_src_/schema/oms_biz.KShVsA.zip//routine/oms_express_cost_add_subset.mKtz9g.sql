create
    definer = jusr3z3dwqbu@`%` procedure oms_express_cost_add_subset()
BEGIN


	#该变量用于标识是否还有数据需遍历
	DECLARE flag INT DEFAULT 0;
	#创建一个变量用来存储遍历过程中的值
	DECLARE id BIGINT(40);
	#查询出需要遍历的数据集合-快递成本
	DECLARE express_cost_id_list CURSOR FOR (select express_cost_id from oms_express_cost oeo where oeo.express_cost_id ='15652997880185856');
	#查询是否有下一个数据，没有将标识设为1，相当于hasNext
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;
	#打开游标
	OPEN express_cost_id_list;
		#取值设置到临时变量中
		FETCH express_cost_id_list INTO id;
		#遍历未结束就一直执行
		WHILE flag != 1 DO
				-- targetSQL #你想要执行的目标功能，这里可以写多个SQL
				
				#  注意
				#这里有一个坑，目标语句引用临时变量，实测发现不需要加@符号，但是搜索到的结果都是例如：@id ，这样来使用，实测发现无法取到数据
				#  注意

				SELECT id;
				select * from oms_express_cost_region where express_cost_id = id;

				#一定要记得把游标向后移一位，这个坑我替各位踩过了，不需要再踩了
				FETCH express_cost_id_list INTO id;
		END WHILE;
	CLOSE express_cost_id_list;
END;

