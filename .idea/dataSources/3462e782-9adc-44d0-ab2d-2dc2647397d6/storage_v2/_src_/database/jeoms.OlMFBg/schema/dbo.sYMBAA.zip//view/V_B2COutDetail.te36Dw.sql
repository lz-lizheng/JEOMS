
/********
*create date: 2019-6-24
*create by：拓斗
*remark ：若羽臣-2C出库明细统计视图
*******/
CREATE VIEW [dbo].[V_B2COutDetail]
AS
SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,so.Code,dod.DispatchOrderCode,DO.ActualExpressName ExpressName,DO.ActualExpressCode ExpressCode,
SO.ExpressFee ActualExpressFee,ISNULL(DO.DeliveryDate,so.CreateDate) Date,so.PayDate,sod.SkuCode,sod.ProductName,sod.Quantity,
sod.AmountActual,ps.WholeSalePrice,ps.PurchasePrice,dod.WarehouseName,so.TradeId,p.Brand
FROM dbo.SalesOrder(nolock) so
LEFT JOIN dbo.SalesOrderDetail(nolock) sod ON so.OrderId=sod.SalesOrderId
LEFT JOIN dbo.Store(nolock) s ON s.Id=so.StoreId
LEFT JOIN dbo.DispatchOrderDetail(nolock) dod ON dod.SalesOrderDetailId=sod.DetailId 
LEFT JOIN dbo.DispatchOrder(NOLOCK) DO ON dod.DispatchOrderId=DO.Id 
LEFT JOIN dbo.ProductSku(nolock) ps ON ps.SkuId=sod.ProductSkuId
LEFT JOIN dbo.Product(nolock) p ON p.ProductId=ps.ProductId
WHERE  ((dod.Status=2 and DO.Status=4) or (so.Status=32 and isnull(DO.Code,'')='')) and sod.IsAbnormal=0 and sod.IsDeleted=0
go

