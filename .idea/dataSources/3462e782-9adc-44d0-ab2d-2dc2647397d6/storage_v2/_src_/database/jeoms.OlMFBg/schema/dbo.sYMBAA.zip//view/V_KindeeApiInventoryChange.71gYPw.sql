
CREATE view [dbo].[V_KindeeApiInventoryChange]
as
select Fromno as 来源单号,Descri as 库存变更说明,
Aptime as 确认时间,sku as 规格编码,Qty as 数量 from ApiInventoryChange
go

