


CREATE PROCEDURE [dbo].[P_ReportProductOrderAnalysis]
(
	@P_BeginDate DATETIME,
	@P_EndDate DATETIME,
	@P_ProductCode NVARCHAR(50),
	@P_SupplierName NVARCHAR(50),
	@P_ReturnType	NVARCHAR(10) -- M:按月统计, D:按日统计
)
AS
BEGIN 
	DECLARE @V_Days INT 
	SELECT @V_Days = DATEDIFF(DAY, @P_BeginDate, @P_EndDate) + 1;
	  
	SELECT pc.OneCatName AS OneCategoryName, PC.twoCatName AS TwoCategoryName, PC.ThreeCatName AS ThreeCategoryName, 
		   ps.SkuId, pd.Code AS Code, ps.Code AS SkuCode, pd.ReturnPeriod, IV.IVQuantity, ps.Color, ps.Size,
		   pd.SupplierName, pd.NewOnlineDate, SafetyStockDays
	INTO #TMPProd
	FROM dbo.Product pd LEFT join dbo.ProductSku ps ON pd.ProductId = ps.ProductId
	LEFT JOIN v_ProductCategory PC ON pd.CategoryId = pc.ThreeCatId
	LEFT JOIN (SELECT SkuId, SUM(CanSaleQuantity) AS IVQuantity FROM dbo.V_InventoryVirtual GROUP BY SkuId) IV ON IV.SkuId = PS.SkuId
	WHERE ps.SkuId IS NOT NULL 
	and (pd.Code = @P_ProductCode OR ISNULL(@P_ProductCode, '') = '')
	AND (pd.SupplierName = @P_SupplierName OR ISNULL(@P_SupplierName, '') = '')
	 
	-- 订单
	SELECT CONVERT(VARCHAR(10), so.PayDate, 20) AS DateKey, sod.ProductSkuId, SUM(sod.Quantity) AS SaleQuantity, pd.NewOnlineDate
	INTO #TmpSale1
	FROM dbo.SalesOrder so(NOLOCK) LEFT JOIN dbo.SalesOrderDetail sod(NOLOCK) ON so.OrderId = sod.SalesOrderId LEFT JOIN #TMPProd PD ON sod.ProductSkuId = pd.SkuId
	WHERE so.PayDate BETWEEN @P_BeginDate AND @P_EndDate
	AND sod.ProductSkuId IN (SELECT SkuId FROM #TMPProd)
	GROUP BY CONVERT(VARCHAR(10), so.PayDate, 20), sod.ProductSkuId, pd.NewOnlineDate

	SELECT DateKey, ProductSkuId, SaleQuantity, CASE WHEN NewOnlineDate > GETDATE() THEN @V_Days ELSE DATEDIFF(DAY, NewOnlineDate, @P_EndDate) + 1 END AS SaleDays
	INTO #TmpSale
	FROM #TmpSale1
	 
	-- 退换货
	SELECT rod.SkuId, SUM(rod.Quantity) AS ReturnQuantity Into #TmpReturn
	FROM dbo.ReturnOrder ro(NOLOCK) LEFT JOIN dbo.ReturnOrderDetail rod(NOLOCK) ON ro.Id = rod.ReturnOrderId
	WHERE ro.ApproveDate BETWEEN @P_BeginDate AND @P_EndDate
	AND rod.SkuId IN (SELECT SkuId FROM #TMPProd)
	GROUP BY rod.SkuId
	 
	 -- 采购在途数据
	SELECT PO.SkuId, SUM(PO.OnWayQty) AS OnWayQty INTO #TmpOnWay
	FROM (
		SELECT po.Code, PO.SkuId, CASE WHEN PO.PurchaseQty < PNO.StockInQty THEN 0 Else (PO.PurchaseQty - ISNULL(PNO.StockInQty, 0)) End AS OnWayQty
		FROM (
				SELECT po.Code, POD.SkuId, POD.PurchaseQty
				FROM dbo.PurchaseOrder PO, dbo.PurchaseOrderDetail POD
				WHERE po.Id = POD.PurchaseOrderId
				AND Status = 1
			) PO
		LEFT JOIN ( 
				SELECT PNO.PurchaseOrderCode, PNOD.SkuId, SUM(PNOD.StockInQty) AS StockInQty
				FROM dbo.PurchaseNoticeOrder PNO, dbo.PurchaseNoticeOrderdetail PNOD
				WHERE PNO.Id = PNOD.PurchaseNoticeOrderId
				AND PNOD.WarehousingTime IS NOT NULL
				GROUP BY PNO.PurchaseOrderCode, PNOD.SkuId
			) PNO ON PO.Code = PNO.PurchaseOrderCode and po.SkuId = PNO.SkuId
		) PO
	GROUP BY PO.SkuId
	 
	IF @P_ReturnType = 'D'
		BEGIN 
			SELECT B.*,  TS.DateKey, ISNULL(TS.SaleQuantity, 0) AS SaleQuantity
			FROM (
				SELECT  A.SkuId, A.OneCategoryname,
						A.TwoCategoryname,
						A.ThreeCategoryname,
						A.Code ,
					   A.SkuCode ,
					   A.SupplierName, A.NewOnlineDate,
					   A.IVQuantity ,
					   A.SaleQuantity ,
					   A.ReturnQuantity,  
					   A.OnWayQty,
					   SafetyStockDays,
					   CASE WHEN A.DateKeyCount = 0 THEN 0 ELSE ROUND(A.SaleQuantity /1.0 / DateKeyCount, 1) END AS DaySale,
					   CASE WHEN A.DateKeyCount = 0 OR (A.SaleQuantity /1.0 / DateKeyCount) = 0 THEN 9999 ELSE ROUND((A.IVQuantity + A.OnWayQty) / (A.SaleQuantity / 1.0 / DateKeyCount), 0) END AS CanSaleDays,  ReturnPeriod, Color, Size
				FROM (
					SELECT A.SkuId, A.OneCategoryname,
						   A.TwoCategoryname,
						   A.ThreeCategoryname,
						   A.Code ,
						   A.SkuCode ,
						   A.SupplierName, A.NewOnlineDate,
						   ISNULL(A.IVQuantity, 0) AS IVQuantity, 
						   ISNULL(S.SaleQuantity, 0) AS SaleQuantity, 
						   ISNULL(R.ReturnQuantity, 0) AS ReturnQuantity, 
						   A.ReturnPeriod, Color, Size, 
						   ISNULL(DateKeyCount, 0) AS DateKeyCount,
						   ow.OnWayQty, SafetyStockDays
					FROM #TMPProd  A
					LEFT JOIN (SELECT ProductSkuId, SUM(SaleQuantity) AS SaleQuantity, SaleDays AS DateKeyCount 
							   FROM #TmpSale 
							   GROUP BY ProductSkuId, SaleDays
							   ) S ON a.SkuId = s.ProductSkuId
					LEFT JOIN #TmpReturn R ON A.SkuId = R.SkuId 
					LEFT JOIN #TmpOnWay OW ON a.SkuId = OW.SkuId
					) A 
				) B LEFT JOIN #TmpSale TS ON B.SkuId = TS.ProductSkuId 
			END;
		ELSE
			BEGIN
				SELECT SUBSTRING(DateKey, 1, 7) AS DateKey, ProductSkuId, SUM(SaleQuantity) AS SaleQuantity INTO #TmpSaleMth FROM  #TmpSale GROUP BY SUBSTRING(DateKey, 1, 7), ProductSkuId;

				SELECT B.*,  TS.DateKey, ISNULL(TS.SaleQuantity, 0) AS SaleQuantity
				FROM (
					SELECT  A.SkuId, A.OneCategoryname,
							A.TwoCategoryname,
							A.ThreeCategoryname,
							A.Code ,
						   A.SkuCode ,
						   A.SupplierName, A.NewOnlineDate,
						   A.IVQuantity ,
						   A.SaleQuantity ,
						   A.ReturnQuantity,  
						   A.OnWayQty,
						   SafetyStockDays,
						   CASE WHEN a.DateKeyCount = 0 THEN 0 ELSE ROUND(A.SaleQuantity /1.0 / DateKeyCount, 1) END AS DaySale,
						   CASE WHEN a.DateKeyCount = 0 OR (A.SaleQuantity / 1.0 / DateKeyCount) = 0 THEN 9999 ELSE ROUND((A.IVQuantity + A.OnWayQty) / (A.SaleQuantity / 1.0 / A.DateKeyCount), 0) END AS CanSaleDays,  ReturnPeriod, Color, Size
					FROM (
						SELECT  A.SkuId, A.OneCategoryname,
							   A.TwoCategoryname,
							   A.ThreeCategoryname,
							   A.Code ,
							   A.SkuCode ,
							   A.SupplierName, A.NewOnlineDate,
							   ISNULL(A.IVQuantity, 0) AS IVQuantity, 
							   ISNULL(S.SaleQuantity, 0) AS SaleQuantity, 
							   ISNULL(R.ReturnQuantity, 0) AS ReturnQuantity, 
							   A.ReturnPeriod, Color, Size, 
							   ISNULL( DateKeyCount, 0) AS DateKeyCount,
							   ow.OnWayQty,
							   SafetyStockDays
						FROM #TMPProd  A
						LEFT JOIN (SELECT ProductSkuId, SUM(SaleQuantity) AS SaleQuantity, SaleDays AS DateKeyCount FROM #TmpSale GROUP BY ProductSkuId, SaleDays) S ON a.SkuId = s.ProductSkuId
						LEFT JOIN #TmpReturn R ON A.SkuId = R.SkuId 
						LEFT JOIN #TmpOnWay OW ON a.SkuId = OW.SkuId
						) A 
					) B LEFT JOIN #TmpSaleMth TS ON B.SkuId = TS.ProductSkuId 

				DROP TABLE #TmpSaleMth; 
			END

	DROP TABLE #TMPProd, #TmpReturn, #TmpSale; 
END;



go

