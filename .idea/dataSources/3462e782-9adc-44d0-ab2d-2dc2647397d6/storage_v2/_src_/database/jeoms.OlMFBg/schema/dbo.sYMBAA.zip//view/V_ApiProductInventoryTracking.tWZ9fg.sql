/**

*create date : 2020-2-10

*create modify：拓斗

*remark ：商品库存跟踪用SkuId关联且不过滤禁用商品（仅限于3.0客户）

*/

CREATE view [dbo].[V_ApiProductInventoryTracking]

as

SELECT APIT.Id,APIT.AdjustmentQuantity,APIT.ChangeDate,APIT.Memo,

APIT.OperatorDate,APIT.OperatorUser,APIT.OrderCode,APIT.OrderType,

APIT.OriginalQuantity,APIT.ProductSkuCode,APIT.Quantity,APIT.WareHouseCode,

w.Name WareHouseName, PS.ProductCode, ps.ProductName, ps.Description,

APIT.VirtualWarehouseCode,APIT.VirtualWarehouseName,

w.Id WarehouseId,P.BrandCode,P.Brand AS BRANDNAME

FROM dbo.ApiProductInventoryTracking APIT(NOLOCK)

LEFT JOIN ProductSku PS(NOLOCK) ON APIT.ProductSkuId = PS.SkuId

LEFT JOIN PRODUCT P ON PS.ProdUCTID=P.ProductId

left join Warehouse w on w.Code = APIT.WareHouseCode

WHERE w.IsDisabled=0

go

