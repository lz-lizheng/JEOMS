CREATE View [dbo].[V_SalesOrderFlow] AS
SELECT
	so.StoreId 'storeId', 	
	sum(case when t.tid is not null then 1 else 0 end) 'rdsQty',
	ISNULL(sum(case when so.PayStatus = 2 then 1 end), 0) 'sysQty',
	ISNULL(SUM ( CASE WHEN so.PayStatus = 2 and so.Status >= 11 THEN 1 ELSE 0 END ), 0) 'auditQty',
	ISNULL(SUM ( CASE WHEN so.PayStatus = 2 and so.Status >= 22 THEN 1 ELSE 0 END ), 0) 'disQty',
	ISNULL(SUM ( CASE WHEN so.Status IN ( 31, 32 ) THEN 1 ELSE 0 END ), 0) 'warehouseQty',
	ISNULL(SUM ( CASE WHEN so.PlatformStatus IN ( 1, 2 ) THEN 1 ELSE 0 END ), 0) 'platformQty'
FROM 
	SalesOrder so ( nolock ) 	
	JOIN DownloadConfig dc ( nolock ) ON so.StoreId = dc.StoreId AND dc.DownloadType = 1 AND dc.PlatformType IN ( 2, 22 ) 
	left JOIN sys_info.dbo.jdp_tb_trade t (nolock )ON  so.TradeId= t.tid and dc.SellerNick = t.seller_nick and t.status NOT IN ( 'TRADE_CLOSED', 'WAIT_BUYER_PAY', 'TRADE_CLOSED_BY_TAOBAO' , 'TRADE_NO_CREATE_PAY') 
WHERE 1= 1	
	AND so.IsAutoDownload = 1
	AND so.CreateDate >= DATEADD( DAY, 0, DATEDIFF( DAY, 0, GETDATE( ) ) )
	AND so.StoreId= dc.StoreId 		
	and so.IsPrepay = 1	
	and so.IsObsolete = 0
Group by so.StoreId
UNION ALL
SELECT s.Id 'storeId',COUNT ( t.tid ) 'rdsQty',
ISNULL(SUM ( CASE WHEN so.OrderId IS NULL THEN 0 ELSE 1 END ), 0) 'sysQty',
ISNULL(SUM ( CASE WHEN so.Status >= 11 THEN 1 ELSE 0 END ), 0) 'auditQty',
ISNULL(SUM ( CASE WHEN so.Status >= 22 THEN 1 ELSE 0 END ), 0) 'disQty',
ISNULL(SUM ( CASE WHEN so.Status IN ( 31, 32 ) THEN 1 ELSE 0 END ), 0) 'warehouseQty',
ISNULL(SUM ( CASE WHEN so.PlatformStatus IN ( 1, 2 ) THEN 1 ELSE 0 END ), 0) 'platformQty'
FROM
	sys_info.dbo.jdp_tb_trade t ( nolock )
	LEFT JOIN DownloadConfig dc ( nolock ) ON dc.SellerNick= t.seller_nick
	LEFT JOIN Store s ( nolock ) ON dc.StoreId = s.Id
	LEFT JOIN SalesOrder so ( nolock ) ON so.StoreId= s.Id 
	AND so.TradeId= CAST ( t.tid AS nvarchar ( 100 ) ) 
WHERE
	t.status NOT IN ( 'TRADE_CLOSED', 'WAIT_BUYER_PAY', 'TRADE_CLOSED_BY_TAOBAO' ) 
	AND dc.PlatformType IN ( 2, 22 ) 
	AND dc.DownloadType = 1 
	AND dc.IsDisabled = 0 
	AND t.created >= DATEADD( DAY, 0, DATEDIFF( DAY, 0, GETDATE( ) ) )
	group by s.Id
go

