CREATE function [dbo].[F_GetKindeeStoreTypeCode](@storeType int)
returns nvarchar(50)
as
begin
declare @storeTypeCode nvarchar(50)
select @storeTypeCode = case @storeType 
when '2' then 'XSCKD01_SYS'
when '7' then 'XSCKD09_SYS'
when '4' then 'XSCKD08_SYS'
when '6' then 'XSCKD08_SYS'
 else 'Other' end
return @storeTypeCode
end


go

