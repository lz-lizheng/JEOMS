
CREATE View V_CanceledDispatchOrder as 
Select REPLACE(note, '取消了配货单：', '') as DpoCode, CreateDate
From SalesOrderLog
Where note like '%取消了配货单：%'
go

