/********
*create date: 2019-6-25
*create by：拓斗
*remark ：若羽臣-出库单汇总表视图
*******/
CREATE VIEW [dbo].[V_OutboundOrderSummary]  
AS  
SELECT oo.WarehouseId,oo.WarehouseName,ood.WarehouseDeliveryTime,SUM(ood.OutQty) OutQty,  
SUM(ood.OutQty*ood.UnitPrice) Price,oo.TypeCode,oo.TypeName  
FROM dbo.OutboundOrder oo  
LEFT JOIN dbo.OutboundOrderDetail ood ON ood.OutboundOrderId=oo.Id  
WHERE oo.Status IN (3,4,6)   
AND oo.TypeCode IN ('HC01','SY01','PKCK01','LPBF01','CPBF01','LHZH01','LHCK01')  
GROUP BY oo.WarehouseId,oo.WarehouseName,ood.WarehouseDeliveryTime,oo.TypeCode,oo.TypeName
go

