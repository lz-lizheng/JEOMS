 

/**********************
*modify by：Byron
*remark ：库存查询商品简称
*date:2020-5-26
***********************/
CREATE VIEW [dbo].[V_InventoryEntity] AS
SELECT v.IsLockStock,V.WarehouseId,v.WarehouseCode,v.IsO2O, v.Quantity Quantity, v.LockedQuantity LockedQuantity,
  v.DispatchedQuantity DispatchedQuantity, v.UnDispatchedQuantity UnDispatchedQuantity,
  v.AllotQuantity AllotQuantity, v.VipQuantity VipQuantity, v.CanSaleQuantity CanSaleQuantity,
  v.CanUseQuantity CanUseQuantity, v.CombQuantity CombQuantity,
  v.TransitTotalQuantity TransitTotalQuantity, p.Brand, p.Season, p.Year, p.CategoryId, p.CategoryName, p.FirstLevelCategoryName,p.TwoLevelCategoryName,
  sku.ProductId, sku.ProductCode, sku.ProductName, sku.SkuId, sku.Code, sku.Description, sku.CustomCode,sku.SKC,sku.Color,sku.Size,sku.FirstPrice,p.ShortName as ProductShortName
FROM ProductSku sku
  JOIN Product p ON sku.ProductId = p.ProductId
  JOIN  (
  SELECT  w.ParentId WarehouseId,
 iv.SkuId SkuId,
 SUM(iv.Quantity) AS Quantity,
 SUM(ios.LockedQuantity) AS LockedQuantity,
 SUM(ios.DispatchedQuantity) AS DispatchedQuantity,
 SUM(ios.UnDispatchedQuantity) AS UnDispatchedQuantity,
 SUM(ios.AllotQuantity) AS AllotQuantity,
 SUM(ios.VipQuantity) AS VipQuantity,
SUM(ios.CombQuantity) AS CombQuantity,
 SUM(ISNULL(iv.Quantity, 0)-ISNULL(ios.LockedQuantity, 0)) AS CanSaleQuantity,
 SUM((ISNULL(iv.Quantity, 0)-ISNULL(ios.DispatchedQuantity, 0)-ISNULL(ios.AllotQuantity, 0)-
ISNULL(ios.VipQuantity, 0)-ISNULL(ios.CombQuantity, 0))) AS CanUseQuantity,
 SUM(TransitTotalQuantity) AS TransitTotalQuantity,
ISNULL(w.IsO2O, 0) AS IsO2O,
parent.Code WarehouseCode,
sum(ISNULL(iv.IsLockStock, 0)) AS IsLockStock
  FROM   V_InventoryVirtualMap iv
   JOIN Warehouse w ON iv.warehouseId=w.Id
   JOIN Warehouse parent on parent.Id = w.ParentId
   LEFT JOIN V_InventoryOccupationSum ios ON iv.SkuId=ios.SkuId AND iv.WarehouseId=ios.WarehouseId
   GROUP BY w.ParentId,parent.Code, iv.Skuid, ISNULL(w.IsO2O, 0)
   ) v ON sku.SkuId=v.SkuId
   WHERE sku.Status=1

go

