

 CREATE View  [dbo].[V_BI_BatchInvneotryVirtual] as     
	SELECT SkuCode,p.Code PCode,p.Description,ab.BatchCode,ab.WarehouseId,ab.WarehouseName,p.ShelfLife,    
			ProductDate,ExpireDate,p.Brand,sku.CustomCode,ab.Quantity Quantity,    
			ISNULL(SUM(ioc.Quantity),0) OccQuantity ,(ab.Quantity-ISNULL(SUM(ioc.Quantity),0)) CanUserQty,case ab.InventoryType when 'ZP' then '正品' when 'CC' then '次品' else null end as InventoryType
    FROM (
		SELECT SkuId,WarehouseId,BatchCode,SkuCode,SUM(ISNULL(Quantity,0)) Quantity,WarehouseName,ExpireDate,ProductDate,InventoryType    
		FROM dbo.ApiOrderBatchRecord 
		GROUP BY SkuId,WarehouseId,BatchCode,SkuCode,WarehouseName,InventoryType,ExpireDate,ProductDate
		) ab
    LEFT JOIN dbo.Warehouse(NOLOCK) swh ON swh.ParentId=ab.WarehouseId
    LEFT JOIN dbo.ProductSku(NOLOCK) sku ON sku.SkuId=ab.SkuId
    LEFT JOIN dbo.Product(NOLOCK) p ON p.ProductId=sku.ProductId
    LEFT JOIN dbo.InventoryOccupation(NOLOCK) ioc ON ioc.BatchCode = ab.BatchCode AND ioc.SkuId = ab.SkuId AND ioc.WarehouseId = swh.Id     
	Group By SkuCode,ab.BatchCode,ab.WarehouseId,ab.WarehouseName,ab.ExpireDate,ab.ProductDate,p.Code,p.Brand,sku.CustomCode,p.ShelfLife,p.Description,ab.Quantity,InventoryType



 go

