
/**********************
*create date :	2018-07-27
*create by：	qiaoni 
*remark ：	订单明细可配货量查询
***********************/  
CREATE Function [dbo].[F_GetCanPackingQty](
	@StoreId nvarchar(100),
	@Skuid nvarchar(100),
	@Paydate DateTime
)
Returns int
As 
Begin 
	Declare @V_WarehouseId Table(WarehouseId UNIQUEIDENTIFIER);

	Insert Into @V_WarehouseId
	Select WarehouseID
	From V_StoreDispatchWarehouse  SDW(nolock)
	Where StoreId = @StoreId;

	declare @V_Result int
	Select @V_Result = Sum(Qty)
	From (
		Select Isnull(Sum(VVS.Quantity), 0) as Qty
		From InventoryVirtual VVS(nolock), @V_WarehouseId SDW
		Where SDW.WarehouseId = vvs.WarehouseId And VVS.SkuId = @Skuid 
		And VVS.IsLockStock = 0 
		
		/*
		Union ALL
		Select isnull(Sum(IOC.Quantity), 0) * -1
		From InventoryOccupation IOC(nolock), @V_WarehouseId SDW
		Where SDW.WarehouseId = IOC.WarehouseId And (IOC.Type > 1 or IsDispatched = 1) And IOC.SkuId = @Skuid
		Union ALL
		Select isnull(Sum(IOC.Quantity), 0) * -1
		From InventoryOccupation IOC(nolock),@V_WarehouseId SDW 
		Where IOC.WarehouseId = SDW.WarehouseId
		And IOC.Type = 1 
		And IsDispatched = 0 
		And IOC.SkuId =@Skuid  
		And IOC.PayDate < @Paydate
		And (IOC.IsAppointDateDelivery = 0 or ( IOC.IsAppointDateDelivery = 1 and PreDeliveryDate < getdate())) 
		*/
	) A
	 
	Return @V_Result;

End;

go

