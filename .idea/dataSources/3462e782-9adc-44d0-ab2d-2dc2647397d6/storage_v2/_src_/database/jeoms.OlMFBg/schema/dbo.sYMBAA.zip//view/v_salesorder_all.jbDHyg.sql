
CREATE view v_salesorder_all as
Select OrderId, so.code, sos.CityName, sos.ProvinceName, so.PayDate
From jehistory.dbo.SalesOrder so
join jehistory.dbo.SalesOrderSub sos on so.OrderId = sos.SubId
union all
Select OrderId, so.code, sos.CityName, sos.ProvinceName, so.PayDate
From jeoms.dbo.SalesOrder so
join jeoms.dbo.SalesOrderSub sos on so.OrderId = sos.SubId

go

