	
  /**
*create date : 2020-2-19
*create modify：乔尼
*remark ：表字段增加描述
*/
Create Procedure [dbo].[P_ColumnAddDescription]
(
	@P_TableName nvarchar(100),
	@P_ColumnName nvarchar(100),
	@P_Description nvarchar(255)
) 
As

	EXEC sys.sp_addextendedproperty @name='OMS_Description', @value=@P_Description, @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=@P_TableName, @level2type=N'COLUMN',@level2name=@P_ColumnName

  go

