


CREATE view [dbo].[V_KindeeB2BDispatchOrder]
as
select dod.Id as 明细行ID,do.Code as 单据编号,dod.WarehouseDeliveryTime as 日期,c.Code as 销售组织
,s.Code as 销售部门,s.Code as 客户,c.Code as 发货组织,dod.ProductSkuCode as 物料编码,
dod.OutQty as 实发数量,dod.Price as 单价,dod.Price*dod.OutQty as 价税合计,
c.LawUser as 仓库,bp.Code as 来源单号,dbo.F_GetKindeeStoreTypeCode(s.StoreType) as 店铺类型,
bp.ScheduleNo as 平台订单号
 from B2BAllocationOut do 
join B2BAllocationOutDetail dod on do.Code = dod.OutCode
join B2BAllocationPlan bp on do.PlanId = bp.Id
join Store s on s.Id = do.StoreId
join Company c on s.CompanyId = c.Id



go

