CREATE view [dbo].[V_ScInventory]
as
select '1200917' as 公司代码,'广州若羽臣科技股份有限公司' as 公司名称, p.Attribute20 as 产品代码,
dod.ProductName as 产品名称,p.Attribute6 as 产品规格,'' as 批号,dod.Quantity as 数量
,p.Unit as 单位,
p.Attribute2 as 产地,p.CategoryName as 产品分类,p.Brand as 品牌名称,p.BrandCode as 品牌编码
 from V_InventoryVirtual dod 
join Product p on p.ProductId = dod.ProductId
join ProductSku sku on dod.SkuId = sku.SkuId
and p.BrandCode in('094','130') --and p.ProductType != 1
and isnull(p.Attribute20, '') <> ''
and dod.WarehouseCode not in ('20-0','STYHD004_GX','ZC002_GX','FWHN07_GX')
go

