
/**
*create date : 2021-11-15
*create modify：奇光
*remark ：【【高梵】-唯品退货通知单统计改造】 https://www.tapd.cn/38026101/prong/stories/view/1138026101001010685
*/
CREATE VIEW [dbo].[V_VipReturnOrderNotice]

AS

SELECT
        VRON.VipReturnOrderCode,
        VRON.ReturnOrderCode,
        VRON.VipReturnOrderNoticeCode,
        VRON.InWarehouseId,
        VRON.InWarehouseName,
        VROND.ProductCode,
        VROND.ProductName,
        VROND.SkuCode,
        VROND.SkuName,
        VROND.NoticeQty,
        VROND.InQty,
        VROND.WarehouseStorageTime,
        VRON.CreateDate,
        VROND.DefectiveQuantity,
        VRON.SignUserName 
FROM
        dbo.VipReturnOrderNotice AS VRON WITH ( NOLOCK )
        LEFT OUTER JOIN dbo.VipReturnOrderNoticeDetail AS VROND WITH ( NOLOCK ) ON VROND.ReturnOrderNoticeId = VRON.Id

go

exec sp_addextendedproperty 'MS_Description', '唯品退供单号', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'VipReturnOrderCode'
go

exec sp_addextendedproperty 'MS_Description', '退供单号', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ReturnOrderCode'
go

exec sp_addextendedproperty 'MS_Description', '退货通知单号', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'VipReturnOrderNoticeCode'
go

exec sp_addextendedproperty 'MS_Description', '入库仓库ID', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InWarehouseId'
go

exec sp_addextendedproperty 'MS_Description', '入库仓库名称', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InWarehouseName'
go

exec sp_addextendedproperty 'MS_Description', '商品编码', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ProductCode'
go

exec sp_addextendedproperty 'MS_Description', '商品名称', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ProductName'
go

exec sp_addextendedproperty 'MS_Description', '规格编码', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'SkuCode'
go

exec sp_addextendedproperty 'MS_Description', '规格名称', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'SkuName'
go

exec sp_addextendedproperty 'MS_Description', '通知数量', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'NoticeQty'
go

exec sp_addextendedproperty 'MS_Description', '入库数量', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InQty'
go

