





/******金蝶销售出库单  Script Date: 2017/5/4 10:43:19 ******/
create view [dbo].[V_KindeeDispatchOrder2]
as

select do.Code as 单据编号,do.DeliveryDate as 日期,c.Code as 销售组织
,s.Code as 销售部门,s.Code as 客户,c.Code as 发货组织,dod.ProductSkuCode as 物料编码,
dod.OutQuantity as 实发数量,case when dod.PriceSelling=0 and OutQuantity<>0 then  (dod.AmountActual+Isnull(0,0))/dod.OutQuantity else dod.PriceSelling end as 单价,dod.AmountActual+Isnull(0,0) as 价税合计,
c.LawUser as 仓库,dod.TradeId as 来源单号,dbo.F_GetKindeeStoreTypeCode(s.StoreType) as 店铺类型
--,so.ExpressFee as 快递费用
 from DispatchOrder do 
join DispatchOrderDetail dod on do.Id = dod.DispatchOrderId
--join SalesOrder so on so.OrderId = dod.SalesOrderId
--left join(select MIN(t.Id) ID,ExpressFee,t.TradeId  from DispatchOrderDetail t  inner join SalesOrder t1 on t1.OrderId = t.SalesOrderId group by ExpressFee,t.TradeId ) T
--on T.ID=dod.Id
join Store s on s.Id = do.StoreId
join Company c on s.CompanyId = c.Id

union all
select do.Code as 单据编号,do.CreateDate as 日期,c.Code as 销售组织
,s.Code as 销售部门,s.Code as 客户,c.Code as 发货组织,dod.SkuCode as 物料编码,
dod.Quantity as 实发数量,dod.PriceSelling as 单价,dod.AmountActual+Isnull(T.ExpressFee,0) as 价税合计,
c.LawUser as 仓库,do.TradeId as 来源单号,dbo.F_GetKindeeStoreTypeCode(s.StoreType) as 店铺类型
--,do.ExpressFee as 快递费用
 from SalesOrder do 
join SalesOrderDetail dod on do.OrderId = dod.SalesOrderId
left join (select MIN(dod.DetailId) DetailId,do.TradeId,do.ExpressFee   from SalesOrder do join SalesOrderDetail dod on do.OrderId = dod.SalesOrderId group  by do.ExpressFee,do.TradeId) T
on T.DetailId=dod.DetailId
join Store s on s.Id = do.StoreId
join Warehouse w on do.SuggestWarehouseId = w.Id
join Company c on s.CompanyId = c.Id
where not exists (select 1 from DispatchOrderDetail where DispatchOrderDetail.SalesOrderDetailId = dod.DetailId)
and dod.Status=2
union all
select do.Code as 单据编号,dod.WarehousingTime as 日期,c.Code as 销售组织
,s.Code as 销售部门,s.Code as 客户,c.Code as 发货组织,dod.ProductSkuCode as 物料编码,
dod.OutQty as 实发数量,dod.Price as 单价,dod.Price*dod.OutQty as 价税合计,
c.LawUser as 仓库,bp.Code as 来源单号,dbo.F_GetKindeeStoreTypeCode(s.StoreType) as 店铺类型
 from B2BAllocationOut do 
join B2BAllocationOutDetail dod on do.Code = dod.OutCode
join B2BAllocationPlan bp on do.PlanId = bp.Id
join Store s on s.Id = do.StoreId
join Company c on s.CompanyId = c.Id



go

