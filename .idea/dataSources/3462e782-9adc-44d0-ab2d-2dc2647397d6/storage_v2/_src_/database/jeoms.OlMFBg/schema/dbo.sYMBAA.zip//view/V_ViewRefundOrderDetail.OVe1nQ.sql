
/**********************
*create date :	2018-08-27
*create by：	qiaoni 
*remark ：		退款单统计
***********************/  
Create View V_ViewRefundOrderDetail as
Select Ro.*, 
	Rod.Id as DtlId,
	ROD.ProductCode,
	Rod.ProductName, 
	Rod.SkuCode,
	Rod.SkuName,
	Rod.Quantity,
	Rod.RefundAmount as DtlAmount
From RefundOrder Ro(nolock)
Left Join RefundOrderDetail ROD(nolock) on ro.Id = Rod.RefundOrderId


go

