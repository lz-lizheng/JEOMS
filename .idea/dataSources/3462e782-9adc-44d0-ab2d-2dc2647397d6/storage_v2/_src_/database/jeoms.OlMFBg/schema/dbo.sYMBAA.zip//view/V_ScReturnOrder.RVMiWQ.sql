
  
  
  
  
  
  
  
  
-- [V_ScDispatchOrder]和[V_ScReturnOrder]--销售表与退货表里采购方直接取订单里面店铺名称，销售方更改为广州若羽臣科技股份有限公司，且产品编码取商品资料的“自定义属性20”字段，自定义属性20字段若羽臣已修改  
-- 为惠氏Code，如果惠氏Code为空则不提供数据；  
  
--惠氏制药有限公司  采购方名称  
-- 阿锋确认 20191023 调整日期取值标准为入库时间， 不看复核状态  
  
-- 阿锋确认 2019-11-13 调整数量为入库数量  
/******金蝶销售退货单  Script Date: 2017/9/7 10:43:19 ******/  
CREATE view [dbo].[V_ScReturnOrder] as   
select ROND.WarehousingTime as 日期,'1200917' as 销售方代码,'广州若羽臣科技股份有限公司' as 销售方名称,  
 '0366' as 采购方代码,s.Name as 采购方名称, p.Attribute20  as 产品代码,  
 dod.ProductName as 产品名称,p.Attribute6 as 产品规格,'' as 批号,  
 -- dod.Quantity as 数量,  
 dod.StorageQuantity as 数量,Convert(decimal(18,2), dod.ActualAmount/dod.Quantity) as 单价,dod.ActualAmount as 金额,p.Unit as 单位,  
 p.Attribute2 as 产地,p.CategoryName as 产品分类,p.Brand as 品牌名称,p.BrandCode as 品牌编码  
 from Returnorder do   
join ReturnOrderDetail dod on do.Id = dod.ReturnOrderId  
Left Join ReturnOrderNoticeDetail ROND on dod.Id = ROND.ReturnOrderDetailId  
--join SalesOrderDetail sod on dod.SalesOrderDetailId = sod.DetailId  
join Store s on s.Id = do.StoreId  
join Company c on s.CompanyId = c.Id  
join Product p on p.ProductId = dod.ProductId  
Where p.Brand in ('caltrate/钙尔奇','Centrum/善存')
--and do.Status=2    
and isnull(p.Attribute20, '') <> ''  
And dod.Quantity <> 0


go

