


/******金蝶销采购入库单  Script Date: 2017/5/4 10:43:19 ******/
CREATE view [dbo].[V_KindeePurchaseReturnOrder]
as
select pod.DetailId as 明细行ID,c.Name as 退料组织,c.Code as 需求组织,c.Code as 采购组织,
pr.Code as 单据编号,pod.WarehousingTime 退料日期,
pr.TypeCode as 退料原因,pr.SupplierCode as 供应商,pod.SkuCode as 物料编码,
pod.OutStockQty as 实退数量,pod.OutStockQty as 补料数量,pod.OutStockQty as 扣款数量,
pod.OutStockQty as 计价数量,'' as 备注,pr.PurchaseOrderCode as 来源单号,c.LawUser as 仓库
,pod.OriginalPrice as 单价,pod.OriginalPrice*pod.OutStockQty as 金额,po.Currency as 币别
 from PurchaseReturnOrder pr
 join PurchaseReturnOrderDetail pod on pod.PurchaseReturnOrderId = pr.Id
 left join PurchaseOrder po on po.Id = pr.PurchaseOrderId
 left join Company c on pr.SupplierCompanyName = c.Name
 left join Warehouse w on pr.WarehouseID = w.Id

go

