


--销售								
--制单时间		付款时间		交易完成时间		店铺名称
--商品编码		规格编码		订单类型		明细状态		
--订单编号		缺货	作废	赠品	预付款	

CREATE View [dbo].[V_SalesOrderCriteria] as 
Select so.CreateDate, so.PayDate, so.TradeFinishDate, so.StoreId, 
	   sod.ProductCode, Sod.SkuCode, So.TransType, Sod.DetailId,
	   so.Code, sod.IsOutOfStock, sod.IsDeleted, sod.DetailType,
	   so.IsPrepay
From SalesOrder So
Join SalesOrderDetail Sod on so.OrderId = sod.SalesOrderId
Where sod.IsAbnormal = 0
--AND SalesOrderPayDate >= '2020-01-10 00:00:00'  
--AND SalesOrderPayDate <= '2020-01-18 23:59:59'  
--AND IsDeleted = '0'  


go

