
Create View V_Operation as 
Select op.id, op.name, op1.id as id1, op1.Name as name1, op2.id as id2, op2.Name as name2
From Operation op
Left join Operation op1 on op.Id = op1.ParentId
Left join Operation op2 on op1.Id = op2.ParentId
where op.ParentId is null
go

