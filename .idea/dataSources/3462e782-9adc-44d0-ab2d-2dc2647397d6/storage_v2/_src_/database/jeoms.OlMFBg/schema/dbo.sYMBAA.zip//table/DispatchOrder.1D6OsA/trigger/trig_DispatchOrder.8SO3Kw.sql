create trigger trig_DispatchOrder
on DispatchOrder
after update
as
begin
 if update(Status)


	begin
	update DispatchOrder set ModifyDate = GETDATE() where id = (select id from inserted);

	end;
end;
go

disable trigger dbo.trig_DispatchOrder on dbo.DispatchOrder
go

