-- =============================================
-- Author:		Creoa
-- Create date: 2016-04-18
-- Description:	订单明细分摊
-- =============================================
CREATE FUNCTION [dbo].[F_AmountFeeShare]
(
	@orderid BIGINT,
	@orderdetailid BIGINT
)
RETURNS DECIMAL(12,4)
AS
BEGIN
	DECLARE @PayAmount  DECIMAL(12,4)
	DECLARE @AmountCount DECIMAL(12,4)
	DECLARE @shareamount DECIMAL(12,4)
	DECLARE @DetailCount INT=0
	DECLARE @i INT =0

	SELECT @PayAmount=Amount FROM dbo.SalesOrderPayMent(NOLOCK) WHERE SalesOrderId=@orderid

	SET @AmountCount=(SELECT SUM(AmountActual) FROM dbo.SalesOrderDetail(NOLOCK) WHERE SalesOrderId=@orderid and DetailType=0)
	
	SET @DetailCount=(SELECT COUNT(1) FROM dbo.SalesOrderDetail(NOLOCK) WHERE SalesOrderId=@orderid and DetailType=0)
	
	DECLARE @AmountActual DECIMAL(12,4)
    DECLARE @DetailId BIGINT
    DECLARE @SareFee DECIMAL(12,4)=0.00
	DECLARE @TempFee DECIMAL(12,4)=0.00

	DECLARE DetailCursor CURSOR FOR SELECT AmountActual,DetailId FROM dbo.SalesOrderDetail(NOLOCK) WHERE SalesOrderId=@orderid and DetailType=0 ORDER BY CreateDate DESC
	OPEN DetailCursor
	fetch next from DetailCursor into @AmountActual,@DetailId
	while @@fetch_status<>-1
	BEGIN
		SET @i=@i+1  
			IF @i=@DetailCount
				BEGIN
					SET @SareFee=@PayAmount-@TempFee-0.00
				END 
			ELSE
				BEGIN
					SET @SareFee=ROUND((@AmountActual/ISNULL(@AmountCount,0)),5)*@PayAmount
				END
			IF @DetailId=@orderdetailid
				BEGIN
					SET @shareamount=@SareFee
				END          
			SET @TempFee=@TempFee+@SareFee
	fetch next from DetailCursor into @AmountActual,@DetailId
	end
	close DetailCursor
	deallocate DetailCursor

	RETURN ROUND(@shareamount,2)
END
go

