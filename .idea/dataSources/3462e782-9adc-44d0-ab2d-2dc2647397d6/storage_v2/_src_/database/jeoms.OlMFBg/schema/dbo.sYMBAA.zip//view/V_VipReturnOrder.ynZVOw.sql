/**
* create date ： 2021-07-22
* create modify：哲别
* remark ：唯品退货视图添加平台状态、差异数
*/
CREATE VIEW [dbo].[V_VipReturnOrder] AS
SELECT VRO.CreateDate,
 Status,vro.ReturnOrderCode,vro.VipReturnOrderCode,
 ReturnType,ReturnSignType,
 WarehouseId, WarehouseName,
 InWarehouseId,InWarehouseName,
 OutDate, TotalCases,
 TotalSkus,TotalQtys,
 SignDate,SignUserName,
 Note,
 PoCode,BoxNo,
 ReturnOrderId,ProductId,
 ProductCode,ProductName,
 vrod.SkuId,
 vrod.SkuCode,
 SkuName,VipSkuCode,
 ReturnQty,VROD.InQty SignQty, 
 ScanUser,
 ScanDate,
 VROD.SupplyPrice,        
 StoreName,StoreId,      
 (SELECT Brand FROM dbo.Product WHERE ProductId=vrod.ProductId) AS Brand,      
 (SELECT Id FROM dbo.GeneralClassiFication       
 WHERE Code=(SELECT BrandCode FROM dbo.Product WHERE ProductId=VROD.ProductId)      
 AND Name=(SELECT Brand FROM dbo.Product WHERE ProductId=VROD.ProductId)) AS BrandId,
 ReturnQty - VROD.InQty as DiffQty,
 VRO.PlatformStatus
FROM dbo.VipReturnOrder(NOLOCK) VRO
LEFT JOIN dbo.VipReturnOrderDetail(NOLOCK) VROD ON VROD.ReturnOrderId = VRO.Id

go

