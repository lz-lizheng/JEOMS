






-- 根据品牌方需求和若羽臣实际业务情况，此前开发的视图需要进行逻辑修改。修改逻辑如下：
-- 1、[V_ScPurchaseOrder]和[V_ScPurchaseReturnOrder]采购表与采退表里采购方更改为广州若羽臣科技股份有限公司，销售方更改为惠氏制药有限公司，且产品编码取商品资料的“自定义属性20”字段，自定义属性20字段若羽臣已修改
--  为惠氏Code，如果惠氏Code为空则不提供数据；

/******金蝶销采购退货单  Script Date: 2017/9/8 10:43:19 ******/
CREATE view [dbo].[V_ScPurchaseReturnOrder]
as
select pnod.WarehouseDeliveryTime as 日期,'1200917' as 销售方代码,'惠氏制药有限公司' as 销售方名称,
'0366' as 采购方代码,'广州若羽臣科技股份有限公司' as 采购方名称,　p.Attribute20 as 产品代码,
pnod.ProductName as 产品名称,p.Attribute6 as 产品规格,'' as 批号,pnod.OutStockQty as 数量
,pod.CurrentPrice as 单价,pod.CurrentPrice*pnod.OutStockQty as 金额,p.Unit as 单位,
p.Attribute2 as 产地,p.CategoryName as 产品分类,p.Brand as 品牌名称,p.BrandCode as 品牌编码
 from PurchaseReturnOrder pno
 join PurchaseReturnOrderDetail pnod on pno.Id = pnod.PurchaseReturnOrderId
 join PurchaseOrder po on po.Id = pno.PurchaseOrderId
 join PurchaseOrderDetail pod on pod.PurchaseOrderId = po.Id and pnod.SkuId = pod.SkuId
 left join Company c on po.SupplierComanyName = c.Name
 left join Warehouse w on po.WarehouseID = w.Id
 left join Product p on p.ProductId = pnod.ProductId
 where p.BrandCode in('094','130') and po.SupplierCode='0366'
and isnull(p.Attribute20, '') <> ''
-- and p.ProductType !=1


go

