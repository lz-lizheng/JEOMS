





/******金蝶销售出库单  Script Date: 2017/5/4 10:43:19 ******/
CREATE view [dbo].[V_KindeeStorageOrder]
as
select dod.Id as 明细行ID,do.Code as 单据编号,dod.WarehouseStorageTime as 入库日期,do.Remark as 备注
,dod.SkuCode as 物料编码,
dod.InQty as 实收数量,
w.Code as 仓库,do.TypeName as 单据类型,isnull(dod.UnitPrice,0) as 商品单价,isnull(dod.UnitPrice,0)*isnull(dod.InQty,0) as 商品金额
 from StorageOrder do 
join StorageOrderDetail dod on do.Id = dod.StorageOrderId
join Warehouse w on do.WarehouseId = w.Id
where dod.WarehouseStorageTime is not null



go

