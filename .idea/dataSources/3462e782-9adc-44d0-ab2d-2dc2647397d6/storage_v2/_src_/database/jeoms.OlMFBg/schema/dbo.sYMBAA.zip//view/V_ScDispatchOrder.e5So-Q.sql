  
  
  
  
-- [V_ScDispatchOrder]和[V_ScReturnOrder]--销售表与退货表里采购方直接取订单里面店铺名称，销售方更改为广州若羽臣科技股份有限公司，且产品编码取商品资料的“自定义属性20”字段，自定义属性20字段若羽臣已修改  
-- 为惠氏Code，如果惠氏Code为空则不提供数据；  
  
--惠氏制药有限公司  采购方名称  
  
  
/******金蝶销售出库单  Script Date: 2017/9/6 14:43:19 ******/  
CREATE view [dbo].[V_ScDispatchOrder]  
as  
  
select do.DeliveryDate as 日期,'1200917' as 销售方代码,'广州若羽臣科技股份有限公司' as 销售方名称,  
'0366' as 采购方代码, s.Name as 采购方名称, p.Attribute20 as 产品代码,  
dod.ProductName as 产品名称,p.Attribute6 as 产品规格,'' as 批号,dod.Quantity as 数量  
,Convert(decimal(18,2),dod.AmountActual/dod.Quantity) as 单价,dod.AmountActual as 金额,p.Unit as 单位,  
p.Attribute2 as 产地,p.CategoryName as 产品分类,p.Brand as 品牌名称,p.BrandCode as 品牌编码  
 from DispatchOrder do   
join DispatchOrderDetail dod on do.Id = dod.DispatchOrderId  
join SalesOrderDetail sod on dod.SalesOrderDetailId = sod.DetailId  
join Store s on s.Id = do.StoreId  
join Company c on s.CompanyId = c.Id  
join Product p on p.ProductId = dod.ProductId  
where do.Status=4 and dod.Status=2  
and p.Brand in ('caltrate/钙尔奇','Centrum/善存')
and isnull(p.Attribute20, '') <> ''



go

