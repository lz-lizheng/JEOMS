







/******金蝶销售出库单  Script Date: 2017/5/4 10:43:19 ******/
CREATE view [dbo].[V_KindeeReturnOrder]
as
select dod.Id as 明细行ID,do.Code as 单据编号,rnd.WarehouseStorageTime as 日期,c.Code as 销售组织
,s.Code as 销售部门,s.Code as 退货客户,c.Code as 库存组织,dod.SkuCode as 物料编码,
isnull(dod.StorageQuantity,0) as 实退数量,dod.RefundAmount as 金额,dod.RefundAmount as 价税合计,
c.LawUser as 仓库,dod.TradeId as 来源单号,dbo.F_GetKindeeStoreTypeCode(s.StoreType) as 店铺类型
 from ReturnOrder do 
join ReturnOrderDetail dod on do.Id = dod.ReturnOrderId
join ReturnOrderNoticeDetail rnd on dod.Id = rnd.ReturnOrderDetailId
join Store s on s.Id = do.StoreId
join Company c on s.CompanyId = c.Id 
where do.StorageStatus!=0 and isnull(dod.StorageQuantity,0)>0


go

