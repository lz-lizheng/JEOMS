

  
  
  
CREATE Procedure [dbo].[P_Clear_Log] as   
Begin   
    Declare @V_Date_1 DateTime,@V_Date_5 DateTime,@V_Date_10 DateTime,@V_Date_15 DateTime, @V_Date_30 DateTime, @V_Date_60 DateTime, @V_Date_90 DateTime, @V_Date_120 DateTime, @V_Date_150 DateTime, @V_Date_180 DateTime, @V_Date_365 dateTime, @V_Date_720 DateTime;  
    Declare @V_rowcnt decimal(15, 0), @V_TotalRow decimal(15, 0)  
    Set @V_Date_1 = DATEADD(Day, -1, GetDate()) Print Convert(Varchar(10), @V_Date_1, 20)  
    Set @V_Date_5 = DATEADD(Day, -5, GetDate()) Print Convert(Varchar(10), @V_Date_5, 20)  
    Set @V_Date_10 = DATEADD(Day, -10, GetDate()) Print Convert(Varchar(10), @V_Date_10, 20)  
    Set @V_Date_15 = DATEADD(Day, -15, GetDate()) Print Convert(Varchar(10), @V_Date_15, 20)  
    Set @V_Date_30 = DATEADD(Day, -30, GetDate()) Print Convert(Varchar(10), @V_Date_30, 20)  
    Set @V_Date_60 = DATEADD(Day, -60, GetDate()) Print Convert(Varchar(10), @V_Date_60, 20)  
    Set @V_Date_90 = DATEADD(Day, -90, GetDate()) Print Convert(Varchar(10), @V_Date_90, 20)  
    Set @V_Date_120 = DATEADD(Day, -120, GetDate()) Print Convert(Varchar(10), @V_Date_120, 20)  
    Set @V_Date_150 = DATEADD(Day, -150, GetDate()) Print Convert(Varchar(10), @V_Date_150, 20)  
    Set @V_Date_180 = DATEADD(Day, -180, GetDate()) Print Convert(Varchar(10), @V_Date_180, 20)  
	Set @V_Date_365 = DATEADD(Day, -365, GetDate()) Print Convert(Varchar(10), @V_Date_365, 20)  
	
  Set @V_Date_720 = DATEADD(YEAR, -2, GetDate()) Print Convert(Varchar(10), @V_Date_720, 20)    
  
  
    Print 'Clear Ods ---- ' + Convert(varchar(20), getdate(), 20) + '  PlatformExchangeOrder 10 '  
    Set @V_rowcnt = 0  
        
    Select @V_TotalRow  = Count(1) FROM jeods.dbo.PlatformExchangeOrder WHERE RecordDate < @V_Date_10 And SyncStatus = 4  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeods.dbo.PlatformExchangeOrder WHERE RecordDate < @V_Date_10 And SyncStatus = 4  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--PlatformExchangeOrd
er--' + Convert(varchar(20), getdate(), 20)  
      END  
  
    Print 'Clear Ods ---- ' + Convert(varchar(20), getdate(), 20) + '  PlatformRefund 10 '  
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeods.dbo.PlatformRefund WHERE RecordDate < @V_Date_10 And SyncStatus = 4  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeods.dbo.PlatformRefund WHERE RecordDate < @V_Date_10 And SyncStatus = 4  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--PlatformRefund--' +
 Convert(varchar(20), getdate(), 20)  
      END  
  
    Print 'Clear Ods ---- ' + Convert(varchar(20), getdate(), 20) + '  PlatformOrder 10'  
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM  jeods.dbo.PlatformOrder WHERE RecordDate < @V_Date_10 And SyncStatus = 4  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeods.dbo.PlatformOrder WHERE RecordDate < @V_Date_10 And SyncStatus = 4  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--PlatformOrder--' + 
Convert(varchar(20), getdate(), 20)  
      END  
  
    Print 'Clear Ods ---- ' + Convert(varchar(20), getdate(), 20) + '  PlatformOrder_Created 60'  
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM  jeods.dbo.PlatformOrder_Created WHERE CreateDate < @V_Date_60    
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeods.dbo.PlatformOrder_Created WHERE CreateDate < @V_Date_60    
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--PlatformOrder_Creat
ed--' + Convert(varchar(20), getdate(), 20)  
      END  
     
  
    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     ApiInventoryChange 90 '     
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiInventoryChange WHERE CreateDate < @V_Date_90 and status = 2  and StockSyncStatus = 2
  
    if not exists( Select * From sys.sysobjects Where Name = 'ApiInventoryChangeHistory' )  
      Begin  
        Select Top 0 * into jeoms.dbo.ApiInventoryChangeHistory From jeoms.dbo.ApiInventoryChange  
      End  
    WHILE 1 = 1  
      BEGIN  
        Select Top 1000 ChangeId Into #TmpChangeId From jeoms.dbo.ApiInventoryChange WHERE CreateDate < @V_Date_90 and status = 2  and StockSyncStatus = 2
  
        Insert Into jeoms.dbo.ApiInventoryChangeHistory (changeid, createdate, id, status, fromno, fromty, whcode, descri, apuser, aptime, sku, qty, stocksyncstatus, isvirtualwarehouse, boxno, isfull, ispush, inventorytype, expresscode, expressnumber, uniquecode, isenableuniquecode, ownercode, outsidewarehousecode, warehouseid, skuid, inventoryinfo, batchinfo, isfinish, modifydate) Select changeid, createdate, id, status, fromno, fromty, whcode, descri, apuser, aptime, sku, qty, stocksyncstatus, isvirtualwarehouse, boxno, isfull, ispush, inventorytype, expresscode, expressnumber, uniquecode, isenableuniquecode, ownercode, outsidewarehousecode, warehouseid, skuid, inventoryinfo, batchinfo, isfinish, modifydate From jeoms.dbo.ApiInventoryChange Where ChangeId In (Select * From #TmpChangeId)
                
        DELETE TOP(1000) FROM jeoms.dbo.ApiInventoryChange WHERE ChangeId In (Select * From #TmpChangeId)  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--ApiInventoryChange-
-' + Convert(varchar(20), getdate(), 20)  
        Drop table #TmpChangeId;  
      END  
  
    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     ApiInventoryChange_isFull 1'    
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiInventoryChange WHERE  CreateDate < @V_Date_1 and Status = 2 and StockSyncStatus = 2 and IsFull = 1  
    WHILE 1 = 1  
      BEGIN  
        Select Top 1000 ChangeId Into #Tmp01ChangeId From jeoms.dbo.ApiInventoryChange WHERE CreateDate < @V_Date_1 and Status = 2 and StockSyncStatus = 2 and IsFull = 1  
  
        DELETE TOP(1000) FROM jeoms.dbo.ApiInventoryChange WHERE ChangeId In (Select * From #Tmp01ChangeId)  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--ApiInventoryChange_
isFull--' + Convert(varchar(20), getdate(), 20)  
  
        Drop table #Tmp01ChangeId;  
      END  
  
    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     ApiInventoryChangeHistory 180 '     
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiInventoryChangeHistory WHERE CreateDate < @V_Date_180  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeoms.dbo.ApiInventoryChangeHistory WHERE CreateDate < @V_Date_180  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--ApiInventoryChangeH
istory--' + Convert(varchar(20), getdate(), 20)  
      END  
  
  
  
    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     DistributionLog 30'     
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.DistributionLog WHERE CreateDate < @V_Date_30  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeoms.dbo.DistributionLog WHERE CreateDate < @V_Date_30  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--DistributionLog--' 
+ Convert(varchar(20), getdate(), 20)  
      END  
  
  
    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     InventoryUploadLog 15'    
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.InventoryUploadLog WHERE CreateDate < @V_Date_15  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeoms.dbo.InventoryUploadLog WHERE CreateDate < @V_Date_15  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--InventoryUploadLog-
-' + Convert(varchar(20), getdate(), 20)  
      END  
     
    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     ApiDeliveryCompleted 180'     
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiDeliveryCompleted WHERE CreateDate < @V_Date_180 and status = 2  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeoms.dbo.ApiDeliveryCompleted WHERE CreateDate < @V_Date_180 and status = 2  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--ApiDeliveryComplete
d--' + Convert(varchar(20), getdate(), 20)  
      END  
  
  
    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     ApiDeliveryCompletedDetail 180'     
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiDeliveryCompletedDetail WHERE CreateDate < @V_Date_180  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeoms.dbo.ApiDeliveryCompletedDetail WHERE CreateDate < @V_Date_180  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' +  '--ApiDeliveryComplet
edDetail--' + Convert(varchar(20), getdate(), 20)  
      END   
     
      Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     DispatchOrderProcessReport 180'     
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.DispatchOrderProcessReport WHERE CreateDate < @V_Date_180  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeoms.dbo.DispatchOrderProcessReport WHERE CreateDate < @V_Date_180  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--DispatchOrderProces
sReport--' + Convert(varchar(20), getdate(), 20)  
      END  
  
  Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     ApiProductInventoryTracking 180 '     
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiProductInventoryTracking WHERE ChangeDate < @V_Date_180  
  
    if not exists( Select * From sys.sysobjects Where Name = 'ApiProductInventoryTrackingHistory' )  
      Begin  
        Select Top 0 * into jeoms.dbo.ApiProductInventoryTrackingHistory From jeoms.dbo.ApiProductInventoryTracking  
      End  
    WHILE 1 = 1  
      BEGIN  
        Select Top 1000 Id Into #TmpInventoryTrackingId From jeoms.dbo.ApiProductInventoryTracking WHERE ChangeDate < @V_Date_180  
  
        Insert Into jeoms.dbo.ApiProductInventoryTrackingHistory Select * From jeoms.dbo.ApiProductInventoryTracking Where Id In (Select * From #TmpInventoryTrackingId)  
                
        DELETE TOP(1000) FROM jeoms.dbo.ApiProductInventoryTracking WHERE Id In (Select * From #TmpInventoryTrackingId)  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--ApiProductInventory
Tracking--' + Convert(varchar(20), getdate(), 20)  
        Drop table #TmpInventoryTrackingId;  
      END    
      
    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     ApiProductInventoryTrackingHistory 720'    
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiProductInventoryTrackingHistory WHERE ChangeDate < @V_Date_720  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeoms.dbo.ApiProductInventoryTrackingHistory WHERE ChangeDate < @V_Date_720  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--ApiProductInventory
TrackingHistory--' + Convert(varchar(20), getdate(), 20)  
      END  
  
    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     MallRequestInfo 5'    
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.MallRequestInfo WHERE CreateDate < @V_Date_5  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeoms.dbo.MallRequestInfo WHERE CreateDate < @V_Date_5  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--MallRequestInfo--' 
+ Convert(varchar(20), getdate(), 20)  
      END  
  
    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     ApiLog 30 '     
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiLog WHERE CreateDate < @V_Date_30  
  
    if not exists( Select * From sys.sysobjects Where Name = 'ApiLogHistory' )  
      Begin  
        Select Top 0 * into jeoms.dbo.ApiLogHistory From jeoms.dbo.ApiLog  
      End  
    WHILE 1 = 1  
      BEGIN  
        Select Top 1000 Id Into #TmpApiId From jeoms.dbo.ApiLog WHERE CreateDate < @V_Date_30  
  
        Insert Into jeoms.dbo.ApiLogHistory Select * From jeoms.dbo.ApiLog Where Id In (Select * From #TmpApiId)  
                 
        DELETE TOP(1000) FROM jeoms.dbo.ApiLog WHERE Id In (Select * From #TmpApiId)  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--ApiLog--' + Convert
(varchar(20), getdate(), 20)  
        Drop table #TmpApiId;  
      END  
  
    Print 'Clear OMS ***** ' + Convert(varchar(20), getdate(), 20) + '     ApiLogHistory 90'     
    Set @V_rowcnt = 0  
    Select @V_TotalRow  = Count(1) FROM jeoms.dbo.ApiLogHistory WHERE CreateDate < @V_Date_90  
    WHILE 1 = 1  
      BEGIN  
        DELETE TOP(1000) FROM jeoms.dbo.ApiLogHistory WHERE CreateDate < @V_Date_90  
        if @@rowcount < 1000  
          Begin  
            print '-- Break'  
            Break;  
          End    
        Set @V_rowcnt +=  1000;  
        print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--ApiLogHistory--' + 
Convert(varchar(20), getdate(), 20)  
      END  
 Print 'Insert PlatformOrder_Created ***** SyncStatus = 0'  
	  INSERT INTO jeods.dbo.PlatformOrder_Created(Id, CreateDate, StoreId, Tid)  
	  select cast(Convert(Varchar(10), getDate(), 12) as decimal(10)) * 1000000 + ROW_NUMBER() over (order by rd.Id) as Id, getdate(), rd.StoreId, rd.Tid from (
			Select row_number() over (partition by pr.RefundCode order by RecordDate desc) RowId,pr.Id, pr.StoreId, pr.Tid, pr.RecordDate, pr.RefundCode, st.Name
			From jeods.dbo.PlatformRefund Pr left join jeoms.dbo.Store st on pr.StoreId = st.Id
			Where Pr.SyncStatus = 0 and st.PlatformType in (2, 4, 22, 23, 61)
			And Not Exists (Select 1 From jeods.dbo.PlatformOrder_Created Prc where pr.StoreId = Prc.StoreId and pr.tid = Prc.Tid)  
			And Exists (Select 1 From jeoms.dbo.SalesOrder so where pr.StoreId = so.StoreId and pr.Tid = so.TradeId and so.IsAutoDownload = 1 )) rd
	  where rd.RowId = 1;  

	   
	   Print 'DataCallCustomRecord_History Start ' 
			Set @V_rowcnt = 0  
			Select @V_TotalRow  = Count(1) FROM jeoms.dbo.DataCallCustomRecord  WHERE FirstTime < @V_Date_180  
  
		if not exists( Select * From sys.sysobjects Where Name = 'DataCallCustomRecord' )  
		  Begin  
			Select Top 0 * into jeoms.dbo.DataCallCustomRecord_History From jeoms.dbo.DataCallCustomRecord  
		  End  
		WHILE 1 = 1  
		  BEGIN  
			Select Top 1000 Id Into #TmpDataCallCustomRecord_HistoryId From jeoms.dbo.DataCallCustomRecord WHERE FirstTime < @V_Date_180  
  
			Insert Into jeoms.dbo.DataCallCustomRecord_History Select * From jeoms.dbo.DataCallCustomRecord Where Id In (Select * From #TmpDataCallCustomRecord_HistoryId)  
                 
			DELETE TOP(1000) FROM jeoms.dbo.DataCallCustomRecord WHERE Id In (Select * From #TmpDataCallCustomRecord_HistoryId)  
			if @@rowcount < 1000  
			  Begin  
				print '-- Break'  
				Break;  
			  End    
			Set @V_rowcnt +=  1000;  
			print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--ApiLog--' + Convert
	(varchar(20), getdate(), 20)  
			Drop table #TmpDataCallCustomRecord_HistoryId;  
		  END 

	   
 --From DataCallCustomRecord_History DataCallCustomRecord
		Print 'DataCallRecord_History Start ' 
		Set @V_rowcnt = 0  
			Select @V_TotalRow  = Count(1) FROM jeoms.dbo.DataCallRecord  WHERE FirstTime < @V_Date_180  
  
		if not exists( Select * From sys.sysobjects Where Name = 'DataCallCustomRecord' )  
		  Begin  
			Select Top 0 * into jeoms.dbo.DataCallRecord_History From jeoms.dbo.DataCallRecord  
		  End  
		WHILE 1 = 1  
		  BEGIN  
			Select Top 1000 Id Into #TmpDataCallRecordId From jeoms.dbo.DataCallRecord WHERE FirstTime < @V_Date_180  
  
			Insert Into jeoms.dbo.DataCallRecord_History Select * From jeoms.dbo.DataCallRecord Where Id In (Select * From #TmpDataCallRecordId)  
                 
			DELETE TOP(1000) FROM jeoms.dbo.DataCallRecord WHERE Id In (Select * From #TmpDataCallRecordId)  
			if @@rowcount < 1000  
			  Begin  
				print '-- Break'  
				Break;  
			  End    
			Set @V_rowcnt +=  1000;  
			print  'Cur Clear ' + cast(@V_rowcnt  as varchar(20)) +'  /  Total '+ cast(@V_TotalRow as nvarchar(20)) + '   Rate : ' + Cast( cast(Round(@V_rowcnt * 1.0 / @V_TotalRow, 2) * 100  as decimal(15, 2)) as nvarchar(20)) + '%  ' + '--ApiLog--' + Convert
	(varchar(20), getdate(), 20)  
			Drop table #TmpDataCallRecordId;  
		  END 
		    


	  	  Print 'Clear NoneQuantityInventoryVirtual Start'
			SELECT
	WarehouseId,SkuId INTO #TempInventoryVirtualWareIdSkuId 
FROM
	V_InventoryVirtual 
WHERE
--库存数
	 Quantity = 0 
	--已配货数
	AND DispatchedQuantity = 0 
	--订单占用数
	AND UnDispatchedQuantity = 0 
	--调拨占用
	AND AllotQuantity = 0 
	--唯品占用
	AND VipQuantity = 0 
	--组合占用数
	AND CombQuantity = 0 
	--可用数
	AND CanUseQuantity = 0 
	--在途数
	AND TransitTotalQuantity = 0 
	
--删除
DELETE FROM InventoryVirtual 
WHERE id IN ( SELECT id FROM InventoryVirtual a INNER JOIN #TempInventoryVirtualWareIdSkuId b ON a.warehouseId= b.warehouseId AND a.SkuId= b.SkuId );	
DROP TABLE #TempInventoryVirtualWareIdSkuId ;
		Print 'Clear NoneQuantityInventoryVirtua End'
End;


go

