









/******金蝶销售出库单  Script Date: 2017/5/4 10:43:19 ******/
CREATE view [dbo].[V_KindeeB2BReturnOrder]
as
select dod.Id as 明细行ID, do.Code as 单据编号,dod.WarehouseStorageTime as 日期,c.Code as 销售组织
,s.Code as 销售部门,s.Code as 客户,c.Code as 发货组织,dod.SkuCode as 物料编码,
isnull(dod.InQty,0)+isnull(dod.DefectiveQuantity,0) as 实退数量,dod.Price as 单价,dod.Price*dod.InQty+dod.Price*dod.DefectiveQuantity as 价税合计,
c.LawUser as 仓库,dbo.F_GetKindeeStoreTypeCode(s.StoreType) as 店铺类型,do.ScheduleNo as 批次号
 from B2BReturnOrderNotice do 
join B2BReturnOrderNoticeDetail dod on do.Id = dod.ReturnOrderNoticeId
join Store s on s.Id = do.StoreId
join Company c on s.CompanyId = c.Id 
where dod.WarehouseStorageTime is not null



go

