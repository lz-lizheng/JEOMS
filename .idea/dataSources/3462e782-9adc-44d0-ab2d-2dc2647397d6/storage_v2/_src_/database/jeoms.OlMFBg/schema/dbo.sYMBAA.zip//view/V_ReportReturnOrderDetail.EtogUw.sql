
/**********************
*create date : 2021-09-18
*create by：程铮
*remark ：【【三彩】-退换货单、商品信息、相关需求【deadline 2021-09-09】】 
https://www.tapd.cn/38026101/prong/stories/view/1138026101001009550
***********************/
CREATE VIEW [dbo].[V_ReportReturnOrderDetail]
AS
SELECT
ROD.Id AS ReturnOrderDetailId,
RO.Code, --退货单号
RO.Message,--退货备注
RO.Note, --退货备注
RO.TradeId AS TradeId, --交易号
RO.IsAbnormal,   --是否异常
ISNULL(SO.Code,ROD.SalesOrderCode) AS SOrderCode, --订单编号
Do.Code as DispatchOrderCode,--配货单号
RO.ExpressNo AS RtnExpressNo,--快递单号
RO.StoreName AS StoreName,--店铺名称
RO.Status,--退换货单状态
RO.ReturnOrderTypeId, --退货类型ID
RO.ReturnOrderTypeName,--退货类型
ROD.ProductCode,--商品编码
ROD.ProductName,--商品名称
ROD.SkuCode, --规格编码
ROD.SkuName, --规格名称
ROD.StorageQuantity,
ROD.RefundAmount,--实际退款金额
ROD.ActualAmount,--应退金额
ROD.OffsetAmount,--补偿金额
RO.CreateDate, --制单日期
RO.CreateUserName,--制单人
RO.ApproveDate, --确认日期
RO.ApproveUser, --确认人
RO.AuditDate, --复核日期
RO.AuditUser, --复核人
ISNULL(SO.Code,ROD.SalesOrderCode) AS ShhOrderCode, --换货订单编号
RO.StoreId AS StoreId,-- 店铺ID
ST.Code AS StoreCode,-- 店铺编码
RO.ReturnStyle,-- 退货方式
ROD.Quantity,-- 退货数量
ROD.DetailResionName, --明细退货原因,
ROD.Remark,
PD.FirstPrice,-- 吊牌价
PD.RetailPrice,-- 零售价
PD.Brand, -- 品牌
PD.FirstCost,-- 财务成本
RO.MemberCode,-- 客户编码
RO.MemberName,-- 客户名称
ISNULL(SOD.AmountActual,0) / ISNULL(SOD.Quantity,1) AS AmountActual, -- 销售单价
DO.DeliveryDate,--发货日期
SO.PayDate, -- 付款日期　
ro.IsReplace,-- 换货订单
do.WarehouseName,-- 发货仓库
dodm.WarehouseName AS VirWarehouseName, --虚拟发货仓库
ar.Status AS ApplyRefundOrderStatus, -- 售后申请状态
ron.Code NoticeCode, --通知单号
rod.DistributionAmount, --分销金额
RO.ScanTime, --扫描时间
RO.ExpressName, --快递公司
RO.WarehouseInId, --入库仓库Id
RO.WarehouseInName,--入库仓库名称
ron.PushDate,
RO.TagName,
ron.WarehouseStorageTime,
RO.ScanUser,
ROD.UniqueCode
,PD.Year --年份
,PD.Season --季节
,PD.CategoryName --三级分类名称
,PD.FirstLevelCategoryName --一级分类名称
,PD.TwoLevelCategoryName --二级分类名称
,PD.ShortName as ProductShortName --商品简称
FROM dbo.ReturnOrder(NOLOCK) RO
LEFT JOIN dbo.Store(NOLOCK) ST ON RO.StoreId = ST.Id
LEFT JOIN dbo.ReturnOrderDetail(NOLOCK) ROD ON RO.Id = ROD.ReturnOrderId
LEFT JOIN dbo.SalesOrder(NOLOCK) SO ON ROD.SalesOrderId = SO.OrderId
LEFT JOIN dbo.Product(NOLOCK) PD ON ROD.ProductId = PD.ProductId
LEFT JOIN dbo.SalesOrderDetail(NOLOCK) SOD ON ROD.SalesOrderDetailId = SOD.DetailId
LEFT JOIN dbo.DispatchOrderDetail dodm(NOLOCK) ON SOD.DetailId = dodm.SalesOrderDetailId and dodm.Status <> 1
LEFT JOIN dbo.DispatchOrder(NOLOCK) do ON dodm.DispatchOrderId = do.Id AND ISNULL(do.Status, 0) <> 3
LEFT JOIN (
select Code,PushDate,WarehouseStorageTime,ReturnOrderDetailId,ReturnOrderId
from ReturnOrderNoticeDetail(nolock) ronl
join ReturnOrderNotice(nolock) ron on ron.Id=ronl.NoticeId
where ron.Status<>3
) ron on ron.ReturnOrderDetailId=ROD.Id and ron.ReturnOrderId=RO.Id
LEFT JOIN ( SELECT TradeId, SkuCode, MAX(ar.Status) AS Status
 FROM ApplyRefundOrder ar
 WHERE SkuCode IS NOT NULL
 GROUP BY TradeId, SkuCode
 ) AR ON rod.TradeId = ar.TradeId AND rod.SkuCode = ar.SkuCode
WHERE RO.IsObsolete = 0
go

