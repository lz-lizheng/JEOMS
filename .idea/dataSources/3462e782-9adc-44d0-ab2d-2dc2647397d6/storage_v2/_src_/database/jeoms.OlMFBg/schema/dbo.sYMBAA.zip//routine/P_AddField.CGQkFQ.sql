CREATE PROCEDURE [dbo].[P_AddField]
  (
    @id UNIQUEIDENTIFIER=NULL,
    @name VARCHAR(50),--名称
    @column VARCHAR(50)=NULL,--列名
    @type INT=0,--类型，0容器，1操作项
    @isSystem BIT=0,--是否系统操作项
    @parentId UNIQUEIDENTIFIER=NULL,--父ID
    @initPrivilege BIT=1--是否初始化管理员角色权限
  )
AS
  DECLARE @orderId INT
  IF @id IS NULL
    SET @id= NEWID()
  --添加操作项
  BEGIN TRAN
  IF @parentId IS NULL
    SELECT @orderId = ISNULL(MAX(OrderId),0)+1 FROM dbo.[Field]  WHERE ParentId IS NULL
  ELSE
    SELECT @orderId = ISNULL(MAX(OrderId),0)+1 FROM dbo.[Field]  WHERE ParentId=@parentId
  INSERT INTO [Field] ( Id, [Name],[COLUMN], Type, IsSystem, ParentId,OrderId)
  VALUES  ( @id,@name,@column,@type,@isSystem,@parentId,@orderId)
  IF	@initPrivilege=1
    BEGIN
      --添加权限
      INSERT INTO dbo.Privilege ( Id, OperaterId, ObjectId, Type )
        SELECT NEWID(),Id,@id,102 FROM dbo.Role WHERE IsSystem=1
    END
  IF	@@ERROR<>0
    ROLLBACK TRAN
  ELSE
    COMMIT TRAN

go

