CREATE view V_KindeeSupplier
as
select Code 供应商编码,ShortName 供应商简称,FullName 供应商全称 from Supplier
go

