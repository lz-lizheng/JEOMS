create view V_ScCheckLossOrder
as
select cod.WarehouseConfirmDate as '日期','100' as '销售方代码','广州若羽臣科技股份有限公司' as '销售方名称','002' as '采购方代码','盘亏' as '采购方名称',p.Attribute20 as '产品代码',p.Description as '产品名称',p.Attribute6 as '产品规格','' as '批号',cod.OutQuatity as '数量',p.Unit as '单位',p.FirstCost as '单价',p.FirstCost*cod.OutQuatity as '金额',p.Attribute2 as '生产厂家','' as '产品分类'
from CheckLossOverOrder co
join CheckLossOverOrderDetail cod on cod.OrderId=co.Id
left join Product p on cod.ProductId=p.ProductId
where co.Status=5 and cod.InQuantity>0 and p.BrandCode in ('094','130') and isnull(p.Attribute20,'')<>'' and co.OrderType=0
go

