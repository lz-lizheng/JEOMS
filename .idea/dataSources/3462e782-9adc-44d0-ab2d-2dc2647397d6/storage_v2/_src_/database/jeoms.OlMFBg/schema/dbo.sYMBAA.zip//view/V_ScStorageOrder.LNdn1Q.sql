
CREATE view [dbo].[V_ScStorageOrder]  
as  
select sod.WarehouseStorageTime as '日期','100' as '销售方代码','广州若羽臣科技股份有限公司' as '销售方名称','004' as '采购方代码','入库' as '采购方名称',p.Attribute20 as '产品代码',p.Description as '产品名称',p.Attribute6 as '产品规格','' as '批号',sod.InQty as '数量',p.Unit as '单位',
sod.UnitPrice as '单价',sod.PlanQty*sod.UnitPrice as '金额',p.Attribute2 as '生产厂家','' as '产品分类'  
from StorageOrder so  
join StorageOrderDetail sod on sod.StorageOrderId=so.Id  
left join Product p on sod.ProductId=p.ProductId  
where so.Status in (3,4,10) and sod.InQty>0 and p.BrandCode in ('094','130') and isnull(p.Attribute20,'')<>''
go

