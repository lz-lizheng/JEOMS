




CREATE view [dbo].[V_KindeeCombinedProduct]
as
select dod.Id as 明细行ID,do.Code 套装编码,do.GiftSkuCode as 父项物料编码,dod.SkuCode as 子项物料编码,dod.Quantity as 分子
 from ProductSku do 
join CombinedProductDetail dod on do.SkuId = dod.CombinedProductId
where do.Status=1 and do.IsCombined=1
and do.GiftSkuCode is not NULL and do.GiftSkuCode<>''



go

