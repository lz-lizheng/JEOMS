

/**********************
*create  date:  2018-12-21
*create  by：Byron
*remark  ：唯品发货增加结算价
*Modified : QiaoNi, 2018-08-16
***********************/    
CREATE  VIEW  [dbo].[V_VipDeliveryOrder]  AS
Select  
vdo.StoreId,
vdo.StoreName,
vdod.PoCode,
vdo.DispatchOrderCode  as  DispatchOrderCode,
vdo.Status,
vdo.PickingCode,
Vdo.WarehouseId  as  WarehouseId,
Vdo.WarehouseName  as  WarehouseName,  
vdod.ProductCode,
vdod.ProductName,
vdod.SkuCode,
vdod.SkuName,
vdod.VipSkuCode,
vdod.NoticeQty,
vdod.OutQty,
vdo.SendWarehouseId,
vdo.SendWarehouseName,
isnull(vdod.WarehousingTime,  vdod.WarehouseDeliveryTime)  as  WarehousingTime,
vdo.CreateDate,
Vdo.BrandCode,  
Vdo.BrandName,
vdo.StorageNo,
vdo.SendWarehouseName as InWarehouseName,
vdod.SupplyPrice*vdod.OutQty as SalesAmount,
vdod.SupplyPrice
From  dbo.VipDispatchOrder  Vdo(nolock)
left  join  VipDispatchOrderDetail  vdod(nolock)  on  Vdo.Id  =  vdod.DispatchOrderId
go

