/********
*create date: 2019-6-26
*create by：拓斗
*remark ：若羽臣-入库单汇总表视图
*******/
CREATE VIEW [dbo].[V_StorageOrderSummary]  
AS  
SELECT so.VirtualWarehouseId,so.VirtualWarehouseName,SUM(sod.InQty) InQty,SUM(sod.InQty*sod.UnitPrice) Price,  
TypeCode,TypeName,sod.WarehouseStorageTime  
FROM dbo.StorageOrder so  
LEFT JOIN dbo.StorageOrderDetail sod ON sod.StorageOrderId=so.Id  
WHERE so.Status IN (3,4,10)  
AND TypeCode IN ('LHZH03','LHZH02','PYRK01','PYRK')  
GROUP BY so.VirtualWarehouseId,so.VirtualWarehouseName,TypeCode,TypeName,sod.WarehouseStorageTime
go

