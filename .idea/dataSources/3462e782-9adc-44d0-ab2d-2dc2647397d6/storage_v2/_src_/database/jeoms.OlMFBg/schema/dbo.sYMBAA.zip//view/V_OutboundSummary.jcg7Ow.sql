/********
*create date: 2019-6-24
*create by：拓斗
*remark ：若羽臣-2B&2C出库汇总表视图
*******/
CREATE VIEW [dbo].[V_OutboundSummary]
AS
SELECT StoreId,StoreCode,StoreName,DeliveryDate,SUM(DisNum) DisNum,SUM(SaleNum) SaleNum,SUM(B2bNum) B2bNum,isnull(SUM(Quantity),0) Quantity,
isnull(SUM(ExpressFee),0) ExpressFee,isnull(SUM(AmountActual),0) AmountActual
FROM
(
--计算2c订单的数据
SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,ISNULL(DO.DeliveryDate,so.CreateDate) as DeliveryDate
,COUNT(distinct dod.DispatchOrderCode) as DisNum,count(distinct so.Code) as SaleNum,0 as B2bNum,sum(sod.Quantity) as Quantity
,0 as ExpressFee,sum(sod.AmountActual) as AmountActual
FROM dbo.SalesOrder(nolock) so
LEFT JOIN dbo.SalesOrderDetail(nolock) sod ON so.OrderId=sod.SalesOrderId
LEFT JOIN dbo.Store(nolock) s ON s.Id=so.StoreId
LEFT JOIN dbo.DispatchOrderDetail(nolock) dod ON dod.SalesOrderDetailId=sod.DetailId 
LEFT JOIN dbo.DispatchOrder(NOLOCK) DO ON dod.DispatchOrderId=DO.Id 
WHERE((dod.Status=2 and DO.Status=4) or (so.Status=32 and isnull(DO.Code,'')='')) and sod.IsAbnormal=0 and sod.IsDeleted=0
group by s.Id,s.Code,s.Name,ISNULL(DO.DeliveryDate,so.CreateDate)

union all 

select StoreId,StoreCode,StoreName,DeliveryDate,DisNum,SaleNum,B2bNum,Quantity,sum(ExpressFee) as ExpressFee,AmountActual from (
SELECT row_number() over(partition by s.Id,s.Code,s.Name,so.Code order by ISNULL(DO.DeliveryDate,so.CreateDate)) OrderId , s.Id StoreId,s.Code StoreCode,s.Name StoreName,
ISNULL(DO.DeliveryDate,so.CreateDate) as DeliveryDate,0 as DisNum,0 as SaleNum,0 as B2bNum,0 as Quantity
,SO.ExpressFee as ExpressFee,0 as AmountActual,so.Code
FROM dbo.SalesOrder(nolock) so
LEFT JOIN dbo.SalesOrderDetail(nolock) sod ON so.OrderId=sod.SalesOrderId
LEFT JOIN dbo.Store(nolock) s ON s.Id=so.StoreId
LEFT JOIN dbo.DispatchOrderDetail(nolock) dod ON dod.SalesOrderDetailId=sod.DetailId 
LEFT JOIN dbo.DispatchOrder(NOLOCK) DO ON dod.DispatchOrderId=DO.Id 
WHERE((dod.Status=2 and DO.Status=4) or (so.Status=32 and isnull(DO.Code,'')='')) and sod.IsAbnormal=0 and sod.IsDeleted=0) a
where OrderId=1
group by StoreId,StoreCode,StoreName,DeliveryDate,DisNum,SaleNum,B2bNum,Quantity,AmountActual

union all
--计算2b订单的数据
SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,aod.WarehouseDeliveryTime DeliveryDate,0 DisNum,0 SaleNum,
COUNT(distinct ao.Code) B2bNum,SUM(aod.OutQty) Quantity,ao.ExpressFee,SUM(aod.Price*aod.OutQty) AmountActual
FROM dbo.B2BAllocationOut ao
LEFT JOIN dbo.B2BAllocationOutDetail aod ON aod.OutCode=ao.Code
LEFT JOIN dbo.Store s ON ao.StoreId=s.Id
WHERE ao.Status IN (3,4,11)
GROUP BY s.Id,s.Code,s.Name,ao.StoreId,aod.WarehouseDeliveryTime,ao.Id,ao.ExpressFee
)b
GROUP BY StoreId,StoreCode,StoreName,DeliveryDate
go

