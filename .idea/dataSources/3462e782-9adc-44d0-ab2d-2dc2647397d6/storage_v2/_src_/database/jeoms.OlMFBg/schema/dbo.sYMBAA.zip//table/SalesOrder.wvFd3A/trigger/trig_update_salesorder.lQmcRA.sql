--创建update触发器
create trigger trig_update_salesorder
on salesorder
after update
as
begin
    declare @stuCount int;
 if update(PayDate)
begin

update SalesOrder set UpdateDate = SYSDATETIME() where OrderId in (select OrderId from Deleted )

end

end
go

