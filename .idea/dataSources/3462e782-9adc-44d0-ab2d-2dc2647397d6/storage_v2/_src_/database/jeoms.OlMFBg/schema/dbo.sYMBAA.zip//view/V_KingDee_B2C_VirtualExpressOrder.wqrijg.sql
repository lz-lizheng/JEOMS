

CREATE View [dbo].[V_KingDee_B2C_VirtualExpressOrder] as 
SELECT   so.OrderId,so.StoreId,so.Code,so.DeliveryDate,so.TradeId,sos.SellerMemo,so.ExpressFee
            FROM SalesOrder(nolock) so
        LEFT JOIN SalesOrderSub(nolock) sos ON so.orderId = sos.SubId
            WHERE IsObsolete = 0
        AND Status IN (31,32)
        AND DispatchTypeStatus IN (1,2)
        AND IsAbnormal = 0 
        AND so.ExpressFee > 0   
		And exists (Select 1 From SalesOrderDetail(nolock) sod where so.orderid = sod.SalesOrderId and sod.DetailType = 0 and sod.status = 2)

 UNion 

 SELECT 
         so.OrderId,so.StoreId,so.Code,so.DeliveryDate,so.TradeId,sos.SellerMemo,so.ExpressFee
            FROM SalesOrder(nolock) so
        LEFT JOIN SalesOrderSub(nolock) sos ON so.orderId = sos.SubId
            WHERE IsObsolete = 0
        AND Status IN (31,32)
        AND DispatchTypeStatus IN (1,2)
        AND IsAbnormal = 0 
        AND  
		  EXISTS (
            SELECT 1 FROM
            SalesOrderDetail(nolock) sod
            WHERE
            sod.SalesOrderId = so.OrderId
            AND
            sod.Status = 2
            AND
            sod.DetailType = 1
            AND
            sod.IsDeleted = 0
            )  
			And exists (Select 1 From SalesOrderDetail(nolock) sod where so.orderid = sod.SalesOrderId and sod.DetailType = 0 and sod.status = 2)

go

