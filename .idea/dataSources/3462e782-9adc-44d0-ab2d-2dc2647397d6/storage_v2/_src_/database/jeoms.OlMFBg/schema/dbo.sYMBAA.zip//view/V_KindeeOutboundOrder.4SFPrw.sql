






/******金蝶销售出库单  Script Date: 2017/5/4 10:43:19 ******/
CREATE view [dbo].[V_KindeeOutboundOrder]
as
select dod.Id as 明细行ID,do.Code as 单据编号,dod.WarehouseDeliveryTime as 出库日期,do.Remark as 备注
,dod.SkuCode as 物料编码,
dod.OutQty as 实发数量,
w.Code as 实发仓库,do.TypeName as 单据类型,isnull(dod.UnitPrice,0) as 商品单价,isnull(dod.UnitPrice,0)*isnull(dod.OutQty,0) as 商品金额
 from OutboundOrder do 
join OutboundOrderDetail dod on do.Id = dod.OutboundOrderId
join Warehouse w on do.WarehouseId = w.Id
where dod.WarehouseDeliveryTime is not null and OutQty>0



go

