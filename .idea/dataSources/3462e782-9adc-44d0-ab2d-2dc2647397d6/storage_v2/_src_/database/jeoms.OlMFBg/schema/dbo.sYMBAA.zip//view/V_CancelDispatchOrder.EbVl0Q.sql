CREATE View V_CancelDispatchOrder as 
Select so.PayDate, SO.StoreId, SO.StoreName, Sol.CreateDate, so.Code, so.TradeId, REPLACE(Note, '取消了配货单：', '') as DpoCode
From SalesOrder so, SalesOrderLog sol
Where so.OrderId = sol.SalesOrderId
and Note like '取消了配货单%'
go

