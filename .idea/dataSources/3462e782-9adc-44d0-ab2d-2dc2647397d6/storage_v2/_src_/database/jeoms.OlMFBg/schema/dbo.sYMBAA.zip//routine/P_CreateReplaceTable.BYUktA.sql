


/*============================================================
获取当前数据库下面的所有表的创建语句并插入到OMS_SYNC_TABLES表中
===============================================================*/
CREATE PROCEDURE [dbo].[P_CreateReplaceTable]
(
	@P_OrigTableName nvarchar(100),
	@P_BackupTableName nvarchar(100)
)
AS
BEGIN
	DECLARE @DBNAME NVARCHAR(100) 
	DECLARE  @RESULT NVARCHAR(max); 
	Select @DBNAME = '['+Name+']' From Master..SysDataBases Where DbId=(Select Dbid From Master..SysProcesses Where Spid = @@spid);
		
		--'[implement-oms]' 
	EXEC [dbo].[GET_TableScript_MSSQL] @DBNAME,@P_OrigTableName,@RESULT OUT
	--打印出结果
	PRINT 'CREATE TABLE SQL :'+@RESULT

	EXEC   sp_rename  @P_OrigTableName,   @P_BackupTableName; 

	Exec SP_EXECUTESQL @RESULT;
		 
END
go

