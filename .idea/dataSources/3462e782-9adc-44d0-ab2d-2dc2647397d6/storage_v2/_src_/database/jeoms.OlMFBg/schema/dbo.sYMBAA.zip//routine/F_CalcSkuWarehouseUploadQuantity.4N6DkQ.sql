CREATE FUNCTION [dbo].[F_CalcSkuWarehouseUploadQuantity]
    (
      @inventoryQuantity INT ,
      @occupationQuantity INT ,
      @scale INT
    )
RETURNS DECIMAL
AS
    BEGIN
        DECLARE @quantity DECIMAL;
        SET @quantity = ISNULL(@inventoryQuantity, 0)
            - ISNULL(@occupationQuantity, 0);
        IF @quantity >= 0
            SET @quantity = @quantity * @scale / 100.00;
        RETURN @quantity;
    END;


go

