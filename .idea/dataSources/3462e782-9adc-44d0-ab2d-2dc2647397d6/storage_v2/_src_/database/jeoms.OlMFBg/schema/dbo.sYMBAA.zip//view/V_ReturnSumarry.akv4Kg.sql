
/********    
*create date: 2019-6-25    
*create by：拓斗    
*remark ：若羽臣-退货汇总表视图    
*******/    
CREATE  VIEW [dbo].[V_ReturnSumarry]    
AS    
SELECT StoreId,StoreCode,StoreName,SUM(Quantity)Quantity,SUM(RefundAmount)RefundAmount,WarehouseStorageTime    
FROM    
(SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,SUM(rod.StorageQuantity) Quantity,SUM(rod.RefundAmount) RefundAmount,    
rond.WarehouseStorageTime    
FROM dbo.ReturnOrder ro    
LEFT JOIN dbo.ReturnOrderDetail rod ON rod.ReturnOrderId=ro.Id    
LEFT JOIN dbo.Store s ON ro.StoreId=s.Id    
LEFT JOIN dbo.ReturnOrderNotice ron ON ron.Code=ro.NoticeCode  
LEFT JOIN dbo.ReturnOrderNoticeDetail rond ON rond.ReturnOrderDetailId=rod.Id and rond.NoticeId=ron.Id
WHERE ro.StorageStatus in (1,2) and isnull(ro.IsObsolete,0)=0 and ron.Status not in (3)     AND rod.StorageQuantity>0
GROUP BY s.Id,s.Code,s.Name,rond.WarehouseStorageTime    
UNION ALL    
SELECT s.StoreId,s.StoreCode,s.StoreName,SUM(rond.InQty+rond.DefectiveQuantity),SUM(rond.Price*(rond.InQty+rond.DefectiveQuantity)),    
rond.WarehouseStorageTime
FROM dbo.B2BReturnOrderNotice ron
LEFT JOIN dbo.B2BReturnOrderNoticeDetail rond ON rond.ReturnOrderNoticeId=ron.Id
LEFT JOIN (select StoreId,StoreName,(select top 1 Code from Store where Id=StoreId) StoreCode,Code from B2BReturnOrder where Status not in (4) group by StoreId,StoreName,Code) s on s.Code=ron.ReturnOrderCode
WHERE ron.Status IN (3,6,7)
GROUP BY s.StoreId,s.StoreCode,s.StoreName,rond.WarehouseStorageTime)a    
GROUP BY StoreId,StoreCode,StoreName,WarehouseStorageTime
go

