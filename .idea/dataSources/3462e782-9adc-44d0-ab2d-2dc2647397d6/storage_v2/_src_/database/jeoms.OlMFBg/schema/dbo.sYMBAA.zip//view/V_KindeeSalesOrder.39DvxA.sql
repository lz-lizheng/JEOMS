










/******金蝶销售出库单  Script Date: 2017/5/4 10:43:19 ******/
CREATE view [dbo].[V_KindeeSalesOrder]
as
select dod.DetailId as 明细行ID,do.Code as 单据编号,do.CreateDate as 日期,c.Code as 销售组织
,s.Code as 销售部门,s.Code as 客户,c.Code as 发货组织,dod.SkuCode as 物料编码,
dod.Quantity as 实发数量,case when dod.AmountActual=0 and dod.Quantity<>0 then  (dod.AmountActual+Isnull(0,0))/dod.Quantity else dod.PriceSelling end as 单价,dod.AmountActual as 价税合计,
c.LawUser as 仓库,do.TradeId as 来源单号,dbo.F_GetKindeeStoreTypeCode(s.StoreType) as 店铺类型
,do.ExpressFee as 快递费用,s.Code 店铺编码,s.Name 店铺名称
 from SalesOrder do 
join SalesOrderDetail dod on do.OrderId = dod.SalesOrderId
join Store s on s.Id = do.StoreId
--join Warehouse w on do.SuggestWarehouseId = w.Id
join Company c on s.CompanyId = c.Id
where not exists (select 1 from DispatchOrderDetail where DispatchOrderDetail.SalesOrderDetailId = dod.DetailId and DispatchOrderDetail.Status<>1)
and IsDeleted=0 and dod.IsAbnormal = 0 and do.TransType<>1 and dod.Status=2



go

