CREATE FUNCTION [dbo].[F_Get_RegionDispatchWarehouseExpress]
(
	@P_warehousetemplateId	UNIQUEIDENTIFIER,
	@P_ProvinceName NVARCHAR(20),
	@P_CityName		NVARCHAR(20),
	@P_CountyName	NVARCHAR(20)
)
RETURNS @V_Express TABLE(TemplateExpressId UNIQUEIDENTIFIER, ExpressId UNIQUEIDENTIFIER, OrderId INT, ExpressCode NVARCHAR(50), ExpressName NVARCHAR(50), 
		KeyWord Nvarchar(max), IsKeywordArrive bit, IsCanCod BIT, PackageCenterCode NVARCHAR(20), PackageCenterName NVARCHAR(20))
AS
BEGIN 
	--2. 建议仓库获取 问题点：a. 如果不设置仓库范围则为全部都到 
	-- 转换需要注意的点： 更新配货模板时需要重启

	--SQL 1:
	--SET STATISTICS IO ON  
	INSERT INTO @V_Express(TemplateExpressId, ExpressId, OrderId, ExpressCode, ExpressName, KeyWord, IsKeywordArrive, IsCanCod, PackageCenterCode, PackageCenterName) 
	SELECT DTE.TemplateExpressId, DTE.ExpressId, DTE.OrderId, EP.Code, EP.Name, ER.Keyword, ER.IsKeywordArrive, EP.IsCanCod, ER.PackageCenterCode, ER.PackageCenterName
	FROM [dbo].[DispatchTemplateExpress] DTE
	INNER JOIN dbo.Express EP ON DTE.ExpressId = EP.ID 
	INNER JOIN ExpressRegion ER ON EP.ID = ER.ExpressId
	INNER JOIN dbo.Region RGP ON ER.ProvinceId = RGP.Id
	INNER JOIN dbo.Region RGC ON ER.CityId = RGC.Id
	INNER JOIN dbo.Region RGD ON ER.CountyId = RGD.Id
	WHERE DTE.TemplateWarehouseId = @P_warehousetemplateId 
	AND ER.ProvinceName = @P_ProvinceName 
	AND ER.CityName = @P_CityName 
	AND ER.CountyName = @P_CountyName
	ORDER BY DTE.OrderID
	 

	--SET STATISTICS IO OFF
	 
	RETURN;
END;

go

