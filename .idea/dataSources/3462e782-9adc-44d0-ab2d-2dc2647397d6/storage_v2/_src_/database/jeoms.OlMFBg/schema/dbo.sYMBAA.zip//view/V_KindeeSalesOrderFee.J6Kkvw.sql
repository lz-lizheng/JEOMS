










/******金蝶销售出库单  Script Date: 2017/5/4 10:43:19 ******/
Create view [dbo].[V_KindeeSalesOrderFee]
as
select Code as 单据编号,ExpressFee as 快递费用 from
SalesOrder
go

