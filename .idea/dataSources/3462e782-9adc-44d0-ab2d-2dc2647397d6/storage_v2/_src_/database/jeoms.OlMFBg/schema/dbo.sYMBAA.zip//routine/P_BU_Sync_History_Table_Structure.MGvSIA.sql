
Create Procedure [dbo].[P_BU_Sync_History_Table_Structure]
(
	@FromTblName nVarchar(200) = 'SalesOrder'
)
As
Begin
	print '[P_BU_Sync_History_Table_Structure]'

 Declare @AlterSql nVarchar(4000), @ToTblName nVarchar(200)
 Set @ToTblName = @FromTblName 
 
 -- 已有字段结构调整, 新增字段, 删除字段
 -- 遍历更新有变更的字段结构
 Declare AlterCol Cursor For
  Select Case When FromTbl.name is not null And ToTbl.name is not null Then 'Alter Table [jehistory].DBO.' + @ToTblName + ' Alter Column ' + FromTbl.name + ' ' + FromTbl.colType + ';'
     When FromTbl.name is not null Then 'Alter Table [jehistory].DBO.' + @ToTblName + ' Add ' + FromTbl.name + ' ' + FromTbl.colType + ';'
     When ToTbl.name is not null Then 'Alter Table [jehistory].DBO.' + @ToTblName + ' Drop Column ' + ToTbl.name +';'
      End As AlterSql
  From 
   (
    Select Distinct col.name
    From sysobjects obj
    left join syscolumns col on obj.id = col.id
    Where obj.name in (@FromTblName)
	UNION 
	Select Distinct col.name
    From [jehistory].SYS.sysobjects obj
    left join [jehistory].SYS.syscolumns col on obj.id = col.id
    Where obj.name in (@ToTblName)
   ) Match
   Left Join 
   (  
    Select col.name, typ.name + case typ.name when 'decimal' then '(' + cast(col.xprec as varchar) +','+ cast(col.xscale as varchar) + ')' 
                   when 'nvarchar' then '(' + CASE WHEN col.length = '-1' THEN 'max' else cast(col.length / 2 as varchar) end + ')'
                   when 'varchar' then '(' + CASE WHEN col.length = '-1' THEN 'max' else cast(col.length as varchar) End+ ')'
                   else '' End as colType, colorder 
    From sysobjects obj
    left join syscolumns  col on obj.id = col.id
    Left join systypes typ ON col.xtype = typ.xtype
    WHERE obj.name = @FromTblName
    --and typ.name in ('decimal', 'nvarchar', 'varchar')
    and typ.status = 0
   ) FromTbl on Match.name = FromTbl.name
   Left Join 
   (
    Select col.name, typ.name + case typ.name when 'decimal' then '(' + cast(col.xprec as varchar) +','+ cast(col.xscale as varchar) + ')' 
                   when 'nvarchar' then '(' + CASE WHEN col.length = '-1' THEN 'max' else cast(col.length / 2 as varchar) end + ')'
                   when 'varchar' then '(' + CASE WHEN col.length = '-1' THEN 'max' else cast(col.length as varchar) End+ ')'
                   else '' End as colType 
    From [jehistory].SYS.sysobjects obj
    left join [jehistory].SYS.syscolumns col on obj.id = col.id
    Left join [jehistory].SYS.systypes typ on col.xtype = typ.xtype
    where obj.name = @ToTblName
    --and typ.name in ('decimal', 'nvarchar', 'varchar')
    and typ.status = 0
   ) ToTbl ON Match.name = ToTbl.name
  Where isnull(FromTbl.colType, '') <> isnull(ToTbl.colType, '')
  order by fromTbl.colorder;
 Open AlterCol
 Fetch next From AlterCol Into @AlterSql;
 While @@FETCH_STATUS = 0
 Begin
  --  更新字段结构
  Print @AlterSql;
  Exec SP_EXECUTESQL @AlterSql;

  Fetch next From AlterCol Into @AlterSql;
 End;

 Close AlterCol;
 Deallocate AlterCol; 

End;



go

