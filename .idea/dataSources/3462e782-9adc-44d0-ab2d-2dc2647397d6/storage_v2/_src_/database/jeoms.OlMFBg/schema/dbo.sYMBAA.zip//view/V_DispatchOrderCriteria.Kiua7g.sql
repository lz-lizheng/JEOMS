--发货时间		快递公司		实体仓库		店铺名称		订单编号
--商品编码		规格编码		平台交易号		快递单号
Create View V_DispatchOrderCriteria as 
Select do.DeliveryDate, Do.ActualExpressId, Do.ActualExpressNo, Do.WarehouseId, Do.StoreId,
		Dod.SalesOrderCode, Dod.ProductCode, Dod.ProductSkuCode, Dod.TradeId 
From DispatchOrder Do
Join DispatchOrderDetail Dod on Do.Id = dod.DispatchOrderId
Where Dod.Status in (0, 2)
go

