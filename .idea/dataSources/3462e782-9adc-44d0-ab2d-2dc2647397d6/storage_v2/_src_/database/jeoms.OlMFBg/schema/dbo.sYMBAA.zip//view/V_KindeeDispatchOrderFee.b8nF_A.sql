









/******金蝶销售出库单  Script Date: 2017/5/4 10:43:19 ******/
Create view [dbo].[V_KindeeDispatchOrderFee]
as
select 单据编号,sum(aa.ExpressFee) as 快递费用 from
(
select so.Code as 订单编号,do.Code as 单据编号,max(so.ExpressFee)ExpressFee
 from DispatchOrder do 
join DispatchOrderDetail dod on do.Id = dod.DispatchOrderId
join SalesOrder so on so.OrderId = dod.SalesOrderId
where do.Status = 4 and dod.Status=2
group by do.Code,so.Code
)aa
group by 单据编号
go

