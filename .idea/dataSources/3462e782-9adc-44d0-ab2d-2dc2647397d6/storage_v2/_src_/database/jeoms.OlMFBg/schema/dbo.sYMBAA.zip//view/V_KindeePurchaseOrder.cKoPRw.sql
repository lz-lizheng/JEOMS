






/******金蝶销采购入库单  Script Date: 2017/5/4 10:43:19 ******/
CREATE view [dbo].[V_KindeePurchaseOrder]
as
select pnod.DetailId as 明细行ID,po.CreateUserName as 制单人,c.Code as 收料组织,c.Code as 采购组织,
PNOID.WarehouseStorageTime as 入库日期,pno.Code as 单据编号,c.Code as 需求组织,
po.SupplierCode as 供应商,pnod.SkuCode as 物料编号,PNOID.StockInQty+PNOID.DefectiveQuantity as 实收数量,
PNOID.StockInQty+PNOID.DefectiveQuantity as 计价数量,pod.CurrentPrice as 单价,pod.CurrentPrice*(PNOID.StockInQty+PNOID.DefectiveQuantity) as 金额,
PNOID.StockInQty+PNOID.DefectiveQuantity as 采购数量,REPLACE(isnull(po.Rate,'0%'),'%','') as 税率,po.Code as 来源单号,c.LawUser as 仓库,po.Currency as 币别
 from PurchaseNoticeOrder pno
 join PurchaseNoticeOrderdetail pnod on pno.Id = pnod.PurchaseNoticeOrderId
 join PurchaseOrder po on po.Id = pno.PurchaseOrderId
 join PurchaseOrderDetail pod on pod.PurchaseOrderId = po.Id and pnod.SkuId = pod.SkuId
 Left Join PurchaseNoticeOrderIndetail PNOID(NOLOCK) ON PNOD.DetailId = PNOID.DetailId
 left join Company c on po.SupplierComanyName = c.Name
 left join Warehouse w on po.WarehouseID = w.Id



go

