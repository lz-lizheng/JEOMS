/**********************
*create date : 2017-12-30
*create by：qiaoni 
*remark ： 采购入库统计爱哆哆

--采购订单：XXXX	商品编码：XXXX	商品名称:XXXX	供应商名称:XXXX 
--采购日期：XXXX-XXXX	入库状态：XXXX 
--字段：入库状态	供应商名称	采购日期	采购订单号	商品编码	商品名称	商品状态(属性2)	
--一级分类	进料箱规	箱单位	采购数	已入库数	未入库数 
***********************/
Create VIEW [dbo].[V_ReportPurchaseOrderSummary_AiDuoDuo] AS 
SELECT PO.Code, 
	   PO.PurchaseDate, 
	   PO.SupplierCode,
	   po.SupplierName, 
	   PO.Status,
	   PO.InStatus,
	   POD.ProductId,
	   POD.ProductCode,
	   POD.ProductName,   
	   POD.SkuCode,
	   POD.SkuName,
	   pc.OneCatName,
	   pd.Attribute2,
	   pd.Attribute4, --进料箱规
	   pd.CartonSpec, --箱单位 
	   POD.PurchaseQty,   
	   pno.StockInQty,
	   Case When pod.PurchaseQty - pno.StockInQty > 0 Then pod.PurchaseQty - pno.StockInQty Else 0 End as NotInQty
FROM PurchaseOrder PO(NOLOCK)
LEFT JOIN PurchaseOrderDetail POD(NOLOCK) ON PO.Id = pod.PurchaseOrderId
Left Join (
			Select Pno.PurchaseOrderId, pnod.ProductId, pnod.SkuId, Sum(pnod.StockInQty) as StockInQty
			From PurchaseNoticeOrder PNO(nolock)
			Join PurchaseNoticeOrderdetail PNOD(nolock) on pno.Id = pnod.PurchaseNoticeOrderId
			Group by Pno.PurchaseOrderId, pnod.ProductId, pnod.SkuId
		) PNO on po.Id = pno.PurchaseOrderId and pno.SkuId = pod.SkuId
LEFT JOIN dbo.Product PD(NOLOCK) ON POD.ProductId = pd.ProductId
LEFT JOIN dbo.Supplier SSP(NOLOCK) ON po.SupplierCode = ssp.Code 
Left Join V_ProductCategory pc(nolock) on pd.CategoryId = pc.ThreeCatId



go

