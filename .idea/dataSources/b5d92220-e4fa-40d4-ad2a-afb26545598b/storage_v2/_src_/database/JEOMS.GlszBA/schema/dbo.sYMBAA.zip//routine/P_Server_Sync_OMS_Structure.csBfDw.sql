CREATE Procedure [dbo].[P_Server_Sync_OMS_Structure]  
As
Begin   
 Declare @ID nvarchar(10),
  @CustomerName nvarchar(255),
  @ServerName nvarchar(255),
  @LoginUser nvarchar(255),
  @LoginPassword nvarchar(255),
  @OmsServerName nvarchar(255),
  @OdsServerName nvarchar(255),
  @OmsHistoryServerName nvarchar(255),
  @OmsDwServerName nvarchar(255),
	@UpdateTime nvarchar(30),
	@startTime datetime,
	@endTime datetime,
	@hours bigint,
  @SQL nvarchar(2000);
 
  PRINT('开始创建P_BU_Generate_OMS_Structure........');
	SET @startTime = GETDATE();
  Exec [dbo].[P_BU_Generate_OMS_Structure];
	SET @endTime = GETDATE();
	SELECT @hours = DATEDIFF(ms, @startTime, @endTime)
	PRINT('完成创建P_BU_Generate_OMS_Structure,耗时:'+convert(varchar(10),@hours)+'ms');
	
	--执行生成所有表创建语句病插入进数据库
	PRINT('开始创建P_GetCreateSqlInsertDB ............');
	SET @startTime = GETDATE();
	Exec [dbo].[P_GetCreateSqlInsertDB];
	SET @endTime = GETDATE();
	SELECT @hours = DATEDIFF(ms, @startTime, @endTime)
	PRINT('完成创建P_GetCreateSqlInsertDB，消耗时间:'+convert(varchar(10),@hours)+'ms');
	
	-- 已有字段结构调整, 新增字段, 修改字段
	-- 遍历更新有变更的字段结构
	 Declare TabCur Cursor For
	  Select ID,CustomerName,ServerName,LoginUser,LoginPassword,OmsServerName,OdsServerName,OmsHistoryServerName,OmsDwServerName
	  From OMS_Product_DB_Info
	  Where Synchronous  = 1
	  Order By ID;
	 Open TabCur
	 Fetch next From TabCur Into @ID,@CustomerName,@ServerName,@LoginUser,@LoginPassword,@OmsServerName,@OdsServerName,@OmsHistoryServerName,@OmsDwServerName;
	 While @@FETCH_STATUS = 0
	 Begin
		  --  更新字段结构
		  Print 'DB Link For :' + @CustomerName;

		exec sp_addlinkedserver @CustomerName,'','SQLOLEDB',@ServerName;
		exec sp_addlinkedsrvlogin @CustomerName,'false',null,@LoginUser,@LoginPassword;
		exec sp_serveroption @CustomerName,'rpc out','true'  --可以调用远程链接中的存储过程
      
		  Set @SQL = 'Delete From [' + @CustomerName + '].[' + @OmsServerName + '].dbo.' + 'OMS_Sync_Table_Structure';
		  Print 'Exec Delete From :' +  @SQL;
		  Exec SP_EXECUTESQL @SQL;
			
		  Set @SQL = 'Insert Into [' + @CustomerName + '].[' + @OmsServerName + '].dbo.' + 'OMS_Sync_Table_Structure Select * From OMS_Sync_Table_Structure';
		  Print 'Exec Sync Table :' +  @SQL;
		  Exec SP_EXECUTESQL @SQL;
  
		  Set @SQL = 'Delete From [' + @CustomerName + '].[' + @OmsServerName + '].dbo.' + 'OMS_SYNC_TABLES';
		  Print 'Exec Delete From :' +  @SQL;
		  Exec SP_EXECUTESQL @SQL;

																					--OMS_SYNC_TABLES 存储表创建语句
			Set @SQL = 'Insert INTO ['+@CustomerName + '].[' + @OmsServerName + '].dbo.'+'OMS_SYNC_TABLES SELECT * FROM OMS_SYNC_TABLES';
			Print 'Insert Into CreateTabelSql :'+@SQL;
			Exec SP_EXECUTESQL @SQL;
		
			Set @SQL = '[' + @CustomerName + '].[' + @OmsServerName + '].[dbo].[P_BU_Sync_OMS_Structure] ';
			Exec SP_EXECUTESQL @SQL;
			Print 'Exec Sync Table : ' + @SQL;

			--	添加最近更新时间和还原更新状态
		  select @UpdateTime = CONVERT(varchar(30),getdate(),121)
		  update OMS_Product_DB_Info set UpdateTime = @UpdateTime,Synchronous = 0 where ID = CONVERT(bigint,@ID);

			Exec sp_dropserver @CustomerName,'droplogins';

		Fetch next From TabCur Into @ID,@CustomerName,@ServerName,@LoginUser,@LoginPassword,@OmsServerName,@OdsServerName,@OmsHistoryServerName,@OmsDwServerName;
	 End;

	 Close TabCur;
	 Deallocate TabCur; 
  
End;


go

