CREATE VIEW [dbo].[V_ApiInventoryChange] 
as
SELECT   APIT.*,w.Name as WarehouseName, PS.ProductCode
FROM dbo.ApiInventoryChange APIT(NOLOCK)
LEFT JOIN ProductSku PS(NOLOCK) ON APIT.Sku = PS.Code 
left join Warehouse w on w.Code = APIT.Whcode
where ps.Status = 1 and w.IsDisabled=0
go

