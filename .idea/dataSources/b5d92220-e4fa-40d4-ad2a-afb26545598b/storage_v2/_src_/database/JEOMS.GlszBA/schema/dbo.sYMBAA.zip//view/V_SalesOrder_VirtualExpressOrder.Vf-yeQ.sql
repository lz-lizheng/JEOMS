
CREATE VIEW [dbo].[V_SalesOrder_VirtualExpressOrder] AS SELECT
	so.OrderId DetailId,
	so.StoreName,
	so.OrderId,
	so.Code,
	so.TradeId,
	so.PayDate PayTime,
	so.PayDate DeliveryTime,
	so.TradeFinishDate EndTime,
	so.TransType,
	so.ExpressFee,
	null SalesOrderDetailType,
	sos.Telephone,
	sos.Mobile,
	sos.Consignee Receiver,
	sos.Contacter Contact,
	null ProductCode,
	null ProductName,
	null ProductSkuCode,
	null ProductSkuName,
	null SalesPrice,
	null OriginalPrice,
	0 SalesAmount,
	0 DiscountAmount,
	0 SettlementAmount,
	0 Quantity 
FROM
	SalesOrder so
	LEFT JOIN SalesOrderSub sos ON so.orderId = sos.SubId 
WHERE
	so.IsObsolete = 0 
	AND so.Status IN ( 31, 32 ) 
	AND so.DispatchTypeStatus IN ( 1, 2 ) 
	AND so.IsAbnormal = 0 
	AND so.ExpressFee > 0 
	AND EXISTS ( SELECT 1 FROM SalesOrderDetail sod WHERE so.orderid = sod.SalesOrderId AND sod.DetailType = 0 AND sod.status = 2 ) UNION
SELECT
	sod.DetailId,
	so.StoreName,
	so.OrderId,
	so.Code,
	so.TradeId,
	so.PayDate PayTime,
	so.PayDate DeliveryTime,
	so.TradeFinishDate EndTime,
	so.TransType,
	so.ExpressFee,
	sod.DetailType SalesOrderDetailType,
	sos.Telephone,
	sos.Mobile,
	sos.Consignee Receiver,
	sos.Contacter Contact,
	sod.ProductCode,
	sod.ProductName,
	sod.SkuCode ProductSkuCode,
	sod.SkuName ProductSkuName,
	sod.PriceSelling SalesPrice,
	sod.PriceOriginal OriginalPrice,
	sod.Amount SalesAmount,
	sod.DiscountAmount,
	sod.AmountActual SettlementAmount,
	sod.Quantity 
FROM
	SalesOrder so
	LEFT JOIN SalesOrderDetail sod ON so.OrderId = sod.SalesorderId
	LEFT JOIN SalesOrderSub sos ON so.orderId = sos.SubId 
WHERE
	so.IsObsolete = 0 
	AND so.Status IN ( 31, 32 ) 
	AND so.DispatchTypeStatus IN ( 1, 2 ) 
	AND so.IsAbnormal = 0 
	AND EXISTS (
SELECT
	1 
FROM
	SalesOrderDetail sod 
WHERE
	sod.SalesOrderId = so.OrderId 
	AND sod.Status = 2 
	AND sod.DetailType = 1 
	AND sod.IsDeleted = 0 
	) 
	AND EXISTS (
SELECT
	1 
FROM
	SalesOrderDetail sod 
WHERE
	so.orderid = sod.SalesOrderId 
	AND sod.DetailType = 0 
	AND sod.status = 2)



go

