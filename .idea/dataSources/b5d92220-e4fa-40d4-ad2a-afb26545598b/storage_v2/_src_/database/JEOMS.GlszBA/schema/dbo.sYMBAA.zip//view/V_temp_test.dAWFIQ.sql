create view [dbo].[V_temp_test]  as
select concat(tempResult.StoreId,'-',tempResult.SkuId) as keyId, Isnull(Sum(tempResult.Qty), 0) as Qty
from (Select SDW.StoreId, VVS.SkuId, Isnull(Sum(VVS.CanUseQuantity), 0) as Qty
      From dbo.V_StoreDispatchWarehouse SDW (nolock),
           dbo.V_InventoryVirtualStock VVS (nolock)
      Where SDW.WarehouseId = VVS.WarehouseId
        And VVS.IsLockStock = 0
      group by SDW.StoreId, VVS.SkuId
      Union ALL
      Select SDW.StoreId, IOC.SkuId, isnull(Sum(IOC.Quantity), 0) * -1 as Qty
      From dbo.V_StoreDispatchWarehouse SDW (nolock),
           dbo.InventoryOccupation IOC (nolock)
      Where SDW.WarehouseId = IOC.WarehouseId
        And IOC.Type = 2
      group by SDW.StoreId, IOC.SkuId
      Union ALL
      select IOC.StoreId, IOC.SkuId, isnull(Sum(IOC.Quantity), 0) * -1 as Qty
      from dbo.InventoryOccupation IOC (nolock)
                   inner join dbo.V_StoreDispatchWarehouse SDW (nolock)
               On SDW.StoreId = IOC.StoreId and IOC.WarehouseId = SDW.WarehouseID
      Where IOC.Type = 1
        And IOC.IsDispatched = 0
        And (IOC.PreDeliveryDate is null or IOC.PreDeliveryDate < getdate())
      group by IOC.StoreId, IOC.SkuId) as tempResult
group by tempResult.StoreId, tempResult.SkuId


go

