


CREATE VIEW [dbo].[V_PurchaseOrderyy] AS 
SELECT PO.Code,
	   PNO.Code AS PnoCode,
	   PO.PurchaseDate,
	   PO.RequestDeliveryDate,
	   PO.SupplierCode,
	   po.SupplierName, 
	   PNO.WarehouseID,
	   PNO.WarehouseName,
	   PO.Status,
	   POD.ProductId,
	   POD.ProductCode,
	   POD.ProductName,
	   POD.SkuId,
	   POD.SkuCode, 
	   POD.SkuName,
	   POD.Color, 
	   POD.Size,
	   POD.PurchaseQty, 
	   POD.CurrentPrice AS OriginalPrice,
	   PNO.Remark,
	   PNO.Status AS PnoStatus,
	   PNOD.NoticeQty, 
	   PNOID.StockInQty,
	   PNOID.DefectiveQuantity,
	   PNOID.WarehouseStorageTime AS WarehousingTime,
	   pd.Year,
	   pd.Season,
	   pd.Brand,
	   pd.CategoryName,
	   PO.ContractNo,
	   SSP.SupplierSettlementType,
	   PNO.ArriveBatchNo,
	   PO.PurchasePersonName,
	   PO.SupplierComanyName,
	   Po.PurchaseTypeName,
	   POD.CurrentPrice * PNOID.StockInQty AS StockInAmt,
	   POD.CurrentPrice * PNOID.DefectiveQuantity AS DefectiveAmt,
	   (CASE WHEN POD.PurchaseQty-PNOID.StockInQty-PNOID.DefectiveQuantity<0 THEN 0 ELSE POD.PurchaseQty-PNOID.StockInQty-PNOID.DefectiveQuantity END) AS TransitQty,
	   PNOD.DetailId
FROM PurchaseOrder PO(NOLOCK)
LEFT JOIN PurchaseOrderDetail POD(NOLOCK) ON PO.Id = pod.PurchaseOrderId
LEFT JOIN PurchaseNoticeOrder PNO(NOLOCK) ON po.Id = PNO.PurchaseOrderId
LEFT JOIN PurchaseNoticeOrderdetail PNOD(NOLOCK) ON PNO.Id = PNOD.PurchaseNoticeOrderId AND POD.SkuId = PNOD.SkuId
LEFT JOIN PurchaseNoticeOrderIndetail PNOID(NOLOCK) ON PNOD.DetailId = PNOID.DetailId
LEFT JOIN dbo.Product PD(NOLOCK) ON POD.ProductId = pd.ProductId
LEFT JOIN dbo.Supplier SSP(NOLOCK) ON po.SupplierCode = ssp.Code



go

