CREATE VIEW [dbo].[V_ReturnSumarry]
AS
SELECT  StoreId,StoreCode,StoreName,SUM(Quantity)Quantity,SUM(RefundAmount)RefundAmount,WarehouseStorageTime 
FROM
(SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,SUM(rod.Quantity) Quantity,SUM(RefundAmount) RefundAmount,
rond.WarehouseStorageTime
FROM dbo.ReturnOrder ro
LEFT JOIN dbo.ReturnOrderDetail rod ON rod.ReturnOrderId=ro.Id
LEFT JOIN dbo.Store s ON ro.StoreId=s.Id
LEFT JOIN dbo.ReturnOrderNoticeDetail rond ON rond.ReturnOrderDetailId=rod.Id
LEFT JOIN dbo.ReturnOrderNotice ron ON ron.Id=rond.NoticeId
WHERE ron.Status=2
GROUP BY s.Id,s.Code,s.Name,rond.WarehouseStorageTime

UNION ALL

SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,SUM(rod.ReturnQty),SUM(rod.Price),
rond.WarehouseStorageTime
FROM dbo.B2BReturnOrder ro
LEFT JOIN dbo.B2BReturnOrderDetail rod ON rod.ReturnOrderId=ro.Id
LEFT JOIN dbo.Store s ON s.Id=ro.StoreId
LEFT JOIN dbo.B2BReturnOrderNotice ron ON ron.ReturnOrderCode=ro.Code
LEFT JOIN dbo.B2BReturnOrderNoticeDetail rond ON rond.ReturnOrderNoticeId=ron.Id
WHERE ro.Status IN (3,6)
GROUP BY s.Id,s.Code,s.Name,rond.WarehouseStorageTime)a
GROUP BY StoreId,StoreCode,StoreName,WarehouseStorageTime


go

