

	  
CREATE PROCEDURE [dbo].[P_QuerySkuQuantityUpload]
(
 @skuIds VARCHAR(MAX) ,
 @storeIds VARCHAR(MAX)
)
AS
      BEGIN
            DECLARE @skuList TABLE (id VARCHAR(100));
            DECLARE @storeList TABLE (id VARCHAR(100));
            INSERT  INTO @skuList
            SELECT  *
            FROM    dbo.F_SplitString(@skuIds, ','); 
            INSERT  INTO @storeList
            SELECT  *
            FROM    dbo.F_SplitString(@storeIds, ','); 

            SELECT  d.ProductSkuId, d.StoreId, d.Brand, uc.BrandName StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, uc.IsManualUpload&d.IsAutoUploadInventory IsAutoUploadInventory, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, dbo.F_CalcSkuUploadQuantity(d.ProductSkuId, uc.StoreId, d.PresellPlanId, SUM(dbo.F_CalcSkuWarehouseUploadQuantity(iv.Quantity, ios.LockedQuantity, uc.Scale))) Quantity
            FROM    V_Distribution d
            LEFT JOIN    V_UploadConfig uc ON d.StoreId=uc.StoreId
            LEFT JOIN dbo.InventoryVirtual iv ON d.ProductSkuId=iv.SkuId AND uc.WarehouseId=iv.WarehouseId
            LEFT JOIN dbo.V_InventoryOccupationSum ios ON uc.WarehouseId=ios.WarehouseId AND d.ProductSkuId=ios.SkuId
            WHERE   d.ProductSkuId IN (SELECT   *
                                       FROM     @skuList) AND d.StoreId IN (SELECT  *
                                                                            FROM    @storeList)
            GROUP BY d.ProductSkuId, d.StoreId, d.Brand, uc.BrandName, d.PlatformId, uc.StoreId,uc.IsManualUpload,d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformOutCode, d.PlatformSkuCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoUploadInventory, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId
            UNION ALL
            SELECT  d.ProductSkuId, d.StoreId, d.Brand, uc.BrandName StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, uc.IsManualUpload&d.IsAutoUploadInventory IsAutoUploadInventory, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, dbo.F_CalcSkuUploadQuantity(sku.SkuId, uc.StoreId, d.PresellPlanId, SUM(dbo.F_CalcSkuWarehouseUploadQuantity(iv.Quantity, ios.LockedQuantity, uc.Scale)))/sku.Quantity Quantity
            FROM    V_Distribution d
            LEFT JOIN  V_UploadConfig uc ON d.StoreId=uc.StoreId
            LEFT JOIN CombinedProductDetail sku ON d.ProductSkuId=sku.CombinedProductId
            LEFT JOIN dbo.InventoryVirtual iv ON sku.SkuId=iv.SkuId AND uc.WarehouseId=iv.WarehouseId
            LEFT JOIN dbo.V_InventoryOccupationSum ios ON uc.WarehouseId=ios.WarehouseId AND sku.SkuId=ios.SkuId
            WHERE   sku.SkuId IN (SELECT    *
                                  FROM      @skuList) AND d.StoreId IN (SELECT  *
                                                                        FROM    @storeList)  AND d.ProductType=1 AND sku.IsMainSku=1
            GROUP BY d.ProductSkuId, d.StoreId, d.Brand, uc.BrandName, d.PlatformId, uc.StoreId, uc.IsManualUpload,d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformOutCode, d.PlatformSkuCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoUploadInventory, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, sku.SkuId, sku.Quantity;
      END;



go

