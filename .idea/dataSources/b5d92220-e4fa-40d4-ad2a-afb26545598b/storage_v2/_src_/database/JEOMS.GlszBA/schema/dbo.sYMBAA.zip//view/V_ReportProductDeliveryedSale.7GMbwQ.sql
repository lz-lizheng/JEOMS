

 
/**
*create date: 2016-07-21
*create by：乔尼
*remark ：商品销售统计 增加付款时间
**/
CREATE VIEW [dbo].[V_ReportProductDeliveryedSale] AS 
 
SELECT  Cast(so.PayTime as Date) AS PayDate, 
	   Cast(sode.DeliveryDate as Date) AS DeliveryDate, 
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.ProductSkuCode AS SkuCode,
	   sod.ProductSkuName AS SkuName,
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color, 
	   pd.FirstLevelCategoryId OneCatId, 
	   pd.FirstLevelCategoryName OneCatName,
	   pd.TwoLevelCategoryId TwoCatId, 
	   pd.TwoLevelCategoryName TwoCatName, 
	   pd.CategoryId ThreeCatId,
	   pd.CategoryName ThreeCatName,
	   SUM(sod.Quantity) AS Quantity,
	   SUM(sod.AmountActual) AS AmountActual,
	   SUM(sl.FirstCost) AS FirstCost
FROM dbo.DispatchOrder(NOLOCK) so
INNER JOIN dbo.DispatchOrderDetail(NOLOCK) sod ON so.Id = sod.DIspatchOrderId
inner join dbo.DispatchOrderDetailExpress(Nolock) sode on sod.Id = sode.DetailId
INNER JOIN dbo.SalesOrderDetail(NOLOCK) sl ON sl.DetailId= sod.SalesOrderDetailId
LEFT JOIN Product(NOLOCK) pd ON sod.ProductId = pd.ProductId
LEFT JOIN dbo.ProductSku(NOLOCK) ps ON sod.ProductSkuId = ps.SkuId
WHERE sod.Status = 2
GROUP BY 
		Cast(so.PayTime as Date), 
	   Cast(sode.DeliveryDate as Date),
	   sl.FirstCost,
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.ProductSkuCode,
	   sod.ProductSkuName,
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color,
	   pd.FirstLevelCategoryId, 
	   pd.FirstLevelCategoryName,
	   pd.TwoLevelCategoryId, 
	   pd.TwoLevelCategoryName, 
	   pd.CategoryId,
	   pd.CategoryName



go

