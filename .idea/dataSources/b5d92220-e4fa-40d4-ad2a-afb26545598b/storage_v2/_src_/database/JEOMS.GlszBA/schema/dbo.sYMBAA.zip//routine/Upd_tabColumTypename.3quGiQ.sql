
  /**********************
*create date : 2018-03-22
*create by：luowen 
*remark ： 将指定库中所有表内字段类型为DECIMAL的精度改为(15,4)
***********************/  
CREATE PROCEDURE [dbo].[Upd_tabColumTypename](
@typename  NVARCHAR(50) --要变成的类型（DECIMAL(15,4)）
)
AS 
DECLARE @count INT,@i INT=1, @tablename NVARCHAR(50),@columnname  NVARCHAR(50),@sql NVARCHAR(500)

SELECT @count=COUNT(*)
from sys.columns c inner join sys.tables t on t.object_id=c.object_id  
inner join sys.types ty on ty.system_type_id=c.system_type_id  
where ty.name='decimal' 
IF	@count!=0
BEGIN

WHILE @i<=@count
 BEGIN 
 --单条数据查询

   SELECT @tablename=tablename ,@columnname=columnname FROM(
   SELECT  ROW_NUMBER() OVER ( ORDER BY t.name  ) AS RN , t.name as tablename,c.name as columnname
from sys.columns c inner join sys.tables t on t.object_id=c.object_id  
inner join sys.types ty on ty.system_type_id=c.system_type_id  
where ty.name='decimal' ) AS tab WHERE tab.RN=@i

   SET @sql='ALTER TABLE '+@tablename+' ALTER COLUMN '+@columnname+' '+@typename+'  NULL' 
   SELECT @sql   
   EXEC(@sql) 
   SET @i = @i + 1
 END

 END

exec Upd_tabColumTypename 'DECIMAL(15,4)'



  go

