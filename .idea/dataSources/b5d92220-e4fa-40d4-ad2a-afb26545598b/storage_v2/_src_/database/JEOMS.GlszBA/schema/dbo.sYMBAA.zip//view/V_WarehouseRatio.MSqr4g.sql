
 


 
 /********************** 
*create date : 2018-05-18
*create by：qiaoni 
*remark ：仓库入库比例
***********************/
Create View [dbo].[V_WarehouseRatio] as 
Select A.*
From (
	Select whp.Id as ParentId, 
		   whp.Code as ParentCode, 
		   WHp.Name as ParentName,
		   Wc.Id as ChdId,
		   Wc.Code as ChdCode, 
		   Wc.Name as ChdName,
		   Wc.WarehouseRatio + 
			  Case When wc.Warehousetype = 2 Then 100 - (Select Sum(Wc1.WarehouseRatio) From Warehouse WC1 Where WC1.ParentId = WHP.Id ) Else 0 End as ShareRatio
	From Warehouse WhP, Warehouse WC 
	Where  whp.id = wc.ParentId
	) A
Where A.ShareRatio > 0



 go

