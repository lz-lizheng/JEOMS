

Create View [dbo].[V_Tru_Product] as 
Select	'18417' as StorerKey,
		PS.Code as Sku,
		ps.Description as DESCR,
		pd.Code as ALTSKU, 
		ps.CustomCode as BUSR6,
		'TRU' + PS.Code as PACKKey,
		'TRUCN' as StrategyKey,
		'Size And Color' as LOTTABLE02LABEL,
		'RCP_DATE' as LOTTABLE05LABEL
From Product pd(nolock)
Join ProductSku ps(nolock) on pd.ProductId = ps.ProductId



go

