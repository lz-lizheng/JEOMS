
/**********************
*create date :	2018-07-27
*create by：	qiaoni 
*remark ：	订单明细可配货量查询
* F_GetCanPackingQty
***********************/  
CREATE  Function [dbo].[F_GetCanPackingQty](
	@StoreId nvarchar(100),
	@Skuid nvarchar(100),
	@Paydate DateTime
)
Returns int
As 
Begin 
	declare @V_Result int, @V_TotalInvQuantity int, @V_OccedInvQuantity int

	-- 总库存数量
	Select @V_TotalInvQuantity = Sum(iv.Quantity)
	From V_StoreDispatchWarehouse sdw(nolock), InventoryVirtual iv(nolock)
	where sdw.WarehouseID = iv.WarehouseId
	and sdw.StoreId = @StoreId 
	And iv.SkuId = @Skuid 
	and iv.IsLockStock = 0;

	if(@V_TotalInvQuantity > 10000 or @V_TotalInvQuantity < 0) return @V_TotalInvQuantity;	

	--非订单占用数量
	Select @V_OccedInvQuantity = isnull(Sum(IOC.Quantity), 0)
	From V_StoreDispatchWarehouse SDW(nolock), InventoryOccupation IOC(nolock) 
	Where SDW.WarehouseId = IOC.WarehouseId And IOC.Type > 1 And SDW.StoreId = @StoreId And IOC.SkuId = @Skuid

	set @V_TotalInvQuantity = @V_TotalInvQuantity - @V_OccedInvQuantity;
	if(@V_TotalInvQuantity <= 0) return @V_TotalInvQuantity;

	--订单已配货数量
	Select @V_OccedInvQuantity = isnull(Sum(IOC.Quantity), 0)
	From V_StoreDispatchWarehouse SDW(nolock), InventoryOccupation IOC(nolock) 
	Where SDW.WarehouseId = IOC.WarehouseId And IOC.Type = 1 And ioc.IsDispatched = 1 And SDW.StoreId = @StoreId And IOC.SkuId = @Skuid

	set @V_TotalInvQuantity = @V_TotalInvQuantity - @V_OccedInvQuantity;
	if(@V_TotalInvQuantity <= 0) return @V_TotalInvQuantity;

	--未送给你订单指定日期前发数量
	Select @V_OccedInvQuantity = isnull(Sum(IOC.Quantity), 0)
	From InventoryOccupation IOC(nolock) 
	Where IOC.Type = 1 And IsDispatched = 0 And IOC.SkuId =@Skuid  And IOC.PayDate < @Paydate
	and isnull(PreDeliveryDate, ioc.paydate) < getdate()
	--And (IOC.IsAppointDateDelivery = 0 or (IOC.IsAppointDateDelivery = 1 and PreDeliveryDate < getdate())) 
	And (IOC.WarehouseId in (Select WarehouseID From V_StoreDispatchWarehouse SDW(nolock) 
	Where SDW.StoreId = @StoreId) Or IOC.StoreId = @StoreId)

	set @V_TotalInvQuantity = @V_TotalInvQuantity - @V_OccedInvQuantity;
	return @V_TotalInvQuantity;

	--Select @V_Result = Sum(Qty)
	--From (		 
	--	Select Isnull(Sum(VVS.CanUseQuantity), 0) as Qty
	--	From V_StoreDispatchWarehouse  SDW(nolock), V_InventoryVirtualStock VVS(nolock) 
	--	Where SDW.WarehouseId = VVS.WarehouseId And SDW.StoreId = @StoreId And VVS.SkuId = @Skuid 
	--	And VVS.IsLockStock = 0
	--	Union ALL
	--	Select isnull(Sum(IOC.Quantity), 0) * -1
	--	From V_StoreDispatchWarehouse SDW(nolock), InventoryOccupation IOC(nolock) 
	--	Where SDW.WarehouseId = IOC.WarehouseId And IOC.Type = 2 And SDW.StoreId = @StoreId And IOC.SkuId = @Skuid
	--	Union ALL
	--	Select isnull(Sum(IOC.Quantity), 0) * -1
	--	From InventoryOccupation IOC(nolock) 
	--	Where IOC.Type = 1 And IsDispatched = 0 And IOC.SkuId =@Skuid  And IOC.PayDate < @Paydate
	--	And (isnull(IOC.IsAppointDateDelivery, 0) = 0 or (isnull(IOC.IsAppointDateDelivery, 0) = 1 and PreDeliveryDate < getdate())) 
	--	And (IOC.WarehouseId in (Select WarehouseID From V_StoreDispatchWarehouse SDW(nolock) 
	--	Where SDW.StoreId = @StoreId) Or IOC.StoreId = @StoreId)
	--) A
	--Return @V_Result;

End;



go

