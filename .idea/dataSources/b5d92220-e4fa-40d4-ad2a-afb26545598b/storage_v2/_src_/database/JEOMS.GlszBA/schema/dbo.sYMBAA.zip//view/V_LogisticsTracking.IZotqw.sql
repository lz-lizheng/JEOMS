CREATE VIEW [dbo].[V_LogisticsTracking]  
AS  
SELECT Lt.StoreName,dod.TradeId,do.Code,do.DeliveryDate,ExpressName,ExpressNo,Lt.Status,  
Lt.Mobile, dod.WarehouseName, Consignee, Address, CreateTime, ModifyTime, Note,Lt.StoreId,ExpressId,Content  
From LogisticsTracking Lt(nolock)  
Left Join DispatchOrder  do (nolock)on lt.ExpressNo = do.ActualExpressNo AND Lt.DispatchOrderCode=do.Code
Left Join DispatchOrderDetail dod(nolock) on do.Id = dod.DispatchOrderId


go

