/**********************
*create date : 2018-05-25
*create by：qiaoni
*remark ： 店铺配货仓库清单视图
***********************/
Create View [dbo].[V_StoreDispatchWarehouse] as
Select S.Name as StoreName, StoreId, DispatchTemplateId, WH.Id as WarehouseID, WH.Name as WarehouseName
From dbo.Store S(nolock), dbo.StoreSetting SS(nolock), dbo.DispatchTemplateWarehouse DTW(nolock), dbo.Warehouse WH(nolock)
Where SS.DispatchTemplateId = DTW.TemplateId
And DTW.WarehouseId = WH.Id
and s.id = ss.StoreId
And WH.WarehouseType in (2, 3)
And WH.IsDisabled = 0
And DTW.IsDisabled = 0
UNION ALL
Select S.Name as StoreName, StoreId, DispatchTemplateId, WHC.Id as WarehouseID, WHC.Name as WarehouseName
From dbo.Store S(nolock), dbo.StoreSetting SS(nolock), dbo.DispatchTemplateWarehouse DTW(nolock), dbo.Warehouse WHP(nolock), dbo.Warehouse WHC(nolock)
Where SS.DispatchTemplateId = DTW.TemplateId
And DTW.WarehouseId = WHP.Id
And S.id  = SS.StoreId
And WHP.WarehouseType = 4
And WHP.Id = WHC.ParentId
And WHP.IsDisabled = 0
And WHC.IsDisabled = 0
And DTW.IsDisabled = 0


go

