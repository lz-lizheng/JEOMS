
-------------------------乔尼
CREATE FUNCTION [dbo].[f_Get_StoreRegionDefaultWarehouse]
(
	@P_StoreID		UNIQUEIDENTIFIER,
	@P_ProvinceName NVARCHAR(50),
	@P_CityName		NVARCHAR(50),
	@P_CountyName	NVARCHAR(50)
)
RETURNS @V_Warehouse TABLE(WarehouseID UNIQUEIDENTIFIER, WarehouseCode NVARCHAR(20), WarehouseName NVARCHAR(50))
AS
BEGIN
	--2. 建议仓库获取 问题点：a. 如果不设置仓库范围则为全部都到， b. 如果店铺没设置配货模板取店铺默认快递下的共享仓
	-- 转换需要注意的点： 更新配货模板时需要重启

	--SQL 1:
	--SET STATISTICS IO ON  
	INSERT INTO @V_Warehouse(WarehouseID, WarehouseCode, WarehouseName) 
	SELECT TOP 1 a.WarehouseId, a.Code, a.WarehouseName
	FROM ( 
		SELECT CASE WHEN WH.WarehouseType = 4 THEN WHC.Id ELSE DTW.warehouseid END AS WarehouseId,
			   CASE WHEN WH.WarehouseType = 4 THEN WHC.Code ELSE wh.Code END AS Code,
			   CASE WHEN WH.WarehouseType = 4 THEN WHC.Name ELSE wh.Name END AS WarehouseName, 
			   DTW.OrderId, wh.WarehouseType 
		FROM dbo.StoreSetting SS 
		INNER JOIN dbo.DispatchTemplate DT ON ss.DispatchTemplateId = DT.Id
		INNER JOIN dbo.DispatchTemplateWarehouse DTW ON DT.Id = DTW.TemplateId
		INNER JOIN dbo.Warehouse WH ON DTW.WarehouseId = WH.Id 
		LEFT JOIN dbo.Warehouse WHC ON ((wh.WarehouseType = 4 AND WH.Id = WHC.ParentId) OR (wh.WarehouseType IN (2, 3) AND wh.ParentId = whc.Id))
		WHERE DTW.IsDisabled = 0
		AND DT.IsDisabled = 0
		AND SS.StoreId = @P_StoreID
		AND (whc.IsRegion = 0 OR EXISTS (SELECT 1 FROM dbo.WarehouseRegion WR WHERE WR.ProvinceName = @P_ProvinceName 
					AND WR.CityName = @P_CityName AND WR.CountyName = @P_CountyName AND WH.ParentId = WR.WarehouseId))
		) A
	WHERE A.WarehouseId IS NOT NULL
	ORDER BY A.OrderId, A.WarehouseType;
	--SET STATISTICS IO OFF
   
   IF @@ROWCOUNT = 0
		BEGIN
			--SQL 2: -- 配货策略优先级最高的仓库
			INSERT INTO @V_Warehouse(WarehouseID, WarehouseCode, WarehouseName) 
			SELECT TOP 1 a.WarehouseId, a.Code, a.WarehouseName
			FROM ( 
				SELECT CASE WHEN WH.WarehouseType = 4 THEN WHC.Id ELSE DTW.warehouseid END AS WarehouseId,
					   CASE WHEN WH.WarehouseType = 4 THEN WHC.Code ELSE wh.Code END AS Code,
					   CASE WHEN WH.WarehouseType = 4 THEN WHC.Name ELSE wh.Name END AS WarehouseName, 
					   DTW.OrderId, wh.WarehouseType 
				FROM dbo.StoreSetting SS 
				INNER JOIN dbo.DispatchTemplate DT ON ss.DispatchTemplateId = DT.Id
				INNER JOIN dbo.DispatchTemplateWarehouse DTW ON DT.Id = DTW.TemplateId
				INNER JOIN dbo.Warehouse WH ON DTW.WarehouseId = WH.Id 
				LEFT JOIN dbo.Warehouse WHC ON ((wh.WarehouseType = 4 AND WH.Id = WHC.ParentId) OR (wh.WarehouseType IN (2, 3) AND wh.ParentId = whc.Id))
				WHERE DTW.IsDisabled = 0
				AND DT.IsDisabled = 0
				AND SS.StoreId = @P_StoreID
				) A
			WHERE A.WarehouseId IS NOT NULL
			ORDER BY A.OrderId, A.WarehouseType;
		END;   
	

	IF @@ROWCOUNT = 0
		BEGIN
			--SQL 2: -- 取店铺默认仓库
			INSERT INTO @V_Warehouse(WarehouseID, WarehouseCode, WarehouseName) 
			SELECT WH.Id, WH.Code, WH.Name AS WarehouseName
			FROM dbo.StoreSetting SS
			INNER JOIN dbo.Warehouse WH ON SS.DefaultWarehouseId = WH.Id
			WHERE WH.IsDisabled = 0 
			AND SS.StoreId = @P_StoreID;  
		END;   
	RETURN;
END;



go

