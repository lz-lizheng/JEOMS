create view [dbo].[purchasOrderReport] as
select  a.Code as PurchaseCode,a.CreateDate,RequestDeliveryDate,PurchaseDate,SupplierCode,SupplierName,
    case when a.Status='0' then '未审核' when a.Status='1' then '已审核'    when a.Status='3' then '已完结' end Status,
    ProductName,b.ProductCode,SkuName,SkuCode,purchaseqty,NoticeQty,InStockQty,isnull(contractno,'') as contractno,isnull(c.CiStockQty,0) CiStockQty,
    (case when  a.Status='0' then purchaseqty  when purchaseqty-isnull(InStockQty,0)<=0 then '0' when a.Status='1' then purchaseqty-isnull(InStockQty,0) else '0' end) as ztsl from  PurchaseOrder a left join PurchaseOrderDetail b on a.id=b.PurchaseOrderId
     left join 
	(
	select a.purchaseorderid,sum(b.DefectiveQuantity) CiStockQty from PurchaseNoticeOrder a inner join PurchaseNoticeOrderdetail b on a.id=b.PurchaseNoticeOrderId
	group by a.purchaseOrderCode,a.purchaseorderid) 
c on a.id=c.purchaseorderid



go

