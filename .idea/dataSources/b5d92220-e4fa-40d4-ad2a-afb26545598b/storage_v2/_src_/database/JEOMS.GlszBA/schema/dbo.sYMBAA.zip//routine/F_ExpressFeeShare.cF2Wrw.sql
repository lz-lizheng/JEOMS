

-- =============================================
-- Author:		Creoa
-- Create date: 2016-04-18
-- Description:	订单明细分摊邮费
-- =============================================
CREATE FUNCTION [dbo].[F_ExpressFeeShare]
(
	@orderid BIGINT,
	@orderdetailid BIGINT
)
RETURNS int
AS
BEGIN
	DECLARE @expressfee DECIMAL(12,4)
	DECLARE @AmountCount DECIMAL(12,4)
	DECLARE @shareamount DECIMAL(12,4)
	DECLARE @DetailCount INT=0
	DECLARE @i INT =0

	SELECT @expressfee=ExpressFee FROM dbo.SalesOrder(NOLOCK) WHERE OrderId=@orderid

	SET @AmountCount=(SELECT SUM(AmountActual) FROM dbo.SalesOrderDetail(NOLOCK) WHERE SalesOrderId=@orderid)
	
	SET @DetailCount=(SELECT COUNT(1) FROM dbo.SalesOrderDetail(NOLOCK) WHERE SalesOrderId=@orderid)
	
	DECLARE @AmountActual DECIMAL(12,4)
    DECLARE @DetailId BIGINT
    DECLARE @SareFee DECIMAL(12,4)=0
	DECLARE @TempFee DECIMAL(12,4)=0

	DECLARE DetailCursor CURSOR FOR SELECT AmountActual,DetailId FROM dbo.SalesOrderDetail(NOLOCK) WHERE SalesOrderId=@orderid ORDER BY CreateDate DESC
	OPEN DetailCursor
	fetch next from DetailCursor into @AmountActual,@DetailId
	while @@fetch_status<>-1
	BEGIN
		SET @i=@i+1  
			IF @i=@DetailCount
				BEGIN
					SET @SareFee=@expressfee-@TempFee
				END 
			ELSE
				BEGIN
					SET @SareFee=ROUND((@AmountActual/ISNULL(@AmountCount,1)),2)*@expressfee
				END
			IF @DetailId=@orderdetailid
				BEGIN
					SET @shareamount=@SareFee+@AmountActual
				END          
			SET @TempFee=@TempFee+@SareFee
	fetch next from DetailCursor into @AmountActual,@DetailId
	end
	close DetailCursor
	deallocate DetailCursor

	RETURN @shareamount
END



go

