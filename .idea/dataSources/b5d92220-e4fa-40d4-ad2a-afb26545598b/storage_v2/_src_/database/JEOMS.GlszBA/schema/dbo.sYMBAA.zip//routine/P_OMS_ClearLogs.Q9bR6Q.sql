
 
--/**
--	创建表清理表结构
--**/
--Create Table OMS_Clear_Tables
--(
--	Id int primary key identity(1, 1),
--	TableName nvarchar(100),
--	TableDescription nvarchar(255),
--	KeyColumn varchar(100),
--	ClearByDateColumn nvarchar(30),
--	SpecialCriteria nvarchar(1000),
--	LastDate DateTime Default '2017-01-01',
--	DataStoreDays int default 90,
--	UpdateDate DateTime,
--	Remark nvarchar(255)
--)
  

--/** 写入清理表清单 **/
--Insert into OMS_Clear_Tables Values('ApiLog', 'Api日志', 'Id', 'CreateDate', Null, '2017-01-01', 90, GetDate(), 'Test')

--Insert into OMS_Clear_Tables Values('ApiInventoryChange', 'API库存异动日志','Id', 'CreateDate', 'join Warehouse w on ApiInventoryChange.Whcode = w.Code where (w.WarehouseType = 5 or ac.IsFull=1) and ApiInventoryChange.Id = ac.Id and ApiInventoryChange.StockSyncStatus=2 ', '2017-01-01', 90, GetDate(), 'Test')


--Insert into OMS_Clear_Tables Values('DistributionLog ','铺货日志', 'Id', 'CreateDate', null, '2017-01-01', 90, GetDate(), 'Test')
  
--Insert into OMS_Clear_Tables Values('InventoryUploadLog ', '库存上传日志','Id', 'CreateDate', null, '2017-01-01', 90, GetDate(), 'Test')
  


/**********************************************************************/




/*

	Select * From OMS_Clear_Tables
	Drop Table TempClearDataTable
	Select * From TempClearDataTable
	 Select Cast(InventoryUploadLog.CreateDate as Date) as CreateDate From  InventoryUploadLog Where 1 = 1 Group By Cast(InventoryUploadLog.CreateDate as Date)

  */
   

CREATE Proc [dbo].[P_OMS_ClearLogs]
As
Begin 
	Declare @TableName nvarchar(100), @KeyColumn nvarchar(50), @ClearByDateColumn nvarchar(100), @SpecialCriteria nvarchar(1000), @LastDate Date
	Declare @DataStoreDays int, @ExecSql nvarchar(4000)
	Declare @DataBeforeDate nvarchar(20), @LoopCnt int, @Current int
	
	Declare TabCur Cursor For
		Select RTrim(TableName), KeyColumn, ClearByDateColumn, SpecialCriteria, LastDate, DataStoreDays
		From OMS_Clear_Tables
		Where TableName like '%Log%' or TableName like '%ApiInventoryChange'
	Open TabCur
	Fetch next From TabCur Into @TableName, @KeyColumn, @ClearByDateColumn, @SpecialCriteria, @LastDate, @DataStoreDays;
	While @@FETCH_STATUS = 0
	Begin 
		Set @Current = 0;
		If Exists (Select 1 From Sysobjects where name = 'TempClearDataTable')
			Begin
				Set @ExecSql = 'Drop Table TempClearDataTable'
				print @ExecSql;
				Exec SP_EXECUTESQL @ExecSql;
			End
		If @DataStoreDays < 30 
			Begin
				Set @DataStoreDays = 30;
			End;

		Set @DataBeforeDate = Convert(varchar(10), Dateadd(day, @DataStoreDays * -1, GetDate()), 20)
		Set @ExecSql =	' Select Cast(' + @TableName + '.' + @ClearByDateColumn + ' as Date) as CreateDate Into TempClearDataTable'
					+ ' From  ' + @TableName 
					+ Isnull(@SpecialCriteria, ' Where 1 = 1') 
					+ ' And ' +  @TableName + '.' + @ClearByDateColumn + ' < ''' + @DataBeforeDate + ''''
					+ ' Group By Cast(' + @TableName + '.' + @ClearByDateColumn + ' as Date)'
 
		Print @ExecSql;
		Exec SP_EXECUTESQL @ExecSql;

		Select @LoopCnt = Count(1) From TempClearDataTable;
		Print 'Loop Cnt ' + cast(@LoopCnt as nvarchar(100)) 
		print  cast(@Current as nvarchar(100))
	 
	 
		----  循环归档数据
		--WHILE  (@LoopCnt > 0 And @Current < @LoopCnt)--循环次数
		--BEGIN 
		--   PRINT '***************************************************************************************'
	 
		--	Select Top 1 @LastDate = CreateDate From TempClearDataTable Order By CreateDate;
          
		--	PRINT CONVERT(VARCHAR, @LastDate, 20)

		--	Set @ExecSql = ' Drop Table TempClearDataTableIds'
		--	Print @ExecSql;
		--	Exec SP_EXECUTESQL @ExecSql;

		--	Set @ExecSql =	' Select ' + @TableName + '.' + @KeyColumn + ' Into TempClearDataTableIds '
		--					+ ' From  ' + @TableName 
		--					+ Isnull(@SpecialCriteria, ' Where 1 = 1') 
		--					+ ' And ' +  @TableName + '.' + @ClearByDateColumn + ' <= ''' + Convert(Varchar(10), @LastDate, 20) + ''''

		--   Print @ExecSql;
		--   Exec SP_EXECUTESQL @ExecSql;

		--   Set @ExecSql = 'Delete From ' + @TableName + ' Where ' + @KeyColumn + ' In ( Select * From TempClearDataTableIds )'	   
		--   Print @ExecSql;
		--   Exec SP_EXECUTESQL @ExecSql;

		--   Delete From TempClearDataTable Where CreateDate = @LastDate; 
		--   PRINT @Current
		--   Set @Current = @Current + 1
		--   waitfor delay '00:00:01.000' -- 休息1秒钟再处理 
		--END 

	 
		--Update OMS_Clear_Tables Set UpdateDate = GetDate(), Remark = 'Update Success' Where Tablename = @TableName;

	
		Fetch next From TabCur Into @TableName, @KeyColumn, @ClearByDateColumn, @SpecialCriteria, @LastDate, @DataStoreDays;
	End
	Close TabCur;
	Deallocate TabCur; 
	
End;



go

