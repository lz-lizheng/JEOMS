
 /**
  区域信息视图
 */
 Create VIEW [dbo].[V_Region] AS 
SELECT	Ct.Id AS CountryId, ct.Name AS CountryName, ct.Code AS CountryCode, Pro.Id AS ProvinceId, 
		pro.Name AS ProvinceName, pro.code AS ProvinceCode, Pro.Lng as ProvinceLng, Pro.Lat as ProvinceLat,
		City.id AS CityId, city.name AS CityName, city.code AS CityCode, City.Lng as CityLng, City.lat as CityLat,
		Dt.Id AS DistrictId,  dt.name AS DistrictName, dt.code AS DistrictCode, dt.Lng as DistrictLng, dt.Lat as DistrictLat
FROM Region AS ct(nolock),
	Region AS Pro(nolock),
	Region AS City(nolock), 
	Region AS dt(nolock)
WHERE ct.RegionLevel = 1
AND ct.Id = pro.ParentId
AND pro.Id = City.ParentId
AND City.id = dt.ParentId



 go

