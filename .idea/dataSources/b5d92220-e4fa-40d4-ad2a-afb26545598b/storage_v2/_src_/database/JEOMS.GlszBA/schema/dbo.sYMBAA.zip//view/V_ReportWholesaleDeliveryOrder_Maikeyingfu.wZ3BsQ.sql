/**
*create date : 2019-10-14
*create modify：拓斗
*remark ：麦克英孚批发发货单报表视图脚本
*/
CREATE VIEW [dbo].[V_ReportWholesaleDeliveryOrder_Maikeyingfu] AS SELECT
wdo.Code,--发货单号
spo.Code AS PlanCode,--销售计划单号
wdo.Status,--状态
wdo.DistributorCode,--分销商编码
wdo.DistributorId,--分销商编码
wdo.DistributorName,--分销商名称
spo.RealDistributorCode,--实际分销商编码
spo.RealDistributorId,--实际分销商编码
spo.RealDistributorName,--实际分销商名称
wdo.SalesArea,--销售区域
wdo.CreateDate,--创建时间
wdo.OutWarehouseName,--出库仓库
wdo.OutVirtualWarehouseName,--出库子仓
InWarehouseName,--入库仓库
spo.OrderTypeName,--单据类型
SalesResonName,--订单原因
SendDistributorName,--送达方
wdo.Consignee,--收件人
ConsigneeMobile,--手机
wdo.CountryName,--国家
wdo.ProvinceName,--省
wdo.CityName,--市
wdo.CountyName,--区
ConsigneeAddress,--详细地址
SalesMan,--销售员
spo.Remark,--备注
wdod.ProductCode,--商品编码
wdod.ProductName,--商品名称
wdod.SkuCode,--规格编码
wdod.SkuName,--规格名称
wdod.IsGift,--赠品
spod.Quantity,--计划数量
wdod.PlanQty as NoticeQuantity,--通知数量
OutQty,--出库数量
Price,--原价
Discount,--折扣
DiscountPrice,--折后价
case when NoticeQuantity=0 then 0 else spod.DiscountAmount / NoticeQuantity * PlanQty end as DiscountAmount,--折后金额
case when spod.NoticeQuantity=0 then 0 else SalesAmount / spod.NoticeQuantity * PlanQty end AS SalesAmount,--销售金额
case when spod.NoticeQuantity=0 then 0 else DiscountCount / NoticeQuantity * PlanQty end AS DiscountCount,--整单优惠
case when spod.NoticeQuantity=0 then 0 else ActualAmount / NoticeQuantity * PlanQty end AS ActualAmount,--结算金额
pd.OutCode AS POutCode,--SAP销售单号
dccr.OutCode AS WOutCode,--SAP交货单号
wdod.WarehouseDeliveryTime,--出库时间
spo.SalesRegion,--销售地区
p.Series,--型号
p.Brand,--品牌
(
CASE
WHEN PATINDEX( '%[0-9]%', w.Code )  <= 0 THEN
w.Code ELSE SUBSTRING ( w.Code, PATINDEX( '%[0-9]%', w.Code ), 4 )
END
) Factory,--发货工厂
spod.Remark DetailRemark --明细备注
FROM
dbo.WholesaleDeliveryOrderMKYF wdo
LEFT JOIN dbo.WholesaleDeliveryOrderDetailMKYF wdod ON wdod.WholesaleDeliveryId= wdo.Id
LEFT JOIN dbo.SalesPlanOrder spo ON wdo.WholesalePlanId= spo.Id
AND wdod.WholesalePlanId= spo.Id
LEFT JOIN dbo.SalesPlanOrderDetail spod ON spod.SalesPlanOrderId= spo.Id
AND wdod.WholesalePlanDetailId= spod.Id
LEFT JOIN dbo.DataCallCustomRecord dccr ON dccr.DataCode= wdo.Code
LEFT JOIN dbo.DataCallCustomRecord pd ON pd.DataCode= spo.Code
LEFT JOIN dbo.Product p ON p.ProductId= wdod.ProductId
LEFT JOIN dbo.Warehouse w ON wdo.OutVirtualWarehouseId= w.Id


go

