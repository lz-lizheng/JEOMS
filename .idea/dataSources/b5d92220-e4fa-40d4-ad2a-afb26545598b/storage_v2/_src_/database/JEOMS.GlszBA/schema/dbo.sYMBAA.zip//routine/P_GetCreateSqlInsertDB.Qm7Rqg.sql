 
/*============================================================
获取当前数据库下面的所有表的创建语句并插入到OMS_SYNC_TABLES表中
===============================================================*/
CREATE PROCEDURE [dbo].[P_GetCreateSqlInsertDB]
AS
BEGIN
	DECLARE @DBNAME NVARCHAR(100),@TBNAME NVARCHAR(100),@SQL NVARCHAR(max)
	DECLARE @Name NVARCHAR(100),@RESULT NVARCHAR(max);
	TRUNCATE TABLE OMS_SYNC_TABLES;

	DECLARE TabCur CURSOR FOR
		--	拿到所有表名
			Select Name FROM SysObjects Where XType='U' ORDER BY Name;
	OPEN TabCur
		FETCH NEXT FROM TabCur INTO @Name;
	WHILE @@FETCH_STATUS = 0
		BEGIN
			Begin try
				Select @DBNAME = '['+Name+']' From Master..SysDataBases Where DbId=(Select Dbid From Master..SysProcesses Where Spid = @@spid);
		
				 --'[implement-oms]'
				SET @TBNAME = @Name
				EXEC [dbo].[GET_TableScript_MSSQL] @DBNAME,@TBNAME,@RESULT OUT
				--打印出结果
				PRINT @RESULT
		
				Insert INTO dbo.OMS_SYNC_TABLES (TableName,CreateSql) 
										VALUES (@Name,@RESULT);
			end try
			begin catch
				print @TBNAME + ' Exec Error. '
			end catch
		  
		FETCH NEXT FROM TabCur INTO @Name;
		END;
	CLOSE TabCur;
	DEALLOCATE TabCur;
END


go

