

CREATE VIEW [dbo].[V_UserPrivilege]
AS
  SELECT  p.*,r.Id RoleId,ru.UserId FROM dbo.Privilege p JOIN dbo.Role r ON p.OperaterId=r.Id JOIN dbo.RoleUser ru ON r.Id=ru.RoleId



go

