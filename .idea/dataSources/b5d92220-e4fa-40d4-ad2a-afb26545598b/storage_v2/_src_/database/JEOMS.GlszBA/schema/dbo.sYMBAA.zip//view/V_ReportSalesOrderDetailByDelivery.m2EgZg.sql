
/**    
*create date : 2021-1-11
*create modify：拓斗    
*remark ：订单明细统计发货视图添加退款状态
*/
CREATE VIEW [dbo].[V_ReportSalesOrderDetailByDelivery]
AS
SELECT SOD.DetailId AS DetailId,            --订单明细ID    
       DO.DeliveryDate AS DeliveryDate,     --发货日期    
       DO.StoreId AS OStoreId,
       DO.StoreId AS StoreId,
       dod.TradeId AS SalesOrderTradeId,
       DO.ActualExpressId AS ExpressId,
       dod.ProductCode,
       dod.ProductSkuCode AS SkuCode,
       DO.WarehouseId,
       dod.SalesOrderCode,
       DO.ActualExpressNo,
       SO.TradeFinishDate,
       SO.PayDate AS SalesOrderPayDate,     --付款时间    
       DO.Code AS DispatchProductOrderCode, --配货单号  
       DO.CreateDate AS DispatchDate,       --配货时间  
       DO.Status AS DispatchOrderStatus,    --配货状态  
       SO.RefundStatus AS SalesOrderRefundStatus  --退款状态
FROM dbo.SalesOrder (NOLOCK) SO
    JOIN dbo.SalesOrderDetail (NOLOCK) SOD
        ON SO.OrderId = SOD.SalesOrderId
    LEFT JOIN dbo.DispatchOrderDetail (NOLOCK) dod
        ON dod.SalesOrderDetailId = SOD.DetailId
           AND dod.Status <> 1
    LEFT JOIN dbo.DispatchOrder (NOLOCK) DO
        ON dod.DispatchOrderId = DO.Id
           AND DO.Status <> 3
WHERE SOD.IsAbnormal = 0
      AND SO.TransType <> 1;

go

