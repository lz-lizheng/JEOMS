CREATE VIEW [dbo].[V_BI_BatchInvneotryVirtual] AS SELECT ab.SkuCode, p.Code AS PCode, p.Description, ab.BatchCode, ab.WarehouseId, 
      ab.WarehouseName, p.ShelfLife, ab.ProductDate, ab.ExpireDate, p.Brand, 
      sku.CustomCode, ab.Quantity, ISNULL(SUM(ioc.Quantity), 0) AS OccQuantity, 
      ab.Quantity - ISNULL(SUM(ioc.Quantity), 0) AS CanUserQty, 
      CASE ab.InventoryType WHEN 'ZP' THEN '正品' WHEN 'CC' THEN '次品' ELSE NULL 
      END AS InventoryType
FROM (SELECT SkuId, WarehouseId, BatchCode, SkuCode, SUM(ISNULL(Quantity, 0)) 
              AS Quantity, WarehouseName, ExpireDate, ProductDate, InventoryType
        FROM dbo.ApiOrderBatchRecord
        GROUP BY SkuId, WarehouseId, BatchCode, SkuCode, WarehouseName, 
              InventoryType, ExpireDate, ProductDate) AS ab LEFT OUTER JOIN
      dbo.Warehouse AS swh WITH (NOLOCK) ON 
      swh.ParentId = ab.WarehouseId LEFT OUTER JOIN
      dbo.ProductSku AS sku WITH (NOLOCK) ON sku.SkuId = ab.SkuId LEFT OUTER JOIN
      dbo.Product AS p WITH (NOLOCK) ON p.ProductId = sku.ProductId LEFT OUTER JOIN
      dbo.InventoryOccupation AS ioc WITH (NOLOCK) ON 
      ioc.BatchCode = ab.BatchCode AND ioc.SkuId = ab.SkuId AND 
      ioc.WarehouseId = swh.Id
GROUP BY ab.SkuCode, ab.BatchCode, ab.WarehouseId, ab.WarehouseName, 
      ab.ExpireDate, ab.ProductDate, p.Code, p.Brand, sku.CustomCode, p.ShelfLife, 
      p.Description, ab.Quantity, ab.InventoryType
go

