Create View [dbo].[V_InventoryVirtual_ERRKE]
As
select 
w.Id WarehouseId,
w.Code WarehouseCode,
w.Name WarehouseName,
vs.DispatchedQuantity,
vs.UnDispatchedQuantity,
vs.AllotQuantity,
vs.VipQuantity,
vs.CombQuantity,
(ISNULL(iv.Quantity, 0)-ISNULL(vs.LockedQuantity, 0)) AS CanSaleQuantity ,
(ISNULL(iv.Quantity, 0)-ISNULL(vs.DispatchedQuantity, 0)-ISNULL(vs.AllotQuantity, 0)-ISNULL(vs.VipQuantity, 0)-ISNULL(vs.CombQuantity, 0)) AS CanUseQuantity,
iv.TransitTotalQuantity,
p.Brand,
p.FirstLevelCategoryName,
p.TwoLevelCategoryName,
p.CategoryName,
p.[Year],
p.Season,
sku.SKC,
sku.CustomCode,
p.Code ProductCode,
p.Description ProductName,
p.Attribute1 Sex,
sku.Code SkuCode,
sku.Description SkuName,
sku.Color,
sku.[Size],
iv.Quantity,
p.WholeSalePrice
from V_InventoryVirtualMap(nolock) iv 
join ProductSku(nolock)  sku on sku.SkuId =iv.SkuId
join Product(nolock)  p on p.ProductId =sku.ProductId
join Warehouse(nolock) w on w.Id=iv.WarehouseId
left join V_InventoryOccupationSum vs on iv.SkuId= vs.SkuId and vs.WarehouseId=iv.WarehouseId


go

