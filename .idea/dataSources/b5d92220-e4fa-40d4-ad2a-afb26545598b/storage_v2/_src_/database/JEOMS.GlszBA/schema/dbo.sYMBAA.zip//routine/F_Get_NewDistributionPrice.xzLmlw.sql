
/*
通过指定时间点，查询某个（或多个）分销商，指定一个商品（或sku）的分销价（经销价）的报表
1.如果调价单被禁用了，禁用的的时候，如果未到失效时间，会把时效时间更新为禁用时间，
	取价的时候看调价单的有效时间和时效时间段，有重叠的取复核时间靠后的


	客户代码	客户名称	货号	商品名称	SKU	颜色编码	颜色	规格	年份	季节	品牌	大类	
	性别	翻单专供	市场价	代发价	批发价	代发折扣	批发折扣	代发策略编号	调价起始日期	调价结束日期
*/


-- Select * from dbo.[F_Get_DistributionPrice_Temps]('20180627133', '2018-09-02', '12214157028', '')
/*
Select * From DistributionPriceChangeDetail
 */

CREATE FUNCTION  [dbo].[F_Get_NewDistributionPrice] 
(
	@P_DistributorId nvarchar(100),
	@P_PayDate DateTime,
	@P_ProductCode nvarchar(100),
	@P_SkuCode nvarchar(100) = ''
)
Returns @ReturnTable  TABLE
(	 
	 ProductCode nvarchar(200),
	 ProductName nvarchar(200),
	 SkuCode nvarchar(200),
	 SkuName nvarchar(200),
	 Color nvarchar(200),
	 Size nvarchar(200),
	 Years nvarchar(200),
	 Season nvarchar(200),
	 Brand nvarchar(200),
	 CategoryName nvarchar(200),
	 FirstPrice Decimal(15, 4),
	 JxPrice Decimal(15, 4),
	 FxDiscount Decimal(10, 2),
	 FxCalcOrderCode nvarchar(200),
	 FxPrice Decimal(15, 4),
	 JxDiscount Decimal(10, 2),
	 JxCalcOrderCode nvarchar(200)
)
	--客户代码	客户名称	货号	商品名称	SKU	颜色编码	颜色	规格	年份	季节	品牌	大类	
	--性别	翻单专供	市场价	代发价	批发价	代发折扣	批发折扣	代发策略编号	调价起始日期	调价结束日期
AS
Begin
		Declare @Fx_Price Decimal(15, 2), @Fx_OrderCode nvarchar(100), @Jx_OrderCode nvarchar(100), @Jx_Price Decimal(15, 2)
		Declare @DistributorDiscountId uniqueidentifier, @Year nvarchar(100), @Season nvarchar(100), @Brand nvarchar(100)
		Declare @Fx_ZK decimal(12, 2), @Jx_ZK decimal(12, 2), @PlatformPrice decimal(12,2)

		if @P_ProductCode is not null and @P_SkuCode is not null
			Begin
				Select Top 1 @P_ProductCode = ProductCode From ProductSku Where Code = @P_SkuCode;
			End

		/************************* Get FX Price Start ******************************/
		If @P_SkuCode is not NULL
			Begin 
					Select Top 1 @Fx_Price = isnull(Price, 0), @Fx_OrderCode = dpc.Code
					From DistributionPriceChange dpc(nolock), DistributionPriceDistributior dpd(nolock), DistributionPriceChangeDetail dpcd(nolock),ProductSku ps(nolock)
					where dpc.Id = dpcd.PriceChangeId
					and dpc.id = dpd.PriceChangeId
					and dpcd.SkuId = ps.SkuId
					And @P_PayDate >= dpc.BeginDate
					And @P_PayDate < dpc.EndDate
					And AuditDate <= @P_PayDate
					And dpcd.SkuCode = @P_SkuCode
					And dpd.DistributiorId = @P_DistributorId
					and dpc.PriceType = 0
					Order by dpc.AuditDate desc;
			End; 
			  
		If isnull(@Fx_Price, 0) = 0
				Begin 
						Select Top 1 @Fx_Price = isnull(Price, 0), @Fx_OrderCode = dpc.Code
						From DistributionPriceChange dpc(nolock), DistributionPriceDistributior dpd(nolock), DistributionPriceChangeDetail dpcd(nolock), Product pd(nolock)
						where dpc.Id = dpcd.PriceChangeId
						and dpc.id = dpd.PriceChangeId
						and dpcd.ProductId = pd.ProductId
						And @P_PayDate >= dpc.BeginDate
						And @P_PayDate < dpc.EndDate
						And AuditDate <= @P_PayDate
						And dpcd.ProductCode = @P_ProductCode
						And dpd.DistributiorId = @P_DistributorId
						and dpcd.SkuCode is null
						and dpc.PriceType = 0
						Order by dpc.AuditDate desc; 
				End;  

		if isnull(@Fx_Price, 0) = 0
			Begin
				-- 取分销价
				Select Top 1 @Year = Year, @Season = Season, @Brand = Brand, @PlatformPrice =PlatformPrice
				From Product
				Where Code = @P_ProductCode; 

				-- Distributor --
				if exists(
						Select *
						From DistributorDiscount dd, DistributorDiscountDetail ddd
						Where ReviewDate < @P_PayDate
						and @P_PayDate < FailureTime 
						and @P_PayDate > EffecTime
						and dd.PriceType = 0
						and ddd.BrandCode = @Brand
						and ddd.Season = @Season
						and ddd.Year = @Year
						) 
					Begin
						Select Top 1 @Fx_ZK = dd.Discount, @Fx_OrderCode = dd.Code
						From DistributorDiscount dd, DistributorDiscountDetail ddd
						Where ReviewDate < @P_PayDate
						and @P_PayDate < FailureTime 
						and @P_PayDate > EffecTime
						and dd.PriceType = 0
						and ddd.BrandCode = @Brand
						and ddd.Season = @Season
						and ddd.Year = @Year
						order by FailureTime desc;
					End;
				Else
					Begin
						Select Top 1 @Fx_ZK = dd.Discount, @Fx_OrderCode = dd.Code  
						From DistributorDiscount dd 
						Where ReviewDate < @P_PayDate
						and @P_PayDate < FailureTime 
						and @P_PayDate > EffecTime
						and dd.PriceType = 0
						Order by ReviewDate Desc;
					End; 

				Set @Fx_Price = Round(isnull(@PlatformPrice, 0) *isnull(@Fx_ZK, 0) / 100, 2);
			End;
		/************************* Get FX Price End ******************************/




		/************************* Get JX Price Start ******************************/
		If @P_SkuCode is not NULL
			Begin 
					Select Top 1 @Jx_Price = isnull(Price, 0), @Jx_OrderCode = dpc.Code
					From DistributionPriceChange dpc(nolock), DistributionPriceDistributior dpd(nolock),  DistributionPriceChangeDetail dpcd(nolock),ProductSku ps(nolock)
					where dpc.Id = dpcd.PriceChangeId
					and dpc.id = dpd.PriceChangeId
					and dpcd.SkuId = ps.SkuId
					And @P_PayDate >= dpc.BeginDate
					And @P_PayDate < dpc.EndDate
					And AuditDate <= @P_PayDate
					And dpcd.SkuCode = @P_SkuCode
					And dpd.DistributiorId = @P_DistributorId
					and dpc.PriceType = 1
					Order by dpc.AuditDate desc;
			End; 
			  
		If isnull(@Jx_Price, 0) = 0
				Begin 
						Select Top 1 @Jx_Price = isnull(Price, 0), @Jx_OrderCode = dpc.Code
						From DistributionPriceChange dpc(nolock),DistributionPriceDistributior dpd(nolock),  DistributionPriceChangeDetail dpcd(nolock), Product pd(nolock)
						where dpc.Id = dpcd.PriceChangeId
						and dpc.id = dpd.PriceChangeId
						and dpcd.ProductId = pd.ProductId
						And @P_PayDate >= dpc.BeginDate
						And @P_PayDate < dpc.EndDate
						And AuditDate <= @P_PayDate
						And dpcd.ProductCode = @P_ProductCode
						And dpd.DistributiorId = @P_DistributorId
						and dpcd.SkuCode is null
						and dpc.PriceType = 1
						Order by dpc.AuditDate desc; 
				End;  

		if isnull(@Jx_Price, 0) = 0
			Begin
				-- 取经销价
				Select Top 1 @Year = Year, @Season = Season, @Brand = Brand, @PlatformPrice =PlatformPrice
				From Product
				Where Code = @P_ProductCode; 

				-- Distributor --
				if exists(
						Select *
						From DistributorDiscount dd, DistributorDiscountDetail ddd
						Where ReviewDate < @P_PayDate
						and @P_PayDate < FailureTime 
						and @P_PayDate > EffecTime
						and dd.PriceType = 1
						and ddd.BrandCode = @Brand
						and ddd.Season = @Season
						and ddd.Year = @Year
						) 
					Begin
						Select Top 1 @Jx_ZK = dd.Discount, @Jx_OrderCode = dd.Code
						From DistributorDiscount dd, DistributorDiscountDetail ddd
						Where ReviewDate < @P_PayDate
						and @P_PayDate < FailureTime 
						and @P_PayDate > EffecTime
						and dd.PriceType = 1
						and ddd.BrandCode = @Brand
						and ddd.Season = @Season
						and ddd.Year = @Year
						order by FailureTime desc;
					End;
				Else
					Begin
						Select Top 1 @Jx_ZK = dd.Discount, @Jx_OrderCode = dd.Code  
						From DistributorDiscount dd 
						Where ReviewDate < @P_PayDate
						and @P_PayDate < FailureTime 
						and @P_PayDate > EffecTime
						and dd.PriceType = 1
						Order by ReviewDate Desc;
					End; 

				Set @Jx_Price = Round(isnull(@PlatformPrice, 0) *isnull(@Jx_ZK, 0) / 100, 2);
			End;
		/************************* Get FX Price End ******************************/

		 

		--return Round(isnull(@PlatformPrice, 0) *isnull(@ZK, 0) / 100, 2)
		If isnull(@P_SkuCode, '') = ''
			Begin
				INSERT INTO @ReturnTable(ProductCode,ProductName,SkuCode,SkuName,Color,Size,Years,Season,Brand,CategoryName,FirstPrice,
											FxPrice,FxDiscount,FxCalcOrderCode,JxPrice,JxDiscount,JxCalcOrderCode)
				Select pd.Code, Pd.Description as ProductName, Null as SkuCode, NUll as SkuName, null, null, pd.Year, pd.Season,
					   pd.Brand, pd.CategoryName, pd.FirstPrice, @Fx_Price, @Fx_ZK as FxDiscout, @Fx_OrderCode, @Jx_Price, @Jx_ZK as JxDiscount, @Jx_OrderCode
				From Product pd 
				Where pd.Code = @P_ProductCode
			End 
		Else 
			Begin
				INSERT INTO @ReturnTable(ProductCode,ProductName,SkuCode,SkuName,Color,Size,Years,Season,Brand,CategoryName,FirstPrice,
											FxPrice,FxDiscount,FxCalcOrderCode,JxPrice,JxDiscount,JxCalcOrderCode)
				Select pd.Code, Pd.Description as ProductName, ps.Code as SkuCode, ps.Description as SkuName, ps.Color, ps.Size, pd.Year, pd.Season,
					   pd.Brand, pd.CategoryName, pd.FirstPrice, @Fx_Price, @Fx_ZK as FxDiscout, @Fx_OrderCode, @Jx_Price, @Jx_ZK as JxDiscount, @Jx_OrderCode
				From Product pd Join ProductSku ps on ps.ProductId = pd.ProductId and (ps.Code = @P_SkuCode or isnull(@P_SkuCode, '') = '')
				Where pd.Code = @P_ProductCode
			End
		Return;
End;


go

