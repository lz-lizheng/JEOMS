

/**********************
*create by：QiaoNi　20180929
-remark 　 商品分类层级视图调整
***********************/
CREATE VIEW [dbo].[V_ProductCategory] AS 
SELECT pc1.Id AS OneCatId, pc1.Name AS OneCatName, pc2.id AS TwoCatId, pc2.Name AS TwoCatName, isnull(pc3.id, pc2.id) AS ThreeCatId, isnull(pc3.Name, pc2.Name) as ThreeCatName
FROM ProductCategory PC1
LEFT JOIN dbo.ProductCategory PC2 ON pc1.Id = pc2.ParentId
LEFT JOIN dbo.ProductCategory PC3 ON pc2.Id = pc3.ParentId
WHERE pc1.Level = 1



go

