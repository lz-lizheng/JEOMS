

-- CreateUser : JE
-- CreateDate : 2016-04-11 
-- ModifyDate : 2017-12-27
-- Description: 自动创建需要开票的信息, 上线时需要设置开票单据的起始时间点，　否则可能存在重复开票问题 
-- 需要设定起始开票时间点，　用来控制重复开票   
CREATE PROC [dbo].[P_AutoElectronicInvoiceReturnAndChange]
AS
BEGIN
	DECLARE @V_BeginDate DATE   
	DECLARE @V_EmailAddr nvarchar(100)  
	  
	DECLARE @V_IndustryClassificationCode NVARCHAR(50), @V_IndustryClassificationName NVARCHAR(50), @V_CrateUser NVARCHAR(50)
	DECLARE @V_GoodsName NVARCHAR(50), @V_TaxRate NUMERIC(12, 6), @V_Status NVARCHAR(10), @V_InvoiceType NVARCHAR(10)
	DECLARE @V_BuyerTypes NVARCHAR(10), @V_InvoiceLineNatureName NVARCHAR(50), @V_InvoiceLineNature NVARCHAR(50)
	 
	SET @V_Status = 2;
	SET @V_InvoiceType = 0;	
	Set @V_EmailAddr = 'fapiao@elfsack.com'
   
	  
	-- 退货单开票 @V_BeginDate 开票时排除退回的商品， 只对未退货的部分开票
	BEGIN
		SELECT ID, TradeId, SalesOrderCode, SalesOrderId INTO #TMPRtn 
		FROM dbo.ReturnOrder 
		WHERE IsReplace = 0 AND IsElectronicInvoiceCreated = 0 AND AuditDate >= @V_BeginDate; 
		  
		-- 开票时排除退回的商品， 只对未退货的部分开票  
		SELECT so.TradeId, MIN(so.Code) Code, SUM(sod.AmountActual) NewInvAmt
		INTO #TMPRtnInv
		FROM dbo.SalesOrder so(NOLOCK), dbo.SalesOrderDetail sod(NOLOCK)
		WHERE so.OrderId = sod.SalesOrderId 
		AND TradeId IN (SELECT TradeId FROM #TMPRtn) 
		AND sod.Status = 2
		AND sod.IsDeleted = 0
		and StoreId in (Select StoreId From StoreSetting Where AutoInvoice = 1)
		And not exists (Select 1 From ReturnOrderDetail rod where sod.DetailId = rod.SalesOrderDetailId)
		GROUP BY so.TradeId;

		-- 销售订单开票
		SELECT NEWID() as ElectronicInvoiceId, SOI.Code, SOI.StoreId, SOI.StoreName, SOI.TradeId, 
			2 AS Status, CrateUser AS AuditUser, GETDATE() AS AuditDate,
			@V_InvoiceType as InvoiceType, soi.Title AS buyerName, SOI.Telephone as Telephone, 
			CrateUser as InvoiceCreateUser, soi.Amount AS InvoiceAmount, 
			ROUND(soi.Amount / (1 + TaxRate), 2) AS InvoiceAmountWithOutTax, 
			(soi.Amount - ROUND(soi.Amount / (1 + TaxRate), 2)) AS InvoiceTax, 
			NULL AS Remark, IndustryClassificationCode, 
			IndustryClassificationName, InvoiceLineNature, GoodsName, NULL AS Unit, 
			ROUND(soi.Amount / (1 + TaxRate), 2) AS GoodsUnitPrice, 1 as GoodsQty,
			TaxRate * 100 as TaxRate, GETDATE() as CreateDate, 
			CrateUser, @V_EmailAddr as EmailAddr, 0 as IsReded, soi.OrderId,
			SOI.IdentificationNoPaxpayer,SOI.GmfAddress,SOI.GmfBankName,SOI.GmfBankNo 
		Into #TMPInvoiceHdr
		FROM (
				SELECT Distinct So.Code, So.StoreId, So.StoreName, so.TradeId, 
					NewAmt.NewInvAmt  as Amount,
					case when so.HasInvoice = 1 then soi.Title else '个人' End as Title,
					isnull(soi.GmfMobile, sos.Mobile) as Telephone, so.OrderId, 
					SOI.IdentificationNoPaxpayer,SOI.GmfAddress,SOI.GmfBankName,SOI.GmfBankNo, 
					EIC.Kpr as CrateUser, EIC.SL * 1.0 / 100 TaxRate, 
					EIC.Hylx as IndustryClassificationCode, EIC.HylxName as IndustryClassificationName,
					EIC.FphXz as InvoiceLineNature, 
					EIC.XmMc as GoodsName
				FROM #TMPRtnInv NewAmt
				LEFT JOIN dbo.SalesOrder so ON so.Code = NewAmt.Code
				LEFT JOIN dbo.SalesOrderInvoice soi ON so.OrderId = soi.SalesOrderId
				LEFT JOIN dbo.SalesOrderSub sos ON so.OrderId = sos.SubId
				Left Join StoreSetting SS on SO.StoreId = SS.StoreId
				Left JOin ElectronicInvoiceConfig EIC on SS.ElectronicInvoiceConfigId = EIC.ID
				WHERE so.PlatformStatus = 2 -- 全部发货 
				AND so.TransType = 0 
				And SS.AutoInvoice = 1
				And EIC.IsDisabled = 0
				and so.IsObsolete = 0
				AND NewAmt.NewInvAmt > 0
				AND NOT EXISTS (SELECT 1 FROM dbo.ElectronicInvoice EI WHERE so.StoreId = ei.StoreId AND so.TradeId = ei.TradeId AND ei.InvoiceType = 0)
			) SOI;

		-- Detail
		Insert Into ElectronicInvoiceDetail(
				Id,ProductCode,ProductId,ProductName,SkuCode,SkuName,SkuId,Quantity,UnitPrice,Amount,TaxAmount,
				Rate,ElectronicInvoiceId,CreateDate)
		Select	newid() as DetailId, sod.ProductCode, sod.ProductId, 
				sod.ProductName, sod.SkuCode, sod.SkuName, sod.ProductSkuId, 
				sod.Quantity, sod.AmountActual / sod.Quantity as UnitPrice, sod.AmountActual,
				Round(sod.AmountActual / (1 + eh.TaxRate /100), 2) as TaxAmount, 
				eh.TaxRate, eh.ElectronicInvoiceId, GetDate() as CreateDate 
		From #TMPInvoiceHdr eh(nolock), SalesOrderDetail sod(nolock)
		where eh.OrderId = sod.SalesOrderId
		and IsDeleted = 0
		and DetailType = 0
		and not exists (Select 1 From ReturnOrderDetail rod(nolock) where sod.DetailId = rod.SalesOrderDetailId); 

		-- Update Invoice Amt
		Update #TMPInvoiceHdr Set InvoiceAmount = A.TotalAmount,
			   InvoiceAmountWithOutTax = A.TaxAmount,  InvoiceTax = A.Tax, GoodsUnitPrice = TaxAmount 
		From (
				Select ElectronicInvoiceId, Sum(Amount) as TotalAmount, Sum(TaxAmount) as TaxAmount, Sum(Amount) - Sum(TaxAmount) as Tax
				From ElectronicInvoiceDetail
				Group by ElectronicInvoiceId
				) A
		Where #TMPInvoiceHdr.ElectronicInvoiceId = A.ElectronicInvoiceId;

		-- Create Return Invoice
		INSERT INTO ElectronicInvoice(ElectronicInvoiceId,Code,StoreId,StoreName,TradeId,Status,AuditUser,AuditDate,InvoiceType,
										BuyerName,BuyerMobile,InvoiceCreateUser,InvoiceAmount,InvoiceAmountWithOutTax,InvoiceTax,
										Remark,IndustryClassificationCode,IndustryClassificationCodeName,InvoiceLineNature,GoodsName,
										Unit,GoodsUnitPrice,GoodsQty,
										TaxRate,CreateDate,CreateUser, EmailAddress, IsReded, SalesOrderId,
										IdentificationNoPaxpayer,GmfAddress,GmfBankName,GmfBankNo)
		Select *
		From #TMPInvoiceHdr; 

		UPDATE dbo.ReturnOrder SET IsElectronicInvoiceCreated = 1 WHERE ID IN (SELECT ID FROM #TMPRtn); 
	END

	/*
	-- 换货订单开不票 ??
	BEGIN	
		-- 换货单已发货未开票的订单信息
		SELECT So.Code, So.StoreId, So.StoreName, so.TradeId 
		INTO #TMPChangeOrder
		FROM dbo.SalesOrder so  
		WHERE so.PlatformStatus = 2 -- 全部发货
		AND so.DeliveryDate >= @V_BeginDate
		AND so.TransType = 4 
		and StoreId in (Select StoreId From StoreSetting Where AutoInvoice = 1)
		AND NOT EXISTS (SELECT 1 FROM dbo.ElectronicInvoice EI WHERE so.StoreId = ei.StoreId AND so.Code = ei.Code AND ei.InvoiceType = 0);
		 
		SELECT Sale.TradeId, (Sale.SaleAmt - Rtn.RtnAmt) AS NewInvAmt
		INTO #TmpChangeAmt
		FROM (
				SELECT so.TradeId, SUM(sod.AmountActual) AS SaleAmt
				FROM dbo.SalesOrder so(NOLOCK), dbo.SalesOrderDetail sod(NOLOCK)
				WHERE so.OrderId = sod.SalesOrderId 
				AND so.TradeId IN (SELECT TradeId FROM #TMPChangeOrder)
				AND so.TransType IN (0, 4)
				AND so.IsObsolete = 0
				and StoreId in (Select StoreId From StoreSetting Where AutoInvoice = 1)
				GROUP BY so.TradeId
			) Sale
			LEFT JOIN ( 
				SELECT ro.TradeId, SUM(Sod.AmountActual) AS RtnAmt
				FROM dbo.ReturnOrder ro(NOLOCK), dbo.ReturnOrderDetail rod(NOLOCK), dbo.SalesOrderDetail sod(NOLOCK)
				WHERE ro.Id = rod.ReturnOrderId
				AND rod.SalesOrderDetailId = sod.DetailId
				AND ro.TradeId IN (SELECT ro.TradeId FROM #TMPChangeOrder)
				AND ro.Status = 2
				and StoreId in (Select StoreId From StoreSetting Where AutoInvoice = 1)
				GROUP BY ro.TradeId
			) Rtn ON Rtn.TradeId = Sale.TradeId;


		-- 订单金额（销售，换货)　－　退货商品金额，　如果金额　> 0 则开票，　否则不开票
		INSERT INTO ElectronicInvoice(ElectronicInvoiceId,Code,StoreId,StoreName,TradeId,Status,AuditUser,AuditDate,InvoiceType,
										BuyerName,BuyerMobile,InvoiceCreateUser,InvoiceAmount,InvoiceAmountWithOutTax,InvoiceTax,
										Remark,IndustryClassificationCode,IndustryClassificationCodeName,InvoiceLineNature,GoodsName,
										Unit,GoodsUnitPrice,GoodsQty,
										TaxRate,CreateDate,CreateUser, EmailAddress, IsReded, SalesOrderId,
										IdentificationNoPaxpayer,GmfAddress,GmfBankName,GmfBankNo ) 
		SELECT NEWID(), SOI.Code, SOI.StoreId, SOI.StoreName, SOI.TradeId, 2 AS Status, CrateUser AS AuditUser, GETDATE() AS AuditDate,
			@V_InvoiceType, soi.Title AS buyerName, SOI.Telephone as Telephone, CrateUser, soi.Amount AS InvocieAmount, 
			ROUND(soi.Amount / (1 + TaxRate), 2) AS InvocieAmountWithOutTax, (soi.Amount - ROUND(soi.Amount / (1 + TaxRate), 2)) AS InvoiceTax, 
			NULL AS Remark, IndustryClassificationCode, 
			IndustryClassificationName, InvoiceLineNature, GoodsName, NULL AS Unit, 
			ROUND(soi.Amount / (1 + TaxRate), 2) AS GoodsUnitPrice, 1 as GoodsQty,
			TaxRate * 100, GETDATE(), CrateUser, @V_EmailAddr, 0, SOI.OrderId,
			SOI.IdentificationNoPaxpayer,SOI.GmfAddress,SOI.GmfBankName,SOI.GmfBankNo 
		FROM (
				SELECT Distinct So.Code, So.StoreId, So.StoreName, so.TradeId, 
					changeAmt.NewInvAmt as Amount,
					case when so.HasInvoice = 1 then soi.Title else '个人' End as Title,
					isnull(soi.GmfMobile, sos.Mobile) as Telephone, so.OrderId,
					SOI.IdentificationNoPaxpayer,SOI.GmfAddress,SOI.GmfBankName,SOI.GmfBankNo,
					EIC.Kpr as CrateUser, EIC.SL * 1.0 / 100 TaxRate, 
					EIC.Hylx as IndustryClassificationCode, EIC.HylxName as IndustryClassificationName,
					EIC.FphXz as InvoiceLineNature, 
					EIC.XmMc as GoodsName
				FROM #TMPChangeOrder changeOrder
				LEFT JOIN #TmpChangeAmt changeAmt ON changeAmt.TradeId = changeOrder.TradeId
				LEFT JOIN dbo.SalesOrder so ON so.Code = changeOrder.Code
				LEFT JOIN dbo.SalesOrderInvoice soi ON so.OrderId = soi.SalesOrderId
				LEFT JOIN dbo.SalesOrderSub sos ON so.OrderId = sos.SubId
				Left Join StoreSetting SS on SO.StoreId = SS.StoreId
				Left JOin ElectronicInvoiceConfig EIC on SS.ElectronicInvoiceConfigId = EIC.ID
				WHERE so.PlatformStatus = 2 -- 全部发货 
				AND so.TransType = 4 
				AND so.DeliveryDate >= @V_BeginDate
				and changeAmt.NewInvAmt > 0
				And SS.AutoInvoice = 1
				And EIC.IsDisabled = 0
			) SOI

	END;
	*/
	  

END;
select * from LogisticsInterface


go

