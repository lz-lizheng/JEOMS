create procedure [dbo].[CompanyIn]
@data  nvarchar(64)='2019-06-05 14:20:20' 
as
 begin
     update Company set CreateDate = @data
	 
 end


go

