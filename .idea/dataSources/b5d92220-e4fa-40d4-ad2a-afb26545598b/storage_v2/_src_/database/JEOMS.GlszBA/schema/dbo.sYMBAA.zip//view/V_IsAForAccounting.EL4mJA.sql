CREATE VIEW [dbo].[V_IsAForAccounting]
AS
SELECT sod.DetailId,
(CASE WHEN EXISTS (SELECT 1 
FROM dbo.SalesOrderDetail a WHERE ISNULL(PlatformStatus,0) NOT IN (5,6)
AND a.DetailId IN (SELECT DetailId FROM dbo.SalesOrderDetail WHERE SalesOrderId=OrderId))
THEN 'F' ELSE 'T' END) AS isa
FROM dbo.SalesOrder so
LEFT JOIN dbo.SalesOrderDetail sod ON so.OrderId=sod.SalesOrderId


go

