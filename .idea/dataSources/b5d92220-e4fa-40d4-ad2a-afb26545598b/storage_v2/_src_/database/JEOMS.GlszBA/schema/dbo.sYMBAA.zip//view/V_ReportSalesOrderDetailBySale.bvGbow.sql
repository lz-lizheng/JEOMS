
/**    
*create date : 2021-4-15
*create modify：天空    
*remark ：添加村淘
*/  
CREATE VIEW [dbo].[V_ReportSalesOrderDetailBySale]  
AS  
SELECT SOD.DetailId AS DetailId,                   --订单明细ID  
       SO.CreateDate AS RecordDate,                -- 制单时间  
       SO.PayDate AS SalesOrderPayDate,            --付款时间  
       SO.CustomerNameKey,  
       SO.TradeId AS SalesOrderTradeId,            --交易号  
       SOD.ShippingDateClerk,                      -- 预计发货日期  
       SO.TradeFinishDate AS TradeFinishDate,  
       SO.StoreId AS OStoreId,  
       SO.StoreId AS StoreId,  
       SOD.ProductCode AS ProductCode,             --商品代码  
       SO.TransType AS SalesOrderTransType,        --订单类型  
       SO.TagName AS TagName,                      -- 标记名称   
       ISNULL(SOD.Status, 0) AS DetailStatus,      --明细状态  
       SOD.SkuCode AS SkuCode,                     --规格代码  
       SO.Code AS SalesOrderCode,                  --订单号   
       SO.IsPrepay,                                -- 预付款  
       SOD.IsOutOfStock AS SalesOrderIsOutOfStock, --明细是否缺货  
       SOD.IsDeleted AS IsDeleted,                 --行销  
       SOD.DetailType AS DetailType,               --明细类型 : 赠品，正常商品，虚拟商品  
       ChannelTypeName,                            --来源渠道  
       SO.RefundStatus AS SalesOrderRefundStatus,  --退款状态  
       SODP.oid LinePlatformOid                    --平台子订单号  
       , SO.IsCunTao															 --村淘
FROM dbo.SalesOrder (NOLOCK) SO  
    JOIN dbo.SalesOrderDetail (NOLOCK) SOD  
        ON SO.OrderId = SOD.SalesOrderId  
    left JOIN dbo.SalesOrderDetailPlatformProduct SODP  
        ON SODP.Id = SOD.DetailId  
    JOIN dbo.SalesOrderSub sub  
        ON sub.SubId = SO.OrderId  
WHERE SOD.IsAbnormal = 0  
      AND SO.TransType <> 1;

go

