

/**********************
*create date : 2017-06-13
*create by：qiaoni 
*remark ：商品销售统计去掉作废明细
*Remark : ModifyDate 2018-05-08 增加商品分类
***********************/  
Create VIEW [dbo].[V_ReportProductSaleNew] AS 
SELECT 
		so.CreateDate,
		so.PayDate,
		so.DeliveryDate,
	   CAST(so.CreateDate AS DATE) AS TruncCreateDate,
	   CAST(so.PayDate AS DATE) AS TruncPayDate, 
	   CAST(so.DeliveryDate AS DATE) AS TruncDeliveryDate, 
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.SkuCode,
	   sod.SkuName,
	   sod.IsDeleted,
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color, 
	   pd.FirstLevelCategoryId OneCatId, 
	   pd.FirstLevelCategoryName  OneCatName,
	   pd.TwoLevelCategoryId TwoCatId, 
	   pd.TwoLevelCategoryName TwoCatName, 
	   pd.CategoryId ThreeCatId,
	   pd.CategoryName ThreeCatName,
	   sod.Quantity AS Quantity,
	   sod.AmountActual AS AmountActual,
	   (sod.Quantity * sod.FirstCost) AS FirstCost  
FROM dbo.SalesOrder(NOLOCK) so
LEFT JOIN dbo.SalesOrderDetail(NOLOCK) sod ON so.OrderId = sod.SalesOrderId
LEFT JOIN Product(NOLOCK) pd ON sod.ProductId = pd.ProductId
LEFT JOIN dbo.ProductSku(NOLOCK) ps ON sod.ProductSkuId = ps.SkuId
WHERE sod.IsDeleted = 0
and ps.SkuId is not null



go

