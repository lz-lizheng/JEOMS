
/**        
 Create By : QiaoNi  20180905        
 Remark  : 唯品退货统计视图        
 Modify  :  QiaoNi 20181124 唯品退货不统计入库数量        
*/        
CREATE VIEW [dbo].[V_VipReturnOrder] AS        
SELECT VRO.CreateDate,        
 Status,vro.ReturnOrderCode,vro.VipReturnOrderCode,        
 ReturnType,ReturnSignType,        
 WarehouseId, WarehouseName,        
 InWarehouseId,InWarehouseName,        
 OutDate, TotalCases,        
 TotalSkus,TotalQtys,        
 SignDate,SignUserName,        
 Note,        
 PoCode,BoxNo,        
 ReturnOrderId,ProductId,        
 ProductCode,ProductName,        
 vrod.SkuId,        
 vrod.SkuCode,        
 SkuName,VipSkuCode,        
 ReturnQty,VROD.InQty SignQty,         
 ScanUser,        
 ScanDate,        
 VROD.SupplyPrice,      
 StoreName,StoreId,    
 (SELECT Brand FROM dbo.Product WHERE ProductId=vrod.ProductId) AS Brand,    
 (SELECT Id FROM dbo.GeneralClassiFication     
 WHERE Code=(SELECT BrandCode FROM dbo.Product WHERE ProductId=VROD.ProductId)    
 AND Name=(SELECT Brand FROM dbo.Product WHERE ProductId=VROD.ProductId)) AS BrandId    
FROM dbo.VipReturnOrder(NOLOCK) VRO        
LEFT JOIN dbo.VipReturnOrderDetail(NOLOCK) VROD ON VROD.ReturnOrderId = VRO.Id



go

