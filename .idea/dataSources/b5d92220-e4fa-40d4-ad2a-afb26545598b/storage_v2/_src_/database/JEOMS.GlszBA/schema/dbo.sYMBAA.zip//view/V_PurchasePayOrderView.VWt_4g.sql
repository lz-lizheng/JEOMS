

/**********************
*create date : 2018-04-14
*create by：qiaoni 
*remark ：  采购付款单报表视图
***********************/ 
Create View [dbo].[V_PurchasePayOrderView] as 
Select	
		ppod.Id,
		ppod.PurchaseOrderCode,
		po.Status as PurchaseOrderStatus,
		ppod.ContractNo, 
		ppo.SupplierCode,
		ppo.SupplierName,
		ppod.IsPayEnd,
		ppod.PurchaseAmount,
		ppod.PurchaseInAmount,
		pro.ReturnAmount as ReturnAmount,
		ppo.Code,
		ppod.PayType,
		ppo.Status PurchasePayOrderStatus,
		ppo.CreateDate,
		ppo.AuditTime,
		ppo.ReviewTime, 
		ppod.PurchasePayedAmount, 
		ppod.PurchasePayAmount,
		ppo.Remark 
From PurchasePayOrder ppo(nolock)
join PurchasePayOrderDetail ppod(nolock) on ppo.id = ppod.PurchasePayOrderId
join PurchaseOrder po(nolock) on ppod.PurchaseOrderCode = po.Code
Left Join (		Select  pro.PurchaseOrderCode, Sum(prod.OutStockQty * prod.OriginalPrice) as ReturnAmount
			 From PurchaseReturnOrder PRO(nolock)
			 Join PurchaseReturnOrderDetail PROD(nolock) on pro.Id = prod.PurchaseReturnOrderId
			 Group by pro.PurchaseOrderCode) pro on ppod.PurchaseOrderCode = pro.PurchaseOrderCode



go

