
CREATE VIEW [dbo].[V_ProductSku]
AS
      SELECT    product.BrandCode ProductBrandCode, product.Brand ProductBrand, product.ProductId, product.Code ProductCode, product.Description ProductName, sku.SkuId, sku.Code SkuCode, sku.Description SkuName, sku.SkuId CountSkuId, 1 CountPer, sku.CreateDate
      FROM      ProductSku sku
      JOIN      Product product ON sku.ProductId=product.ProductId
      WHERE     sku.Status=1 AND product.Status=1
      UNION ALL
      SELECT    product.BrandCode ProductBrandCode, product.Brand ProductBrand, product.ProductId, product.Code ProductCode, product.Description ProductName, sku.SkuId, sku.Code SkuCode, sku.Description SkuName, cpd.SkuId CountSkuId, cpd.Quantity CountPer, sku.CreateDate
      FROM      ProductSku sku
      JOIN      Product product ON sku.ProductId=product.ProductId
      JOIN      CombinedProductDetail cpd ON sku.SkuId=cpd.CombinedProductId AND cpd.IsMainSku=1
      WHERE     sku.Status=1 AND product.Status=1;



go

