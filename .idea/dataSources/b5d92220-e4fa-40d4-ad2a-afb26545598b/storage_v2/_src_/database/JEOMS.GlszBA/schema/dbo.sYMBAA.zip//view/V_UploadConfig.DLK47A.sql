
/**
*create date: 2020-11-28
*create by：阿紫
*remark ：增加 IsEntityWarehouse 和 PlatformWarehouseCode 字段
**/
CREATE VIEW [dbo].[V_UploadConfig] AS SELECT
iuc.Id,
iuc.Name,
iuc.Flag,
iuc.StoreId,
iuc.BrandId,
iuc.BrandName,
iuc.IsUpload,
iuc.IsManualUpload,
iuc.IsNotUseValue,
iuc.IsEntityWarehouse,
iuc.PlatformWarehouseCode,
iuw.WarehouseId,
iuw.WarehouseType,
iuw.Scale,
iuc.IsNotUseAllCanSale,
iuc.UploadLessQuantity,
Isnull( w.isOc, 0 ) isOc,
ISNUll( UploadValve, 20 ) UploadValve,
ISNULL( UploadTigger, 5 ) UploadTigger 
FROM
  InventoryUploadConfig iuc
  JOIN InventoryUploadWarehouse iuw ON iuc.Id = iuw.ConfigId
  JOIN Warehouse w ON iuw.WarehouseId = w.Id 
  AND w.IsDisabled = 0 
  AND ( iuw.WarehouseType IN ( 2, 3 ) OR ( w.WarehouseType = 5 AND w.IsOC = 1 ) ) UNION
SELECT
  iuc.Id,
  iuc.Name,
  iuc.Flag,
  iuc.StoreId,
  iuc.BrandId,
  iuc.BrandName,
  iuc.IsUpload,
  iuc.IsManualUpload,
  iuc.IsNotUseValue,
  iuc.IsEntityWarehouse,
  iuc.PlatformWarehouseCode,
  w.Id,
  w.WarehouseType,
  iuw.Scale,
  iuc.IsNotUseAllCanSale,
  iuc.UploadLessQuantity,
  Isnull( w.isOc, 0 ) isOc,
  ISNUll( UploadValve, 20 ) UploadValve,
  ISNULL( UploadTigger, 5 ) UploadTigger 
FROM
  InventoryUploadConfig iuc
  JOIN InventoryUploadWarehouse iuw ON iuc.Id = iuw.ConfigId 
  AND iuw.WarehouseType = 4
  JOIN Warehouse w ON iuw.WarehouseId = w.ParentId 
  AND w.IsDisabled = 0 
  AND w.IsOC = 1

go

