


 /**
  获取位置坐标
 */
Create FUNCTION [dbo].[F_Get_AddressLatLng]
( 
	@P_ProvinceName				NVARCHAR(50),
	@P_CityName					NVARCHAR(50),
	@P_CountyName				NVARCHAR(50)
)
RETURNS @V_AddressLatLng TABLE(Lat decimal(12, 4), Lng Decimal(12, 4))
AS
BEGIN 
	Declare @V_Lat decimal(12, 4), @V_Lng decimal(12, 4)
	 
	If @P_CountyName is not null
		Begin
			Select Top 1 @V_Lat = Reg.DistrictLat, @V_Lng = Reg.DistrictLng
			From V_Region Reg
			Where ProvinceName = @P_ProvinceName
			And CityName = @P_CityName
			And DistrictName = @P_CountyName
		End

	If @V_lat Is null And @P_CityName is not null
		Begin
			Select Top 1 @V_Lat = Reg.DistrictLat, @V_Lng = Reg.DistrictLng
			From V_Region Reg
			Where ProvinceName = @P_ProvinceName
			And CityName = @P_CityName
		End

	If @V_Lat Is null And @P_ProvinceName is not null
		Begin
			Select Top 1 @V_Lat = Reg.DistrictLat, @V_Lng = Reg.DistrictLng
			From V_Region Reg
			Where ProvinceName = @P_ProvinceName
		End
	
	Insert Into @V_AddressLatLng(Lat, Lng) values(@V_lat, @V_lng) 
	RETURN;
END;



 go

