

/**********************
*create date : 2018-07-05
*create by：qiaoni 
*remark　配货单时效

--0 　接单
--4　 捡货
--5　 出货
--9　 出库
***********************/ 
Create View [dbo].[V_DispatchOrderProcessReport] as
Select do.Id, do.Code, do.CreateDate, do.DeliveryDate, do.Status, 
		   dopr0.OperateTime as OperateTime0,
			 dopr4.OperateTime as OperateTime4,
			 dopr5.OperateTime as OperateTime5,
			 dopr9.OperateTime as OperateTime9,
			 do.ActualExpressNo
From DispatchOrder do
left Join (Select * From DispatchOrderProcessReport dopr where Status = 0) dopr0 on do.id = dopr0.dispatchorderId
left Join (Select * From DispatchOrderProcessReport dopr where Status = 4) dopr4 on do.id = dopr4.dispatchorderId
left Join (Select * From DispatchOrderProcessReport dopr where Status = 5) dopr5 on do.id = dopr5.dispatchorderId
left Join (Select * From DispatchOrderProcessReport dopr where Status = 9) dopr9 on do.id = dopr9.dispatchorderId



go

