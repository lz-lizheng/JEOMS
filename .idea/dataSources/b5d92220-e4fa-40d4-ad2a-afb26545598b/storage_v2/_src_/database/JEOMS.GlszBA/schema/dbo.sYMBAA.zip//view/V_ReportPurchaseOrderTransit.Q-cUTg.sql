


 /**********************
*create date : 2017-12-30
*create by：qiaoni 
*remark ： 增加入库金额
 Modify : 20181016 QiaoNi 采购订单关联通知单增加SKUID.
***********************/
CREATE VIEW [dbo].[V_ReportPurchaseOrderTransit] AS 
SELECT Distinct PO.Code,
		PO.WarehouseId,
		PO.WarehouseName,
	   PO.PurchaseDate,
	   PO.CreateDate,
	   PO.RequestDeliveryDate,
	   PO.SupplierCode,
	   po.SupplierName, 
	   PO.Status,
	   POD.ProductCode,
	   POD.ProductName,
	   POD.SkuCode, 
	   POD.SkuName,
	   POD.Color, 
	   POD.Size,
	   POD.PurchaseQty, 
	   POD.CurrentPrice AS OriginalPrice,
	   POD.NoticeQty, 
	   P.StockInQty,
	   P.DefectiveQuantity,
	   P.WarehouseStorageTime AS WarehousingTime,
	   pd.Year,
	   pd.Season,
	   pd.Brand,
	   PO.Remark,
	   pd.CategoryName,
	   PO.ContractNo,
	   SSP.SupplierSettlementType,
	   PO.PurchasePersonName,
	   PO.SupplierComanyName,
	   (CASE WHEN POD.PurchaseQty-isnull(P.StockInQty, 0)-isnull(P.DefectiveQuantity, 0)<0 THEN 0 ELSE POD.PurchaseQty-isnull(P.StockInQty, 0)-isnull(P.DefectiveQuantity, 0) END) AS TransitQty
FROM PurchaseOrder PO(NOLOCK)
LEFT JOIN PurchaseOrderDetail POD(NOLOCK) ON PO.Id = pod.PurchaseOrderId
LEFT JOIN (
	SELECT SUM(PNOID.StockInQty) StockInQty,SUM(PNOID.DefectiveQuantity) DefectiveQuantity,PNOD.SkuId,PNO.PurchaseOrderId,MAX(PNOID.WarehouseStorageTime) WarehouseStorageTime FROM PurchaseNoticeOrder PNO(NOLOCK)
	LEFT JOIN PurchaseNoticeOrderdetail PNOD(NOLOCK) ON PNO.Id = PNOD.PurchaseNoticeOrderId
	LEFT JOIN PurchaseNoticeOrderIndetail PNOID(NOLOCK) ON PNOD.DetailId = PNOID.DetailId
	where PNO.Status!=4
	GROUP BY PNOD.SkuId,PNO.PurchaseOrderId
	) P  ON po.Id = P.PurchaseOrderId And pod.Skuid = p.SkuId
LEFT JOIN dbo.Product PD(NOLOCK) ON POD.ProductId = pd.ProductId
LEFT JOIN dbo.Supplier SSP(NOLOCK) ON po.SupplierCode = ssp.Code 
WHERE P.PurchaseOrderId IS NOT NULL



 go

