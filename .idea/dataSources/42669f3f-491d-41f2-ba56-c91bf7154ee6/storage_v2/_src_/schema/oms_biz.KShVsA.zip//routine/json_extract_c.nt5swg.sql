create
    definer = jusr6xf464v4@`%` function json_extract_c(details text, required_field varchar(255)) returns text
BEGIN
SET details = SUBSTRING_INDEX(details, "{", -1);
SET details = SUBSTRING_INDEX(details, "}", 1);
RETURN TRIM(
    BOTH '"' FROM SUBSTRING_INDEX(
        SUBSTRING_INDEX(
            SUBSTRING_INDEX(
                details,
                CONCAT(
                    '"',
                    SUBSTRING_INDEX(required_field,'$.', -1),
                    '":'
                ),
                -1
            ),
            ',"',
            1
        ),
        ':',
        -1
    )
) ;
END;

