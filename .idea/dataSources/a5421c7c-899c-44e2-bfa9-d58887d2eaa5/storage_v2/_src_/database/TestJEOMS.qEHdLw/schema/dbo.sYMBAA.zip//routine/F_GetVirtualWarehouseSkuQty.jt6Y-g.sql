
 /**********************
*create date : 2018-11-26
*create by：creoa
*remark ：获取虚拟仓库数
***********************/  
Create FUNCTION [dbo].[F_GetVirtualWarehouseSkuQty]
(
	@P_WarehouseID	UNIQUEIDENTIFIER,	--共享/独立仓库
	@P_SkuId		UNIQUEIDENTIFIER	--SKU ID 
)
RETURNS INT
AS
BEGIN
	DECLARE @V_Rlt INT
	  
    SELECT TOP 1  @V_Rlt = Quantity FROM V_InventoryVirtual WHERE WarehouseId = @P_WarehouseID AND SkuId = @P_SkuId AND IsLockStock = 0;

	-- 返回可销
	RETURN ISNULL(@V_Rlt, 0);
END
 go

