


/**********************
*create date :	2018-06-06
*create by：	qiaoni 
*remark ：	--库存查询增加锁标记
***********************/  
CREATE View V_InventoryVirtualStock As
SELECT		iv.WarehouseId, iv.SkuId, iv.Quantity, ios.LockedQuantity, ios.DispatchedQuantity, ios.UnDispatchedQuantity, ios.AllotQuantity, 
			ios.VipQuantity, 
			(ISNULL(iv.Quantity, 0)-ISNULL(ios.LockedQuantity, 0)) AS CanSaleQuantity, 
			(ISNULL(iv.Quantity, 0)-ISNULL(ios.DispatchedQuantity, 0)-ISNULL(ios.AllotQuantity, 0)-ISNULL(ios.VipQuantity, 0)) AS CanUseQuantity,
			isnull(iv.IsLockStock, 0) as IsLockStock
From InventoryVirtual iv(NOLOCK)
LEFT JOIN V_InventoryOccupationSum ios(NOLOCK) ON ios.SkuId=iv.SkuId AND ios.WarehouseId=iv.WarehouseId;
go

