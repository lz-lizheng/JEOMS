CREATE VIEW V_SkuBatchOcc
AS 
SELECT a.SkuId,w.Id WarehouseId,SUM(occ.Quantity) Quantity FROM (SELECT SkuId,WarehouseId,SUM(Quantity) Quantity 
FROM dbo.ApiOrderBatchRecord GROUP BY SkuId,WarehouseId) a JOIN dbo.Warehouse w ON w.ParentId=a.WarehouseId JOIN dbo.InventoryOccupation occ ON occ.WarehouseId=w.Id
GROUP BY a.SkuId,w.Id
go

