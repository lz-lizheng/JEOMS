
/********

*create date : 2019-06-17

*create modify：拓斗

*remark ：未发货套餐明细统计表视图修改

*******/
CREATE VIEW [dbo].[V_ReportCombProduct] AS     
SELECT sod.Detailid, so.PayDate, so.Code, sod.CombProductCode, sod.CombProductName,  
 sod.CombProductQuantity, sod.CombAmount, sod.CombAmount / sod.CombProductQuantity AS UnitPrice,     
 sod.ProductCode, sod.ProductName, sod.SkuCode, sod.SkuName, sod.Quantity,     
 sod.Status,     
 CASE WHEN sod.Status = 2 THEN sod.Quantity ELSE 0 END AS DeliveryQty,    
 pc.OneCatId, pc.TwoCatId, pc.ThreeCatId,    
 pc.OneCatName, pc.TwoCatName, pc.ThreeCatName,Pd.Attribute4,    
 do.DeliveryDate, sos.CustomerShipDate, sos.ProvinceName, sos.CityName,     
 sod.IsStandard,    
 ps.IsProduct,     
 SOD.CombProductId,    
 pd.Attribute3,    
 so.TradeId,    
 so.Status AS SoStatus,    
 ps.ProductionCategory,  
 So.StoreName,  
 So.StoreId,  
 sos.SellerMemo  
FROM SalesOrder So(NOLOCK)    
JOIN SalesOrderSub sos(NOLOCK) ON so.OrderId = sos.SubId    
JOIN SalesOrderDetail sod(NOLOCK) ON so.OrderId = sod.SalesOrderId    
LEFT JOIN (    
   SELECT do.DeliveryDate, dod.SalesOrderDetailId    
   FROM DispatchOrder do(NOLOCK)    
   JOIN  DispatchOrderDetail dod(NOLOCK) ON do.id = dod.DispatchOrderId     
   WHERE do.Status <> 3    
    ) do ON do.SalesOrderDetailId = sod.DetailId    
LEFT JOIN Product pd(NOLOCK) ON sod.ProductId = pd.ProductId    
LEFT JOIN productsku ps(NOLOCK) ON sod.CombProductId = ps.SkuId    
LEFT JOIN V_ProductCategory pc(NOLOCK) ON pd.CategoryId = pc.ThreeCatId    
WHERE sod.IsCombproduct = 1      
AND sod.IsDeleted = 0

go

