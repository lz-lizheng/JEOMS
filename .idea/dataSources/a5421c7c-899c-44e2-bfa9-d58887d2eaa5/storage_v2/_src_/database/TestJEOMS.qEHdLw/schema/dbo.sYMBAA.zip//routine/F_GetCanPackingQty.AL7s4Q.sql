
/**********************
*create date :	2018-07-27
*create by：	qiaoni 
*remark ：	订单明细可配货量查询
***********************/  
CREATE  Function [dbo].[F_GetCanPackingQty](
	@StoreId nvarchar(100),
	@Skuid nvarchar(100),
	@Paydate DateTime
)
Returns int
As 
Begin 
	declare @V_Result int
	Select @V_Result = Sum(Qty)
	From (
		Select Isnull(Sum(VVS.CanUseQuantity), 0) as Qty
		From V_StoreDispatchWarehouse  SDW(nolock), V_InventoryVirtualStock VVS(nolock) 
		Where SDW.WarehouseId = VVS.WarehouseId And SDW.StoreId = @StoreId And VVS.SkuId = @Skuid 
		And VVS.IsLockStock = 0
		Union ALL
		Select isnull(Sum(IOC.Quantity), 0) * -1
		From V_StoreDispatchWarehouse SDW(nolock), InventoryOccupation IOC(nolock) 
		Where SDW.WarehouseId = IOC.WarehouseId And IOC.Type = 2 And SDW.StoreId = @StoreId And IOC.SkuId = @Skuid
		Union ALL
		Select isnull(Sum(IOC.Quantity), 0) * -1
		From InventoryOccupation IOC(nolock) 
		Where IOC.Type = 1 And IsDispatched = 0 And IOC.SkuId =@Skuid  And IOC.PayDate < @Paydate
		And (isnull(IOC.IsAppointDateDelivery, 0) = 0 or (isnull(IOC.IsAppointDateDelivery, 0) = 1 and PreDeliveryDate < getdate())) 
		And (IOC.WarehouseId in (Select WarehouseID From V_StoreDispatchWarehouse SDW(nolock) 
		Where SDW.StoreId = @StoreId) Or IOC.StoreId = @StoreId)
	) A

	Return @V_Result;

End;
go

