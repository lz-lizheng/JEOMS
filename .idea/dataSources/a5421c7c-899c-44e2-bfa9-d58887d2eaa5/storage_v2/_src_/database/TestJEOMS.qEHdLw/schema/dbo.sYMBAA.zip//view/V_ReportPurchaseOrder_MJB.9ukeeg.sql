
CREATE VIEW [dbo].[V_ReportPurchaseOrder_MJB] AS 
SELECT 
	Cast(PO.PurchaseDate as Date) as PurchaseDate,
	Cast(PNOID.WarehouseStorageTime as Date) as WarehousingTime,
	Cast(PO.RequestDeliveryDate as Date) as RequestDeliveryDate,
	PO.Code as PurchaseCode,
	PO.SupplierCode,
	PO.SupplierName, 
	PO.ContractNo,
	POD.ProductCode,
	POD.ProductName,
	POD.SkuCode, 
	POD.SkuName, 
	POD.PurchaseQty, 
	POD.CurrentPrice AS OriginalPrice, 
	POD.PurchaseQty * POD.CurrentPrice as PurchaseAmount,
	Round(POD.CurrentPrice / Case When isnull(SSP.BillingType, 0) = 0 Then 1 Else 1 + isnull(SSP.Rate, 0) / 100 End, 2) FinalCost,
	PNOID.StockInQty,
	PNOID.StockInQty * POD.CurrentPrice as StockAmount,
	PNOID.DefectiveQuantity, 
	PO.PurchasePersonName,
	PO.SupplierComanyName,
	Po.WarehouseID, 
	PO.WarehouseName 
FROM PurchaseOrder PO(NOLOCK)
LEFT JOIN PurchaseOrderDetail POD(NOLOCK) ON PO.Id = pod.PurchaseOrderId
Left Join (
			Select PNO.Id, Pno.PurchaseOrderCode, 
			Pno.PurchaseOrderId, PNOD.*
			From PurchaseNoticeOrder PNO(nolock) Join PurchaseNoticeOrderdetail PNOD(NOLOCK) ON PNO.Id = PNOD.PurchaseNoticeOrderId 
		) as PNO on po.Id = PNO.PurchaseOrderId And POD.SkuId = PNO.SkuId
Left Join PurchaseNoticeOrderIndetail PNOID(NOLOCK) ON PNO.DetailId = PNOID.DetailId
LEFT JOIN dbo.Supplier SSP(NOLOCK) ON po.SupplierCode = ssp.Code
go

