

/**

*create date : 2019-09-12

*create modify：拓斗

*remark ：发货和退货记账统计报表脚本修改

*/

CREATE VIEW V_AccountingForDeliveryAndReturn

as

SELECT dode.DeliveryDate,dccr.FirstTime,dccr.DataCode,dod.SalesOrderCode AS Code,dod.TradeId,dod.ProductSkuCode,

sod.TradeFinishDate,(case sod.PlatformStatus when 5 then '交易关闭' when 6 then '交易完成' else '' end) as PlatformStatus,

'DELIV_RESULT' as Result,ISNULL(isa.isa,'F') AS isa,

(case when isnull(dode.ActualExpressFee,0.00)>0 then 'T' else 'F' end) as isfee,

do.Code AS DispatchCode,do.StoreId

FROM DispatchOrder do

LEFT JOIN DispatchOrderDetail dod ON dod.DispatchOrderId=do.Id

LEFT JOIN dbo.DispatchOrderDetailExpress dode ON dode.SalesOrderDetailId=dod.SalesOrderDetailId

LEFT JOIN dbo.DataCallCustomRecord dccr ON dccr.DataCode=dod.OutOrderCode

left join SalesOrderDetail sod on sod.DetailId=dod.SalesOrderDetailId

left join (SELECT sod.DetailId,

(CASE WHEN EXISTS (SELECT 1

FROM dbo.SalesOrderDetail a WHERE ISNULL(PlatformStatus,0) NOT IN (5,6)

AND a.DetailId IN (SELECT DetailId FROM dbo.SalesOrderDetail WHERE SalesOrderId=OrderId))

THEN 'F' ELSE 'T' END) AS isa

FROM dbo.SalesOrder so

LEFT JOIN dbo.SalesOrderDetail sod ON so.OrderId=sod.SalesOrderId) as isa on isa.DetailId=dod.SalesOrderDetailId

where dod.Status=2

UNION ALL

SELECT dode.DeliveryDate,dccr.FirstTime,dccr.DataCode,ro.Code,rod.TradeId,rod.SkuCode AS ProductSkuCode,

sod.TradeFinishDate,(case sod.PlatformStatus when 5 then '交易关闭' when 6 then '交易完成' else '' end) as PlatformStatus,

'RCV_RESULT' AS Result,ISNULL(isa.isa,'F') AS isa,

(case when isnull(dode.ActualExpressFee,0.00)>0 then 'T' else 'F' end) as isfee,

(SELECT Code FROM dbo.DispatchOrder WHERE Id=dode.DispatchOrderId) AS DispatchCode,ro.StoreId

FROM dbo.ReturnOrder ro

LEFT JOIN dbo.ReturnOrderDetail rod ON rod.ReturnOrderId=ro.Id

LEFT JOIN dbo.DispatchOrderDetailExpress dode ON dode.SalesOrderDetailId=rod.SalesOrderDetailId

LEFT JOIN dbo.SalesOrderDetail sod ON sod.DetailId=rod.SalesOrderDetailId

LEFT JOIN dbo.DataCallCustomRecord dccr ON dccr.DataCode=ro.CaiNiaoOrderId

left join (SELECT sod.DetailId,

(CASE WHEN EXISTS (SELECT 1

FROM dbo.SalesOrderDetail a WHERE ISNULL(PlatformStatus,0) NOT IN (5,6)

AND a.DetailId IN (SELECT DetailId FROM dbo.SalesOrderDetail WHERE SalesOrderId=OrderId))

THEN 'F' ELSE 'T' END) AS isa

FROM dbo.SalesOrder so

LEFT JOIN dbo.SalesOrderDetail sod ON so.OrderId=sod.SalesOrderId) as isa on isa.DetailId=rod.SalesOrderDetailId

WHERE ro.Status IN (1,2) AND rod.SalesOrderCode IS NOT NULL
go

