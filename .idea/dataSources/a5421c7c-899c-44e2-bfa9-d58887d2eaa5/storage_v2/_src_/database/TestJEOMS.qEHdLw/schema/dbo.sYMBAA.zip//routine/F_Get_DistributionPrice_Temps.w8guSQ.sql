 
/*
通过指定时间点，查询某个（或多个）分销商，指定一个商品（或sku）的分销价（经销价）的报表
1.如果调价单被禁用了，禁用的的时候，如果未到失效时间，会把时效时间更新为禁用时间，
	取价的时候看调价单的有效时间和时效时间段，有重叠的取复核时间靠后的
*/


-- Select * from dbo.[F_Get_DistributionPrice_Temps]('20180627133', '2018-09-02', '12214157028', '', 1)
/*
Select * From DistributionPriceChangeDetail
 


*/

Create FUNCTION  [dbo].[F_Get_DistributionPrice_Temps] 
(
	@P_DistributorId nvarchar(100),
	@P_PayDate DateTime,
	@P_ProductCode nvarchar(100),
	@P_SkuCode nvarchar(100),
	@P_PriceType int
)
Returns @ReturnTable  TABLE
(	 price nvarchar(100),
	 ProductCode nvarchar(100),
	 SkuCode nvarchar(100),
	 OrderCode nvarchar(100)
)
AS
Begin

		Declare @V_Result Decimal(15, 2), @OrderCode nvarchar(100)
		
		if @P_ProductCode is null and @P_SkuCode is not null
			Begin
				Select Top 1 @P_ProductCode = ProductCode From ProductSku Where Code = @P_SkuCode;
			End
 
		If @P_SkuCode is not NULL
			Begin 
			
					Select Top 1 @V_Result = isnull(Price, 0), @OrderCode = dpc.Code
					From DistributionPriceChange dpc(nolock), DistributionPriceChangeDetail dpcd(nolock),ProductSku ps(nolock)
					where dpc.Id = dpcd.PriceChangeId
					and dpcd.SkuId = ps.SkuId
					And @P_PayDate >= dpc.BeginDate
					And @P_PayDate < dpc.EndDate
					And AuditDate <= @P_PayDate
					And dpcd.SkuCode = @P_SkuCode
					And DistributorId = @P_DistributorId
					and dpc.PriceType = @P_PriceType
					Order by dpc.AuditDate desc;
			End; 
			  
		If isnull(@V_Result, 0) = 0
				Begin 
						Select Top 1 @V_Result = isnull(Price, 0), @OrderCode = dpc.Code
						From DistributionPriceChange dpc(nolock), DistributionPriceChangeDetail dpcd(nolock), Product pd(nolock)
						where dpc.Id = dpcd.PriceChangeId
						and dpcd.ProductId = pd.ProductId
						And @P_PayDate >= dpc.BeginDate
						And @P_PayDate < dpc.EndDate
						And AuditDate <= @P_PayDate
						And dpcd.ProductCode = @P_ProductCode
						And DistributorId = @P_DistributorId
						and dpc.PriceType = @P_PriceType
						Order by dpc.AuditDate desc; 
				End;  

		if isnull(@V_Result, 0) = 0
			Begin
				-- 取分销价
				Declare @DistributorDiscountId uniqueidentifier, @Year nvarchar(100), @Season nvarchar(100), @Brand nvarchar(100), @ZK decimal(12, 2), @PlatformPrice decimal(12,2)
				Select Top 1 @Year = Year, @Season = Season, @Brand = Brand, @PlatformPrice =PlatformPrice
				From Product
				Where Code = @P_ProductCode; 

				-- Distributor --
				if exists(
						Select *
						From DistributorDiscount dd, DistributorDiscountDetail ddd
						Where ReviewDate < @P_PayDate
						and @P_PayDate < FailureTime 
						and @P_PayDate > EffecTime
						and dd.PriceType = @P_PriceType
						and ddd.BrandCode = @Brand
						and ddd.Season = @Season
						and ddd.Year = @Year
						) 
					Begin
						Select Top 1 @ZK = dd.Discount, @OrderCode = dd.Id
						From DistributorDiscount dd, DistributorDiscountDetail ddd
						Where ReviewDate < @P_PayDate
						and @P_PayDate < FailureTime 
						and @P_PayDate > EffecTime
						and dd.PriceType = @P_PriceType
						and ddd.BrandCode = @Brand
						and ddd.Season = @Season
						and ddd.Year = @Year
						order by FailureTime desc;
					End;
				Else
					Begin
						Select Top 1 @ZK = dd.Discount, @OrderCode = dd.Id  
						From DistributorDiscount dd 
						Where ReviewDate < @P_PayDate
						and @P_PayDate < FailureTime 
						and @P_PayDate > EffecTime
						and dd.PriceType = @P_PriceType
						Order by ReviewDate Desc;
					End; 
					 
				--return Round(isnull(@PlatformPrice, 0) *isnull(@ZK, 0) / 100, 2)
				    INSERT INTO @ReturnTable
						SELECT Round(isnull(@PlatformPrice, 0) *isnull(@ZK, 0) / 100, 2),@P_ProductCode, @P_SkuCode, @OrderCode 
						
RETURN
			End; 
	--	Return isnull(@V_Result, 0); 
	    INSERT INTO @ReturnTable
			SELECT isnull(@V_Result, 0),@P_ProductCode,	@P_SkuCode, @OrderCode
	RETURN
		
End;
go

