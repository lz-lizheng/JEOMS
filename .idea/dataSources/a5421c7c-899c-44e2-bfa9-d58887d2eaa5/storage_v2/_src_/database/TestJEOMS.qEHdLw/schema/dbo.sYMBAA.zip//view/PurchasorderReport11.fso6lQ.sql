




  CREATE View [dbo].[PurchasorderReport11] as
	  SELECT a.Code AS PurchaseCode, a.CreateDate, a.RequestDeliveryDate, a.PurchaseDate,a.SupplierCode, a.SupplierName,
	  a.Status,
	  b.ProductName, b.ProductCode, b.SkuName,b.SkuCode, b.PurchaseQty, b.NoticeQty, b.InStockQty - c.CiStockQty AS InStockQty, 
      ISNULL(a.ContractNo, '') AS contractno,(CASE WHEN a.Status = '0' THEN purchaseqty WHEN purchaseqty - isnull(InStockQty, 
      0) <= 0 THEN '0' WHEN a.Status = '1' THEN purchaseqty - isnull(InStockQty, 0) ELSE '0' END) AS ztsl,ISNULL(c.CiStockQty, 0) AS CiStockQty,
	  a.PurchasePersonName as PurchasePersonName
FROM dbo.PurchaseOrder AS a 
	  LEFT OUTER JOIN  dbo.PurchaseOrderDetail AS b ON a.Id = b.PurchaseOrderId
	  LEFT OUTER JOIN (  SELECT a.PurchaseOrderId, b.SkuCode, sum(b.DefectiveQuantity) AS CiStockQty
						 FROM dbo.PurchaseNoticeOrder AS a 
						 INNER JOIN  dbo.PurchaseNoticeOrderdetail AS b ON a.Id = b.PurchaseNoticeOrderId
						 WHERE (a.Status IN (3, 5))		 group by  a.PurchaseOrderId, b.SkuCode
					  ) AS c ON a.Id = c.PurchaseOrderId AND       b.SkuCode = c.SkuCode
	 where 1=1



  go

