

 
/**********************
*create by：QiaoNi
-remark   ：通过订单号获取可配货仓库列表
-Modify by Qiaoni 20180620
***********************/  
CREATE FUNCTION [dbo].[F_Get_RegionDispatchWarehouseByOrderCode]
(  
	@P_OrderCode				NVARCHAR(50)
)
RETURNS @V_Warehouse TABLE(WarehouseTemplateId UNIQUEIDENTIFIER, TemplateId UNIQUEIDENTIFIER, OrderId BigInt, WarehouseID VARCHAR(36), 
						   WarehouseCode NVARCHAR(20), WarehouseName NVARCHAR(50), ParentId UNIQUEIDENTIFIER, ParentCode NVARCHAR(50), ParentName NVARCHAR(50),
						   WarehouseDispatchType INT, DefalutCodExpressId UNIQUEIDENTIFIER, DefaultNoCodExpressId UNIQUEIDENTIFIER,IsOnlyPrePackage BIT,SplitFirst BIT
						   )
AS
BEGIN 
	
 
	Declare @V_Code Varchar(100), @TempId uniqueidentifier
	Declare @V_ProvName varchar(100), @V_City varchar(100), @V_County Varchar(100), @V_Skus nvarchar(4000)
	  
	Select @TempId = ss.DispatchTemplateId, @V_ProvName = sos.ProvinceName, @V_City = sos.CityName,@V_County = sos.CountyName
	From SalesOrder so left join SalesOrderSub sos on so.OrderId = sos.SubId left join  StoreSetting ss on so.StoreId = ss.StoreId
	where so.code = @P_OrderCode
	 
	select @V_Skus = stuff((
		Select ',' + Cast(sod.ProductSkuId as Varchar(100))
		From SalesOrder so(nolock), SalesOrderDetail sod(nolock)
		where so.OrderId = sod.SalesOrderId
		and so.code = @P_OrderCode
		and sod.IsDeleted = 0
		and so.IsObsolete = 0 FOR xml PATH('')), 1, 1, '')


	Insert into @V_Warehouse
	Select *
	From [dbo].[f_Get_RegionDispatchWarehouseWithSku](@TempId, @V_ProvName, @V_City, @V_County, @V_Skus)

	Return;

END;

go

