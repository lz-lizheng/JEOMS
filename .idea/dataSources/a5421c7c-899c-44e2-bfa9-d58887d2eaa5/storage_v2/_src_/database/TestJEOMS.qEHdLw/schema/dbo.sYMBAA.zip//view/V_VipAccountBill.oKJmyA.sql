    
CREATE VIEW [dbo].[V_VipAccountBill] AS 
SELECT Sale.StoreId ,
       Sale.StoreName ,
       Sale.PoCode , 
       Sale.ScheduleBeginDate ,   --档期时间
       Sale.ScheduleEndDate,	  --档期时间	
       Sale.DeliveryAmt,		  --发货金额
	   Rtn.ReturnAmt,			  --退货金额
	   AR.inAmt,				  --账单收入
	   AR.outAmt				  --账单支出
FROM (
		SELECT vs.StoreId, vs.StoreName, vs.PoCode, vs.ScheduleCode, vs.ScheduleBeginDate, vs.ScheduleEndDate,
			SUM(vsd.SupplyPrice * vsd.OutQty) AS DeliveryAmt
		FROM dbo.VipSchedule VS(NOLOCK) LEFT JOIN dbo.VipScheduleDetail vsd(NOLOCK) ON vs.Id = vsd.ScheduleId
		GROUP BY vs.StoreId, vs.StoreName, vs.PoCode, vs.ScheduleCode, vs.ScheduleBeginDate, vs.ScheduleEndDate
	) AS Sale
	LEFT JOIN ( 
		SELECT VRD.PoCode, SUM(vrd.InQty * vsd.SupplyPrice) AS ReturnAmt
		FROM dbo.VipReturnOrderDetail VRD(NOLOCK) 
		LEFT JOIN dbo.VipSchedule vs(NOLOCK) ON vrd.PoCode = vs.PoCode
		LEFT JOIN dbo.VipScheduleDetail vsd(NOLOCK) ON vs.Id = vsd.ScheduleId AND vrd.SkuId = vsd.SkuId
		GROUP BY vrd.PoCode
	) AS Rtn ON Sale.PoCode = rtn.PoCode 
	LEFT JOIN ( 
		SELECT StoreId, AlipayOrderNo, SUM(inamount) AS inAmt, SUM(OutAmount) AS outAmt
		FROM dbo.AlipayRecord 
		GROUP BY StoreId, AlipayOrderNo
		) AR ON sale.StoreId = ar.StoreId AND sale.PoCode = ar.AlipayOrderNo



go

