
/*
通过指定时间点，查询某个（或多个）分销商，指定一个商品（或sku）的分销价（经销价）的报表
1.如果调价单被禁用了，禁用的的时候，如果未到失效时间，会把时效时间更新为禁用时间，
	取价的时候看调价单的有效时间和时效时间段，有重叠的取复核时间靠后的
*/

-- Select dbo.F_Get_DistributionPrice('20180627133', '2018-07-02', 'ProductCode', 'SkuCode')
/*



*/

Create Function [dbo].[F_Get_DistributionPrice] 
(
	@P_DistributorId nvarchar(100),
	@P_PayDate DateTime,
	@P_ProductCode nvarchar(100),
	@P_SkuCode nvarchar(100)
)
Returns Decimal(15, 2)
AS
Begin
		Declare @V_Result Decimal(15, 2);
		
		if @P_ProductCode is null and @P_SkuCode is not null
			Begin
				Select Top 1 @P_ProductCode = ProductCode From ProductSku Where Code = @P_SkuCode;
			End
 
		If @P_SkuCode is not NULL
			Begin 
			
					Select Top 1 @V_Result = isnull(Price, 0)
					From DistributionPriceChange dpc(nolock), DistributionPriceChangeDetail dpcd(nolock),ProductSku ps(nolock)
					where dpc.Id = dpcd.PriceChangeId
					and dpcd.SkuId = ps.SkuId
					And @P_PayDate >= dpc.BeginDate
					And @P_PayDate < dpc.EndDate
					And AuditDate <= @P_PayDate
					And dpcd.SkuCode = @P_SkuCode
					And DistributorId = @P_DistributorId
					Order by dpc.AuditDate desc;
			End; 
			  
		If isnull(@V_Result, 0) = 0
				Begin 
						Select Top 1 @V_Result = isnull(Price, 0)
						From DistributionPriceChange dpc(nolock), DistributionPriceChangeDetail dpcd(nolock), Product pd(nolock)
						where dpc.Id = dpcd.PriceChangeId
						and dpcd.ProductId = pd.ProductId
						And @P_PayDate >= dpc.BeginDate
						And @P_PayDate < dpc.EndDate
						And AuditDate <= @P_PayDate
						And dpcd.ProductCode = @P_ProductCode
						And DistributorId = @P_DistributorId
						Order by dpc.AuditDate desc; 
				End;  

		if isnull(@V_Result, 0) = 0
			Begin
				-- 取分销价
				Declare @DistributorDiscountId uniqueidentifier, @Year nvarchar(100), @Season nvarchar(100), @Brand nvarchar(100), @ZK decimal(12, 2), @PlatformPrice decimal(12,2)
				Select Top 1 @Year = Year, @Season = Season, @Brand = Brand, @PlatformPrice =PlatformPrice
				From Product
				Where Code = @P_ProductCode;

				-- Distributor --
				if exists(
						Select *
						From DistributorDiscount dd, DistributorDiscountDetail ddd
						Where ReviewDate is not null
						and FailureTime <= @P_PayDate
						and ddd.BrandCode = @Brand
						and ddd.Season = @Season
						and ddd.Year = @Year
						) 
					Begin
						Select Top 1 @ZK = dd.Discount
						From DistributorDiscount dd, DistributorDiscountDetail ddd
						Where ReviewDate is not null
						and FailureTime <= @P_PayDate
						and ddd.BrandCode = @Brand
						and ddd.Season = @Season
						and ddd.Year = @Year
						order by FailureTime desc;
					End;
				Else
					Begin
						Select Top 1 @ZK = dd.Discount  
						From DistributorDiscount dd 
						Where ReviewDate is not null
						and FailureTime <= @P_PayDate
						Order by FailureTime Desc;
					End;
					 
				return Round(isnull(@PlatformPrice, 0) *isnull(@ZK, 0) / 100, 2)

			End;
		Return isnull(@V_Result, 0); 
		
End;
go

