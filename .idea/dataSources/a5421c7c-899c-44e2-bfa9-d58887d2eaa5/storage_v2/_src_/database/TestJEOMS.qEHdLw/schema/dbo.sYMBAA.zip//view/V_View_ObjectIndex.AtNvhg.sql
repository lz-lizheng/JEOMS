		CREATE VIEW [dbo].[V_View_ObjectIndex]
	AS
	SELECT a.id AS 'ID', a.name AS 'tableName', b.name AS 'colName', d.name AS 'indexName'
	FROM sysobjects a, sys.syscolumns b, sys.index_columns c, sys.sysindexes d
	WHERE a.xtype = 'u'
		AND a.id = b.id
		AND a.id = c.object_id
		AND b.colid = c.column_id
		AND a.id = d.id
		AND c.index_id = d.indid
        go

