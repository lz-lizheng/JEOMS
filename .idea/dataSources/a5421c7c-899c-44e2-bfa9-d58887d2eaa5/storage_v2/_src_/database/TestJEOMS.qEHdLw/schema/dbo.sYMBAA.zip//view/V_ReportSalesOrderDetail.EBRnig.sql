

/**********************
*create date : 2017-05-10
*create by：qiaoni 
*remark ：订单明细统计去掉快递信息Isnull 检查 
***********************/ 
--修改退货明细统计视图
CREATE VIEW [dbo].[V_ReportSalesOrderDetail] AS 
SELECT 
	SOD.DetailId AS DetailId							--订单明细ID
	,SO.CreateDate AS RecordDate						-- 制单时间
	,SO.Code AS SalesOrderCode					--订单号 
	,SO.IsCod AS SalesOrderIsCod				--是否是货到付款的订单
	,SO.ExpressFeeIsCod AS SalesOrderExpressFeeIsCod		--是否是物流费用到付的订单
	,SO.IsHold AS SalesOrderIsHold							--留单标记	
	,SO.IsManual AS SalesOrderIsManual						--是否人工处理
	,SO.IsObsolete AS SalesOrderIsObsolete					--是否作废
	,SOD.IsOutOfStock AS SalesOrderIsOutOfStock					--明细是否缺货	
	,SO.HasInvoice AS SalesOrderHasInvoice					--是否需要发票
	,SOS.Consignee AS SalesOrderConsignee					--收货人
	,SOS.Mobile AS SalesOrderConsigneeMobile				--手机号码
	,SO.PlatfromDate AS PlatformDate						--拍单时间 
	,SO.PayDate AS SalesOrderPayDate						--付款时间		
	,SO.SpeedDelivery AS SalesOrderSpeedDelivery			--是否加急发货 
	,SO.PreSaleType AS SalesOrderPreSaleType				--预售类型	
	,SO.PlatformType AS SalesOrderPlatformType				--平台类型
	,sos.SellerMemo AS Remark
	,SO.Status AS SalesOrderStatus							--订单状态
	,SO.TradeId AS SalesOrderTradeId						--交易号
	,SO.TransType AS SalesOrderTransType					--订单类型
	,sos.Contacter AS SalesOrderConsigneeContacter					--联系人
	,sos.Address AS SalesOrderConsigneeAddress						--联系地址
	,SOS.Telephone AS SalesOrderConsigneeTelephone			--电话号码 
	,SOD.ProductCode AS ProductCode							--商品代码
	,SOD.ProductName AS ProductName					--商品名称		
	,SOD.SkuCode AS SkuCode							--规格代码
	,SOD.SkuName AS SkuName							--规格名称	
	,ISNULL(SOD.Quantity,0) AS Quantity							--数量	
	,ISNULL(SOD.PriceSelling,0) AS PriceSelling					--销售单价
	,ISNULL(SOD.PriceOriginal,0) AS PriceOriginal					--原始单价
	,ISNULL(SOD.Amount,0) AS Amount								--销售金额
	,ISNULL(SOD.DiscountAmount,0) AS DiscountAmount				--折扣金额			
	,SOD.IsDeleted  AS IsDeleted									--行销
	,SODP.outer_iid AS LinePlatformProductOuterId					--商品编号
	,SODP.title AS LinePlatformProductTitle							--商品标题
	,SODP.outer_sku_id AS LinePlatformProductSkuCode					--商品Sku编号
	,SODP.num AS LinePlatformProductQuantity							--平台购买数量
	,SODP.sku_properties_name AS LinePlatformProductSkuName			--平台规格名称	
	,SOD.DetailType AS DetailType									--明细类型 : 赠品，正常商品，虚拟商品
	,ISNULL(SOD.Status,0) AS DetailStatus								--明细状态	
	,SO.StoreName AS StoreName								--店铺名称		
	,SO.CustomerCode AS CustomerCode						--客户编码
	,SO.CustomerName AS CustomerName						--客户名称  
	,SOD.AmountActual												--结算金额                  								
	,DO.Code AS DispatchProductOrderCode							--配货通知单号
	,DO.DeliveryDate AS DeliveryDate								--发货日期
	,SO.AuditDate											--审核时间	
	,PD.FirstPrice														--吊牌价　
	,PD.WholeSalePrice													--标准价	
	,PD.RetailPrice													--零售价
	,PD.Brand															--品牌
	,DO.ActualExpressName												-- 快递公司
	,DO.ActualExpressNo													-- 快递单号
	,SOD.FirstCost AS FirstCost									-- 财务成本
	,SO.ExpressFee AS ExpressFee							-- 物流费用 
	,SOD.DistributionAmount									--  分销商实收金额 
	,SOD.ShippingDateClerk										-- 预计发货日期
	,SO.TagName AS TagName								-- 标记名称 
	,so.StoreId
	,do.ExpressId
	,Do.WarehouseName
	,pd.SupplierName
	,sod.FirstCost * sod.Quantity AS FirstCostTotal
	,sod.TagName AS DetailTagname		--明细标记
	,sod.RefundStatus                   --退款状态
	,so.IsPrepay						-- 预付款
	,so.TradeFinishDate
FROM dbo.SalesOrder(NOLOCK) SO
LEFT JOIN dbo.SalesOrderDetail(NOLOCK) SOD ON SO.OrderId = SOD.SalesOrderId
LEFT JOIN dbo.SalesOrderSub(NOLOCK) SOS ON SO.OrderId = SOS.SubId
LEFT JOIN dbo.SalesOrderDetailPlatformProduct(NOLOCK) SODP ON SOD.DetailId = SODP.Id
LEFT JOIN (  SELECT DO.Code, DO.Status, DOD.SalesOrderDetailId, 
					DODE.ExpressName AS ActualExpressName, 
					DODE.ExpressNo AS ActualExpressNo, 
					DODE.DeliveryDate AS DeliveryDate, 
					DODE.ExpressId AS ExpressId, 
					Do.WarehouseName					
		FROM dbo.DispatchOrder(NOLOCK) DO
		LEFT JOIN dbo.DispatchOrderDetail(NOLOCK) DOD ON DO.Id = DOD.DispatchOrderId 
		LEFT JOIN dbo.DispatchOrderDetailExpress(NOLOCK) DODE ON DOD.Id = DODE.DetailId
		WHERE DO.Status <> 3) DO ON SOD.DetailId = DO.SalesOrderDetailId
LEFT JOIN dbo.Product(NOLOCK) PD ON SOD.ProductId = PD.ProductId
WHERE SOD.IsAbnormal = 0
AND SO.TransType <> 1
go

