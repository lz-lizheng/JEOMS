


--唯品档期"/>PO号" Fie开始时间""/>款式数量"备货库存"剩余库存"售罄率" F 销售额" F"/>件单价" Ft"/>销量（件）"/>退货数量""/>退货率" F

CREATE VIEW [dbo].[V_VipScheduleAnalyse] AS
SELECT Sale.ScheduleCode,
	   Sale.PoCode ,
       Sale.ScheduleBeginDate ,
       Sale.ScheduleEndDate ,
       Sale.ProductQty ,
       Sale.PlanQty ,
       Sale.RemainingInventory ,
       Sale.SaleThroughRate ,
       Sale.SaleQty ,
       Sale.SaleAmount ,
       Rtn.RtnQty,
	   Rtn.RtnQty * 1.0 / Sale.SaleQty AS ReturnRate,
	   Sale.SaleCost,
	   rtn.RtnCost,
	   Rtn.RtnAmount
FROM (
		SELECT vs.ScheduleCode, vs.PoCode, vs.ScheduleBeginDate, vs.ScheduleEndDate, 
			COUNT(DISTINCT vsd.ProductCode) AS ProductQty, 
			SUM(vsd.PlanQty) AS PlanQty, 
			SUM(ISNULL(vsd.PlanQty, 0) - ISNULL(vsd.OutQty, 0)) AS RemainingInventory,
			SUM(vsd.OutQty) * 1.0 / SUM(vsd.PlanQty) AS SaleThroughRate,
			SUM(vsd.OutQty) AS SaleQty,
			SUM(Vsd.OutQty * vsd.SupplyPrice) AS SaleAmount,
			SUM(vsd.OutQty * pd.FirstCost) AS SaleCost
		FROM dbo.VipSchedule vs(NOLOCK)
		LEFT JOIN dbo.VipScheduleDetail vsd(NOLOCK) ON vs.Id = vsd.ScheduleId 
		LEFT JOIN dbo.Product pd(NOLOCK) ON vsd.ProductId = pd.ProductId
		WHERE vs.PoCode IS NOT NULL
		GROUP BY vs.ScheduleCode, vs.PoCode, vs.ScheduleBeginDate, vs.ScheduleEndDate
	) Sale
LEFT JOIN 
	(	
		SELECT vrod.PoCode, SUM(vrod.ReturnQty) AS RtnQty, SUM(vrod.ReturnQty * pd.FirstCost) AS RtnCost, SUM(vrod.ReturnQty * SalePrice.SupplyPrice) AS RtnAmount
		FROM dbo.VipReturnOrder vro(NOLOCK)
		LEFT JOIN dbo.VipReturnOrderDetail vrod(NOLOCK) ON vro.Id = vrod.ReturnOrderId
		LEFT JOIN dbo.Product pd(NOLOCK) ON vrod.ProductId = pd.ProductId
		LEFT JOIN (	SELECT vs.PoCode, vsd.SkuId , MAX(vsd.SupplyPrice) AS SupplyPrice
					FROM dbo.VipSchedule vs(NOLOCK) 
					LEFT JOIN dbo.VipScheduleDetail vsd(NOLOCK) ON vs.Id = vsd.ScheduleId
					GROUP BY vs.PoCode, vsd.SkuId
				   ) AS SalePrice ON vrod.PoCode = SalePrice.PoCode AND vrod.SkuId = SalePrice.SkuId
		GROUP BY vrod.PoCode
		 

	) Rtn ON Rtn.PoCode = Sale.PoCode



go

