

-- CreateUser : JE
-- CreateDate : 2017-12-27 
-- Description: 淘系、京东以交易完成节点开发票
--				其他平台以发货完成开票
CREATE PROC [dbo].[P_AutoElectronicInvoice]
AS
BEGIN
	DECLARE @V_BeginDate DATE 
	SET @V_BeginDate = DATEADD(DAY, -7, GETDATE())
	PRINT @V_BeginDate
	DECLARE @V_EmailAddr nvarchar(100) 
	  
	DECLARE @V_IndustryClassificationCode NVARCHAR(50), @V_IndustryClassificationName NVARCHAR(50), @V_CrateUser NVARCHAR(50)
	DECLARE @V_GoodsName NVARCHAR(50), @V_TaxRate NUMERIC(12, 6), @V_Status NVARCHAR(10), @V_InvoiceType NVARCHAR(10)
	DECLARE @V_BuyerTypes NVARCHAR(10), @V_InvoiceLineNatureName NVARCHAR(50), @V_InvoiceLineNature NVARCHAR(50)
	 
	SET @V_Status = 2;
	SET @V_InvoiceType = 0;	
	Set @V_EmailAddr = 'fapiao@elfsack.com'
     
	-- 销售订单开票.
	BEGIN 
		-- Blue Invoice Header
		SELECT NEWID() as ElectronicInvoiceId, 
			SOI.Code, 
			SOI.StoreId, 
			SOI.StoreName, 
			SOI.TradeId, 
			2 AS Status, 
			CreateUser AS AuditUser,
			GETDATE() AS AuditDate,
			@V_InvoiceType as InvoiceType, 
			soi.Title AS buyerName, 
			GmfMobile as Telephone, 
			CreateUser as InvoiceCreateUser, 
			soi.Amount AS InvoiceAmount, 
			ROUND(soi.Amount / (1 + TaxRate), 2) AS InvoiceAmountWithOutTax, 
			(soi.Amount - ROUND(soi.Amount / (1 + TaxRate), 2)) AS InvoiceTax, 
			NULL AS Remark, 
			IndustryClassificationCode, 
			IndustryClassificationName, 
			InvoiceLineNature, 
			GoodsName, 
			NULL AS Unit, 
			ROUND(soi.Amount / (1 + TaxRate), 2) AS GoodsUnitPrice, 
			1 as GoodsQty,
			TaxRate * 100 as TaxRate, 
			GETDATE() as CreateDate, 
			CreateUser, 
			@V_EmailAddr as EmailAddr, 
			0 IsReded, 
			SOI.OrderId,
			IdentificationNoPaxpayer, 
			GmfAddress, 
			GmfBankName, 
			GmfBankNo
		Into #TMPInvoiceHdr
		FROM (
				SELECT Distinct So.Code, So.StoreId, So.StoreName, so.TradeId, 
					case when so.HasInvoice = 1 then soi.Amount else so.PayAmount End as Amount,
					case when so.HasInvoice = 1 then soi.Title else '个人' End as Title,
					isnull(sos.Mobile, '') as Telephone, 
					so.OrderId, Soi.GmfAddress, Soi.GmfMobile, Soi.GmfBankName, Soi.GmfBankNo, Soi.IdentificationNoPaxpayer,
					EIC.Kpr as CreateUser, EIC.Hylx as IndustryClassificationCode, EIC.HylxName as IndustryClassificationName,
					EIC.FphXz as InvoiceLineNature, EIC.XmMc as GoodsName, SL * 1.0 / 100 as TaxRate
				FROM dbo.SalesOrder so 
				LEFT JOIN dbo.SalesOrderInvoice soi ON so.OrderId = soi.SalesOrderId
				LEFT JOIN dbo.SalesOrderSub sos ON so.OrderId = sos.SubId
				Left Join StoreSetting SS on so.StoreId = SS.StoreId
				Left Join ElectronicInvoiceConfig EIC on SS.ElectronicInvoiceConfigId = EIC.Id
				WHERE 1 = 1
				AND so.PlatformStatus = 2 -- 全部发货
				and SO.StoreId in (Select StoreId From StoreSetting Where AutoInvoice = 1) 
				AND so.TransType = 0 
				And EIC.IsDisabled = 0
				and case when so.HasInvoice = 1 then soi.Amount else so.PayAmount End > 0
				AND so.TradeFinishDate >= @V_BeginDate
				And Not Exists (Select 1 From ReturnOrderDetail rod where so.OrderId = rod.SalesOrderId)
				AND NOT EXISTS (SELECT 1 FROM dbo.ElectronicInvoice EI WHERE so.StoreId = ei.StoreId AND so.TradeId = ei.TradeId AND ei.InvoiceType = 0)
			) SOI;  
			   
		-- Detail
		Insert Into ElectronicInvoiceDetail(
				Id,ProductCode,ProductId,ProductName,SkuCode,SkuName,SkuId,Quantity,UnitPrice,Amount,TaxAmount,
				Rate,ElectronicInvoiceId,CreateDate)
		Select	newid() as DetailId, sod.ProductCode, sod.ProductId, 
				sod.ProductName, sod.SkuCode, sod.SkuName, sod.ProductSkuId, 
				sod.Quantity, sod.AmountActual / sod.Quantity as UnitPrice, sod.AmountActual,
				Round(sod.AmountActual / (1 + eh.TaxRate /100), 2) as TaxAmount, 
				eh.TaxRate, eh.ElectronicInvoiceId, GetDate() as CreateDate 
		From #TMPInvoiceHdr eh(nolock), SalesOrderDetail sod(nolock)
		where eh.OrderId = sod.SalesOrderId
		and IsDeleted = 0
		and DetailType = 0;
		  
		Update #TMPInvoiceHdr Set InvoiceAmount = A.TotalAmount,
			   InvoiceAmountWithOutTax = A.TaxAmount,  InvoiceTax = A.Tax, GoodsUnitPrice = TaxAmount From (
				Select ElectronicInvoiceId, Sum(Amount) as TotalAmount, Sum(TaxAmount) as TaxAmount, Sum(Amount) - Sum(TaxAmount) as Tax
				From ElectronicInvoiceDetail
				Group by ElectronicInvoiceId
				) A
		Where #TMPInvoiceHdr.ElectronicInvoiceId = A.ElectronicInvoiceId 

		-- Blue Invoice Header
		INSERT INTO ElectronicInvoice(  ElectronicInvoiceId,Code,StoreId,StoreName,TradeId,Status,AuditUser,AuditDate,InvoiceType,
										BuyerName,BuyerMobile,InvoiceCreateUser,InvoiceAmount,InvoiceAmountWithOutTax,InvoiceTax,
										Remark,IndustryClassificationCode,IndustryClassificationCodeName,InvoiceLineNature,GoodsName,
										Unit,GoodsUnitPrice,GoodsQty,
										TaxRate,CreateDate,CreateUser, EmailAddress, IsReded, SalesOrderId, 
										IdentificationNoPaxpayer, GmfAddress, GmfBankName, GmfBankNo) 
		Select *
		From #TMPInvoiceHdr; 
	End 
END;


go

