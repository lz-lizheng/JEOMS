
CREATE View [dbo].[V_AssemblyOrder] as

Select

ao.Id,

ao.Status, --单 据状态

ao.Code, --加工单号

ao.WarehouseId, --仓库名称

ao.WarehouseName, --仓库名称

ao.AssemblyType, --组装类型

ao.MachiningType, --加工类型

ao.CreateDate, --创建时间

ao.CreateUser, --创建人

ao.AuditDate, --审核时间

ao.AuditUser, --审核人

ao.StorageTime, --礼盒入库时间

ps.ProductCode SkuProductCode,

ps.ProductName,

aod.SourceProductCode, --商品编码

ps.Description as SourceProductName, --规格编码

aod.TargetSkuCode, --礼盒编码

aod.TargetSkuName, --礼盒名称

aod.TargetQuantity, --礼盒数量

Case when MachiningType = 0 Then aod.SourceQuantity Else aod.TargetQuantity end as SourceQuantity, --数量

Case when MachiningType = 0 Then aod.InQuantity Else aod.InQuantity end as InQuantity, -- 入库数量

--aod.InQuantity, -- 入库数量

aod.OutQuantity, --Out库数量

ao.Remark, --备注

aod.Id as DetailId --DetailId

From AssemblyOrder Ao(nolock)

JOin AssemblyOrderDetail Aod(nolock) on ao.id = aod.AssemblyOrderId

Join ProductSku ps(nolock) on aod.SourceProductId = ps.SkuId

go

