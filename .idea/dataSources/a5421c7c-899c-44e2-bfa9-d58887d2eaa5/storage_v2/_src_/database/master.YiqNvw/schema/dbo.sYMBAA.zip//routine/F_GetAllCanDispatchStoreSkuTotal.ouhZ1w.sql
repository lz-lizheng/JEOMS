
 

/**********************
*create by：Qiaoni
*remark ：订单界面显示可配计算逻辑调整
*date:2017-07-21
***********************/
CREATE FUNCTION [dbo].[F_GetAllCanDispatchStoreSkuTotal]
  (
    @SkuId   UNIQUEIDENTIFIER, --规格ID
    @storeId   UNIQUEIDENTIFIER --规格ID  
  )
  RETURNS INT
AS
  BEGIN
    DECLARE @inventory INT
    DECLARE @occupation INT
    
    SELECT @inventory = ISNULL(SUM(iv.Quantity),0)
    FROM InventoryVirtual(NOLOCK)iv
    JOIN (
			Select TemplateId, case WHen Isnull(a.WarehouseType, 1) != 4 then WarehouseId Else b.Id End as WarehouseId
			From DispatchTemplateWarehouse a
			left Join Warehouse b on a.WarehouseType = 4 and b.ParentId = a.WarehouseId
		) dtw on iv.WarehouseId=dtw.WarehouseId
    JOIN StoreSetting ss on dtw.TemplateId=ss.DispatchTemplateId
    WHERE iv.SkuId = @SkuId and ss.StoreId=@storeId

    SELECT @occupation = ISNULL(SUM(ioc.Quantity),0)
    FROM InventoryOccupation(NOLOCK)ioc
    JOIN (
			Select TemplateId, case WHen Isnull(a.WarehouseType, 1) != 4 then WarehouseId Else b.Id End as WarehouseId
			From DispatchTemplateWarehouse a
			left Join Warehouse b on a.WarehouseType = 4 and b.ParentId = a.WarehouseId
		) dtw on ioc.WarehouseId=dtw.WarehouseId
    JOIN StoreSetting ss on dtw.TemplateId=ss.DispatchTemplateId
    WHERE ioc.SkuId = @SkuId and ss.StoreId=@storeId AND (ioc.Type in (2,3,4,5,6) OR ioc.IsDispatched=1)
 
    RETURN @inventory-@occupation
  END



go

