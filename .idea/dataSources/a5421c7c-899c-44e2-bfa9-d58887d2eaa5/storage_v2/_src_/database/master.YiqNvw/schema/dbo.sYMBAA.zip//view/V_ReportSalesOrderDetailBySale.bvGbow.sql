/**
*create date : 2020-5-7
*create modify：拓斗
*remark ：添加明细退款状态字段
*/
CREATE VIEW [dbo].[V_ReportSalesOrderDetailBySale] AS SELECT
SOD.DetailId AS DetailId--订单明细ID
,SO.CreateDate AS RecordDate-- 制单时间
,SO.PayDate AS SalesOrderPayDate--付款时间
,so.CustomerNameKey
,SO.TradeId AS SalesOrderTradeId--交易号
,SOD.ShippingDateClerk-- 预计发货日期
,so.TradeFinishDate AS TradeFinishDate
,so.StoreId AS OStoreId
,so.StoreId AS StoreId
,SOD.ProductCode AS ProductCode--商品代码
,SO.TransType AS SalesOrderTransType--订单类型
,SO.TagName AS TagName-- 标记名称 
,ISNULL(SOD.Status,0) AS DetailStatus--明细状态
,SOD.SkuCode AS SkuCode--规格代码
,SO.Code AS SalesOrderCode--订单号 
,so.IsPrepay-- 预付款
,SOD.IsOutOfStock AS SalesOrderIsOutOfStock--明细是否缺货
,SOD.IsDeleted AS IsDeleted--行销
,SOD.DetailType AS DetailType--明细类型 : 赠品，正常商品，虚拟商品
,ChannelTypeName--来源渠道
,SO.RefundStatus --退款状态
FROM dbo.SalesOrder(NOLOCK) SO
JOIN dbo.SalesOrderDetail(NOLOCK) SOD ON SO.OrderId = SOD.SalesOrderId
join dbo.SalesOrderSub sub on sub.SubId=SO.OrderId
WHERE SOD.IsAbnormal = 0 AND SO.TransType <> 1
go

