
CREATE VIEW [dbo].[V_SMSTemplateStoreJoin]
--WITH ENCRYPTION, SCHEMABINDING, VIEW_METADATA
AS
    SELECT tsj.*,vst.Name TemplateName,s.Name StoreName FROM SMSTemplateStoreJoin tsj JOIN dbo.V_SMSTemplate vst ON tsj.TemplateId=vst.Id JOIN dbo.Store s ON tsj.StoreId=s.Id
-- WITH CHECK OPTION


go

