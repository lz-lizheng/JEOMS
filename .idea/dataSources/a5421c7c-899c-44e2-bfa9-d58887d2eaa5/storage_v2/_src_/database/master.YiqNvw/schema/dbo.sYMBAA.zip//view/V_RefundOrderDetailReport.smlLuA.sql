/**  
 Create By : creoa
 Remark  : 退款单明细统计  
 Modify  : 2019-04-27
*/  
CREATE VIEW [dbo].[V_RefundOrderDetailReport]
AS
SELECT rf.*,rfd.ProductCode,rfd.ProductName,rfd.SkuCode,rfd.SkuName,rfd.Quantity,rfd.RefundAmount FROM dbo.RefundOrder(nolock) rf JOIN dbo.RefundOrderDetail(NOLOCK) rfd ON rfd.RefundOrderId = rf.Id
UNION ALL
SELECT rf.*,rtl.ProductCode,rtl.ProductName,rtl.SkuCode,rtl.SkuName,rtl.Quantity,rtl.RefundAmount FROM dbo.RefundOrder(nolock) rf JOIN  dbo.ReturnOrderDetail(NOLOCK) rtl ON rf.ReturnOrderId=rtl.ReturnOrderId
UNION ALL
SELECT rf.*,rfd.ProductCode,rfd.ProductName,rfd.SkuCode,rfd.SkuName,rfd.Quantity,rfd.RefundAmount FROM dbo.RefundOrder(nolock) rf LEFT JOIN dbo.RefundOrderDetail(NOLOCK) rfd ON rfd.RefundOrderId = rf.Id WHERE rfd.Id IS NULL and rf.ReturnOrderId is null

go

