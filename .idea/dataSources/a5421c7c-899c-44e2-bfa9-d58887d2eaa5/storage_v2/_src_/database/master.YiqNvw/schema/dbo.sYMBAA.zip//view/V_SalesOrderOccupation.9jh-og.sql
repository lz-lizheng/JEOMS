

/**********************
*create by：Byron
*remark ：库存占用显示支付日期
*date:2018-11-27
***********************/
CREATE VIEW [dbo].[V_SalesOrderOccupation]
AS
SELECT c.Code,c.TradeId,b.ProductName,b.SkuName,a.SkuId,a.WarehouseId,a.Quantity,a.IsDispatched,a.Type,a.PayDate FROM dbo.InventoryOccupation  a
JOIN dbo.SalesOrderDetail b ON a.DetailId=b.DetailId
JOIN dbo.SalesOrder c ON b.SalesOrderId=c.OrderId
UNION ALL
SELECT r.Code,r.TradeId,rl.ProductName,rl.SkuName,a.SkuId,a.WarehouseId,rl.Quantity,0 IsDispatched,a.Type,a.PayDate FROM dbo.InventoryOccupation  a
JOIN dbo.ReturnOrderOutDetail rl ON a.DetailId=rl.Id
JOIN dbo.ReturnOrder r ON rl.ReturnOrderId=r.Id
go

