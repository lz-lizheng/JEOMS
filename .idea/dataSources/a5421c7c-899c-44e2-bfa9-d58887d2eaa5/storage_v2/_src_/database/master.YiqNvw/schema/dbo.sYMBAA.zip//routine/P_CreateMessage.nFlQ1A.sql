
CREATE PROCEDURE [dbo].[P_CreateMessage]
AS
BEGIN
	
	SELECT OrderId, MessageString INTO #TMp01 	FROM dbo.SalesOrder WHERE MessageString IS NOT NULL;
	 
	INSERT INTO #TMp01 SELECT id, Message  FROM dbo.ReturnOrder WHERE Message IS NOT NULL AND LEN(Message) > 0

	INSERT INTO #TMp01 SELECT id, Message FROM dbo.ReturnOrder WHERE Message IS NOT NULL AND LEN(Message) > 0

	DECLARE @OrderId BIGINT, @MessageString NVARCHAR(MAX)
	DECLARE DetailCursor CURSOR FOR SELECT OrderID, MessageString FROM #TMp01
	OPEN DetailCursor
	fetch next from DetailCursor into @OrderId,@MessageString
	while @@fetch_status<>-1
	BEGIN 
		 INSERT INTO TempMessage
		 SELECT SUBSTRING(colData, 0, CHARINDEX( ',', coldata)), 
				SUBSTRING(colData, CHARINDEX( ',', coldata)+1, CHARINDEX( ',', REPLACE(coldata, SUBSTRING(colData, 0, CHARINDEX( ',', coldata)+1), ''))-1), 
				REVERSE(SUBSTRING(REVERSE(coldata), 0, CHARINDEX( ',', REVERSE(coldata)))),
				OrderId
		 FROM [dbo].[F_SplitString_Order](@MessageString,';', @OrderId)
		  
	fetch NEXT from DetailCursor into @OrderId,@MessageString
	end
	close DetailCursor
	deallocate DetailCursor

END;



go

