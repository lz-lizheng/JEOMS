/**

*create date : 2019-06-25

*create modify：拓斗

*remark ：物流轨迹视图

*/

CREATE VIEW [dbo].[V_LogisticsTracking]

AS

SELECT DISTINCT Lt.StoreName,dod.TradeId,do.Code,do.DeliveryDate,ExpressName,ExpressNo,Lt.Status,

Lt.Mobile, dod.WarehouseName, Consignee, Address, CreateTime, ModifyTime, Note,Lt.StoreId,ExpressId,Content

From LogisticsTracking Lt(nolock)

Left Join DispatchOrder do (nolock)on lt.ExpressNo = do.ActualExpressNo

Left Join DispatchOrderDetail dod(nolock) on do.Id = dod.DispatchOrderId
go

