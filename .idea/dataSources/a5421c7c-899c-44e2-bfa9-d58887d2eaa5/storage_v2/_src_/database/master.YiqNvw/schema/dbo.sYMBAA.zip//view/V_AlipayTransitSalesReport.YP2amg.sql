
/**
 * 黑蚁  财务报表(在途销售明细)
*/
CREATE VIEW [dbo].[V_AlipayTransitSalesReport]
AS
SELECT 
s.Code StoreCode,
s.Id StoreId,
s.Name StoreName,
(
	CASE WHEN so.Status<32 THEN 
		1 --平台已付款未发货
	WHEN so.Status>=32 AND sl.TradeFinishDate IS NULL THEN
		2 --已发货买家未确认收货
	WHEN so.Status>=32 AND sl.TradeFinishDate IS NOT NULL AND ar.OrderNo IS NULL THEN
		3 --已发货买家已确认收货-未到账
	WHEN so.Status>=32 AND sl.TradeFinishDate IS NOT NULL AND ar.OrderNo IS NOT NULL THEN
		4 --已发货买家已确认收货-已到账 
	END
) Status,
so.Code OrderCode,
so.TradeId,
so.TransType,
D.Code DispatchCode,
sl.SkuCode,
sl.ProductName,
sl.Quantity,
sl.PriceSelling,
sl.PriceOriginal,
sl.AmountActual,
sl.DistributionAmount,
sl.ReissueActual,
sl.CombProductQuantity,
sl.CombAmount,
so.ExpressFee,
so.PayDate
FROM dbo.Store(NOLOCK) s 
JOIN dbo.SalesOrder(NOLOCK) so ON SO.StoreId=s.Id
JOIN dbo.SalesOrderDetail(NOLOCK) sl ON so.OrderId=sl.SalesOrderId
LEFT JOIN
(
	SELECT dl.SalesOrderDetailId,do.Code FROM dbo.DispatchOrder(NOLOCK) do JOIN dbo.DispatchOrderDetail(NOLOCK) dl ON dl.DispatchOrderId=do.Id GROUP BY dl.SalesOrderDetailId,do.Code
) D ON D.SalesOrderDetailId=sl.SalesOrderId
LEFT JOIN 
(
	SELECT ar.StoreId,ar.OrderNo FROM dbo.AlipayRecord(NOLOCK) ar WHERE ar.AccountType=0 GROUP BY ar.StoreId,ar.OrderNo
) ar ON ar.OrderNo=so.TradeId AND ar.StoreId=so.StoreId

go

