
/**********************
*create date: 2019-01-07
*modify by：Byron
*remark ：增加采购公司字段
***********************/
CREATE View [dbo].[V_ReportPurchaseReturnOrder] as
SELECT pro.CreateDate ,
        pro.Code ,
        pro.SupplierCode ,
        pro.SupplierName ,
        pro.WarehouseID ,
        pro.WarehouseName ,
        pro.TypeCode ,
        pro.TypeName ,
        pro.Status ,
        pro.ApprovalUser ,
        pro.ApprovalDate ,
        pro.Remark ,
        pro.CreateUserName ,
        pro.VirtualWarehouseId ,
        pro.VirtualWarehouseName ,
        pro.PurchaseOrderId ,
        pro.PurchaseOrderCode,   
        prod.ProductCode ,
        prod.ProductName , 
        prod.SkuCode ,
        prod.SkuName ,
        prod.Color ,
        prod.Size ,
        prod.ReturnQty ,
        prod.OriginalPrice ,
        prod.OutStockQty ,
        prod.WarehousingTime ,
        prod.WarehouseDeliveryTime,
        prod.PlanQty,
        prod.Remark as DetailRemark,
pro.SupplierCompanyName
 FROM dbo.PurchaseReturnOrder pro(NOLOCK)
 LEFT JOIN dbo.PurchaseReturnOrderDetail prod(NOLOCK) ON pro.Id = prod.PurchaseReturnOrderId
go

