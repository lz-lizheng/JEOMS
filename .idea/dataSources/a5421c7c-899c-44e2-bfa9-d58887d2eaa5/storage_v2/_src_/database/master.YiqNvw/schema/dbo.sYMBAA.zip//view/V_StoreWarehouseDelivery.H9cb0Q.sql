
CREATE View [dbo].[V_StoreWarehouseDelivery] as 
select distinct a.StoreName,a.Code,b.ProductCode, b.TradeId, b.WarehouseName,a.PayTime,a.CreateDate,CancelDate,
	a.IsReceived, case when a.IsReceived=1 then '已接单' else '未接单' end IsReceivedName   
from DispatchOrder a left join DispatchOrderDetail b on a.Code=b.DispatchOrderCode    
left join Warehouse c on b.WarehouseId=c.Id     
where c.WarehouseType=5 and a.Status=2



go

