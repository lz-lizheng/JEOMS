/**

*create date : 2019-06-27

*create modify：拓斗

*remark ：获取时间所在周的周一及周日日期

*/

CREATE function [dbo].[GetBeginEndDate](@date varchar(20))

returns varchar(100)

as

begin

declare @temp datetime

declare @beginDate datetime

declare @count int

declare @endDate datetime

declare @beginEndDate varchar(200)

begin

set @count=datepart(dw,@date)

begin

set @temp=DATEADD(dd,7-@count,@date)

select @endDate= CONVERT(varchar(100),@temp,23)+' 23:59:59'

set @temp=DATEADD(dd,1-@count,@date)

select @beginDate= CONVERT(varchar(100),@temp,23)+' 00:00:00'

end

set @beginEndDate=CONVERT(varchar(100), @beginDate, 23)+'-'+CONVERT(varchar(100), @endDate, 23)

end

return @beginEndDate

end
go

