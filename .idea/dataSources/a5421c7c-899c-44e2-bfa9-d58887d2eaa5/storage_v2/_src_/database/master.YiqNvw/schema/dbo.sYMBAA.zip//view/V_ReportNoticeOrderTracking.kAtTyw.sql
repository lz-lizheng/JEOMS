
/**********************
*create date: 2019-02-20
*create by：Byron
*remark ：通知单跟踪视图修改
***********************/
CREATE View [dbo].[V_ReportNoticeOrderTracking]
AS
--B2B通知单
SELECT case bao.Status when 1 then '已审核' when 2 then '已通知' when 4 then '部分出库' end Status,bao.PlanCode,bao.Code,'B2B通知单' as OrderType,max(bao.CreateDate) as AuditDate,bao.StoreName,bao.OutWarehouseName,bao.ScheduleNo
,sum(baod.NoticeQty)NoticeQty,sum(baod.OutQty)OutQty,sum(baod.NoticeQty)-sum(baod.OutQty) DifferenceQuantity,
max(baod.WarehouseDeliveryTime)WarehouseDeliveryTime,bao.CreateUser,bao.Remark
 FROM B2BAllocationOut bao
join B2BAllocationOutDetail baod on bao.Code = baod.OutCode
join B2BAllocationPlan bap on bao.PlanId = bap.Id
where bao.Status in(1,2,4) and bao.CreateDate<DATEADD(HOUR, -48, GETDATE())
group by bao.Status,bao.PlanCode,bao.Code,bao.StoreName,bao.OutWarehouseName,bao.ScheduleNo,bao.CreateUser,bao.Remark
Union All
--出库订单
SELECT case oo.Status when 1 then '已审核' when 2 then '已通知' when 3 then '部分出库' end Status,oo.FromCode,oo.Code,'出库订单',max(oo.AuditDate) as AuditDate,'' StoreName,oo.WarehouseName,'' ScheduleNo
,sum(ood.LockedQty)LockedQty,sum(ood.OutQty)OutQty,sum(ood.LockedQty)-sum(ood.OutQty) DifferenceQuantity,
max(ood.WarehouseDeliveryTime)WarehouseDeliveryTime,oo.CreateUser,oo.Remark
 FROM OutboundOrder oo
join OutboundOrderDetail ood on oo.Id = ood.OutboundOrderId
where oo.Status in(1,2,3) and oo.AuditDate<DATEADD(HOUR, -48, GETDATE())
group by oo.Status,oo.FromCode,oo.Code,oo.WarehouseName,oo.CreateUser,oo.Remark
Union All
--采购退货单
SELECT case pr.Status when 1 then '已审核' when 2 then '已通知' when 3 then '部分出库' end Status,pr.FromCode,pr.Code,'采购退货单',max(pr.CreateDate) as CreateDate,'' StoreName,pr.WarehouseName,'' ScheduleNo
,sum(prd.ReturnQty)LockedQty,sum(prd.OutStockQty)OutQty,sum(prd.ReturnQty)-sum(prd.OutStockQty) DifferenceQuantity,
max(prd.WarehouseDeliveryTime)WarehouseDeliveryTime,pr.CreateUserName,pr.Remark
 FROM PurchaseReturnOrder pr
join PurchaseReturnOrderDetail prd on pr.Id = prd.PurchaseReturnOrderId
where pr.Status in(1,2,3) and pr.CreateDate<DATEADD(HOUR, -48, GETDATE())
group by pr.Status,pr.FromCode,pr.Code,pr.WarehouseName,pr.CreateUserName,pr.Remark
go

