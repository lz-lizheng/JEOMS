CREATE VIEW [dbo].[V_AliPayCostReport]
AS
SELECT s.Id,s.Code,s.Name,ali.BusinessTypeDesc,CONVERT(varchar(100),ali.CreateDate,23) RecordDate,
(CASE WHEN SUM(ali.InAmount)=0 THEN SUM(ali.OutAmount) ELSE SUM(ali.InAmount) END) Amount,
(CASE WHEN SUM(ali.InAmount)>0 THEN '收入' ELSE '支出' END) AmountType
FROM dbo.Store(NOLOCK) s JOIN dbo.AlipayRecord(NOLOCK) ali ON s.Id=ali.StoreId
WHERE ISNULL(ali.AccountType,0)=6
GROUP BY ali.BusinessTypeDesc,CONVERT(varchar(100),ali.CreateDate,23),s.Id,s.Code,s.NAME
go

