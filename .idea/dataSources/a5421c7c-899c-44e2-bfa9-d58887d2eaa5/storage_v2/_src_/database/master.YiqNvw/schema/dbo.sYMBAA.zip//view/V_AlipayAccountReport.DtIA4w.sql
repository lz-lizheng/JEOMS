

/**
 * 黑蚁  财务报表(已结算销售明细)
*/
CREATE VIEW [dbo].[V_AlipayAccountReport]
AS
SELECT ar.AccountType,ac.IsMatched,ac.Id AccountOrderId,ar.BusinessTypeDesc,s.Code StoreCode,s.Name StoreName,so.Code OrderCode,so.TradeId,ar.InAmount Amount,so.PayAmount OrderAmount,so.PayDate OrderDate
FROM 
dbo.Store(NOLOCK) s
JOIN (
 SELECT StoreId,OrderNo,AccountType,BusinessTypeDesc,SUM(ISNULL(InAmount,0)) InAmount FROM dbo.AlipayRecord(NOLOCK) WHERE AccountType=0 GROUP BY StoreId,OrderNo,AccountType,BusinessTypeDesc
) ar ON s.Id=ar.StoreId 
JOIN dbo.SalesOrder(NOLOCK) so ON so.TradeId=ar.OrderNo
LEFT JOIN dbo.AccountOrderDetail(NOLOCK) acl ON acl.Code=so.Code
LEFT JOIN dbo.AccountOrder(NOLOCK) ac ON ac.Id=acl.AccountOrderId
UNION ALL
SELECT ar.AccountType,ac.IsMatched,ac.Id AccountOrderId,ar.BusinessTypeDesc,s.Code StoreCode,s.Name StoreName,ro.Code OrderCode,ro.TradeId,ar.OutAmount Amount,ro.AmountActual OrderAmount,ro.AuditDate OrderDate
FROM 
dbo.Store(NOLOCK) s
JOIN (
 SELECT StoreId,OrderNo,AccountType,BusinessTypeDesc,SUM(ISNULL(OutAmount,0)) OutAmount FROM dbo.AlipayRecord(NOLOCK) WHERE AccountType=1 GROUP BY StoreId,OrderNo,AccountType,BusinessTypeDesc
) ar ON s.Id=ar.StoreId
JOIN dbo.ReturnOrder(NOLOCK) ro ON ro.TradeId=ar.OrderNo
LEFT JOIN dbo.AccountOrderDetail(NOLOCK) acl ON acl.Code=ro.Code
LEFT JOIN dbo.AccountOrder(NOLOCK) ac ON ac.Id=acl.AccountOrderId
go

