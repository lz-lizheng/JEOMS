

/**
*create date : 2020-3-2
*create modify：疾斗
*remark ：修改物流轨迹视图
*/
CREATE VIEW V_LogisticsTracking  
AS   
SELECT distinct Lt.StoreName,dod.TradeId,do.Code,do.DeliveryDate,ExpressName,ExpressNo,Lt.Status,  
Lt.Mobile, dod.WarehouseName, Consignee, Address, CreateTime, ModifyTime, Note,Lt.StoreId,ExpressId,Content  
From LogisticsTracking Lt(nolock)  
Left Join DispatchOrder do (nolock)on lt.ExpressNo = do.ActualExpressNo AND Lt.DispatchOrderCode=do.Code  
Left Join DispatchOrderDetail dod(nolock) on do.Id = dod.DispatchOrderId
go

