CREATE Procedure [dbo].[P_BU_Generate_OMS_Structure] 
As
Begin   
	Print 'Generate Table Start ************'

    Truncate Table OMS_Sync_Table_Structure

	Insert Into OMS_Sync_Table_Structure
	Select *
	--Into OMS_Sync_Table_Structure
	From V_View_OrderColumns
	Order By TableName, colorder
	Print 'Generate Table End ************'
End;
go

