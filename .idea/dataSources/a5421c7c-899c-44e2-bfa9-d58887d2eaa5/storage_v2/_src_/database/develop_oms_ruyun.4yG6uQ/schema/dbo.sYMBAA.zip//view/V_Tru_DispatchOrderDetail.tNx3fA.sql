
  
CREATE View [dbo].[V_Tru_DispatchOrderDetail] as
Select '18417' as StorerKey, 
	'TRUSL' as Facility, 
	Do.Code as ExternOrderKey, 
	dod.Id as ExternLineNo,
	dod.ProductSkuCode as Sku, 
	dod.Quantity as OpenQty,
	5 as 'Priority', 
	0 as 'Type',
	do.PayTime as OrderDate,
	'TRU' as Consigneekey,
	do.Consignee as C_Company,
	Do.County as C_Address1,
	do.Address as C_Address2,
	null as C_Address3,
	'' as C_Address4,
	do.City as C_City,
	do.Province as C_State,
	do.ZipCode as C_Zip,
	do.Telephone as C_Phone1,
	do.Mobile as C_Phone2,
	dod.TradeId as BuyerPO,
	'TRU E-Commerce' as Company,
	'TRU' as VAT,
	'上海市青浦区' as Address1,
	'上海' as City,
	DO.SuggestExpressCode as ShipperKey,
	do.SuggestExpressName as ShipCompany,
	'E' as Doctype,
	Do.CreateDate
From DispatchOrder do(nolock)
join DispatchOrderDetail dod(nolock) on do.id = dod.DispatchOrderId
Where Do.Status in (0, 2)



go

