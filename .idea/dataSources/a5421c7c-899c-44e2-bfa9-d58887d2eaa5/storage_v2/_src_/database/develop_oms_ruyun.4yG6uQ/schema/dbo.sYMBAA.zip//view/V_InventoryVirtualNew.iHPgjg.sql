CREATE VIEW [dbo].[V_InventoryVirtualNew] AS SELECT
	v.IsLockStock,
	v.WarehouseId,
	v.Quantity,
	v.LockedQuantity,
	v.DispatchedQuantity,
	v.UnDispatchedQuantity,
	v.AllotQuantity,
	v.VipQuantity,
	v.CombQuantity,
	v.Quantity- v.LockedQuantity CanSaleQuantity,
	v.Quantity- v.DispatchedQuantity- v.AllotQuantity - v.VipQuantity - v.CombQuantity CanUseQuantity,
	v.TransitTotalQuantity,
	p.Brand,
	p.Season,
	p.Year,
	p.CategoryId,
	p.CategoryName,
	p.FirstLevelCategoryName,
	p.TwoLevelCategoryName,
	w.Code WarehouseCode,
	w.IsO2O,
	sku.ProductId,
	sku.ProductCode,
	sku.ProductName,
	sku.SkuId,
	sku.Code,
	sku.Description,
	sku.CustomCode,
	sku.SKC,
	sku.Color,
	sku.Size,
	sku.FirstPrice 
FROM
	ProductSku sku
	JOIN Product p ON sku.ProductId= p.ProductId
	JOIN V_InventoryVirtualMapNew v ON sku.SkuId= v.SkuId
	JOIN Warehouse w ON v.warehouseId= w.Id
go

