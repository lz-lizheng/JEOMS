
/**********************
*create date : 2019-05-13
*create by：qiaoni  
*remark ：库存异动报表 增加仓库名称查询列
**/
CREATE VIEW [dbo].[V_ApiInventoryChange] AS 
SELECT   APIT.*,w.Name as WarehouseName, PS.ProductCode
FROM dbo.ApiInventoryChange APIT(NOLOCK)
LEFT JOIN ProductSku PS(NOLOCK) ON APIT.Sku = PS.Code 
left join Warehouse w on w.Code = APIT.Whcode
where ps.Status = 1 and w.IsDisabled=0
go

