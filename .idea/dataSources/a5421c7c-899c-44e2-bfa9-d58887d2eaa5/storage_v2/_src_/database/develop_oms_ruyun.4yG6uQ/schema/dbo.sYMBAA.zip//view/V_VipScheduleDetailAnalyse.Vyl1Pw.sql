


--唯品档期"/>PO号" Fie开始时间""/>款式数量"备货库存"剩余库存"售罄率" F 销售额" F"/>件单价" Ft"/>销量（件）"/>退货数量""/>退货率" F
  
CREATE VIEW [dbo].[V_VipScheduleDetailAnalyse] AS 
SELECT Sale.PoCode ,
	   Sale.ProductCode,
	   Sale.ProductName,
	   Sale.SkuCode,
	   Sale.SkuName,
       Sale.PlanQty ,
       Sale.RemainingInventory ,
       Sale.SaleThroughRate ,
       Sale.SaleQty ,
       Sale.SaleAmount ,
       Rtn.RtnQty,
	   CASE WHEN Sale.SaleQty > 0 THEN Rtn.RtnQty * 1.0 / Sale.SaleQty ELSE 0 END AS ReturnRate,
	   Sale.SaleCost,
	   Rtn.RtnCost,
	   Sale.SupplyPrice,
	   Sale.SupplyPrice * Rtn.RtnQty AS RtnAmount
FROM (
		SELECT  vs.PoCode, 
				vsd.ProductCode,
				vsd.ProductName,
				vsd.SkuCode,
				vsd.SkuName, 
				vsd.SupplyPrice,
				SUM(vsd.PlanQty) AS PlanQty, 
				SUM(vsd.PlanQty - vsd.OutQty) AS RemainingInventory,
				SUM(vsd.OutQty) * 1.0 / SUM(vsd.PlanQty) AS SaleThroughRate,
				SUM(vsd.OutQty) AS SaleQty,
				SUM(Vsd.OutQty * vsd.SupplyPrice) AS SaleAmount,
				SUM(Vsd.OutQty * pd.FirstCost) AS SaleCost
		FROM dbo.VipSchedule vs(NOLOCK)
		LEFT JOIN dbo.VipScheduleDetail vsd(NOLOCK) ON vs.Id = vsd.ScheduleId 
		LEFT JOIN dbo.Product pd(NOLOCK) ON vsd.ProductId = pd.ProductId
		GROUP BY vs.PoCode, vsd.ProductCode, vsd.ProductName, vsd.SkuCode, vsd.SkuName, vsd.SupplyPrice
		HAVING SUM(vsd.PlanQty) > 0
	) Sale
LEFT JOIN 
	(	
		SELECT vrod.PoCode, vrod.skucode, SUM(vrod.ReturnQty) AS RtnQty, SUM(vrod.ReturnQty * pd.FirstCost) AS RtnCost
		FROM dbo.VipReturnOrder vro(NOLOCK)
		LEFT JOIN dbo.VipReturnOrderDetail vrod(NOLOCK) ON vro.Id = vrod.ReturnOrderId
		LEFT JOIN dbo.Product pd(NOLOCK) ON vrod.ProductId = pd.ProductId
		GROUP BY vrod.PoCode, vrod.skucode
	) Rtn ON Rtn.PoCode = Sale.PoCode AND rtn.SkuCode = Sale.SkuCode



go

