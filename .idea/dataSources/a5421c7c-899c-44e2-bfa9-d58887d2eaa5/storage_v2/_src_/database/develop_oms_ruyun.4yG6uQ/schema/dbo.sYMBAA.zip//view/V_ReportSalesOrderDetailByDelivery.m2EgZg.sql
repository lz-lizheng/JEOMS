

/**

*create date : 2020-02-07

*create modify：拓斗

*remark ：订单明细统计发货视图

*/

CREATE VIEW [dbo].[V_ReportSalesOrderDetailByDelivery] AS SELECT

SOD.DetailId AS DetailId--订单明细ID

,DO.DeliveryDate AS DeliveryDate --发货日期

,DO.StoreId AS OStoreId

,dod.TradeId as SalesOrderTradeId

,DO.ActualExpressId as ExpressId

,dod.ProductCode

,dod.ProductSkuCode as SkuCode

,DO.WarehouseId

,dod.SalesOrderCode

,DO.ActualExpressNo

FROM dbo.SalesOrder(NOLOCK) SO

JOIN dbo.SalesOrderDetail(NOLOCK) SOD on SO.OrderId = SOD.SalesOrderId

LEFT JOIN dbo.DispatchOrderDetail(NOLOCK) dod ON dod.SalesOrderDetailId = sod.DetailId AND dod.Status  <> 1

LEFT JOIN dbo.DispatchOrder(NOLOCK) DO ON dod.DispatchOrderId=DO.Id AND DO.Status  <> 3

WHERE SOD.IsAbnormal = 0 AND SO.TransType  <> 1

go

