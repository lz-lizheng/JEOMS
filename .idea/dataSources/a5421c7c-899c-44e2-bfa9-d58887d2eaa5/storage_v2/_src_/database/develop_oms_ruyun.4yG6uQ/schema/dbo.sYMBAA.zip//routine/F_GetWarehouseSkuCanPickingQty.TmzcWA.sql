
CREATE FUNCTION [dbo].[F_GetWarehouseSkuCanPickingQty]
(
	@SkuId VARCHAR(50), --规格ID
	@WarehouseId VARCHAR(50) --实体仓ID
)
RETURNS INT
AS
BEGIN

	DECLARE @V_CanPickingQty INT

	SELECT @V_CanPickingQty = SUM(TotalQty)
	FROM (
		SELECT SUM(Quantity) AS TotalQty
		FROM dbo.InventoryVirtual
		WHERE SkuId = @SkuId AND WarehouseId IN (SELECT Id FROM dbo.Warehouse WHERE ParentId = @WarehouseId)
		UNION ALL
		SELECT SUM(Quantity) AS IocQty
		FROM dbo.InventoryOccupation
		WHERE SkuId = @SkuId
		AND WarehouseId IN (SELECT Id FROM dbo.Warehouse WHERE ParentId = @WarehouseId)
		AND (Type IN (3, 4, 5,6) OR IsDispatched = 1)
	) A;

	RETURN @V_CanPickingQty;
END



go

