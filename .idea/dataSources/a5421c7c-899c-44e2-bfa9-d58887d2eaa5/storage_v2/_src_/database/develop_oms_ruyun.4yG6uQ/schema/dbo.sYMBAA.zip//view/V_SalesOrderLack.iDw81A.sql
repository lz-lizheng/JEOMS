
/**********************
*create by：tuodou
-remark ：缺货商品统计(总的缺货量)
 180416： 增加ProductName
***********************/
CREATE View [dbo].[V_SalesOrderLack] As
Select ps.SkuId, ps.ProductCode,ps.ProductName, ps.Code as SkuCode, ps.Description as SkuDescription, orig.NeedQty, Inv.InvQty, 
 pd.Brand, pd.BrandCode,
 Case when Orig.NeedQty - isnull(inv.invqty, 0) > 0 Then Orig.NeedQty - isnull(inv.invqty, 0) Else 0 End as LackQty, 
 Case when Orig.NeedQty - isnull(inv.invqty, 0) > 0 Then 'Warning' End as Warning
From (
 Select SkuId, Sum(Quantity) NeedQty
 From InventoryOccupation(nolock)
 where IsDispatched = 0
 and TYPE = 1
 Group by skuid
 ) Orig
Left JOin ( 
 Select SkuId, Sum(iv.CanUseQuantity) InvQty 
 From V_InventoryVirtual iv(nolock)
 Where WarehouseId in (
Select WarehouseId From DispatchTemplateWarehouse dw, Warehouse wh
where dw.IsDisabled = 0 and dw.WarehouseId = wh.Id and wh.WarehouseType in (2, 3)
UNion ALL
Select whc.Id From DispatchTemplateWarehouse dw, Warehouse wh, Warehouse whc
where dw.IsDisabled = 0 and dw.WarehouseId = wh.Id and wh.Id = whc.ParentId and wh.WarehouseType in (4)
) 
 Group by SkuId
 ) Inv on Orig.SkuId = Inv.SkuId
Left JOin ( 
 Select SkuId, Sum(iv.CanUseQuantity) InvQty
 From V_InventoryVirtual iv(nolock) 
 Group by SkuId
 ) InvTotal on Orig.SkuId = InvTotal.SkuId
Left JOin ProductSku ps(nolock) on Orig.SkuId = ps.SkuId
left join Product pd(nolock) on ps.ProductId = pd.ProductId



go

