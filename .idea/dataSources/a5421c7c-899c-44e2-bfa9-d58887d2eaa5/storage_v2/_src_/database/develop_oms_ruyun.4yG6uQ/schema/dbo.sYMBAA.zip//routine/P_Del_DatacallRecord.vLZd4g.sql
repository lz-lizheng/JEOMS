
CREATE Proc P_Del_DatacallRecord
(
  @V_OrderNo nvarchar(100)
)
as
begin  

	Declare @V_RowCnt int 
    update DatacallRecord Set DataCode = DataCode + '_Del' Where DataCode = @V_OrderNo  and Status = 1

	
	Set @V_RowCnt = @@ROWCOUNT
	if @V_RowCnt > 0
		Begin
			Select 'Update ' + @V_Orderno  +  ' Success.'
		End
	Else 
		Begin
			Select 'Update ' + @V_Orderno  +  ' Fail, No Data Found.' as Result
		End

End;
go

