

/**********************
*create date : 2019-06-12
*create modify：拓斗
*remark ：
***********************/ 
CREATE VIEW [dbo].[V_purchasedatereport] AS   
select a1.*,b.ArrivalDate as RequestDeliveryDate  from (select c.CreateDate as BeginDate,a.CreateDate ,a.code as purchasecode , a.warehousename ,a.PurchaseTypeName as Xdtype,a.SupplierName ,b.Productcode ,d.FactoryCode ,b.SkuCode,e.CostPrice,  
e.FirstPrice ,e.Color ,pcy.Name as Oname,pcs.Name as Twoname,pce.Name as Threename,case SUBSTRING(b.ProductCode,2,1) when 'M' then '男' when 'L' then '女' else '不分' end Sex ,  
b.PurchaseQty,b.PurchaseQty*e.CostPrice  AS AMOUNT ,a.ContractNo,case when a.InStatus=0 then '未入库' when a.InStatus=1 then '部分入库'  
else '全部入库' end  InStatus,e.CustomCode,d.Attribute4,v.OneCatName,v.TwoCatName,v.ThreeCatName,a.Remark as RENOTE,WarehouseID,b.InStockQty,a.VirtualWarehouseId,a.VirtualWarehouseName,
b.CurrentPrice,b.CurrentPrice*b.PurchaseQty AS PurchaseAmount
from PurchaseOrder a   
left join PurchaseOrderDetail b on a.id=b.PurchaseOrderId  
left join WholesalePurchaseOrder c on a.ContractNo=c.code  
left join product d on b.productcode=d.code  
left join productsku  e on b.skucode=e.code  
left join ProductCategory pcs on d.CategoryId=pcs.Id  
left join ProductCategory pce on pcs.ParentId=pce.Id  
left join ProductCategory pcy on pcy.Id=pce.ParentId  
left join V_ProductCategory v on d.CategoryId=v.ThreeCatId ) a1   
left join (select b.ArrivalDate,code,SkuCode  
from WholesalePurchaseOrder a left join WholesalePurchaseOrderDetail b on a.id=b.WholesalePurchaseOrderId) b on a1.ContractNo=b.Code and  a1.SkuCode=b.SkuCode

go

