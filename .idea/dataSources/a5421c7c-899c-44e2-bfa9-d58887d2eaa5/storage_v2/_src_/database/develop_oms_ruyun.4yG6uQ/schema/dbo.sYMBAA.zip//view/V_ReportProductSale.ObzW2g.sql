

/**********************
*create date : 2017-06-13
*create by：qiaoni 
*remark ：商品销售统计去掉作废明细
*Remark : ModifyDate 2018-05-08 增加商品分类
***********************/  
CREATE VIEW [dbo].[V_ReportProductSale] AS 
SELECT '销售订单' AS DateType,
	   CAST(so.CreateDate AS DATE) AS CreateDate,
	   CAST(so.PayDate AS DATE) AS PayDate, 
	   CAST(so.DeliveryDate AS DATE) AS DeliveryDate, 
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.SkuCode,
	   sod.SkuName,
	   sod.IsDeleted,
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color, 
	   pd.FirstLevelCategoryId OneCatId, 
	   pd.FirstLevelCategoryName OneCatName,
	   pd.TwoLevelCategoryId TwoCatId, 
	   pd.TwoLevelCategoryName TwoCatName, 
	   pd.CategoryId ThreeCatId,
	   pd.CategoryName ThreeCatName,
	   SUM(sod.Quantity) AS Quantity,
	   SUM(sod.AmountActual) AS AmountActual,
	   SUM((sod.Quantity * sod.FirstCost)) AS FirstCost  
FROM dbo.SalesOrder(NOLOCK) so
LEFT JOIN dbo.SalesOrderDetail(NOLOCK) sod ON so.OrderId = sod.SalesOrderId
LEFT JOIN Product(NOLOCK) pd ON sod.ProductId = pd.ProductId
LEFT JOIN dbo.ProductSku(NOLOCK) ps ON sod.ProductSkuId = ps.SkuId
WHERE sod.IsDeleted = 0
and ps.SkuId is not null
GROUP BY CAST(so.CreateDate AS DATE),
	   CAST(so.PayDate AS DATE), 
	   CAST(so.DeliveryDate AS DATE), 
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.SkuCode,
	   sod.SkuName,
	   sod.IsDeleted,
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color,
	   pd.FirstLevelCategoryId,
	   pd.FirstLevelCategoryName,
	   pd.TwoLevelCategoryId,
	   pd.TwoLevelCategoryName,
	   pd.CategoryId,
	   pd.CategoryName


go

