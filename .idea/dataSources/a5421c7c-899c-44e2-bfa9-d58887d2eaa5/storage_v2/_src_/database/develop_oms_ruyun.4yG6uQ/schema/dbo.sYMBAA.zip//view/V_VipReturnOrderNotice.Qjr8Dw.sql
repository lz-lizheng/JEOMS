
/**********************
*create date: 2016-07-11
*create by：拓斗
*remark ：唯品退货通知单报表加次品入库数量
***********************/
CREATE VIEW [dbo].[V_VipReturnOrderNotice] AS 
SELECT VRO.VipReturnOrderCode,
VRON.ReturnOrderCode, 
VRON.VipReturnOrderNoticeCode,
VRO.InWarehouseId,
VRO.InWarehouseName,
VROND.ProductCode,
VROND.ProductName,
VROND.SkuCode,
VROND.SkuName,
VROND.NoticeQty,
VROND.InQty,
VROND.WarehousingTime,
VRON.CreateDate,
VROND.DefectiveQuantity
FROM dbo.VipReturnOrderNotice VRON(NOLOCK)
LEFT JOIN dbo.VipReturnOrderNoticeDetail VROND(NOLOCK) ON VROND.ReturnOrderNoticeId = VRON.Id
LEFT JOIN dbo.VipReturnOrder VRO(NOLOCK) ON VRO.ReturnOrderCode = VRON.ReturnOrderCode
go

exec sp_addextendedproperty 'MS_Description', '唯品退供单号', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'VipReturnOrderCode'
go

exec sp_addextendedproperty 'MS_Description', '退供单号', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ReturnOrderCode'
go

exec sp_addextendedproperty 'MS_Description', '退货通知单号', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'VipReturnOrderNoticeCode'
go

exec sp_addextendedproperty 'MS_Description', '入库仓库ID', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InWarehouseId'
go

exec sp_addextendedproperty 'MS_Description', '入库仓库名称', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InWarehouseName'
go

exec sp_addextendedproperty 'MS_Description', '商品编码', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ProductCode'
go

exec sp_addextendedproperty 'MS_Description', '商品名称', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ProductName'
go

exec sp_addextendedproperty 'MS_Description', '规格编码', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'SkuCode'
go

exec sp_addextendedproperty 'MS_Description', '规格名称', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'SkuName'
go

exec sp_addextendedproperty 'MS_Description', '通知数量', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'NoticeQty'
go

exec sp_addextendedproperty 'MS_Description', '入库数量', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InQty'
go

exec sp_addextendedproperty 'MS_Description', '入库时间', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'WarehousingTime'
go

