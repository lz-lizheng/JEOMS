/**********************
*create date : 2018-07-05
*create by：qiaoni 
*remark　配货单订单ID清单
***********************/ 
Create View V_DispatchOrderDetailOrderId As 
Select Distinct DispatchOrderId, SalesOrderId
From DispatchOrderDetail
Where Status in (0 ,2)

go

