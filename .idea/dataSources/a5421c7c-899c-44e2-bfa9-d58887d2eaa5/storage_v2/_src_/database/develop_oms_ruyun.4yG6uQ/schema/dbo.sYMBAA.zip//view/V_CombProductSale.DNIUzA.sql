/**
  -- QiaoNi 20180227
  -- 套装销售统计  支付时间、店铺名称、套装编码、套装名称、分类、销量、销售额
**/
CREATE View [dbo].[V_CombProductSale] as 
Select so.PayDate, sod.DeliveryDate, so.StoreId, so.Code, so.StoreName, ps.code as CombProductCode, ps.Description, sod.CombProductQuantity, Sum(sod.AmountActual) as AmountActual
From SalesOrder so(nolock)
Join SalesOrderDetail sod(nolock) on so.OrderId = sod.SalesOrderId
left join DispatchOrderDetail dod(nolock) on sod.DetailId = dod.SalesOrderDetailId
left join DispatchOrder do(nolock) on dod.DispatchOrderId = do.Id
join ProductSku ps(nolock) on sod.CombProductId = ps.SkuId
Where sod.IsCombproduct = 1
and so.IsObsolete = 0
and sod.IsDeleted = 0
Group by so.PayDate, sod.DeliveryDate, so.StoreId, so.Code, so.StoreName, ps.code, ps.Description, sod.CombProductQuantity



go

