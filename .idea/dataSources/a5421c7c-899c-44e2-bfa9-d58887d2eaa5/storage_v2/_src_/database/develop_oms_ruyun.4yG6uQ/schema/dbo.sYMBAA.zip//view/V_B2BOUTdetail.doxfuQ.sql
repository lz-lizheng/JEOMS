
/**********************
*create date : 2019-06-13
*create modify：库洛
*remark ：B2B报表出库仓库ID
***********************/ 
creATE VIEW [dbo].[V_B2BOUTdetail] AS 
 select D.*,c.Price from (
 select  a.Remark,a.PlanCode,a.ScheduleNo,a.code NoticeCode,a.OutWarehouseId,a.OutWarehouseName,a.InWarehouseName,a.StoreName,a.CreateDate,b.ProductCode,b.ProductSkuCode,b.ProductName,b.ProductSkuName,
    b.NoticeQty,b.OutQty,b.WarehouseDeliveryTime,a.Status,a.ConsigneeAddress,a.ExpressName,storeid,
	a.ExpressNo,a.weight,b.NoticeQty-b.OutQty as DifferenceQty 
	from     B2BAllocationOut(nolock) a 
	left join B2BAllocationOutDetail(nolock) b on a.code=b.OutCode)D
		left join (	select code,ProductSkuCode,Price
	 from B2BAllocationPlan a left join B2BAllocationPlanDetail b on a.code=b.PlanCode
	) c on  D.PlanCode=c.code and D.ProductSkuCode=c.ProductSkuCode
go

