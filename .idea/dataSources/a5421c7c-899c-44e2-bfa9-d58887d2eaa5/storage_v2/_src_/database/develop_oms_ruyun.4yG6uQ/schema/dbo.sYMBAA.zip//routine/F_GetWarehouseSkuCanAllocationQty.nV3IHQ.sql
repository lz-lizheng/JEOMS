
 

CREATE FUNCTION [dbo].[F_GetWarehouseSkuCanAllocationQty]
(
	@P_WarehouseID	UNIQUEIDENTIFIER,	 
	@P_SkuId		UNIQUEIDENTIFIER	 
)
RETURNS INT
AS
BEGIN
	DECLARE @V_Rlt INT
	  
	SELECT @V_Rlt = SUM(AC.TotalQuantity)
	FROM ( 
		SELECT SUM(IV.Quantity) AS TotalQuantity
		FROM dbo.InventoryVirtual IV(NOLOCK), dbo.Warehouse WH(NOLOCK)
		WHERE IV.WarehouseId = WH.Id
		AND WH.WarehouseType = 2
		AND WH.ParentId = @P_WarehouseID
		AND IV.SkuId = @P_SkuId 
		AND IV.IsLockStock = 0 
		UNION
		SELECT SUM(IOCC.Quantity) * -1 AS DispatchLocked
		FROM dbo.InventoryOccupation IOCC(NOLOCK), dbo.Warehouse WH(NOLOCK)
		WHERE IOCC.WarehouseId = WH.Id
		AND Wh.ParentId = @P_WarehouseID
		AND IOCC.SkuId = @P_SkuId
		AND IOCC.Type IN (1, 2)
		AND IOCC.IsDispatched = 1  
		UNION
		SELECT SUM(IOCC.Quantity) * -1 AS AllocationLocked
		FROM dbo.InventoryOccupation IOCC(NOLOCK), dbo.Warehouse WH(NOLOCK)
		WHERE IOCC.WarehouseId = WH.Id
		AND Wh.ParentId = @P_WarehouseID
		AND IOCC.SkuId = @P_SkuId
		AND IOCC.Type IN (3, 4) 
		UNION
		SELECT SUM(IOCC.Quantity) * -1 AS UnDispatchLocked
		FROM dbo.InventoryOccupation IOCC(NOLOCK)
		WHERE iocc.SkuId = @P_SkuId
		AND iocc.IsDispatched = 0
		AND iocc.Type IN (1, 2)
		AND iocc.WarehouseId IN (SELECT DTW.WarehouseId
								FROM dbo.DispatchTemplate DT(NOLOCK), dbo.DispatchTemplateWarehouse DTW(NOLOCK), dbo.StoreSetting ss(NOLOCK), dbo.Warehouse Wh(NOLOCK)
								WHERE dt.Id = dtw.TemplateId  
								AND wh.ParentId = @P_WarehouseID
								AND dt.Id = ss.DispatchTemplateId
								AND DTW.WarehouseId = wh.Id
								AND dt.IsDisabled = 0)  
		) AC
		 
	IF ISNULL(@V_Rlt, 0) < 0 
		BEGIN
			SET @V_Rlt = 0;
		END
		
	RETURN ISNULL(@V_Rlt, 0); 
END
go

