
CREATE VIEW [dbo].[V_CustomReportPurchaseOrderTransit] AS 
SELECT DISTINCT PO.Code,
PO.WarehouseId,
PO.WarehouseName,
PO.PurchaseDate,
PO.CreateDate,
PO.RequestDeliveryDate,
PO.SupplierCode,
po.SupplierName, 
PO.Status,
POD.ProductCode,
POD.ProductName,
POD.SkuCode, 
POD.SkuName,
POD.Color, 
POD.Size,
POD.PurchaseQty, 
POD.CurrentPrice AS OriginalPrice,
POD.NoticeQty, 
P.StockInQty,
P.DefectiveQuantity,
P.WarehouseStorageTime AS WarehousingTime,
pd.Year,
pd.Season,
pd.Brand,
PO.Remark,
pd.CategoryName,
PO.ContractNo,
SSP.SupplierSettlementType,
PO.PurchasePersonName,
PO.SupplierComanyName,
(CASE WHEN POD.PurchaseQty-POD.InStockQty<0 THEN 0 ELSE POD.PurchaseQty-POD.InStockQty END) AS TransitQty,
PO.VirtualWarehouseId,
PO.VirtualWarehouseName
FROM PurchaseOrder PO(NOLOCK)
LEFT JOIN PurchaseOrderDetail POD(NOLOCK) ON PO.Id = pod.PurchaseOrderId
LEFT JOIN (
SELECT SUM(PNOID.StockInQty) StockInQty,SUM(PNOID.DefectiveQuantity) DefectiveQuantity,PNOD.SkuId,PNO.PurchaseOrderId,MAX(PNOID.WarehouseStorageTime) WarehouseStorageTime FROM PurchaseNoticeOrder PNO(NOLOCK)
LEFT JOIN PurchaseNoticeOrderdetail PNOD(NOLOCK) ON PNO.Id = PNOD.PurchaseNoticeOrderId
LEFT JOIN PurchaseNoticeOrderIndetail PNOID(NOLOCK) ON PNOD.DetailId = PNOID.DetailId
GROUP BY PNOD.SkuId,PNO.PurchaseOrderId
) P ON po.Id = P.PurchaseOrderId
LEFT JOIN dbo.Product PD(NOLOCK) ON POD.ProductId = pd.ProductId
LEFT JOIN dbo.Supplier SSP(NOLOCK) ON po.SupplierCode = ssp.Code

go

