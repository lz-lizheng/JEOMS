



 /**********************
*create date : 2016-09-05
*create by：qiaoni 
*remark ：实体调拨可调计算逻辑
	Modify: 2018-06-06 按虚拟仓库的可用 可销计划可调量
***********************/  
CREATE FUNCTION [dbo].[F_GetVirtualWarehouseSkuCanAllocationQty]
(
	@P_WarehouseID	UNIQUEIDENTIFIER,	--共享/独立仓库
	@P_SkuId		UNIQUEIDENTIFIER,	--SKU ID 
	@P_CalcOthersVirtualWarehouse nvarchar(10) -- 按可用 、 可销来锁定库存  'Y', 'N'
)
RETURNS INT
AS
BEGIN
	DECLARE @V_Rlt INT
	  
	DECLARE @V_EntityWarehouse UNIQUEIDENTIFIER 
	SELECT @V_EntityWarehouse = ParentId FROM dbo.Warehouse WHERE id = @P_WarehouseID
	  
    Select @V_Rlt = Sum(Case @P_CalcOthersVirtualWarehouse When 'Y' Then CanUseQuantity Else CanSaleQuantity End)
	From V_InventoryVirtual
	Where WarehouseId = @P_WarehouseID
	And SkuId = @P_SkuId
	And IsLockStock = 0;

	-- 返回可销
	RETURN ISNULL(@V_Rlt, 0);
END
 go

