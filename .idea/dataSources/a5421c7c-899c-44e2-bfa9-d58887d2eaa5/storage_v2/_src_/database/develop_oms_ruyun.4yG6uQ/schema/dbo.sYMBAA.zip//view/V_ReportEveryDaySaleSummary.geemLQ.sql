



-- 每日销售统计
CREATE VIEW [dbo].[V_ReportEveryDaySaleSummary] AS  
SELECT a.CreateDate AS CreateDate,	--查询日期， 根据业务口径调整
	a.StoreName AS StoreName,			--店铺名称
	A.OrderType AS OrderType,			--订单类型
	a.AmountActual AS AmountActual,		--金额
	a.Quantity AS Quantity,				--商品数量
	a.OrderQty AS OrderQty, 			--订单数量 
	A.StoreID
FROM 	
	(
	--每日店铺订单汇总数据
	SELECT CAST(SO.CreateDate AS DATE) AS CreateDate, SO.StoreName, '订单' AS OrderType, SUM(SOD.AmountActual) AS AmountActual, SUM(sod.Quantity) AS Quantity, COUNT( DISTINCT so.OrderId) AS OrderQty, SUM(CASE so.ExpressFee WHEN 0 THEN 1 ELSE 0 END) AS FreeExpressOrderQty, so.StoreId
	FROM SalesOrder SO WITH(NOLOCK)
	LEFT JOIN SalesOrderDetail SOD WITH(NOLOCK) ON SO.OrderId = SOD.SalesOrderId
	WHERE SOD.IsDeleted=0 
	AND SOD.IsAbnormal = 0 
	AND So.TransType<>1
	GROUP BY CAST(SO.CreateDate AS DATE), SO.StoreName,SO.StoreId
	UNION ALL
	--每日店铺订单取消明细汇总数据
	SELECT CAST(SOD.DeletedDate AS DATE) AS CancelDate, SO.StoreName, '取消订单' AS OrderType, SUM(SOD.AmountActual) AS CancelAmountActual, SUM(sod.Quantity) AS CancelQuantity, COUNT(DISTINCT so.OrderID) AS OrderQty, '0' AS FreeExpressOrderQty, so.StoreId
	FROM SalesOrder SO WITH(NOLOCK)
	LEFT JOIN SalesOrderDetail SOD WITH(NOLOCK) ON SO.OrderId = SOD.SalesOrderId
	WHERE SOD.DeletedDate IS NOT NULL
	GROUP BY CAST(SOD.DeletedDate AS DATE), SO.StoreName, so.StoreId
	UNION ALL
	--每日店铺退货明细汇总数据
	SELECT CAST(RO.ApproveDate AS DATE) AS ApproveDate, RO.StoreName, '退货订单' AS OrderType, SUM(ROD.ActualAmount) AS RtnActualAmount, SUM(ROD.Quantity) AS RtnQuantity, COUNT(DISTINCT RO.Id) AS OrderQty, '0' AS FreeExpressOrderQty, RO.StoreId
	FROM ReturnOrder RO WITH(NOLOCK)
	LEFT JOIN dbo.ReturnOrderDetail ROD WITH(NOLOCK) ON RO.Id = ROD.ReturnOrderId
	WHERE RO.ApproveDate IS NOT NULL
	GROUP BY CAST(RO.ApproveDate AS DATE), RO.StoreName, ro.StoreId
	) A



go

