CREATE VIEW [dbo].[V_InventoryVirtualMapNew] AS SELECT
	isnull( iv.SkuId, ic.SkuId ) SkuId,
	isnull( iv.WarehouseId, ic.WarehouseId ) WarehouseId,
	isnull( iv.Quantity, 0 ) Quantity,
	isnull( iv.TransitTotalQuantity, 0 ) TransitTotalQuantity,
	isnull(iv.IsLockStock,0) IsLockStock,
	SUM (
	isnull( ic.Quantity, 0 )) LockedQuantity,
	SUM ( CASE WHEN ic.IsDispatched = 1 THEN isnull( ic.Quantity, 0 ) ELSE 0 END ) AS DispatchedQuantity,--已配占用数
	SUM (
	CASE
			
			WHEN ic.IsDispatched = 0 
			AND ( ic.Type= 1 OR ic.Type= 2 ) THEN
				isnull( ic.Quantity , 0 ) ELSE 0 
			END 
			) AS UnDispatchedQuantity,--未配订单占用数
			SUM ( CASE WHEN ic.Type IN ( 3, 5 ) THEN isnull( ic.Quantity, 0 ) ELSE 0 END ) AS AllotQuantity,--调拨占用数
			SUM ( CASE WHEN ic.Type= 4 THEN isnull( ic.Quantity, 0 ) ELSE 0 END ) AS VipQuantity,--调拨占用数
			SUM ( CASE WHEN ic.Type= 6 THEN isnull( ic.Quantity, 0 ) ELSE 0 END ) AS CombQuantity --套装占用
			
		FROM 
			InventoryVirtual iv
			JOIN InventoryOccupation ic ON iv.SkuId= ic.SkuId 
			AND iv.WarehouseId= ic.WarehouseId 
		GROUP BY
			iv.SkuId,
			ic.SkuId,
			iv.WarehouseId,
			ic.WarehouseId,
			iv.Quantity,
		iv.TransitTotalQuantity,
	iv.IsLockStock
go

