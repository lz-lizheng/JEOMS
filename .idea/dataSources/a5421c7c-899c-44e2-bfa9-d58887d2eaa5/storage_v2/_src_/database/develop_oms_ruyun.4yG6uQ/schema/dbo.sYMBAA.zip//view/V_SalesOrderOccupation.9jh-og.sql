/**********************  
*create date : 2018-11-19  
*create by：qiaoni   
*remark ：占用视图调整 －增加售后换货占用  
***********************/     
CREATE view V_SalesOrderOccupation as   
SELECT c.Code,c.TradeId,b.ProductName,b.SkuName,a.SkuId,a.WarehouseId,a.Quantity,a.IsDispatched,a.Type FROM dbo.InventoryOccupation  a  
JOIN dbo.SalesOrderDetail b ON a.DetailId=b.DetailId  
JOIN dbo.SalesOrder c ON b.SalesOrderId=c.OrderId  
UNION ALL  
SELECT r.Code,r.TradeId,rl.ProductName,rl.SkuName,a.SkuId,a.WarehouseId,rl.Quantity,0 IsDispatched,a.Type FROM dbo.InventoryOccupation  a  
JOIN dbo.ReturnOrderOutDetail rl ON a.DetailId=rl.Id  
JOIN dbo.ReturnOrder r ON rl.ReturnOrderId=r.Id  
UNION ALL  
SELECT r.DisputeId ,r.TradeId,rl.ProductName,rl.SkuName,a.SkuId,a.WarehouseId,rl.Quantity,0 IsDispatched,a.Type FROM dbo.InventoryOccupation  a  
JOIN dbo.ExchangeOrderDetail rl ON a.DetailId=rl.Id  
JOIN dbo.ExchangeOrder r ON rl.ExchangeId=r.Id
go

