CREATE Procedure [P_Users_Disabled] as
Begin
    --检测长时间未登录的用户（90天）自动禁用
    declare users_cursor cursor for
        select id, UserName from users where datediff(day, LastLoginTime, sysdatetime()) > 90 and IsDisabled = 0
    open users_cursor
    declare @id uniqueidentifier
    declare @UserName nvarchar(150)

    fetch next from users_cursor into @id,@UserName
    while @@fetch_status = 0
        begin
            print (@UserName)
            update users set IsDisabled = 1 where id = @id
            insert into SystemLog(id,UserName,Note,ObjectId,ModuleType,CreateDate) values (newId(),'系统账户','超过90天未登录自动禁用',@id,105,sysdatetime());
            fetch next from users_cursor into @id,@UserName
        end
     Close users_cursor
    deallocate users_cursor
End;
go

