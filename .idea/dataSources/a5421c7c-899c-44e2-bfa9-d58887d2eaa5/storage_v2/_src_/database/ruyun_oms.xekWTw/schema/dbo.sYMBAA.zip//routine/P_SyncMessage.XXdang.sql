CREATE PROCEDURE [dbo].[P_SyncMessage](@bussinessIds VARCHAR(MAX),@orderIds VARCHAR(MAX))
AS
  BEGIN
    UPDATE so
    SET so.MessageString = STUFF((SELECT ',' + LTRIM(RTRIM(MessageString))
                                  FROM OrderMessage(nolock)
                                  WHERE OrderId = so.OrderId
                                  ORDER BY CreateDate DESC
                                  FOR XML PATH ('')), 1, 1, '') FROM SalesOrder(nolock) so
    WHERE so.OrderId IN (SELECT * FROM dbo.F_SplitString(@orderIds, ','));
                         
    UPDATE ro
    SET ro.Message = STUFF((SELECT ',' + LTRIM(RTRIM(MessageString))
                            FROM OrderMessage(nolock)
                            WHERE OrderId = ro.SalesOrderId OR BusinessId = ro.Id
                            ORDER BY CreateDate DESC
                            FOR XML PATH ('')), 1, 1, '') FROM ReturnOrder(nolock) ro
    WHERE ro.id IN 
    (
     Select id From ReturnOrder(nolock) where SalesOrderId in (Select * From dbo.F_SplitString(@orderIds, ','))
     union 
     Select id From ReturnOrder(nolock) where Id IN (SELECT * FROM dbo.F_SplitString(@bussinessIds, ','))
     );
     
   
    UPDATE rfo
    SET rfo.MessageString = STUFF((SELECT ',' + LTRIM(RTRIM(MessageString))
                                   FROM OrderMessage(nolock)
                                   WHERE OrderId = rfo.SalesOrderId OR BusinessId = rfo.Id
                                   ORDER BY CreateDate DESC
                                   FOR XML PATH ('')), 1, 1, '') FROM RefundOrder(nolock) rfo
    WHERE rfo.Id IN 
    (
     Select id From RefundOrder(nolock) where SalesOrderId in (Select * From dbo.F_SplitString(@orderIds, ','))
     union 
     Select id From RefundOrder(nolock) where Id IN (SELECT * FROM dbo.F_SplitString(@bussinessIds, ','))
     );
  END
go

