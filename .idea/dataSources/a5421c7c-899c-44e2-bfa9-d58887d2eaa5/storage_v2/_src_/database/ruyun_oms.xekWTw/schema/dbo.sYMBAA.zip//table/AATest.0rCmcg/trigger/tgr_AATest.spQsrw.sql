CREATE trigger tgr_AATest

on AATest

    for insert,update

as

    declare @id int, @col1 nvarchar(128), @col2 nvarchar(128), @col3 nvarchar(128);

    select @id=id,@col1 = name, @col2 = createDate, @col3 = updateTime from inserted;

    

    if @col1=N'luqi111'

		update AATest set updateTime = GETDATE() where id=@id

go

