
CREATE PROCEDURE [dbo].[P_PurchaseOrderSuggest]
(
	@P_BeginDate DATETIME,
	@P_EndDate DATETIME,
	@P_ProductCode NVARCHAR(max), 
	@P_ReturnType	NVARCHAR(10) -- M:按月统计, D:按日统计
)
AS
BEGIN 

	Select *  From [develop-oms].dbo.Temp01 
	Update [develop-oms].dbo.Temp01 Set CanSaleDays = IVQuantity / SaleQuantity 

	 

	return;
	DECLARE @V_Days INT 
	SELECT @V_Days = DATEDIFF(DAY, @P_BeginDate, @P_EndDate) + 1;

	-- 当前待计算的商品列表
	-- SELECT ColData AS ProductCode INTO #Products FROM [dbo].[F_SplitString](@P_ProductCode, ',')
	SELECT Code as ProductCode INTO #Products FROM Product

	-- 当前待计算的商品，库存信息
	SELECT pc.OneCatName AS OneCategoryName, PC.twoCatName AS TwoCategoryName, PC.ThreeCatName AS ThreeCategoryName, 
		   ps.SkuId, pd.Code AS Code, ps.Code AS SkuCode, pd.ReturnPeriod, IV.IVQuantity, ps.Color, ps.Size,
		   pd.SupplierId, pd.SupplierName, pd.NewOnlineDate, ISNULL(pd.CeilingDay, 0) AS CeilingDay, ISNULL(pd.LowerDay, 0) AS LowerDay,
		   pd.PurchasePrice, ps.Note AS SkuRemark, pd.Year AS ProductYear
	INTO #TMPProd
	FROM #Products PP
	LEFT JOIN dbo.Product pd ON PP.ProductCode = pd.Code
	LEFT JOIN dbo.ProductSku ps ON pd.ProductId = ps.ProductId
	LEFT JOIN v_ProductCategory PC ON pd.CategoryId = pc.ThreeCatId
	LEFT JOIN (SELECT SkuId, SUM(CanSaleQuantity) AS IVQuantity FROM dbo.V_InventoryVirtual GROUP BY SkuId) IV ON IV.SkuId = PS.SkuId
	WHERE ps.SkuId IS NOT NULL
	 
	-- 订单
	SELECT CONVERT(VARCHAR(10), so.PayDate, 20) AS DateKey, sod.ProductSkuId, SUM(sod.Quantity) AS SaleQuantity, 
		CASE WHEN DATEDIFF(DAY, NewOnlineDate, @P_EndDate) + 1 > @V_Days THEN @V_Days 
			 WHEN DATEDIFF(DAY, NewOnlineDate, @P_EndDate) + 1 < 0 THEN 1 
			 ELSE DATEDIFF(DAY, NewOnlineDate, @P_EndDate) + 1 END AS SaleDays -- pd.NewOnlineDate
	INTO #TmpSale
	FROM dbo.SalesOrder so(NOLOCK) 
	LEFT JOIN dbo.SalesOrderDetail sod(NOLOCK) ON so.OrderId = sod.SalesOrderId 
	LEFT JOIN #TMPProd PD ON sod.ProductSkuId = pd.SkuId
	WHERE so.PayDate BETWEEN @P_BeginDate AND @P_EndDate
	AND sod.ProductSkuId IN (SELECT SkuId FROM #TMPProd)
	GROUP BY CONVERT(VARCHAR(10), so.PayDate, 20), sod.ProductSkuId, NewOnlineDate
	    
	 -- 采购在途数据
	SELECT PO.SkuId, SUM(PO.OnWayQty) AS OnWayQty INTO #TmpOnWay
	FROM (
		SELECT po.Code, PO.SkuId, CASE WHEN PO.PurchaseQty < PNO.StockInQty THEN 0 Else (PO.PurchaseQty - ISNULL(PNO.StockInQty, 0)) End AS OnWayQty
		FROM (
				SELECT po.Code, POD.SkuId, POD.PurchaseQty
				FROM dbo.PurchaseOrder PO, dbo.PurchaseOrderDetail POD
				WHERE po.Id = POD.PurchaseOrderId
				AND Status IN (1, 0)
				AND pod.SkuId IN (SELECT SkuId FROM #TMPProd)
			) PO
		LEFT JOIN ( 
				SELECT PNO.PurchaseOrderCode, PNOD.SkuId, SUM(PNOD.StockInQty) AS StockInQty
				FROM dbo.PurchaseNoticeOrder PNO, dbo.PurchaseNoticeOrderdetail PNOD
				WHERE PNO.Id = PNOD.PurchaseNoticeOrderId
				AND PNOD.WarehousingTime IS NOT NULL
				AND PNOD.SkuId IN (SELECT SkuId FROM #TMPProd)
				GROUP BY PNO.PurchaseOrderCode, PNOD.SkuId
			) PNO ON PO.Code = PNO.PurchaseOrderCode and po.SkuId = PNO.SkuId
		) PO
	GROUP BY PO.SkuId

	-- 可销情况
	SELECT  A.SkuId, A.OneCategoryname,
			A.TwoCategoryname,
			A.ThreeCategoryname,
			A.Code ,
			A.SkuCode ,
			A.SupplierName, 
			A.NewOnlineDate,
			A.CeilingDay,
			A.LowerDay,
			ISNULL(A.IVQuantity, 0) AS IVQuantity,  
			ow.OnWayQty,
			ISNULL(S.SaleQuantity, 0) AS SaleQuantity,  
			A.ReturnPeriod, Color, Size,
			S.DaySale,
			A.SupplierId,
			A.PurchasePrice,
			A.SkuRemark, 
			A.ProductYear,
			CASE When ISNULL(S.DaySale, 0) = 0 THEN 9999 ELSE ROUND((ISNULL(A.IVQuantity, 0) + ISNULL(ow.OnWayQty, 0)) * 1.0 / S.DaySale, 0) END AS CanSaleDays
	INTO #TmpResult1
	FROM #TMPProd  A
	LEFT JOIN (SELECT ProductSkuId, SUM(SaleQuantity) AS SaleQuantity, ROUND(SUM(SaleQuantity) * 1.0 / SaleDays, 2) AS DaySale
				FROM #TmpSale 
				GROUP BY ProductSkuId, SaleDays
				) S ON a.SkuId = s.ProductSkuId 
	LEFT JOIN #TmpOnWay OW ON a.SkuId = OW.SkuId

	 
	IF @P_ReturnType = 'D'
		BEGIN 
			-- 可销情况
			SELECT B.*,  TS.DateKey, ISNULL(TS.SaleQuantity, 0) AS SaleQuantity
			FROM (
					SELECT SkuId ,
							OneCategoryName ,
							TwoCategoryName ,
							ThreeCategoryName ,
							Code ,
							SkuCode ,
							SupplierName ,
							NewOnlineDate ,
							CeilingDay ,
							LowerDay ,
							IVQuantity ,
							OnWayQty ,
							SaleQuantity ,
							ReturnPeriod ,
							Color ,
							Size ,
							DaySale ,
							CanSaleDays,
							SupplierId,
							PurchasePrice,
							SkuRemark, 
							ProductYear,
							(SELECT CASE WHEN SUM(CASE WHEN CanSaleDays < CeilingDay THEN 1 ELSE 0 END) = 0 THEN 0 ELSE 1 End FROM #TmpResult1 B WHERE A.Code = B.Code) AS NeedPurchase -- 需要采购
							--CASE WHEN A.CanSaleDays < A.LowerDay THEN 1 ELSE 0 END AS UnderLowerDay
					 FROM #TmpResult1 A
				) B LEFT JOIN #TmpSale TS ON B.SkuId = TS.ProductSkuId  
			END;
		ELSE
			BEGIN
				SELECT SUBSTRING(DateKey, 1, 7) AS DateKey, ProductSkuId, SUM(SaleQuantity) AS SaleQuantity INTO #TmpSaleMth FROM  #TmpSale GROUP BY SUBSTRING(DateKey, 1, 7), ProductSkuId;

				SELECT B.*,  TS.DateKey, ISNULL(TS.SaleQuantity, 0) AS SaleQuantity
				FROM (
						SELECT SkuId ,
								OneCategoryName ,
								TwoCategoryName ,
								ThreeCategoryName ,
								Code ,
								SkuCode ,
								SupplierName ,
								NewOnlineDate ,
								CeilingDay ,
								LowerDay ,
								IVQuantity ,
								OnWayQty ,
								SaleQuantity ,
								ReturnPeriod ,
								Color ,
								Size ,
								DaySale,
								CanSaleDays,
								SupplierId,
							    PurchasePrice,
								SkuRemark, 
								ProductYear,
								(SELECT CASE WHEN SUM(CASE WHEN CanSaleDays < CeilingDay THEN 1 ELSE 0 END) = 0 THEN 0 ELSE 1 End FROM #TmpResult1 B WHERE A.Code = B.Code) AS NeedPurchase -- 需要采购
								--CASE WHEN A.CanSaleDays < A.LowerDay THEN 1 ELSE 0 END AS NeedColor
						 FROM #TmpResult1 A
					) B LEFT JOIN #TmpSaleMth TS ON B.SkuId = TS.ProductSkuId 

				DROP TABLE #TmpSaleMth; 
			END

	
	Select SkuId, OneCategoryName, TwoCategoryName, ThreeCategoryName, Code, SkuCode, SupplierName, NewOnlineDate, CeilingDay, LowerDay, IVQuantity, OnWayQty, SaleQuantity, ReturnPeriod, Color, Size, DaySale, CanSaleDays, SupplierId, PurchasePrice, SkuRemark, ProductYear, NeedPurchase, DateKey, SaleQuantity1 as SaleQuantity
	From [develop-oms].dbo.Temp01 
	DROP TABLE #TMPProd, #TmpSale, #TmpOnWay, #TmpResult1;
END;



go

