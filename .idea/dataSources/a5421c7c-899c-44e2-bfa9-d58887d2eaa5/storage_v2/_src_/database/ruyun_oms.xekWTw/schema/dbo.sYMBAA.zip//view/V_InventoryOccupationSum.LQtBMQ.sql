
/**********************
*create by：Creoa
*remark ：添加套装占用显示
*date:2017-05-26
***********************/

CREATE VIEW [dbo].[V_InventoryOccupationSum] AS 
SELECT
ioc.WarehouseId,ioc.SkuId,
SUM(ioc.Quantity) LockedQuantity,--总占用数
SUM(CASE WHEN ioc.IsDispatched = 1 THEN ioc.Quantity END) AS DispatchedQuantity,--已配占用数
SUM(CASE WHEN ioc.IsDispatched = 0 AND (ioc.Type=1 OR ioc.Type=2) THEN ioc.Quantity ELSE 0 END) AS UnDispatchedQuantity,--未配订单占用数
SUM(CASE WHEN ioc.Type IN (3,5) THEN ioc.Quantity ELSE 0  END) AS AllotQuantity,--调拨占用数
SUM(CASE WHEN ioc.Type=4 THEN ioc.Quantity ELSE 0  END) AS VipQuantity,--调拨占用数
SUM(CASE WHEN ioc.Type=6 THEN ioc.Quantity ELSE 0  END) AS CombQuantity--套装占用
FROM dbo.InventoryOccupation ioc
GROUP BY ioc.WarehouseId,ioc.SkuId
go

