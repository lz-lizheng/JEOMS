



 
CREATE VIEW [dbo].[V_InventoryTransitDetail] AS 
SELECT *
FROM (
	SELECT Id , CreateDate , SkuId , SkuCode , TransitQuantity , TransitDate 
	FROM InventoryTransitDetail 
	)A



go

