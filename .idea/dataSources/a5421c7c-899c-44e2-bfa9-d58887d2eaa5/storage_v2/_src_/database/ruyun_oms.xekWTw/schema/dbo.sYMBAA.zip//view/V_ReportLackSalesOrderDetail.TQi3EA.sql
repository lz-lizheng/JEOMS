

/**********************
*create date : 2018-08-15
*create by：qiaoni 
*remark ：缺货统计报表增加品牌
***********************/   
CREATE VIEW [dbo].[V_ReportLackSalesOrderDetail] AS 
SELECT so.StoreId, so.PayDate, sod.ProductCode, sod.ProductName, SkuCode, SkuName, sod.Quantity, sod.ShippingDateClerk,
	   CASE WHEN sod.ShippingDateClerk IS NOT NULL THEN sod.Quantity ELSE 0 END AS PreSellQauntity, pd.Brand,ps.CustomCode 
FROM dbo.SalesOrder so, dbo.SalesOrderDetail sod, dbo.ProductSku ps, dbo.Product pd
WHERE so.OrderId = sod.SalesOrderId
AND sod.IsOutOfStock = 1
AND sod.ProductSkuId = ps.SkuId
AND sod.IsDeleted = 0
and sod.ProductId = pd.ProductId
go

