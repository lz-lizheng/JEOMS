CREATE VIEW V_B2COutDetail
AS
SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,so.Code,dod.DispatchOrderCode,dode.ExpressName,dode.ExpressCode,
dode.ActualExpressFee,ISNULL(dode.DeliveryDate,so.CreateDate) Date,so.PayDate,sod.SkuCode,sod.ProductName,sod.Quantity,
sod.AmountActual,ps.WholeSalePrice,ps.PurchasePrice,dod.WarehouseName,so.TradeId,p.Brand
FROM dbo.SalesOrder so
LEFT JOIN dbo.SalesOrderDetail sod ON so.OrderId=sod.SalesOrderId
LEFT JOIN dbo.Store s ON s.Id=so.StoreId
LEFT JOIN dbo.DispatchOrderDetail dod ON dod.SalesOrderDetailId=sod.DetailId
LEFT JOIN dbo.DispatchOrderDetailExpress dode ON dode.SalesOrderId=so.OrderId
LEFT JOIN dbo.ProductSku ps ON ps.SkuId=sod.ProductSkuId
LEFT JOIN dbo.Product p ON p.ProductId=ps.ProductId
WHERE dod.Status=2 AND so.Status=32
go

