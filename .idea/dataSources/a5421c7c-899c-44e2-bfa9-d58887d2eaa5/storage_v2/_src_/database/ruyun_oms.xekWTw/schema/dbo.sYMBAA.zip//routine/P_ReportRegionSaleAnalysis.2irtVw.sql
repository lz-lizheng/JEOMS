

CREATE PROCEDURE [dbo].[P_ReportRegionSaleAnalysis]
(
	@P_CalcType INT, -- 1: 省份汇总, 2: 省份对应销售明细数据
	@P_BeginDate DATETIME,
	@P_EndDate DATETIME,
	@P_ProvinceName NVARCHAR(max) = '',
	@P_PageSize INT = 0,
	@P_CurrentPage INTEGER = 0,
	@P_TotalRow INT OUTPUT
)
AS
BEGIN
  
	IF @P_CalcType = 1
		BEGIN 
			-- 订单
			IF LEN(@P_ProvinceName) > 0
				BEGIN 
				  
					SELECT TOP 100  RG.Name AS ProvinceName, Sale.SaleQuantity AS SaleQuantity
					FROM dbo.Region RG
					LEFT JOIN (
								SELECT SOS.ProvinceName, SUM(sod.Quantity) AS SaleQuantity
								FROM  dbo.SalesOrder so(NOLOCK)
								LEFT JOIN dbo.SalesOrderSub sos(NOLOCK) ON so.OrderId = sos.SubId 
								LEFT JOIN dbo.SalesOrderDetail sod(NOLOCK) ON so.OrderId = sod.SalesOrderId
								WHERE so.PayDate BETWEEN @P_BeginDate AND @P_EndDate 
								AND sos.ProvinceId IN (SELECT * FROM [dbo].[F_SplitString]( @P_ProvinceName, ','))
								GROUP BY SOS.ProvinceName 
							  ) Sale ON RG.Name = Sale.ProvinceName
					WHERE RegionLevel = 2
					ORDER BY Sale.SaleQuantity desc;
				END;
			ELSE
				BEGIN 
					SELECT TOP 100  RG.Name AS ProvinceName, Sale.SaleQuantity AS SaleQuantity
					FROM dbo.Region RG
					LEFT JOIN (
								SELECT SOS.ProvinceName, SUM(sod.Quantity) AS SaleQuantity
								FROM dbo.SalesOrder so(NOLOCK) 
								LEFT JOIN dbo.SalesOrderSub sos(NOLOCK) ON so.OrderId = sos.SubId 
								LEFT JOIN dbo.SalesOrderDetail sod(NOLOCK) ON so.OrderId = sod.SalesOrderId
								WHERE so.PayDate BETWEEN @P_BeginDate AND @P_EndDate 
								GROUP BY SOS.ProvinceName 
							  ) Sale ON RG.Name = Sale.ProvinceName
					WHERE RegionLevel = 2
					ORDER BY Sale.SaleQuantity desc;
				END;
		END; 
	ELSE
		BEGIN 
			-- 订单
			SELECT sod.ProductSkuId, SUM(sod.Quantity) AS SaleQuantity, SUM(sod.AmountActual) AS AmountActual
			INTO #TmpSale
			FROM dbo.SalesOrder so(NOLOCK) LEFT JOIN dbo.SalesOrderSub sos(NOLOCK) ON so.OrderId = sos.SubId LEFT JOIN dbo.SalesOrderDetail sod(NOLOCK) ON so.OrderId = sod.SalesOrderId
			WHERE so.PayDate BETWEEN @P_BeginDate AND @P_EndDate 
			AND sos.ProvinceName = @P_ProvinceName
			GROUP BY sod.ProductSkuId
	 
			-- 退换货
			SELECT rod.SkuId, SUM(rod.Quantity) AS ReturnQuantity INTO #TmpReturn
			FROM dbo.ReturnOrder ro(NOLOCK) LEFT JOIN dbo.ReturnOrderDetail rod(NOLOCK) ON ro.Id = rod.ReturnOrderId LEFT JOIN dbo.SalesOrderSub sos(NOLOCK) ON rod.SalesOrderId = sos.SubId
			WHERE ro.ApproveDate BETWEEN @P_BeginDate AND @P_EndDate
			AND sos.ProvinceName = @P_ProvinceName
			GROUP BY rod.SkuId

			SELECT @P_TotalRow = COUNT(1) FROM (SELECT S.ProductSkuId AS ProductSkuId FROM #TmpSale S UNION ALL SELECT SkuId AS ProductSkuId FROM #TmpReturn ) B  
			  
			SELECT pd.Code, ps.Code AS SkuCode, ps.Color, ps.Size, sale.SaleQuantity AS SaleQuantity, rtn.ReturnQuantity AS ReturnQuantity, 
				   CASE WHEN ISNULL(sale.SaleQuantity, 0) = 0 THEN NULL ELSE sale.AmountActual / sale.SaleQuantity END AS UnitPrice
			FROM (
				SELECT C.ProductSkuId 
				FROM (
					SELECT b.ProductSkuId, ROW_NUMBER() OVER (ORDER BY ProductSkuId) AS rowId
					FROM (SELECT S.ProductSkuId AS ProductSkuId FROM #TmpSale S UNION ALL SELECT SkuId AS ProductSkuId FROM #TmpReturn ) B 
					) C
				WHERE C.rowId >( @P_CurrentPage - 1) * @P_PageSize AND c.rowId <= @P_PageSize * @P_CurrentPage 
				) A
			LEFT JOIN dbo.ProductSku ps(NOLOCK) ON a.ProductSkuId = ps.SkuId
			LEFT JOIN dbo.Product pd(NOLOCK) ON ps.ProductId = pd.ProductId
			LEFT JOIN #TmpSale sale ON a.ProductSkuId = sale.ProductSkuId
			LEFT JOIN #TmpReturn rtn ON a.ProductSkuId = rtn.SkuId;
			 
			DROP TABLE #TmpReturn, #TmpSale; 
		END; 
	
END;

go

