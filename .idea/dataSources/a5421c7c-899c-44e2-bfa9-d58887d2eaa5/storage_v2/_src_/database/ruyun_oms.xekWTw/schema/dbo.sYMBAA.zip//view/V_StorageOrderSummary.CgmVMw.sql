CREATE VIEW V_StorageOrderSummary
AS
SELECT so.VirtualWarehouseId,so.VirtualWarehouseName,SUM(sod.InQty) InQty,SUM(sod.InQty*sod.UnitPrice) Price,
TypeCode,TypeName,sod.WarehouseStorageTime
FROM dbo.StorageOrder so
LEFT JOIN dbo.StorageOrderDetail sod ON sod.StorageOrderId=so.Id
WHERE so.Status IN (3,4)
AND TypeCode IN ('LHZH03','LHZH02','PYRK01')
GROUP BY so.VirtualWarehouseId,so.VirtualWarehouseName,TypeCode,TypeName,sod.WarehouseStorageTime
go

