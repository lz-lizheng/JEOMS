


CREATE trigger [dbo].[refund_update]
on [dbo].[RefundOrder]
for update
as
declare @Status int
set @Status = 0
if update(Status)
begin
select top 1 @Status=Status from inserted where Status = 3 and RefundWay = 1
if @Status=3
begin
insert into OrderTrigger select i.id,105,GETDATE(),1 from inserted i left join RefundOrder d on d.Id = i.Id where i.Status = 3 and i.RefundWay = 1 and d.Status = 3
end
end
go

