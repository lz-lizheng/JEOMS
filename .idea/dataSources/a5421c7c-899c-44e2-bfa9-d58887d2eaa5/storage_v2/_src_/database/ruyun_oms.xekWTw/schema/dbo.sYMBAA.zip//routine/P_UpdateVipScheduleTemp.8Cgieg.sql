----------------格普唯品档期锁定数量迁移
CREATE proc P_UpdateVipScheduleTemp
(
	@scheduleCode nvarchar(50),
	@inVirtualWarehouseCode nvarchar(50)
)
as
BEGIN
	begin  tran 
		select top 1 Id,Name into #Warehouse from Warehouse where ParentId in
		(
			select WarehouseId from VipSchedule where ScheduleCode=@scheduleCode
		) and WarehouseType=2

		select top 1 Id,Name into #InWarehouse from Warehouse where Code=@inVirtualWarehouseCode

		update VipSchedule set Status=3,ScheduleType=0,OutVirtualWarehouseId=(select Id from #Warehouse),
		OutVirtualWarehouseName=(select Name from #Warehouse)
		,InVirtualWarehouseId=(select Id from #InWarehouse),InVirtualWarehouseName=(select Name from #InWarehouse) where ScheduleCode=@scheduleCode
		UPDATE iv SET iv.Quantity=iv.Quantity+(case when (vsd.LockQty-vsd.OutQty) <0 then 0 else (vsd.LockQty-vsd.OutQty) end)
		FROM InventoryVirtual iv,VipSchedule vs,VipScheduleDetail vsd 
		WHERE vs.ScheduleCode=@scheduleCode AND vs.Id=vsd.ScheduleId AND iv.WarehouseId=vs.InVirtualWarehouseId AND iv.SkuId=vsd.SkuId

		UPDATE iv SET iv.Quantity=iv.Quantity-(case when (vsd.LockQty-vsd.OutQty) <0 then 0 else (vsd.LockQty-vsd.OutQty) end) 
		FROM InventoryVirtual iv,VipSchedule vs,VipScheduleDetail vsd 
		WHERE vs.ScheduleCode=@scheduleCode AND vs.Id=vsd.ScheduleId AND iv.WarehouseId=vs.OutVirtualWarehouseId AND iv.SkuId=vsd.SkuId

		insert into InventoryVirtual
		(Id,WarehouseId,SkuId,Quantity,Note,ModifyTime,CreateDate,TransitTotalQuantity)
		SELECT ard.Id,ar.InVirtualWarehouseId,ard.SkuId,ard.LockQty,'唯品生成1227',GETDATE(),GETDATE(),0
		 FROM dbo.VipSchedule ar JOIN dbo.VipScheduleDetail ard ON ar.Id = ard.ScheduleId
						  WHERE ar.ScheduleCode = @scheduleCode AND 
						  NOT EXISTS(SELECT 1 FROM InventoryVirtual WHERE WarehouseId = ar.InVirtualWarehouseId
						  AND SkuId = ard.SkuId)

		delete from InventoryOccupation where OrderId=(select Id from VipSchedule where ScheduleCode=@scheduleCode)
	if @@ERROR<>0 --判断  如果两条语句有任何一条出现错误。(如果前面的SQL 语句执行没有错误，则返回0)
	begin
	rollback tran --开始执行事务的回滚，恢复转账开始之前的状态
	return 0
	end
	else  --如果两个语句都执行成功
	begin
	commit tran --执行这个事务的操作
	end
End
go

