

CREATE VIEW [dbo].[V_PlatFormBillReport] AS 
select so.PayDate as OrderTime,so.CreateDate,
so.StoreName,
so.TradeId,
so.StoreId,
so.Code as OrderCode,
so.PayAmount as OrderAmount,
SUM(ar.InAmount) AS InAmount,
SUM(CASE BusinessTypeDesc WHEN '佣金' THEN ISNULL(OutAmount,0) ELSE 0 END) AS TmallAmount,
SUM(CASE BusinessTypeDesc WHEN '积分' THEN ISNULL(OutAmount,0) ELSE 0 END) AS IntegralAmount,
SUM(CASE BusinessTypeDesc WHEN '服务费' THEN ISNULL(OutAmount,0) ELSE 0 END) AS CreditAmount,
(SELECT SUM(OutAmount) FROM dbo.AlipayRecord WHERE OrderNo=TradeId AND BusinessTypeDesc='保险') AS QuickAmount,
Max(CASE WHEN InAmount>0 THEN ar.CreateDate ELSE Null END) AS InDate,
Max(CASE WHEN vl.IsVerified>0 THEN 1 ELSE 0 END) AS IsVerified
from SalesOrder so left join alipayRecord ar on so.TradeId=ar.[OrderNo]
left join VerificationDetail vl on vl.OrderCode=so.TradeId
GROUP BY so.PayDate,so.CreateDate,so.StoreName,so.TradeId,so.StoreId,so.Code,so.PayAmount


go

