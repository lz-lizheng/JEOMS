

/**  
*create date : 2020-08-21
*create modify：拓斗  
*remark ：订单明细统计发货视图添加搜索条件
*/  
CREATE VIEW [dbo].[V_ReportSalesOrderDetailByDelivery] AS SELECT  
SOD.DetailId AS DetailId--订单明细ID  
,DO.DeliveryDate AS DeliveryDate--发货日期  
,DO.StoreId AS OStoreId  
,DO.StoreId AS StoreId  
,dod.TradeId as SalesOrderTradeId  
,DO.ActualExpressId as ExpressId  
,dod.ProductCode  
,dod.ProductSkuCode as SkuCode  
,DO.WarehouseId  
,dod.SalesOrderCode  
,DO.ActualExpressNo  
,SO.TradeFinishDate  
,SO.PayDate AS SalesOrderPayDate--付款时间  
,DO.Code AS DispatchProductOrderCode--配货单号
,DO.CreateDate as DispatchDate--配货时间
,DO.Status as DispatchOrderStatus--配货状态
FROM dbo.SalesOrder(NOLOCK) SO  
JOIN dbo.SalesOrderDetail(NOLOCK) SOD on SO.OrderId = SOD.SalesOrderId  
LEFT JOIN dbo.DispatchOrderDetail(NOLOCK) dod ON dod.SalesOrderDetailId = sod.DetailId AND dod.Status <> 1  
LEFT JOIN dbo.DispatchOrder(NOLOCK) DO ON dod.DispatchOrderId=DO.Id AND DO.Status <> 3  
WHERE SOD.IsAbnormal = 0 AND SO.TransType <> 1

go

