--唯品档期"/>PO号" Fie开始时间""/>款式数量"备货库存"剩余库存"售罄率" F 销售额" F"/>件单价" Ft"/>销量（件）"/>退货数量""/>退货率" F
  
CREATE VIEW V_VipScheduleCategoryAnalyse AS 
SELECT Sale.PoCode ,
	   Sale.CategoryName,
       Sale.PlanQty ,
       Sale.RemainingInventory ,
       Sale.SaleThroughRate ,
       Sale.SaleQty ,
       Sale.SaleAmount ,
       Rtn.RtnQty,
	   CASE when Sale.SaleQty > 0 THEN Rtn.RtnQty * 1.0 / Sale.SaleQty ELSE 0 end AS ReturnRate
FROM (
		SELECT  vs.PoCode,
				pd.CategoryName,
				SUM(vsd.PlanQty) AS PlanQty, 
				SUM(vsd.PlanQty - vsd.OutQty) AS RemainingInventory,
				SUM(vsd.OutQty) * 1.0 / SUM(vsd.PlanQty) AS SaleThroughRate,
				SUM(vsd.OutQty) AS SaleQty,
				SUM(Vsd.OutQty * vsd.SupplyPrice) AS SaleAmount 
		FROM dbo.VipSchedule vs(NOLOCK)
		LEFT JOIN dbo.VipScheduleDetail vsd(NOLOCK) ON vs.Id = vsd.ScheduleId 
		LEFT JOIN dbo.Product pd(NOLOCK) ON vsd.ProductId = pd.ProductId
		GROUP BY vs.PoCode, pd.CategoryName 
	) Sale
LEFT JOIN 
	(	
		SELECT vrod.PoCode, pd.CategoryName, SUM(vrod.ReturnQty) AS RtnQty
		FROM dbo.VipReturnOrder vro(NOLOCK)
		LEFT JOIN dbo.VipReturnOrderDetail vrod(NOLOCK) ON vro.Id = vrod.ReturnOrderId
		LEFT JOIN dbo.Product pd(NOLOCK) ON vrod.ProductId = pd.ProductId
		GROUP BY vrod.PoCode, pd.CategoryName
	) Rtn ON Rtn.PoCode = Sale.PoCode AND rtn.CategoryName = Sale.CategoryName



go

