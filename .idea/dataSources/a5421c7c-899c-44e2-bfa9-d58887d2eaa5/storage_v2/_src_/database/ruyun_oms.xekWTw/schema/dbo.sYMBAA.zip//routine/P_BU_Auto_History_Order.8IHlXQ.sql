
CREATE PROC [dbo].[P_BU_Auto_History_Order] 
(
	@P_DayBefore DateTime
)
AS
	-- 更新数据表结构
	Exec [dbo].[P_BU_Sync_History_Table];

	PRINT '--**归档截止时间 : ' + Convert(Varchar, @P_DayBefore, 20)	
	
	DECLARE @V_RecordCount int=0
	DECLARE @V_SQL NVARCHAR(max); 
 	Print '--**订单归档开始 Start At: ' + Convert(Varchar, GetDate(), 20)	
 	  
	-- 已发货完成订单
	SELECT OrderId As SoOrderId into #TmpOrderId from SalesOrder(nolock) where CreateDate <= @P_DayBefore and (DeliveryDate <= @P_DayBefore OR TransType = 2) AND DeliveryTypeStatus = 2 AND PlatformStatus = 2; -- and code = 'SA1608290000001';
	  
	-- 已作废订单
	INSERT into #TmpOrderId Select OrderId From SalesOrder where IsObsolete = 1 and CreateDate <= @P_DayBefore;
		 
	SELECT @V_RecordCount = COUNT(1) from #TmpOrderId
	Print '--**归档订单总量 :' + Cast(@V_RecordCount as varchar)

	If @V_RecordCount > 0
		Begin
			Begin Try 
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------				
				Print '>1. 订单日志(SalesOrderLog) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderLog Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderLog') + ' From SalesOrderLog Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL ; 
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 1.1 删除已经备份的数据开始时间 : ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderLog Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
			 
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>2. 订单缺货(SalesOrderOutofStock) Start At: ' + Convert(Varchar, GetDate(), 20)  
 				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderOutofStock Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderOutofStock') + ' From SalesOrderOutofStock Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL; 
				EXECUTE SP_EXECUTESQL @V_SQL; 
				Print ' 2.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderOutofStock Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);

				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>3. 订单发票(SalesOrderInvoice) Start At: ' + Convert(Varchar, GetDate(), 20) 
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderInvoice Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderInvoice') + ' From SalesOrderInvoice Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 3.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderInvoice Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
				 
				Print '>4. 订单优惠(SalesOrderDiscount) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderDiscount Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderDiscount') + ' From SalesOrderDiscount Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 4.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderDiscount Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
				  
				Print '>5. 订单支付(SalesOrderPayment) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderPayMent Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderPayMent') + ' From SalesOrderPayMent Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;   
				Print ' 5.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderPayMent Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
				 
				Print '>6. 订单活动信息(SalesOrderActivity) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderActivity Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderActivity') + ' From SalesOrderActivity Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 6.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderActivity Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
				 
				Print '>7. 订单发货信息(SalesOrderDeliveryInfo) Start At: ' + Convert(Varchar, GetDate(), 20) 
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderDeliveryInfo Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderDeliveryInfo') + ' From SalesOrderDeliveryInfo Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 7.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderDeliveryInfo Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);
				 
				Print '>8. 订单平台商品信息(SalesOrderDetailPlatformProduct) Start At: ' + Convert(Varchar, GetDate(), 20) 
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderDetailPlatformProduct Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderDetailPlatformProduct') + ' From SalesOrderDetailPlatformProduct SODP Where Exists (Select 1 From SalesOrderDetail sod(nolock) Inner Join #TmpOrderId oi on sod.SalesOrderId = oi.SoOrderId Where SODP.Id = sod.DetailId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 8.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderDetailPlatformProduct Where Exists (Select 1 From SalesOrderDetail sod(nolock) Inner Join #TmpOrderId oi on sod.SalesOrderId = oi.SoOrderId Where SalesOrderDetailPlatformProduct.Id = sod.DetailId);
				  
				Print '>9. 订单商品信息（SalesOrderDetail) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderDetail Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderDetail') + ' From SalesOrderDetail Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 9.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderDetail Where Exists (Select 1 From #TmpOrderId Where SalesOrderId = SoOrderId);

				Print '>10. 订单子信息(SalesOrderSub) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrderSub Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrderSub') + ' From SalesOrderSub Where Exists (Select 1 From #TmpOrderId Where SubId = SoOrderId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;
				Print ' 10.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrderSub Where Exists (Select 1 From #TmpOrderId Where SubId = SoOrderId);
					 
				Print '>11. 订单表(SalesOrder) Start At: ' + Convert(Varchar, GetDate(), 20) 
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.SalesOrder Select ' + dbo.F_BU_Generate_Auto_History_Sql('SalesOrder') + ' FROM SalesOrder WHERE EXISTS (SELECT 1 FROM #TmpOrderId WHERE SoOrderId = OrderID);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL; 
				PRINT ' 11.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From SalesOrder Where Exists (Select 1 From #TmpOrderId A Where SoOrderId = OrderID);

				Drop Table #TmpOrderId; 
				Print '--**订单归档完成 Commit At: ' + Convert(Varchar, GetDate(), 20)
			End Try
			Begin Catch			 			
				Print '--**订单归档出错 Rollback At: ' + Convert(Varchar, GetDate(), 20)												
				Print '--**Error Msg : ' +  error_message()
			End Catch
		End



	--========================================================================================================================--
	Print '=============================================================================================='
	Print '=============================================================================================='
	Print ''
	Print '--**配货通知单归档开始 Start At: ' + Convert(Varchar, GetDate(), 20)	
	Select Distinct dpod.DispatchOrderId As DpoId, dpod.Id DpoDetailid  Into #TmpDpoId FROM dbo.DispatchOrderDetail dpod(nolock) INNER Join [jehistory].dbo.SalesOrderDetail sod(nolock) on dpod.SalesOrderDetailId = sod.DetailId;
	   
	SELECT @V_RecordCount = COUNT(1) from #TmpDpoId
	Print '--**配货单明细量:' + Cast(@V_RecordCount as varchar)

	If @V_RecordCount > 0
		Begin
			Begin Try   
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>1. 配货快递信息(DispatchOrderDetailExpress) Start At: ' + Convert(Varchar, GetDate(), 20) 
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.DispatchOrderDetailExpress Select ' + dbo.F_BU_Generate_Auto_History_Sql('DispatchOrderDetailExpress') + ' From DispatchOrderDetailExpress dpod Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where dpod.detailid = DpoDetailid);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 1.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete DispatchOrderDetailExpress Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where DispatchOrderDetailExpress.DetailId = DpoDetailid);
				 
				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>2. 配货商品信息(DispatchOrderDetail) Start At: ' + CONVERT(VARCHAR, GETDATE(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.DispatchOrderDetail Select ' + dbo.F_BU_Generate_Auto_History_Sql('DispatchOrderDetail') + ' From DispatchOrderDetail dpo Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where dpo.Id = DpoDetailid);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				PRINT ' 2.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From DispatchOrderDetail Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where DispatchOrderDetail.Id = DpoDetailid);


				----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Print '>3. 配货主信息(DispatchOrder) Start At: ' + Convert(Varchar, GetDate(), 20)  
				SELECT @V_SQL = 'Insert Into [jehistory].dbo.DispatchOrder Select ' + dbo.F_BU_Generate_Auto_History_Sql('DispatchOrder') + ' From DispatchOrder dpo Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where dpo.Id = DpoId);'
				PRINT @V_SQL;
				EXECUTE SP_EXECUTESQL @V_SQL;  
				Print ' 3.1 删除已经备份的数据: ' + Convert(Varchar, GetDate(), 20)
				Delete From DispatchOrder Where Exists (Select 1 From #TmpDpoId dpoList(nolock) Where DispatchOrder.Id = DpoId) AND NOT EXISTS (SELECT 1 FROM dbo.DispatchOrderDetail dod(NOLOCK) WHERE dbo.DispatchOrder.Id = dod.DispatchOrderId);
				 
				Drop Table #TmpDpoId 
				Print '--**配货通知单归档完成 Commit At: ' + Convert(Varchar, GetDate(), 20)
			End Try
			Begin Catch 
				Print '--**配货通知单归档出错 Rollback At: ' + Convert(Varchar, GetDate(), 20)				
				Print '--**Error Msg : ' +  error_message()				
			End Catch
		End
go

