CREATE VIEW V_OutboundSummary  
AS  
SELECT StoreId,StoreCode,StoreName,DeliveryDate,SUM(DisNum) DisNum,SUM(SaleNum) SaleNum,0 B2bNum,SUM(Quantity) Quantity,  
SUM(ExpressFee) ExpressFee,SUM(AmountActual) AmountActual  
FROM  
(SELECT StoreId,StoreCode,StoreName,DeliveryDate,SUM(DisNum) DisNum,SUM(SaleNum) SaleNum,0 B2bNum,SUM(Quantity) Quantity,  
SUM(ExpressFee) ExpressFee,SUM(AmountActual) AmountActual  
FROM   
(SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,dode.DeliveryDate,COUNT(DISTINCT dod.DispatchOrderId) DisNum,  
0 SaleNum,SUM(sod.Quantity) Quantity,SUM(dode.ActualExpressFee) ExpressFee,SUM(sod.AmountActual) AmountActual  
FROM dbo.SalesOrder so  
LEFT JOIN dbo.SalesOrderDetail sod ON sod.SalesOrderId=so.OrderId  
LEFT JOIN dbo.Store s ON s.Id=so.StoreId  
LEFT JOIN dbo.DispatchOrderDetail dod ON dod.SalesOrderId=so.OrderId AND dod.Status NOT IN (1)  
LEFT JOIN dbo.DispatchOrderDetailExpress dode ON dode.SalesOrderId=so.OrderId  
WHERE so.Status=32 AND sod.Status=2  
GROUP BY s.Id,s.Code,s.Name,so.StoreId,dode.DeliveryDate  
  
UNION ALL  
  
SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,so.DeliveryDate,0 DisNum,COUNT(so.OrderId) SaleNum,  
SUM(sod.Quantity) Quantity,SUM(so.ExpressFee) ExpressFee,SUM(sod.AmountActual) AmountActual  
FROM dbo.SalesOrder so  
LEFT JOIN dbo.SalesOrderDetail sod ON sod.SalesOrderId=so.OrderId  
LEFT JOIN dbo.Store s ON so.StoreId=s.Id  
WHERE so.OrderId NOT IN (SELECT SalesOrderId FROM dbo.DispatchOrderDetail WHERE Status NOT IN (1))  
AND so.Status=32 AND sod.Status=2  
GROUP BY s.Id,s.Code,s.Name,so.StoreId,so.DeliveryDate)a  
GROUP BY StoreId,StoreCode,StoreName,DeliveryDate  
  
UNION ALL  
  
SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,aod.WarehouseDeliveryTime DeliveryDate,0 DisNum,0 SaleNum,  
COUNT(ao.Code) B2bNum,SUM(aod.OutQty) Quantity,SUM(ao.ExpressFee) ExpressFee,SUM(aod.Price) AmountActual  
FROM dbo.B2BAllocationOut ao  
LEFT JOIN dbo.B2BAllocationOutDetail aod ON aod.OutCode=ao.Code  
LEFT JOIN dbo.Store s ON ao.StoreId=s.Id  
WHERE ao.Status IN (3,4)  
GROUP BY s.Id,s.Code,s.Name,ao.StoreId,aod.WarehouseDeliveryTime  
)b  
GROUP BY StoreId,StoreCode,StoreName,DeliveryDate
go

