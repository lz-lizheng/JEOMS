CREATE VIEW V_AssemblyOrderSummary  
AS  
SELECT * FROM   
(SELECT ao.WarehouseId,ao.WarehouseName,MachiningType,aod.SourceProductCode,aod.SourceProductName,  
SUM(aod.SourceQuantity) OutQty,0 InQty,ao.StorageTime  
FROM dbo.AssemblyOrder ao  
LEFT JOIN dbo.AssemblyOrderDetail aod ON aod.AssemblyOrderId=ao.Id  
WHERE ao.Status=5 AND MachiningType=0  
GROUP BY ao.WarehouseId,ao.WarehouseName,MachiningType,aod.SourceProductCode,aod.SourceProductName,ao.StorageTime  
  
UNION ALL   
  
SELECT ao.WarehouseId,ao.WarehouseName,MachiningType,aod.TargetSkuCode,aod.TargetSkuName,  
0 OutQty,AVG(aod.InQuantity) InQty,ao.StorageTime  
FROM dbo.AssemblyOrder ao  
LEFT JOIN dbo.AssemblyOrderDetail aod ON aod.AssemblyOrderId=ao.Id  
WHERE ao.Status=5 AND MachiningType=0  
GROUP BY ao.WarehouseId,ao.WarehouseName,MachiningType,aod.TargetSkuCode,aod.TargetSkuName,ao.StorageTime)a  
  
UNION ALL  
  
SELECT * FROM   
(SELECT ao.WarehouseId,ao.WarehouseName,MachiningType,aod.SourceProductCode,aod.SourceProductName,  
0 OutQty,SUM(aod.InQuantity) InQty,ao.StorageTime  
FROM dbo.AssemblyOrder ao  
LEFT JOIN dbo.AssemblyOrderDetail aod ON aod.AssemblyOrderId=ao.Id  
WHERE ao.Status=5 AND MachiningType=1  
GROUP BY ao.WarehouseId,ao.WarehouseName,MachiningType,aod.SourceProductCode,aod.SourceProductName,ao.StorageTime  
  
UNION ALL   
  
SELECT ao.WarehouseId,ao.WarehouseName,MachiningType,aod.TargetSkuCode,aod.TargetSkuName,  
AVG(aod.InQuantity) OutQty,0 InQty,ao.StorageTime  
FROM dbo.AssemblyOrder ao  
LEFT JOIN dbo.AssemblyOrderDetail aod ON aod.AssemblyOrderId=ao.Id  
WHERE ao.Status=5 AND MachiningType=1  
GROUP BY ao.WarehouseId,ao.WarehouseName,MachiningType,aod.TargetSkuCode,aod.TargetSkuName,ao.StorageTime)a
go

