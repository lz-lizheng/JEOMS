/**
*create date : 2020-6-23
*create modify：路奇
*remark ：上传配置添加是否使用阀值字段
*/
CREATE View [dbo].[V_UploadConfig]
AS
SELECT iuc.Id, iuc.Name, iuc.Flag, iuc.StoreId, iuc.BrandId, iuc.BrandName, iuc.IsUpload, iuc.IsManualUpload,iuc.IsNotUseValue,
  iuw.WarehouseId, iuw.WarehouseType, iuw.Scale, iuc.IsNotUseAllCanSale,iuc.UploadLessQuantity,Isnull(w.isOc,0) isOc,ISNUll(UploadValve,20) UploadValve,ISNULL(UploadTigger,5) UploadTigger
FROM InventoryUploadConfig iuc
  JOIN InventoryUploadWarehouse iuw ON iuc.Id = iuw.ConfigId
  JOIN Warehouse w ON iuw.WarehouseId = w.Id
                      AND w.IsDisabled = 0
                      AND (iuw.WarehouseType IN (2, 3) OR
                           (w.WarehouseType = 5 AND w.IsOC = 1))
UNION
SELECT iuc.Id, iuc.Name, iuc.Flag, iuc.StoreId, iuc.BrandId, iuc.BrandName, iuc.IsUpload, iuc.IsManualUpload,iuc.IsNotUseValue, w.Id,
  w.WarehouseType, iuw.Scale, iuc.IsNotUseAllCanSale,iuc.UploadLessQuantity,Isnull(w.isOc,0) isOc,ISNUll(UploadValve,20) UploadValve,ISNULL(UploadTigger,5) UploadTigger
FROM InventoryUploadConfig iuc
  JOIN InventoryUploadWarehouse iuw ON iuc.Id = iuw.ConfigId
                                       AND iuw.WarehouseType = 4
  JOIN Warehouse w ON iuw.WarehouseId = w.ParentId
                      AND w.IsDisabled = 0 AND w.IsOC = 1
go

