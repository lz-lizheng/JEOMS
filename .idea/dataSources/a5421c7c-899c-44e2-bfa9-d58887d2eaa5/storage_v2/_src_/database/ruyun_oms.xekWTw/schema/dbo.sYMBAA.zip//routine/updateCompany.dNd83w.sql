create procedure updateCompany
as
 begin
     update Company set CreateDate = GETDATE()
 end
go

