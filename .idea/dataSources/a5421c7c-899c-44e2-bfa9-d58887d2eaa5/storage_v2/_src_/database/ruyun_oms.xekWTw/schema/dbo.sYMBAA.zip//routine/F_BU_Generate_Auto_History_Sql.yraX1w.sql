
CREATE FUNCTION [dbo].[F_BU_Generate_Auto_History_Sql]
(
	@P_HistoryTableName nvarchar(100)
)
RETURNS nVarchar(max)
AS
BEGIN
 
	DECLARE @V_Str NVARCHAR(max)	
	SELECT @V_Str = (
		SELECT col.name + ','
		FROM [JEhistory].sys.sysobjects obj, [jehistory].sys.syscolumns col 
		WHERE obj.id = col.id AND obj.name = @P_HistoryTableName
		ORDER BY col.colorder
		FOR XML PATH('')
		)  
	 		 
	SELECT @V_Str = SUBSTRING(@V_Str, 1, LEN(@V_Str) - 1)
 
	RETURN @V_Str;
END;
go

