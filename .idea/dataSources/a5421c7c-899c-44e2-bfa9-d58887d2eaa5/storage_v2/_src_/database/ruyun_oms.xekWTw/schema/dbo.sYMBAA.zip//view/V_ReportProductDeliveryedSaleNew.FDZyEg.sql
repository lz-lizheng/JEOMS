

/**
*create date: 2020-9-1
*create by：拓斗
*remark ：商品销售统计 去重
**/
CREATE VIEW [dbo].[V_ReportProductDeliveryedSaleNew] AS 
 
SELECT distinct
so.PayTime,
sode.DeliveryDate,
Cast(so.PayTime as Date) AS TruncPayDate, 
Cast(sode.DeliveryDate as Date) AS TruncDeliveryDate, 
so.StoreId,
so.StoreName,
sod.ProductCode,
sod.ProductName,
sod.ProductSkuCode AS SkuCode,
sod.ProductSkuName AS SkuName,
pd.Season,
pd.Year,
pd.CategoryName,
ps.Size,
ps.Color, 
pd.FirstLevelCategoryId OneCatId, 
pd.FirstLevelCategoryName OneCatName,
pd.TwoLevelCategoryId TwoCatId, 
pd.TwoLevelCategoryName TwoCatName, 
pd.CategoryId ThreeCatId,
pd.CategoryName ThreeCatName,
sod.Quantity AS Quantity,
sod.AmountActual AS AmountActual,
sod.Quantity * sl.FirstCost AS FirstCost
FROM dbo.DispatchOrder(NOLOCK) so
INNER JOIN dbo.DispatchOrderDetail(NOLOCK) sod ON so.Id = sod.DIspatchOrderId
inner join dbo.DispatchOrderDetailExpress(Nolock) sode on sod.Id = sode.DetailId
INNER JOIN dbo.SalesOrderDetail(NOLOCK) sl ON sl.DetailId= sod.SalesOrderDetailId
LEFT JOIN Product(NOLOCK) pd ON sod.ProductId = pd.ProductId
LEFT JOIN dbo.ProductSku(NOLOCK) ps ON sod.ProductSkuId = ps.SkuId

go

