

CREATE View [dbo].[V_SalesOrderCriteria] as 
Select so.CreateDate as RecordDate, so.PayDate as SalesOrderPayDate, 
	  so.TradeFinishDate as TradeFinishDate, 
	  so.StoreId as StoreId, 
	  so.StoreId as OStoreId, 
	   sod.ProductCode as ProductCode, Sod.SkuCode as SkuCode, 
	   So.TransType as SalesOrderTransType, Sod.DetailId as DetailId,
	   so.Code as SalesOrderCode, sod.IsOutOfStock as SalesOrderIsOutOfStock, 
	   sod.IsDeleted as IsDeleted, sod.DetailType as DetailType,
	   so.IsPrepay as IsPrepay
From SalesOrder So
Join SalesOrderDetail Sod on so.OrderId = sod.SalesOrderId
Where sod.IsAbnormal = 0


go

