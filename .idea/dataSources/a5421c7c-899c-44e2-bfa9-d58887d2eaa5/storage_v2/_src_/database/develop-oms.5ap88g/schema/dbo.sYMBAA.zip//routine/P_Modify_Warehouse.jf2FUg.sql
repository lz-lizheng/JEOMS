CREATE PROCEDURE P_Modify_Warehouse
@Code nvarchar(50),
@WarehouseCode nvarchar(50),
@OrderType int
as
begin
	declare @WarehouseId uniqueidentifier,@WarehouseName nvarchar(50),@ParentWarehouseId uniqueidentifier
	print '-------------------------开始获取仓库-------------------------'
	select @WarehouseId=Id,@WarehouseName=Name,@ParentWarehouseId=ParentId from Warehouse where Code=@WarehouseCode and ParentId is not null and isnull(IsDisabled,0)=0
	if @WarehouseId is null
	begin
		print '仓库不存在'
		return
	end
	else
	begin
		print '获取到仓库：Id:'+convert(nvarchar(50),@WarehouseId)+',Name:'+@WarehouseName
	end
	declare @OrderId bigint
	if @OrderType=1
	begin
		print '-------------------------开始获取退换货单-------------------------'
		select @OrderId=Id from ReturnOrder where Code=@Code and isnull(IsObsolete,0)=0
		if @OrderId is null
		begin
			print '未获取到退换货单'
		end
		else
		begin
			update ReturnOrder set WarehouseInCode=@WarehouseCode,WarehouseInId=@WarehouseId,WarehouseInName=@WarehouseName where Id=@OrderId
			insert into ReturnOrderLog select NEWID(),'存储过程',GETDATE(),'修改退入仓库为:'+@WarehouseName,@OrderId
			print '-------------------------更新退换货单成功-------------------------'
		end
	end
	else
	begin
		print '-------------------------开始获取批发退货单-------------------------'
		select @OrderId=Id from WholesaleReturnOrder where Code=@Code
		if @OrderId is null
		begin
			print '未获取到批发退货单'
		end
		else
		begin
			declare @ParentWarehouseCode nvarchar(50),@ParentWarehouseName nvarchar(50)
			select @ParentWarehouseCode=Code,@ParentWarehouseName=Name from Warehouse where Id=@ParentWarehouseId
			update WholesaleReturnOrder set InWarehouseId=@ParentWarehouseId,InWarehouseName=@ParentWarehouseName,VirtualWarehouseId=@WarehouseId,VirtualWarehouseName=@WarehouseName where Id=@OrderId
			insert into WholesaleReturnOrderLog select NEWID(),GETDATE(),'修改入库仓库为:'+@ParentWarehouseName+',入库虚拟仓为:'+@WarehouseName,'存储过程',@OrderId
			print '-------------------------更新批发退货单成功-------------------------'
		end
	end
end
go

