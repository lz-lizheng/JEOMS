

/**  
 Create By : QiaoNi  20180905  
 Remark  : 采购运营报表   
 Modify  :  QiaoNi 20181121 增加完结状态  
*/  
CREATE VIEW [dbo].[V_PurchasorderReportyy] AS  
SELECT a.Code AS PurchaseCode,
 a.CreateDate,
 a.RequestDeliveryDate,
 a.PurchaseDate,
 a.SupplierCode, 
 a.SupplierName,
 a.SupplierComanyName,  
 a.Status,  
 b.ProductName,
 b.ProductCode, 
 b.SkuName,
 b.SkuCode, 
 b.PurchaseQty, 
 b.NoticeQty, 
 b.InStockQty - c.CiStockQty AS InStockQty,   
 ISNULL(a.ContractNo, '') AS contractno,
 (CASE WHEN a.Status = '0' THEN purchaseqty 
	WHEN purchaseqty - isnull(InStockQty,0) <= 0 THEN '0' 
	WHEN a.Status = '1' THEN purchaseqty - isnull(InStockQty, 0) 
	ELSE '0' END) AS ztsl,
 ISNULL(c.CiStockQty, 0) AS CiStockQty,  
 a.PurchasePersonName as PurchasePersonName,  
 pd.Brand, 
 Season,
 b.ReturnQuantity,
 a.ArriveBatchNo
FROM dbo.PurchaseOrder AS a   
   LEFT OUTER JOIN  dbo.PurchaseOrderDetail AS b ON a.Id = b.PurchaseOrderId  
   JOin Product PD on b.ProductId = pd.ProductId  
   LEFT OUTER JOIN (  SELECT a.PurchaseOrderId, b.SkuCode, sum(b.DefectiveQuantity) AS CiStockQty,a.ArriveBatchNo
       FROM dbo.PurchaseNoticeOrder AS a   
       INNER JOIN  dbo.PurchaseNoticeOrderdetail AS b ON a.Id = b.PurchaseNoticeOrderId  
       WHERE (a.Status IN (3, 5, 7))   group by  a.PurchaseOrderId, b.SkuCode,a.ArriveBatchNo
       ) AS c ON a.Id = c.PurchaseOrderId AND       b.SkuCode = c.SkuCode  
  where 1=1

go

