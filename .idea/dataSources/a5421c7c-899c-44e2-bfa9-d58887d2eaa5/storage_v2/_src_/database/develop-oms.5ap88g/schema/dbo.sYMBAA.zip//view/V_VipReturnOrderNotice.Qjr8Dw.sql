
/**********************
*create date : 2021-07-20
*create by：钟灵
*remark ：唯品退货通知统计添加签收人
***********************/
CREATE VIEW [dbo].[V_VipReturnOrderNotice]
AS
SELECT
VRO.VipReturnOrderCode,
VRON.ReturnOrderCode,
VRON.VipReturnOrderNoticeCode,
VRO.InWarehouseId, 
VRO.InWarehouseName,
VROND.ProductCode, 
VROND.ProductName,
VROND.SkuCode,
VROND.SkuName, 
VROND.NoticeQty, 
VROND.InQty,
VROND.WarehouseStorageTime, 
VRON.CreateDate,
VROND.DefectiveQuantity,
VRON.SignUserName
FROM dbo.VipReturnOrderNotice AS VRON WITH (NOLOCK) 
LEFT OUTER JOIN dbo.VipReturnOrderNoticeDetail AS VROND WITH (NOLOCK) 
ON VROND.ReturnOrderNoticeId = VRON.Id
LEFT OUTER JOIN dbo.VipReturnOrder AS VRO WITH (NOLOCK) 
ON VRO.ReturnOrderCode = VRON.ReturnOrderCode
go

exec sp_addextendedproperty 'MS_Description', '唯品退供单号', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'VipReturnOrderCode'
go

exec sp_addextendedproperty 'MS_Description', '退供单号', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ReturnOrderCode'
go

exec sp_addextendedproperty 'MS_Description', '退货通知单号', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'VipReturnOrderNoticeCode'
go

exec sp_addextendedproperty 'MS_Description', '入库仓库ID', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InWarehouseId'
go

exec sp_addextendedproperty 'MS_Description', '入库仓库名称', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InWarehouseName'
go

exec sp_addextendedproperty 'MS_Description', '商品编码', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ProductCode'
go

exec sp_addextendedproperty 'MS_Description', '商品名称', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ProductName'
go

exec sp_addextendedproperty 'MS_Description', '规格编码', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'SkuCode'
go

exec sp_addextendedproperty 'MS_Description', '规格名称', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'SkuName'
go

exec sp_addextendedproperty 'MS_Description', '通知数量', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'NoticeQty'
go

exec sp_addextendedproperty 'MS_Description', '入库数量', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InQty'
go

