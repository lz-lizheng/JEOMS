
/**********************
*create by：QiaoNi
*remark ：订单优惠
*date:2017-06-19
***********************/
  Create View V_ReportSalesOrderDiscount as
 select sd.DiscountId, so.PayDate,so.Code,so.TradeId, so.StoreId, so.StoreName,
	DiscountType,
	sd.DiscountName,sd.Amount 
From SalesOrderDiscount sd
Inner join SalesOrder so on so.OrderId=SalesOrderId 
Where SO.isobsolete = 0
go

