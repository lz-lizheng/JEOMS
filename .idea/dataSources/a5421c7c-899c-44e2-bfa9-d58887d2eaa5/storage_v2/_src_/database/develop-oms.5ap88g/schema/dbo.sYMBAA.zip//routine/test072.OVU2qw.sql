create procedure test072
as
 begin
     select * 
     from Company s
 end
go

