

 
 /**********************
*create by：QiaoNi 2017-12-23
-remark 开票商品类目 税局类目对照表 
***********************/  
CREATE  View V_InvoiceCategoryMap as
Select Hdr.Code, Hdr.Name, ProductCategoryId, ProductCategoryCode
From [dbo].[InvoiceCategory] Hdr 
Join InvoiceCategoryDetail Dtl on hdr.id = dtl.InvoiceCategoryId
where Hdr.isDisabled = 0
 go

