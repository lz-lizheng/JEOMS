/**
*create date : 2019-12-16
*create modify：拓斗
*remark ：商品库存跟踪添加品牌查询&显示
*/
CREATE view V_ApiProductInventoryTracking      
as      
SELECT APIT.Id,APIT.AdjustmentQuantity,APIT.ChangeDate,APIT.Memo,        
APIT.OperatorDate,APIT.OperatorUser,APIT.OrderCode,APIT.OrderType,        
APIT.OriginalQuantity,APIT.ProductSkuCode,APIT.Quantity,APIT.WareHouseCode,        
w.Name WareHouseName, PS.ProductCode, ps.ProductName, ps.Description,        
APIT.VirtualWarehouseCode,APIT.VirtualWarehouseName,      
w.Id WarehouseId,P.BrandCode,P.Brand as BrandName
FROM dbo.ApiProductInventoryTracking APIT(NOLOCK)        
LEFT JOIN ProductSku PS(NOLOCK) ON APIT.ProductSkuCode = PS.Code     
left join Product p(nolock) on PS.ProductId=p.ProductId
left join Warehouse w on w.Code = APIT.WareHouseCode        
WHERE ps.Status = 1 and w.IsDisabled=0
go

