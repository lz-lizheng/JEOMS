
 
/**********************
*create by：Qiaoni
*remark ：预售销售统计
*date:2017-08-24
***********************/
Create View V_PreSellPlanSale As
Select Pre.Id, Pre.Code, Pre.SkuCode,Pre.PreSellQuantity,Pre.BeginDate,Pre.EndDate,Pre.StoreId, Sum(SOD.Quantity) as SaleQty
From (
	Select PRPD.Id, PRP.Code, prpd.SkuCode, prpd.PreSellQuantity, PRP.BeginDate, ISNULL(PRPD.EndDate, PRP.EndDate) as EndDate, PRPS.StoreId
	From PreSellPlan PRP(nolock)
	Left JOin PreSellPlanDetail PRPD(nolock) on prp.Id = PRPD.PreSellPlanId
	Left JOin PreSellPlanStore PRPS(nolock) on PRP.Id = PRPS.PreSellPlanId 
	) Pre
	Left Join 
	(
		Select so.StoreId, so.PayDate, sod.ShippingDateClerk, sod.SkuCode, sod.Quantity
		From SalesOrder SO(nolock)
		Left JOin SalesOrderDetail SOD(nolock) on so.OrderId = sod.SalesOrderId
		and sod.IsDeleted = 0
	) SOD on sod.PayDate >= Pre.BeginDate and sod.ShippingDateClerk between pre.BeginDate and Pre.EndDate and sod.SkuCode = pre.SkuCode and sod.StoreId = pre.StoreId
Group By Pre.Id, Pre.Code,Pre.SkuCode,Pre.PreSellQuantity,Pre.BeginDate,Pre.EndDate,Pre.StoreId

go

