  
 Create Procedure P_Cacl_TableRow
  As
 Begin

		IF NOT EXISTS(SELECT * FROM sys.sysobjects WHERE name = 'TempTableRowCount')
			Begin
				Create Table TempTableRowCount(TableName nvarchar(100), RowCnt BigInt)
			End;

		Truncate Table TempTableRowCount;

		Declare @V_SQL nvarchar(1000) 
	
		Declare MyCursor Cursor  for 
			Select 'Insert Into TempTableRowCount Select '''+ Name + ''', Count(1) as RowCnt From  ' + Name + ' (nolock)' as CntSQL
			From sys.sysobjects 
			where xtype = 'U'
		open MyCursor
		Fetch Next from MyCursor into @V_SQL;
 
		while(@@Fetch_Status=0)
		 begin
		  --begin
			Exec SP_EXECUTESQL @V_SQL;
		  --end
		  Fetch Next from MyCursor into @V_SQL;
		 end

		close MyCursor
		Deallocate MyCursor

		Select * 
		From TempTableRowCount
		Order By RowCnt Desc

End;
 go

