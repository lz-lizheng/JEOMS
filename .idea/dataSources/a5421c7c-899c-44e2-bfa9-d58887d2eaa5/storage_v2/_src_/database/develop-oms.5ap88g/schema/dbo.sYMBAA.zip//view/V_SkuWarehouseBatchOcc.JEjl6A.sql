CREATE VIEW [dbo].[V_SkuWarehouseBatchOcc]    
AS     
SELECT a.SkuId,w.Id WarehouseId,a.Quantity InventoryQty,a.Quantity-ISNULL(SUM(occ.Quantity),0) Quantity,a.BatchCode,SkuCode   
FROM     
(SELECT SkuId,WarehouseId,BatchCode,SkuCode,SUM(ISNULL(Quantity,0)) Quantity     
FROM dbo.ApiOrderBatchRecord GROUP BY SkuId,WarehouseId,BatchCode,SkuCode) a     
LEFT JOIN dbo.Warehouse w ON w.ParentId=a.WarehouseId     
LEFT JOIN dbo.InventoryOccupation occ ON occ.WarehouseId=w.Id AND occ.SkuId=a.SkuId AND occ.BatchCode=a.BatchCode    
GROUP BY a.SkuId,w.Id,a.BatchCode,a.SkuCode,a.WarehouseId,a.Quantity
go

