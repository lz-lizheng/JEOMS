CREATE VIEW [dbo].[V_InventoryVirtual]
AS
 SELECT v.IsLockStock,v.WarehouseCode, v.WarehouseId, v.Quantity, v.LockedQuantity, v.DispatchedQuantity,v.IsO2O, v.UnDispatchedQuantity, v.AllotQuantity, v.VipQuantity,v.CombQuantity, v.CanSaleQuantity, v.CanUseQuantity, v.TransitTotalQuantity, p.Brand, p.Season,p.Year,p.CategoryId,p.CategoryName,p.FirstLevelCategoryName,p.TwoLevelCategoryName,sku.ProductId, sku.ProductCode, sku.ProductName, sku.SkuId, sku.Code, sku.Description,sku.CustomCode,sku.SKC,sku.Color,sku.Size,sku.FirstPrice,p.ShortName as ProductShortName,w2.Code as WarehouseEntityCode,w2.Name as WarehouseEntityName
FROM ProductSku sku
JOIN Product p ON sku.ProductId=p.ProductId
JOIN (SELECT iv.WarehouseId WarehouseId ,
iv.SkuId SkuId ,
isnull(iv.IsLockStock,0) IsLockStock,
ISNULL(iv.Quantity, 0) Quantity , 
ios.LockedQuantity ,
ios.DispatchedQuantity ,
ios.UnDispatchedQuantity ,
ios.AllotQuantity ,
ios.VipQuantity ,
ios.CombQuantity,
(ISNULL(iv.Quantity, 0)-ISNULL(ios.LockedQuantity, 0)) AS CanSaleQuantity ,
(ISNULL(iv.Quantity, 0)-ISNULL(ios.DispatchedQuantity, 0)-ISNULL(ios.AllotQuantity, 0)-ISNULL(ios.VipQuantity, 0)-ISNULL(ios.CombQuantity, 0)) AS CanUseQuantity ,
TransitTotalQuantity,
w.IsO2O,
w.Code as WarehouseCode,
w.ParentId
 FROM V_InventoryVirtualMap iv
 JOIN Warehouse w ON iv.warehouseId=w.Id
 LEFT JOIN V_InventoryOccupationSum ios ON iv.SkuId=ios.SkuId AND iv.WarehouseId=ios.WarehouseId) v ON sku.SkuId=v.SkuId
 join Warehouse w2 on v.ParentId = w2.Id
 where sku.Status=1
go

