CREATE VIEW [dbo].[V_View_Financ_ReturnInfo]
AS
SELECT ds.DistributorCode AS CustCode,
       ds.DistributorName AS CustName,
       ST.Code AS StoreCode,
       ST.Id StoreId,
       ST.Name AS StoreName,
       ro.ReturnOrderTypeCode,
       ro.WarehouseInName,
       ro.WarehouseInId AS WarehouseId,
       ro.Code AS ReturnCode,
       ro.TradeId AS DistributorId,
       ro.SalesOrderCode AS FromTradeId,
       ro.NoticeCode AS FromCode,
       (CASE ST.StoreType
            WHEN 2 THEN
                '零售'
            ELSE
                '代发'
        END
       ) AS OrderType,
       ro.ExpressNo,
       ro.ExpressName,
       rod.ProductCode,
       rod.ProductName,
       rod.SkuCode AS SkuCode,
       pds.Size AS size,
       pds.Color,
       pd.Year AS year,
       pd.Season,
       pds.SKC AS skc,
       (CASE pd.Attribute1
            WHEN '0' THEN
                '中性'
            WHEN '1' THEN
                '男'
            WHEN '2' THEN
                '女'
            WHEN '3' THEN
                '男童'
            WHEN '4' THEN
                '女童'
            WHEN '5' THEN
                '童中性'
            ELSE
                ''
        END
       ) AS Sex,
       (CASE
            WHEN LEFT(CategoryCode, 1) = 1 THEN
                '鞋'
            WHEN LEFT(CategoryCode, 1) = 2 THEN
                '服装'
            WHEN LEFT(CategoryCode, 1) = 3 THEN
                '配件'
            WHEN LEFT(CategoryCode, 1) = 4 THEN
                '店铺用品'
            WHEN LEFT(CategoryCode, 1) = 5 THEN
                '陈列道具'
            ELSE
                ''
        END
       ) AS Category,
       NULL AS CategoryName,
       rod.Quantity,
       pd.FirstPrice AS PriceOriginal,
       (CASE ST.StoreType
            WHEN 2 THEN
                rod.RefundAmount / rod.Quantity
            ELSE
                rod.DistributionAmount / rod.Quantity
        END
       ) AS Price,
       (CASE ST.StoreType
            WHEN 2 THEN
                rod.RefundAmount
            ELSE
                rod.DistributionAmount
        END
       ) AS ActualAmount,
       ro.CreateDate,
       rond.WarehouseStorageTime
FROM ReturnOrder ro (NOLOCK)
    JOIN ReturnOrderDetail rod (NOLOCK)
        ON ro.Id = rod.ReturnOrderId
    JOIN ReturnOrderNoticeDetail rond (NOLOCK)
        ON rod.Id = rond.ReturnOrderDetailId
    JOIN Store ST (NOLOCK)
        ON ro.StoreId = ST.Id
    LEFT JOIN V_DistributorStore ds (NOLOCK)
        ON ro.StoreId = ds.StoreId
    JOIN Product pd (NOLOCK)
        ON rod.ProductId = pd.ProductId
    JOIN ProductSku pds (NOLOCK)
        ON rod.SkuId = pds.SkuId
WHERE ro.StorageStatus = '2'
      AND rond.InQuantity > 0

--Vip退  
UNION ALL
SELECT NULL AS CustCode,
       NULL AS CustName,
       '40005-01' AS storeName,
       'FE15AAA6-12AB-445E-B519-C942D71EF501' AS StoreId,
       '唯品会鸿星尔克旗舰店' AS StoreName,
       NULL AS ReturnOrderTypeCode,
       vro.InWarehouseName,
       vro.InWarehouseId AS WarehouseId,
       vro.ReturnOrderCode AS ReturnCode,
       NULL AS DistributorId,
       NULL AS FromTradeId,
       vro.VipReturnOrderNoticeCode AS FromCode,
       '唯品退货' AS OrderType,
       NULL AS expressNo,
       NULL AS expressName,
       vrod.ProductCode,
       vrod.ProductName,
       vrod.SkuCode AS SkuCode,
       pds.Size AS size,
       pds.Color,
       pd.Year AS year,
       pd.Season,
       pds.SKC AS skc,
       (CASE pd.Attribute1
            WHEN '0' THEN
                '中性'
            WHEN '1' THEN
                '男'
            WHEN '2' THEN
                '女'
            WHEN '3' THEN
                '男童'
            WHEN '4' THEN
                '女童'
            WHEN '5' THEN
                '童中性'
            ELSE
                ''
        END
       ) AS Sex,
       (CASE
            WHEN LEFT(CategoryCode, 1) = 1 THEN
                '鞋'
            WHEN LEFT(CategoryCode, 1) = 2 THEN
                '服装'
            WHEN LEFT(CategoryCode, 1) = 3 THEN
                '配件'
            WHEN LEFT(CategoryCode, 1) = 4 THEN
                '店铺用品'
            WHEN LEFT(CategoryCode, 1) = 5 THEN
                '陈列道具'
            ELSE
                ''
        END
       ) AS Category,
       NULL AS CategoryName,
       vrod.InQty,
       pd.FirstPrice AS PriceOriginal,
       vod.SupplyPrice AS Price,
       vod.SupplyPrice * vrod.InQty AS ActualAmount,
       vro.CreateDate,
       vrod.WarehouseStorageTime AS WarehouseStorageTime
FROM VipReturnOrderNotice vro (NOLOCK)
    JOIN VipReturnOrderNoticeDetail vrod (NOLOCK)
        ON vro.Id = vrod.ReturnOrderNoticeId
    JOIN VipReturnOrder vo (NOLOCK)
        ON vro.ReturnOrderCode = vo.ReturnOrderCode
    INNER JOIN VipReturnOrderDetail vod (NOLOCK)
        ON vo.Id = vod.ReturnOrderId
           AND vrod.SkuCode = vod.SkuCode
    JOIN Product pd (NOLOCK)
        ON vrod.ProductId = pd.ProductId
    JOIN ProductSku pds (NOLOCK)
        ON vrod.SkuId = pds.SkuId
WHERE vod.Id IN
      (
          SELECT TOP 1
                 vod.Id
          FROM VipReturnOrderDetail vod (NOLOCK)
          WHERE vrod.SkuCode = vod.SkuCode
                AND vo.Id = vod.ReturnOrderId
      )
      AND vro.Status = 3

--批发退货单  
UNION ALL
SELECT ds.Code AS CustCode,
       ds.Name AS CustName,
       NULL AS storeName,
       NULL AS StoreId,
       NULL AS StoreName,
       NULL AS ReturnOrderTypeCode,
       vro.InWarehouseName,
       vro.InWarehouseId AS WarehouseId,
       vro.Code AS ReturnCode,
       NULL AS DistributorId,
       NULL AS FromTradeId,
       vro.Code AS FromCode,
       '批发退货' AS OrderType,
       NULL AS expressNo,
       NULL AS expressName,
       vrod.ProductCode,
       vrod.ProductName,
       vrod.SkuCode AS SkuCode,
       pds.Size AS size,
       pds.Color,
       pd.Year AS year,
       pd.Season,
       pds.SKC AS skc,
       (CASE pd.Attribute1
            WHEN '0' THEN
                '中性'
            WHEN '1' THEN
                '男'
            WHEN '2' THEN
                '女'
            WHEN '3' THEN
                '男童'
            WHEN '4' THEN
                '女童'
            WHEN '5' THEN
                '童中性'
            ELSE
                ''
        END
       ) AS Sex,
       (CASE
            WHEN LEFT(CategoryCode, 1) = 1 THEN
                '鞋'
            WHEN LEFT(CategoryCode, 1) = 2 THEN
                '服装'
            WHEN LEFT(CategoryCode, 1) = 3 THEN
                '配件'
            WHEN LEFT(CategoryCode, 1) = 4 THEN
                '店铺用品'
            WHEN LEFT(CategoryCode, 1) = 5 THEN
                '陈列道具'
            ELSE
                ''
        END
       ) AS Category,
       NULL AS CategoryName,
       vrod.InQty,
       pd.FirstPrice AS PriceOriginal,
       vrod.DiscountAmount AS Price,
       vrod.DiscountAmount * vrod.InQty AS ActualAmount,
       vro.CreateDate,
       vrod.WarehouseStorageTime AS WarehouseStorageTime
FROM WholesaleReturnOrder vro (NOLOCK)
    JOIN WholesaleReturnOrderDetail vrod (NOLOCK)
        ON vro.Id = vrod.WholesaleReturnId
    LEFT JOIN Distributor ds (NOLOCK)
        ON vro.DistributorId = ds.Id
    JOIN Product pd (NOLOCK)
        ON vrod.ProductId = pd.ProductId
    JOIN ProductSku pds (NOLOCK)
        ON vrod.SkuId = pds.SkuId
WHERE vro.Status = 8

--B2B退货单  
UNION ALL
SELECT NULL AS CustCode,
       NULL AS CustName,
       st.Code AS storeName,
       bso.StoreId AS StoreId,
       bso.StoreName AS StoreName,
       NULL AS ReturnOrderTypeCode,
       bso.OutWarehouseName,
       bso.OutWarehouseId AS WarehouseId,
       bso.Code AS ReturnCode,
       NULL AS DistributorId,
       NULL AS FromTradeId,
       bso.Code AS FromCode,
       'B2B销售退货' AS OrderType,
       NULL AS expressNo,
       NULL AS expressName,
       bsod.ProductCode,
       bsod.ProductName,
       bsod.SkuCode AS SkuCode,
       pds.Size AS size,
       pds.Color,
       pd.Year AS year,
       pd.Season,
       pds.SKC AS skc,
       (CASE pd.Attribute1
            WHEN '0' THEN
                '中性'
            WHEN '1' THEN
                '男'
            WHEN '2' THEN
                '女'
            WHEN '3' THEN
                '男童'
            WHEN '4' THEN
                '女童'
            WHEN '5' THEN
                '童中性'
            ELSE
                ''
        END
       ) AS Sex,
       (CASE
            WHEN LEFT(CategoryCode, 1) = 1 THEN
                '鞋'
            WHEN LEFT(CategoryCode, 1) = 2 THEN
                '服装'
            WHEN LEFT(CategoryCode, 1) = 3 THEN
                '配件'
            WHEN LEFT(CategoryCode, 1) = 4 THEN
                '店铺用品'
            WHEN LEFT(CategoryCode, 1) = 5 THEN
                '陈列道具'
            ELSE
                ''
        END
       ) AS Category,
       NULL AS CategoryName,
       bsod.Qty,
       pd.FirstPrice AS PriceOriginal,
       bsod.SellingPrice AS Price,
       bsod.Amount AS ActualAmount,
       bso.CreateDate,
       bso.AuditDate AS WarehouseStorageTime
FROM B2BSalesOrder bso (NOLOCK)
    JOIN B2BSalesOrderDetail bsod (NOLOCK)
        ON bso.Id = bsod.SalesOrderId
    JOIN Store st (NOLOCK)
        ON bso.StoreId = st.Id
    JOIN Product pd (NOLOCK)
        ON bsod.ProductId = pd.ProductId
    JOIN ProductSku pds (NOLOCK)
        ON bsod.SkuId = pds.SkuId
    LEFT JOIN V_DistributorStore ds (NOLOCK)
        ON bso.StoreId = ds.StoreId
WHERE bso.Status = 2
      AND bso.OrderType = 1;
go

