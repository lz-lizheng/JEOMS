



-- =============================================
-- Author:		Qiaoni
-- Create date: 2017-06-21
-- Description:	计算两地址的距离
-- Modify : 2018-05-24 空时返回 0
-- =============================================
CREATE FUNCTION [dbo].[F_GetAddressDistance]
(
	@FromProvince nvarchar(100),
	@FromCity nvarchar(100),
	@FromDistrict nvarchar(100),
	@ToProvince nvarchar(100),
	@ToCity nvarchar(100),
	@ToDistrict nvarchar(100)
)
RETURNS Decimal(10, 3)
AS
BEGIN 
	Declare @V_Result Decimal(10, 3);

	 Select @V_Result = DBO.F_GetDistance(FrReg.Lat, FrReg.Lng, ToReg.Lat, ToReg.Lng)
	 From [dbo].[F_Get_AddressLatLng](@FromProvince, @FromCity, @FromDistrict) as FrReg
	 Cross Join [dbo].[F_Get_AddressLatLng](@ToProvince, @ToCity, @ToDistrict) as ToReg
	 
	Return isnull(@V_Result, 0);
END
go

