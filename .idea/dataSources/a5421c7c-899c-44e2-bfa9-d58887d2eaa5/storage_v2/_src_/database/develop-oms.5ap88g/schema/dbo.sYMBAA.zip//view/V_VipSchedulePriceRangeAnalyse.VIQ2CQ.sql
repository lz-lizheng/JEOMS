--唯品档期"/>PO号" Fie开始时间""/>款式数量"备货库存"剩余库存"售罄率" F 销售额" F"/>件单价" Ft"/>销量（件）"/>退货数量""/>退货率" F
  
CREATE VIEW V_VipSchedulePriceRangeAnalyse AS 
SELECT Sale.PoCode ,
	   Sale.PriceRange,
	   sale.BeginRange,
       SUM(Sale.PlanQty) AS PlanQty ,
       SUM(Sale.RemainingInventory) AS RemainingInventory ,
       SUM(Sale.SaleQty) AS SaleQty,
       SUM(Sale.SaleAmount) AS SaleAmount,
       SUM(Rtn.RtnQty) AS RtnQty 
FROM (
		SELECT  vs.PoCode,
				vsd.ProductCode, 
				vsd.SupplyPrice,
				FLOOR((CASE WHEN vsd.SupplyPrice = 0 THEN 0 ELSE vsd.SupplyPrice -0.01 end) * 1.0 / 50) * 50 AS BeginRange,
				CAST(FLOOR((CASE WHEN vsd.SupplyPrice = 0 THEN 0 ELSE vsd.SupplyPrice -0.01 end) * 1.0 / 50) * 50 AS VARCHAR(20)) + ' - ' + CAST(CEILING((vsd.SupplyPrice-0.01) * 1.0 / 50) * 50 AS NVARCHAR(20)) AS PriceRange,
				SUM(vsd.PlanQty) AS PlanQty, 
				SUM(vsd.PlanQty - vsd.OutQty) AS RemainingInventory,
				SUM(vsd.OutQty) * 1.0 / SUM(vsd.PlanQty) AS SaleThroughRate,
				SUM(vsd.OutQty) AS SaleQty,
				SUM(Vsd.OutQty * vsd.SupplyPrice) AS SaleAmount 
		FROM dbo.VipSchedule vs(NOLOCK)
		LEFT JOIN dbo.VipScheduleDetail vsd(NOLOCK) ON vs.Id = vsd.ScheduleId  
		WHERE vsd.PlanQty > 0
		GROUP BY vs.PoCode, vsd.ProductCode, vsd.SupplyPrice

	) Sale
LEFT JOIN 
	(	
		SELECT vrod.PoCode, vrod.ProductCode, SUM(vrod.ReturnQty) AS RtnQty
		FROM dbo.VipReturnOrder vro(NOLOCK)
		LEFT JOIN dbo.VipReturnOrderDetail vrod(NOLOCK) ON vro.Id = vrod.ReturnOrderId 
		GROUP BY vrod.PoCode, vrod.ProductCode
	) Rtn ON Rtn.PoCode = Sale.PoCode AND rtn.ProductCode = Sale.ProductCode
GROUP BY Sale.PoCode, Sale.PriceRange, Sale.BeginRange

go

