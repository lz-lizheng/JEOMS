CREATE FUNCTION GetOrderByUniqueCode(  
@UniqueCode NVARCHAR(50)  
)  
RETURNS @temp TABLE (OrderCode nvarchar(50),OrderType INT,ErrMsg NVARCHAR(100))  
AS  
BEGIN  
 IF NOT EXISTS (SELECT 1 FROM dbo.UniqueCodeDetail WHERE UniqueCode=@UniqueCode)  
 BEGIN  
  INSERT INTO @temp SELECT '',-1,'唯一码'+@UniqueCode+'在系统中不存在'  
  RETURN  
 END  
 --2C退货单匹配  
 IF EXISTS (SELECT 1 FROM dbo.ReturnOrderDetail WHERE UniqueCode=@UniqueCode)  
 BEGIN  
  INSERT INTO @temp SELECT TOP 1 ro.Code,103,'' FROM dbo.ReturnOrderDetail rod LEFT JOIN dbo.ReturnOrder ro ON ro.Id=rod.ReturnOrderId WHERE rod.UniqueCode=@UniqueCode AND ISNULL(ro.IsAbnormal,0)=0  
  RETURN   
 END
 --批发退货单
 IF EXISTS (SELECT 1 FROM dbo.WholesaleReturnOrderDetail WHERE UniqueCode=@UniqueCode)  
 BEGIN  
  INSERT INTO @temp SELECT TOP 1 ro.Code,1002,'' FROM dbo.WholesaleReturnOrderDetail rod LEFT JOIN dbo.WholesaleReturnOrder ro ON ro.Id=rod.WholesaleReturnId WHERE rod.UniqueCode=@UniqueCode
  RETURN   
 END
 --不存在退货记录
 INSERT INTO @temp SELECT '',-1,'唯一码'+@UniqueCode+'在系统中不存在退货记录'  
 RETURN  
END


go

