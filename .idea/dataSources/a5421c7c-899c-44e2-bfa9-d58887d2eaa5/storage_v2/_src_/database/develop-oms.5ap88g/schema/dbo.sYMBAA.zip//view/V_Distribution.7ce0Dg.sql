
/**********************
*create date : 2021-07-21
*create by：哲别
*remark ：由于表结构改变时，视图未刷新，导致视图数据异常，需重刷视图脚本
***********************/
CREATE VIEW [dbo].[V_Distribution] AS 
SELECT    d.*,dp.*
      FROM      Distribution d
      JOIN      DistributionProduct dp ON d.Id=dp.DistributionId

go

