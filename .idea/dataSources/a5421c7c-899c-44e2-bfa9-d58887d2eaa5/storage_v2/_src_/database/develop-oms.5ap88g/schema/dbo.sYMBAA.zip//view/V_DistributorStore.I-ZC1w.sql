CREATE VIEW V_DistributorStore
AS
SELECT d.Code AS DistributorCode,
       d.Name AS DistributorName,
       ds.StoreId,
       ds.StoreName
FROM Distributor d (NOLOCK)
    JOIN DistributorStore ds (NOLOCK)
        ON d.Id = ds.DistributorId;
go

