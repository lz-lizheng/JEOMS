
/********
*create date: 2019-6-24
*create by：拓斗
*remark ：若羽臣-2B&2C出库汇总表视图
*******/
CREATE VIEW [dbo].[V_OutboundSummary]
AS
SELECT StoreId,StoreCode,StoreName,DeliveryDate,SUM(DisNum) DisNum,SUM(SaleNum) SaleNum,SUM(B2bNum) B2bNum,isnull(SUM(Quantity),0) Quantity,
isnull(SUM(ExpressFee),0) ExpressFee,isnull(SUM(AmountActual),0) AmountActual
FROM
(
--计算有配货单订单的数量及结算金额
select s.Id StoreId,s.Code StoreCode,s.Name StoreName,do.DeliveryDate,COUNT(distinct dod.DispatchOrderId) DisNum,
0 SaleNum,0 B2bNum,SUM(sod.Quantity) Quantity,0 ExpressFee,SUM(sod.AmountActual) AmountActual
from DispatchOrder do
join DispatchOrderDetail dod on do.Id=dod.DispatchOrderId
join SalesOrderDetail sod on sod.DetailId=dod.SalesOrderDetailId
join SalesOrder so on so.OrderId=sod.SalesOrderId
join Store s on s.Id=so.StoreId 
WHERE so.Status=32 AND sod.Status=2 and sod.IsAbnormal=0
and isnull(sod.IsDeleted,0)=0 and dod.Status=2 and do.Status=4
and so.TransType<>2
GROUP BY s.Id,s.Code,s.Name,so.StoreId,do.DeliveryDate,so.ExpressFee,so.OrderId

union all
--计算有配货单订单的运费
select StoreId,StoreCode,StoreName,DeliveryDate,DisNum,SaleNum,B2bNum,Quantity,ExpressFee,AmountActual from (
select ROW_NUMBER() over(partition by so.Code order by do.DeliveryDate) rowId,s.Id StoreId,s.Code StoreCode,s.Name StoreName,do.DeliveryDate DeliveryDate,0 DisNum,
0 SaleNum,0 B2bNum,0 Quantity,so.ExpressFee,0 AmountActual
from DispatchOrder do
join DispatchOrderDetail dod on do.Id=dod.DispatchOrderId
join SalesOrderDetail sod on sod.DetailId=dod.SalesOrderDetailId
join SalesOrder so on so.OrderId=sod.SalesOrderId
join Store s on s.Id=so.StoreId
WHERE so.Status=32 AND sod.Status=2 and sod.IsAbnormal=0
and isnull(sod.IsDeleted,0)=0 and dod.Status=2 and do.Status=4
and so.TransType<>2)a
where a.rowId=1

UNION ALL
--计算费用订单的数据（数量、运费、金额）
SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,so.CreateDate,0 DisNum,COUNT(distinct so.OrderId) SaleNum,0 B2bNum,
SUM(sod.Quantity) Quantity,so.ExpressFee,SUM(sod.AmountActual) AmountActual
FROM dbo.SalesOrder so
LEFT JOIN dbo.SalesOrderDetail sod ON sod.SalesOrderId=so.OrderId
LEFT JOIN dbo.Store s ON so.StoreId=s.Id
WHERE so.TransType=2
AND so.Status=32 AND sod.Status=2 and sod.IsAbnormal=0
and isnull(sod.IsDeleted,0)=0
GROUP BY s.Id,s.Code,s.Name,so.StoreId,so.CreateDate,so.ExpressFee,so.OrderId

UNION ALL
--计算海淘订单的数据
SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,so.CreateDate,0 DisNum,COUNT(distinct so.OrderId) SaleNum,0 B2bNum,
SUM(sod.Quantity) Quantity,so.ExpressFee,SUM(sod.AmountActual) AmountActual
FROM dbo.SalesOrder so
LEFT JOIN dbo.SalesOrderDetail sod ON sod.SalesOrderId=so.OrderId
LEFT JOIN dbo.Store s ON so.StoreId=s.Id
WHERE so.TransType=0 and DispatchTypeStatus=0
AND so.Status=32 AND sod.Status=2 and sod.IsAbnormal=0
and isnull(sod.IsDeleted,0)=0
GROUP BY s.Id,s.Code,s.Name,so.StoreId,so.CreateDate,so.ExpressFee,so.OrderId

union all
--计算2b订单的数据
SELECT s.Id StoreId,s.Code StoreCode,s.Name StoreName,aod.WarehouseDeliveryTime DeliveryDate,0 DisNum,0 SaleNum,
COUNT(distinct ao.Code) B2bNum,SUM(aod.OutQty) Quantity,ao.ExpressFee,SUM(aod.Price*aod.OutQty) AmountActual
FROM dbo.B2BAllocationOut ao
LEFT JOIN dbo.B2BAllocationOutDetail aod ON aod.OutCode=ao.Code
LEFT JOIN dbo.Store s ON ao.StoreId=s.Id
WHERE ao.Status IN (3,4,11)
GROUP BY s.Id,s.Code,s.Name,ao.StoreId,aod.WarehouseDeliveryTime,ao.Id,ao.ExpressFee
)b
GROUP BY StoreId,StoreCode,StoreName,DeliveryDate
go

