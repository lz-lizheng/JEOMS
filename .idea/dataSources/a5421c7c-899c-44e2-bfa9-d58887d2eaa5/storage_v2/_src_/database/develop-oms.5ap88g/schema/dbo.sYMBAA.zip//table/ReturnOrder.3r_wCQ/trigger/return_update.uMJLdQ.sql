
CREATE trigger [dbo].[return_update]
on [dbo].[ReturnOrder]
for update
as
declare @storageStatus int
set @storageStatus = 0
if update(storageStatus)
begin
select top 1 @storageStatus=storageStatus from inserted where storageStatus = 2 and TradeId is not null
if @storageStatus=2
begin
insert into OrderTrigger select i.id,103,GETDATE(),1 from inserted i left join ReturnOrder d on d.Id = i.Id where i.storageStatus = 2 and d.storageStatus = 2
end
end
go

