



CREATE trigger [dbo].[tgr_update]
on [dbo].[DispatchOrder]
for update
as
declare @noticeStatus int ,@deliverStatus int,@cancelStatus int,@id bigint
set @noticeStatus = 0
set @deliverStatus=0
set @cancelStatus=0
if update(Status)
begin
select top 1 @noticeStatus=status from inserted where Status = 2 
if @noticeStatus=2
begin
insert into OrderTrigger select i.id,102,GETDATE(),1 from inserted i left join DispatchOrder d on d.Id = i.Id where i.Status = 2 and d.Status = 2
end
select top 1 @cancelStatus=status from inserted where Status = 3
if @cancelStatus =3
begin
insert into OrderTrigger select i.id,102,GETDATE(),3 from Deleted i left join DispatchOrder d on d.Id = i.Id where i.Status = 2 and d.Status = 3
end
select top 1 @deliverStatus=status from inserted where Status = 4
if @deliverStatus =4
begin
insert into OrderTrigger select i.id,102,GETDATE(),2 from inserted i left join DispatchOrder d on d.Id = i.Id where i.Status = 4 and d.Status = 4
end
end

go

disable trigger tgr_update on DispatchOrder
go

