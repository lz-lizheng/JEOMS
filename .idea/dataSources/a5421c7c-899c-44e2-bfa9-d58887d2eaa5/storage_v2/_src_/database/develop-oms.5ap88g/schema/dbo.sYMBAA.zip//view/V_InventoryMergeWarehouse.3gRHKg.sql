
/**********************
*modify by：Byron
*remark ：库存查询增加商品简称
*date:2020-05-26
***********************/
CREATE VIEW [dbo].[V_InventoryMergeWarehouse] 
AS 
select sum(v.Quantity) Quantity, sum(v.LockedQuantity) LockedQuantity,
sum(v.DispatchedQuantity) DispatchedQuantity, sum(v.UnDispatchedQuantity) UnDispatchedQuantity,
sum(v.AllotQuantity) AllotQuantity, sum(v.VipQuantity) VipQuantity, sum(v.CanSaleQuantity) CanSaleQuantity,
sum(v.CanUseQuantity) CanUseQuantity, sum(v.CombQuantity) CombQuantity,
sum(v.TransitTotalQuantity) TransitTotalQuantity, v.Brand, v.Season, v.Year, v.CategoryId, v.CategoryName, v.FirstLevelCategoryName,v.TwoLevelCategoryName,
v.ProductId, v.ProductCode, v.ProductName, v.SkuId, v.Code, v.Description, v.CustomCode,v.SKC,v.Color,v.Size,max(FirstPrice)FirstPrice
,v.WarehouseId,v.ProductShortName
from V_InventoryEntity v
group by v.Brand, v.Season, v.Year, v.CategoryId, v.CategoryName,v.FirstLevelCategoryName,v.TwoLevelCategoryName,
v.ProductId, v.ProductCode, v.ProductName, v.SkuId, v.Code, v.Description, v.CustomCode,v.SKC,v.Color,v.SIZE,v.WarehouseId,v.ProductShortName
go

