

/**
*create by：Byron
*remark ：库存查询添加IsLockStock字段
*date:2018-05-29
*/
CREATE View [dbo].[V_InventoryVirtualMap] as 
	 Select IV.WarehouseId, Skuid, Quantity, IV.TransitTotalQuantity,isnull(IsLockStock,0) IsLockStock
	 From InventoryVirtual Iv
	 Union All 
	 Select Distinct a.WarehouseId, A.SkuId, 0 as Quantity, 0 as TransitTotalQuantity,0 as IsLockStock
	 From InventoryOccupation A
	 where not exists(Select 1 From InventoryVirtual B where a.WarehouseId = b.WarehouseId and a.SkuId = b.SkuId)
go

