create
    definer = jusre4557wkn@`%` function calc_selling_price(s_distribute_type int, settlement_price decimal(15, 4),
                                                           distribution_price decimal(15, 4)) returns decimal(15, 4)
BEGIN
RETURN (SELECT case s_distribute_type
when 3 then 
   distribution_price
else
   settlement_price
 END
);
END;

