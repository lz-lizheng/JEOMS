create
    definer = jusre4557wkn@`%` procedure create_sap_report_whole_return(IN beginTime datetime, IN endTime datetime)
BEGIN

Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1003 Begin B2BSalesOrder', 5, 'aty_sap_report_detail', now());

	INSERT IGNORE INTO `aty_sap_report_detail` (
		`created_time`,
		`oms_order_id`,
		`oms_order_code`,
		`oms_order_detail_id`,
		`order_type`,
		`product_id`,
		`product_code`,
		`product_name`,
		`quantity`,
		`sku_id`,
		`sku_code`,
		`sku_name`,
		`settlement_price`,
		`settlement_amount`,
		`distribution_price`,
		`cost_price`,
		`selling_amount`,
		`warehouse_operation_point`,
		`delivery_return_time`,
		`virtual_warehouse_id`,
		`unique_code` 
	) SELECT
	now(),
	owr.whole_sales_return_order_id AS oms_order_id,
  owr.whole_sales_return_order_code AS oms_order_code,
	owrd.whole_sales_return_order_detail_id AS oms_order_detail_id,
	806,
	owrd.product_id AS product_id,
	owrd.product_code AS product_code,
	owrd.product_name AS product_name,
	owrd.in_quantity+owrd.in_substandard_quantity AS quantity,
	owrd.sku_id AS sku_id,
	owrd.sku_code AS sku_code,
	owrd.sku_name AS sku_name,
	owrd.discounted_price AS settlement_price,
	owrd.discounted_price * owrd.in_quantity AS settlement_amount,
	owrd.discounted_price AS distribution_price,
	IFNULL( sku.cost_price, 0 ) AS cost_price,
	owrd.discounted_price * (owrd.in_quantity+owrd.in_substandard_quantity) AS selling_amount,
	0 AS warehouse_operation_point,
	owrd.in_time AS delivery_return_time,
	owr.in_virtual_warehouse_id AS virtual_warehouse_id,
    CONCAT('WHOLE_SALES_RETURN_ORDER',owrd.whole_sales_return_order_detail_id ) as unique_code
	FROM
	 oms_whole_sales_return_order owr
    INNER JOIN oms_whole_sales_return_order_detail owrd ON owr.whole_sales_return_order_id =
    owrd.whole_sales_return_order_id
    INNER JOIN oms_product_sku sku ON owrd.sku_id = sku.sku_id
	WHERE
		owr.last_in_time >= beginTime 
		AND owr.last_in_time < endTime
		AND owr.in_status IN (2,3);
	
Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1003 End SalesOrder', 6, 'aty_sap_report_detail', now());

Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1004 End SalesOrder Check', 7, 'aty_sap_report_check', now());

INSERT IGNORE INTO aty_sap_report_check
	SELECT
	a.order_type `单据类型`,
	a.oms_order_id `单据ID`,
	a.oms_order_code `单据编码`,
	a.oms_order_detail_id `单据明细ID`,
	a.sku_code 规格编码,
	null as 店铺,
	d.warehouse_name 仓库,
  null as 店铺分销类型,
CASE
		w_company.distribute_type 
		WHEN 1 THEN
		'直营' 
		WHEN 2 THEN
		'联营' ELSE '分销' 
	END 仓库分销类型,
	d.sales_type 仓库销售类型,
	null AS 分销销售类型,
	null AS 店铺公司,
	w_company.company_name AS 仓库公司,
	a.warehouse_operation_point 仓库扣点,
  null 平台类型,
	a.delivery_return_time as 业务确认时间,
	a.quantity 数量,
	a.distribution_price 分销价,
	-a.distribution_price * a.quantity 分销金额,
	a.settlement_price 电商结算价,
	-a.settlement_price * a.quantity 电商结算金额,
	a.settlement_price 仓库结算价,
	-a.settlement_price * a.quantity 仓库结算金额,
	-a.settlement_price * a.quantity 销售金额,
	a.unique_code
FROM
	aty_sap_report_detail a,
	oms_virtual_warehouse c,
	oms_warehouse d,
	oms_company w_company
WHERE
  a.virtual_warehouse_id = c.virtual_warehouse_id 
	AND c.warehouse_id = d.warehouse_id 
	AND d.company_id = w_company.company_id 
	AND order_type = 806;
	
	Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1004 End SalesOrder Check', 8, 'aty_sap_report_check', now());
	
END;

