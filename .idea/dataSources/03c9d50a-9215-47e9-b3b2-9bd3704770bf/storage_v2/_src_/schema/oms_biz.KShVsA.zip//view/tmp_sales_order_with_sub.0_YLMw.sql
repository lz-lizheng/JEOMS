create definer = jusrk6h2rspq@`%` view tmp_sales_order_with_sub as
(
select `sales`.`sales_order_id`    AS `sales_order_id`,
       `sales`.`store_id`          AS `store_id`,
       `sales`.`store_name`        AS `store_name`,
       `sub`.`sales_order_type`    AS `sales_order_type`,
       `sales`.`status`            AS `status`,
       `sales`.`settlement_amount` AS `settlement_amount`
from (`oms_biz`.`oms_sales_order` `sales`
         left join `oms_biz`.`oms_sales_order_sub` `sub` on ((`sales`.`sales_order_id` = `sub`.`sales_order_id`)))
where ((`sales`.`status` <> 100) and (`sales`.`store_id` = 14704146397791232) and
       (`sales`.`first_delivery_time` >= '2021-08-01 00:00:00.0') and
       (`sales`.`first_delivery_time` < '2021-08-02 00:00:00.0')));

