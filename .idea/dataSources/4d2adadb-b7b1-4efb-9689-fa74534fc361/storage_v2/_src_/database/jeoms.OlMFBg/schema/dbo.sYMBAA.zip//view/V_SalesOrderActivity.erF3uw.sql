
---------------------------------乔尼


/**********************
*create by：Qiaoni
*remark ：订单活动销量视图调整
*date:2017-08-21
***********************/
CREATE View V_SalesOrderActivity as 
SELECT ActivityId, SOD.ProductSkuId, Sum(Quantity) as SalesQty   
From (
	Select Distinct ActivityId, SalesOrderId
	From SalesOrderActivity(nolock)
	Where ActivityId is not null
	) SOA
LEFT join SalesOrderDetail SOD(nolock) on SOA.SalesOrderId = SOD.SalesOrderId 
GROUP by ActivityId, SOD.ProductSkuId

go

