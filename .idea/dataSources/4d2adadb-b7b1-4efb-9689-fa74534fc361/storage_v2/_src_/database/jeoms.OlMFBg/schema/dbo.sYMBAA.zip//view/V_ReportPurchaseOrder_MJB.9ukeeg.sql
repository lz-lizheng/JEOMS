

/**********************
*create by：QiaoNi 20180227 
-remark   ：美甲帮 采购汇总报表
***********************/ 
--QiaoNi 20180227
--采购时间，入库时间，货期，供应商，采购员，采购单号，采购数量，采购金额，财务成本=采购价/(1+税率) ，入库数量 
--因财务成本在系统没有，需要根据开票类型和税率决定 供应商中加开票类型
--普通发票： 财务成本 = 采购价 
--专票 ： 财务 = 采购 / (1 + 税率)
Create VIEW [dbo].[V_ReportPurchaseOrder_MJB] AS 
SELECT 
	   Cast(PO.PurchaseDate as Date) as PurchaseDate,
	   Cast(PNOID.WarehouseStorageTime as Date) as WarehousingTime,
	   Cast(PO.RequestDeliveryDate as Date) as RequestDeliveryDate,
	   PO.SupplierCode,
	   PO.SupplierName, 
	   POD.ProductCode,
	   POD.ProductName,
	   POD.SkuCode, 
	   POD.SkuName, 
	   POD.PurchaseQty, 
	   POD.CurrentPrice AS OriginalPrice, 
	   Round(POD.CurrentPrice / Case When isnull(SSP.BillingType, 0) = 0 Then 1 Else 1 + isnull(SSP.Rate, 0) / 100 End, 2) FinalCost,
	   PNOID.StockInQty,
	   PNOID.DefectiveQuantity, 
	   PO.PurchasePersonName,
	   PO.SupplierComanyName	   
FROM PurchaseOrder PO(NOLOCK)
LEFT JOIN PurchaseOrderDetail POD(NOLOCK) ON PO.Id = pod.PurchaseOrderId
Left Join (
		Select  PNO.Id, Pno.PurchaseOrderCode, 
				Pno.PurchaseOrderId, PNOD.*
		 From PurchaseNoticeOrder PNO(nolock) Join PurchaseNoticeOrderdetail PNOD(NOLOCK)  ON PNO.Id = PNOD.PurchaseNoticeOrderId 
		) as PNO on po.Id = PNO.PurchaseOrderId And POD.SkuId = PNO.SkuId
Left Join PurchaseNoticeOrderIndetail PNOID(NOLOCK) ON PNO.DetailId = PNOID.DetailId
LEFT JOIN dbo.Supplier SSP(NOLOCK) ON po.SupplierCode = ssp.Code
go

