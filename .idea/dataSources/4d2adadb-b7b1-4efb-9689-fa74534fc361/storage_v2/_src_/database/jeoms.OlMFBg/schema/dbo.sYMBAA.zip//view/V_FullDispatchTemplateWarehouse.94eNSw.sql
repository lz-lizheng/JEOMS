
create VIEW [dbo].[V_FullDispatchTemplateWarehouse]
AS
  SELECT *
  FROM DispatchTemplateWarehouse
  WHERE WarehouseType <> 4
  UNION
  SELECT
    dtw.TemplateWarehouseId, dtw.TemplateId, w.Id, dtw.WarehouseDispatchType, dtw.IsDisabled, dtw.OrderId,
    w.WarehouseType
  FROM DispatchTemplateWarehouse dtw
    JOIN Warehouse w ON dtw.WarehouseId = w.ParentId AND dtw.WarehouseType = 4
go

