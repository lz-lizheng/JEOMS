		--2.创建P_BU_Sync_OMS_Table_Structure存储过程
		-- 存储过程： 同步表结构
		CREATE Procedure [dbo].[P_BU_Sync_OMS_Table_Structure]
		(
			@TblName nVarchar(255) = 'SalesOrder'
		)
		As
		Begin
		Print '-------------------------------------------------------'
		Print '**=Start=**  Sync Table : ' + @TblName + ' Begin. ';
		
		 Declare @AlterSql nVarchar(4000),@ToTblName nVarchar(200),
		 @ToTblDataType nvarchar(20),@ToTblCharLength nvarchar(20),
		 @FrTblDataType nvarchar(20),@FrTblCharLength nvarchar(20),
		 @ColType nvarchar(20),@ColumnName nvarchar(20)
		 
		 -- 已有字段结构调整, 新增字段, 删除字段
		 -- 遍历更新有变更的字段结构
		 Declare AlterCol Cursor For
			Select Frtbl.ColumnName,Frtbl.colType,Frtbl.columntype,Frtbl.ColLength,ToTbl.columntype,ToTbl.ColLength,
				Case When FrTbl.ColumnName is not null And ToTbl.ColumnName is not null Then 'Alter Table DBO.' + FrTbl.TableName + ' Alter Column ' + FrTbl.ColumnName + ' ' + FrTbl.colType + ';'
				When FrTbl.ColumnName is not null Then 'Alter Table DBO.' + FrTbl.TableName + ' Add ' + FrTbl.ColumnName + ' ' + FrTbl.colType + ';'
				When ToTbl.ColumnName is not null Then 'Alter Table DBO.' + FrTbl.TableName +';' End As AlterSql
		  From OMS_Sync_Table_Structure FrTbl(nolock)
		  Left Join V_View_OrderColumns ToTbl(nolock) on FrTbl.TableName = ToTbl.TableName And FrTbl.ColumnName = ToTbl.ColumnName
		  Where FrTbl.TableName = @TblName
		  And isnull(FrTbl.colType, '') <> isnull(ToTbl.colType, '')
		  Order By FrTbl.ColOrder

		 Open AlterCol
		 Fetch next From AlterCol Into @ColumnName,@ColType,@FrTblDataType,@FrTblCharLength,@ToTblDataType,@ToTblCharLength,@AlterSql;
		 While @@FETCH_STATUS = 0
			Begin
				--新增
				IF(CHARINDEX('alter',substring(@AlterSql,6,len(@AlterSql))) = 0)
					BEGIN
						Print @AlterSql;
						Exec SP_EXECUTESQL @AlterSql;
					END
				ELSE
					BEGIN
					IF EXISTS (SELECT * FROM V_View_ObjectIndex WHERE tableName = @TblName AND colName = @ColumnName)
					BEGIN
						--如果数据类型相同并且修改长度大于现在的长度(修改长度)
						IF (@ToTblDataType = @FrTblDataType AND CONVERT(int,@FrTblCharLength)>= CONVERT(int,@ToTblCharLength))
							BEGIN
								Print @AlterSql;
								Exec SP_EXECUTESQL @AlterSql;
							END
						END
					ELSE
						Begin
							IF (@ToTblDataType = @FrTblDataType AND CONVERT(int,@FrTblCharLength)>= CONVERT(int,@ToTblCharLength))
								BEGIN
								Print @AlterSql;
								Exec SP_EXECUTESQL @AlterSql;
								END;
						End;  
					END;

			Fetch next From AlterCol Into @ColumnName,@ColType,@FrTblDataType,@FrTblCharLength,@ToTblDataType,@ToTblCharLength,@AlterSql;
			End;
		 Close AlterCol;
		 Deallocate AlterCol;
		 Print '**=End=**  Sync Table : ' + @TblName + ' Completed. ';
		 Print '-----------===========================---------------';
		End;
        go

