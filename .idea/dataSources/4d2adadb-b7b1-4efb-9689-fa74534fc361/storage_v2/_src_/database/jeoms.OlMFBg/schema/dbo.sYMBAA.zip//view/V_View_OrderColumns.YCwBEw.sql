		 
		Create View [dbo].[V_View_OrderColumns] as 
						SELECT Obj.name AS TableName, col.name AS ColumnName, typ.name + CASE typ.name
		WHEN 'decimal' THEN '(' + CAST(col.xprec AS varchar) + ',' + CAST(col.xscale AS varchar) + ')'
		WHEN 'nvarchar' THEN '(' + CASE 
			WHEN col.length = '-1' THEN 'max'
			ELSE CAST(col.length / 2 AS varchar)
		END + ')'
		WHEN 'varchar' THEN '(' + CASE 
			WHEN col.length = '-1' THEN 'max'
			ELSE CAST(col.length AS varchar)
		END + ')'
		ELSE ''
	END AS colType, col.isnullable AS isCanNull
	, typ.name AS columntype
	, CASE typ.name
		WHEN 'nvarchar' THEN 
			CASE 
				WHEN col.length = '-1' THEN 2000
				ELSE col.length / 2
			END
		WHEN 'varchar' THEN 
			CASE 
				WHEN col.length = '-1' THEN 2000
				ELSE col.length
			END
	END AS ColLength, obj.Id, col.colorder
FROM sysobjects obj
	LEFT JOIN syscolumns col ON obj.id = col.id
	LEFT JOIN systypes typ ON col.xtype = typ.xtype
WHERE obj.xtype = 'U'
	AND typ.status = 0
        go

