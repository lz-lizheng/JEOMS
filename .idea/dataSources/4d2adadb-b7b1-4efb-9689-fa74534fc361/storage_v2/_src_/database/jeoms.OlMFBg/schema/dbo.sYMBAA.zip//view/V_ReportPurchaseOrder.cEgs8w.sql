
/**
*create date : 2020-4-17
*create modify：拓斗
*remark ：视图添加采购日期
*/
CREATE View [dbo].[V_ReportPurchaseOrder]
AS
SELECT
 PO.Code, 
 pnod.Code as PnoCode,
 PO.PurchaseDate,
 PO.RequestDeliveryDate,
 PO.SupplierCode,
 po.SupplierName,
 Pnod.VirtualWarehouseId,
 Pnod.VirtualWarehouseName, 
 Pnod.WarehouseID,
 Pnod.WarehouseName,
 PO.Status,
 POD.ProductId,
 POD.ProductCode,
 POD.ProductName,
 POD.SkuId,
 POD.SkuCode,
 POD.SkuName,
 POD.Color,
 POD.Size,
 POD.PurchaseQty,
 POD.CurrentPrice AS OriginalPrice,
 Pnod.Remark,
 Pnod.Status AS PnoStatus,
 Pnod.NoticeQty,
 Pnod.StockInQty,
 Pnod.DefectiveQuantity,
 Pnod.WarehouseStorageTime AS WarehousingTime,
 pd.Year,
 pd.Season,
 pd.Brand,
 pd.CategoryName,
 PO.ContractNo,
 SSP.SupplierSettlementType, 
 PO.PurchasePersonName,
 PO.SupplierComanyName,
 Po.PurchaseTypeName,
 pd.FirstLevelCategoryName,
 POD.CurrentPrice * Pnod.StockInQty AS StockInAmt,
 POD.CurrentPrice * Pnod.DefectiveQuantity AS DefectiveAmt, 
 Pnod.ArriveBatchNo,
 ( CASE WHEN POD.PurchaseQty- Pnod.StockInQty- Pnod.DefectiveQuantity< 0 THEN 0 ELSE POD.PurchaseQty- Pnod.StockInQty- Pnod.DefectiveQuantity END ) AS TransitQty,
 Pnod.DetailId,
 (case When SSP.BillingType=1 then POD.CurrentPrice* (1+(Cast(ISNULL(SSP.Rate,'0') as decimal))/100) else POD.CurrentPrice end) FirstCost,
 PO.CreateDate
FROM
 PurchaseOrder PO ( NOLOCK )
 LEFT JOIN PurchaseOrderDetail POD ( NOLOCK ) ON PO.Id = pod.PurchaseOrderId
 Left join (
Select pno.Code,pno.Remark,pno.Status,pno.ArriveBatchNo,pnod.DetailId, pnod.SkuId, pno.PurchaseOrderId,pno.WarehouseID,pno.WarehouseName,pno.VirtualWarehouseId,pno.VirtualWarehouseName, pnod.NoticeQty, PNOID.StockInQty,PNOID.DefectiveQuantity,
PNOID.WarehouseStorageTime
From PurchaseNoticeOrder PNO ( NOLOCK ) 
LEFT JOIN PurchaseNoticeOrderdetail PNOD ( NOLOCK ) ON PNO.Id = PNOD.PurchaseNoticeOrderId 
LEFT JOIN PurchaseNoticeOrderIndetail PNOID ( NOLOCK ) ON PNOD.DetailId = PNOID.DetailId
) Pnod on Pnod.PurchaseOrderId = pod.PurchaseOrderId and pod.skuid = pnod.skuId
 LEFT JOIN dbo.Product PD ( NOLOCK ) ON POD.ProductId = pd.ProductId
 LEFT JOIN dbo.Supplier SSP ( NOLOCK ) ON po.SupplierCode = ssp.Code and ssp.IsDisabled = 0
go

exec sp_addextendedproperty 'MS_Description', '采购订单号', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'Code'
go

exec sp_addextendedproperty 'MS_Description', '采购入库单号', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'PnoCode'
go

exec sp_addextendedproperty 'MS_Description', '货期', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'PurchaseDate'
go

exec sp_addextendedproperty 'MS_Description', '到库日期', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'RequestDeliveryDate'
go

exec sp_addextendedproperty 'MS_Description', '供应商编码', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'SupplierCode'
go

exec sp_addextendedproperty 'MS_Description', '供应商名称', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'SupplierName'
go

exec sp_addextendedproperty 'MS_Description', '仓库ID', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'WarehouseID'
go

exec sp_addextendedproperty 'MS_Description', '仓库名称', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'WarehouseName'
go

exec sp_addextendedproperty 'MS_Description', '采购订单状态', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'Status'
go

exec sp_addextendedproperty 'MS_Description', '商品编码', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'ProductCode'
go

exec sp_addextendedproperty 'MS_Description', '商品名称', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'ProductName'
go

exec sp_addextendedproperty 'MS_Description', '规格编码', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'SkuCode'
go

exec sp_addextendedproperty 'MS_Description', '规格名称', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'SkuName'
go

exec sp_addextendedproperty 'MS_Description', '颜色', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN', 'Color'
go

exec sp_addextendedproperty 'MS_Description', '尺码', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN', 'Size'
go

exec sp_addextendedproperty 'MS_Description', '采购数量', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'PurchaseQty'
go

exec sp_addextendedproperty 'MS_Description', '采购价', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'OriginalPrice'
go

exec sp_addextendedproperty 'MS_Description', '说明', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN', 'Remark'
go

exec sp_addextendedproperty 'MS_Description', '采购入库单状态', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'PnoStatus'
go

exec sp_addextendedproperty 'MS_Description', '通知数量', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'NoticeQty'
go

exec sp_addextendedproperty 'MS_Description', '入库数量', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'StockInQty'
go

exec sp_addextendedproperty 'MS_Description', '入库时间', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
     'WarehousingTime'
go

