
------------------------张秦脚本

/**********************
*author：buer 
*date：20170302
*remark ：1、增加下载后是否上传配置；2、规格编码与自定义编码双匹配
***********************/

CREATE PROCEDURE [dbo].[P_RelateDistributionProduct]
(
 @storeId UNIQUEIDENTIFIER ,
 @flag VARCHAR(MAX)=NULL ,
 @sync BIT=0,
 @upload BIT=0
)
AS
      BEGIN
  --给定SKU或ID铺货
            IF @flag IS NOT NULL AND @flag<>''
               BEGIN
                     DECLARE @temp TABLE (Flag VARCHAR(100));--铺货的内容
                     INSERT INTO @temp
                     SELECT *
                     FROM   dbo.F_SplitString(@flag, ',');
      --修复关联错的
                     DELETE dp
                     FROM   DistributionProduct dp
                     JOIN   Distribution d ON dp.DistributionId=d.Id
                     WHERE  d.Id IN (SELECT *
                                     FROM   @temp) AND dp.IsManual=0 AND d.PlatformMatchSkuCode<>dp.ProductSkuCode AND d.ActivityId IS NULL AND d.PresellPlanId IS NULL;
      --加入未关联的
                     INSERT INTO DistributionProduct (DistributionId, ProductId, ProductCode, ProductTitle, ProductSkuId, ProductSkuCode, ProductSkuTitle, ProductType, ListingThreshold, DeListingThreshold, IsManual, Brand)
                     SELECT d.Id, sku.ProductId, sku.ProductCode, sku.ProductName, sku.SkuId, sku.Code, sku.Description, sku.IsCombined, 0, 0, 0, p.Brand
                     FROM   Distribution d
                     JOIN   ProductSku sku ON d.PlatformMatchSkuCode=sku.Code
                     JOIN   Product p ON sku.ProductId=p.ProductId
                     WHERE  d.Id IN (SELECT *
                                     FROM   @temp) AND NOT EXISTS ( SELECT  1
                                                                    FROM    DistributionProduct dp
                                                                    WHERE   dp.DistributionId=d.Id ) AND sku.Status=1
					 UNION
					 SELECT d.Id, sku.ProductId, sku.ProductCode, sku.ProductName, sku.SkuId, sku.Code, sku.Description, sku.IsCombined, 0, 0, 0, p.Brand
                     FROM   Distribution d
                     JOIN   ProductSku sku ON d.PlatformMatchSkuCode=sku.CustomCode
                     JOIN   Product p ON sku.ProductId=p.ProductId
                     WHERE  d.Id IN (SELECT *
                                     FROM   @temp) AND NOT EXISTS ( SELECT  1
                                                                    FROM    DistributionProduct dp
                                                                    WHERE   dp.DistributionId=d.Id ) AND sku.Status=1

                     UPDATE d
                     SET    d.IsAssociated=CASE WHEN dp.DistributionId IS NULL THEN 0
                                                ELSE 1
                                           END
                     FROM   Distribution d
                     LEFT JOIN DistributionProduct dp ON d.Id=dp.DistributionId
                     WHERE  d.Id IN (SELECT *
                                     FROM   @temp);

      --修改上新时间
                     IF @sync=1
                        UPDATE  p
                        SET     p.NewOnlineDate=CASE p.NewOnlineDate
                                                  WHEN NULL THEN GETDATE()
                                                  ELSE p.NewOnlineDate
                                                END, p.MainPictureUrl=d.MainPictureUrl
                        FROM    Product p ,
                                V_Distribution d
                        WHERE   d.Id IN (SELECT *
                                         FROM   @temp) AND p.ProductId=d.ProductId;
                     ELSE
                        UPDATE  p
                        SET     p.NewOnlineDate=GETDATE()
                        FROM    Product p ,
                                V_Distribution d
                        WHERE   d.Id IN (SELECT *
                                         FROM   @temp) AND p.ProductId=d.ProductId AND p.NewOnlineDate IS NULL;



                     INSERT INTO dbo.DistributionLog (Id, StoreId, PlatformId, PlatformSkuId, ProductCode, SkuCode, Note, CreateDate, CreateUserName)
                     SELECT NEWID(), StoreId, PlatformId, PlatformSkuId, ProductCode, ProductSkuCode, '下载铺货关系：自动上传：'+CASE IsAutoUploadInventory
                                                                                                                       WHEN 0 THEN '否'
                                                                                                                       ELSE '是'
                                                                                                                     END+'，自动上架：'+CASE IsAutoListing
                                                                                                                                    WHEN 0 THEN '否'
                                                                                                                                    ELSE '是'
                                                                                                                                  END+'，自动下架：'+CASE IsAutoDeListing
                                                                                                                                                 WHEN 0 THEN '否'
                                                                                                                                                 ELSE '是'
                                                                                                                                               END, UpdateDate, Updater
                     FROM   dbo.V_Distribution
                     WHERE  Id IN (SELECT   *
                                   FROM     @temp);
					
					IF @upload=1
					INSERT INTO InventoryTrigger(skuid,createdate) SELECT ProductSkuId,getdate() FROM V_Distribution WHERE  Id IN (SELECT * FROM @temp) 
               END;
            ELSE
               BEGIN
      --修复关联错的
                     DELETE dp
                     FROM   DistributionProduct dp
                     JOIN   Distribution d ON dp.DistributionId=d.Id
                     WHERE  d.PlatformMatchSkuCode<>dp.ProductSkuCode AND dp.IsManual=0 AND d.StoreId=@storeId AND d.ActivityId IS NULL AND d.PresellPlanId IS NULL;
      --新增未关联的
                     INSERT INTO DistributionProduct (DistributionId, ProductId, ProductCode, ProductTitle, ProductSkuId, ProductSkuCode, ProductSkuTitle, ProductType, ListingThreshold, DeListingThreshold, IsManual, Brand)
                     SELECT d.Id, sku.ProductId, sku.ProductCode, sku.ProductName, sku.SkuId, sku.Code, sku.Description, sku.IsCombined, 0, 0, 0, p.Brand
                     FROM   Distribution d
                     JOIN   ProductSku sku ON d.PlatformMatchSkuCode=sku.Code
                     JOIN   Product p ON sku.ProductId=p.ProductId
                     WHERE  NOT EXISTS ( SELECT 1
                                         FROM   DistributionProduct dp
                                         WHERE  dp.DistributionId=d.Id ) AND d.StoreId=@storeId AND sku.Status=1
					UNION
					SELECT d.Id, sku.ProductId, sku.ProductCode, sku.ProductName, sku.SkuId, sku.Code, sku.Description, sku.IsCombined, 0, 0, 0, p.Brand
                     FROM   Distribution d
                     JOIN   ProductSku sku ON d.PlatformMatchSkuCode=sku.CustomCode
                     JOIN   Product p ON sku.ProductId=p.ProductId
                     WHERE  NOT EXISTS ( SELECT 1
                                         FROM   DistributionProduct dp
                                         WHERE  dp.DistributionId=d.Id ) AND d.StoreId=@storeId AND sku.Status=1
      --取消没关联或关联错误的
                     UPDATE d
                     SET    d.IsAssociated=CASE WHEN dp.DistributionId IS NULL THEN 0
                                                ELSE 1
                                           END
                     FROM   Distribution d
                     LEFT JOIN DistributionProduct dp ON d.Id=dp.DistributionId
                     WHERE  d.StoreId=@storeId; 

      --修改上新时间
                     IF @sync=1
                        UPDATE  p
                        SET     p.NewOnlineDate=CASE p.NewOnlineDate
                                                  WHEN NULL THEN GETDATE()
                                                  ELSE p.NewOnlineDate
                                                END, p.MainPictureUrl=d.MainPictureUrl
                        FROM    Product p ,
                                V_Distribution d
                        WHERE   d.StoreId=@storeId AND p.ProductId=d.ProductId;
                     ELSE
                        UPDATE  p
                        SET     p.NewOnlineDate=GETDATE()
                        FROM    Product p ,
                                V_Distribution d
                        WHERE   d.StoreId=@storeId AND p.ProductId=d.ProductId AND p.NewOnlineDate IS NULL;
               END;
      END;



go

