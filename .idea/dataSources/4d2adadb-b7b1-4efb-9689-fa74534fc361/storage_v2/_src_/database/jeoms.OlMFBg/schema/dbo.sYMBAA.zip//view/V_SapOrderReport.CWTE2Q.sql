
CREATE view [dbo].[V_SapOrderReport]
as
SELECT so.StoreName,so.TradeId,so.Code,dod.DispatchOrderCode,case when ISNULL(dal.OutCode,'')='' then ISNULL(sal.OutCode,'') else ISNULL(dal.OutCode,'') end SAPCode,
do.ActualExpressName,do.ActualExpressNo,so.CustomerCode,so.CustomerName,sub.Consignee,sub.Mobile,so.PayDate,
so.CreateDate,do.DeliveryDate,so.PlatfromShipingType,sod.ProductCode,sod.ProductName,sod.Quantity,sod.AmountActual,so.storeid,
sod.DistributionAmount,so.PlatformType
FROM dbo.SalesOrder so
LEFT JOIN dbo.SalesOrderSub sub ON sub.SubId=so.OrderId
LEFT JOIN dbo.SalesOrderDetail sod ON so.OrderId=sod.SalesOrderId
LEFT JOIN dbo.DispatchOrderDetail dod ON dod.SalesOrderId=so.OrderId AND dod.SalesOrderDetailId=sod.DetailId
LEFT JOIN dbo.DispatchOrder do ON do.Id=dod.DispatchOrderId
LEFT JOIN dbo.DataCallCustomRecord dal ON dal.DataCode=do.Code AND ISNULL(dal.OutCode,'') not in ('') AND  dal.SystemTypeName = 'SAP' AND dal.DataType='102'
LEFT JOIN dbo.SalesOrderDeliveryInfo d ON d.SalesOrderId=so.OrderId AND so.DispatchTypeStatus=0
LEFT JOIN dbo.DataCallCustomRecord sal ON d.DispatchCode=sal.DataCode
where so.Status in (31,32)
union all 
select a.StoreName,a.TradeId,a.SalesOrderCode,a.code,isnull(dal.outcode,'') SAPCode,
a.ExpressName,a.ExpressNo,a.MemberCode,a.MemberName,sub.Consignee,sub.Mobile,isnull(so.PayDate,'') PayDate,
a.CreateDate,a.AuditDate,isnull(so.PlatfromShipingType,'')PlatfromShipingType,b.ProductCode,b.ProductName,b.Quantity,b.RefundAmount,so.storeid,
b.DistributionAmount,isnull(so.PlatformType,'') PlatformType from ReturnOrder a left join ReturnOrderDetail b on a.Id=ReturnOrderId 
left join SalesOrder so on a.SalesOrderCode=so.Code 
left join SalesOrderSub sub on sub.SubId=so.OrderId 
left join DataCallCustomRecord dal on a.code=dal.DataCode 
where  dal.SystemTypeName='SAP'  AND  dal.DataType='105'
go

