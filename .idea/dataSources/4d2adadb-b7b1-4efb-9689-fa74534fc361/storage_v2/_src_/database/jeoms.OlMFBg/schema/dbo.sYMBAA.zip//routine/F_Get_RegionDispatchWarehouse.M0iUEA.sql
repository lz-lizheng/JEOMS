
/********

*create date : 2018-09-14

*create by：qiaoni

*remark ：配货仓库清单

modify date : 20190827 remark : 配货策略增加优先拆单发货

*******/

CREATE FUNCTION [dbo].[F_Get_RegionDispatchWarehouse]

(

@P_DispatchTemplateId UNIQUEIDENTIFIER,

@P_ProvinceName NVARCHAR(50),

@P_CityName NVARCHAR(50),

@P_CountyName NVARCHAR(50)

)

RETURNS @V_Warehouse TABLE(WarehouseTemplateId UNIQUEIDENTIFIER, TemplateId UNIQUEIDENTIFIER, OrderId bigint, WarehouseID VARCHAR(36),

WarehouseCode NVARCHAR(20), WarehouseName NVARCHAR(50), ParentId UNIQUEIDENTIFIER, ParentCode NVARCHAR(50), ParentName NVARCHAR(50),

WarehouseDispatchType INT, DefalutCodExpressId UNIQUEIDENTIFIER, DefaultNoCodExpressId UNIQUEIDENTIFIER, IsOnlyPrePackage BIT,

SplitFirst Bit

)

AS

BEGIN

Declare @V_StoreWarehouseId UNIQUEIDENTIFIER -- 门店组父级ID

Declare @V_Point_One BigInt, @V_Point_Two BigInt, @V_Point_Three BigInt; -- 指数用来区分实体跟门店组, 门店组需要在门店的情况下区分区域层级，门店指数并以此来决定门店配货优先级

Set @V_Point_One = 100000; -- 一级排序扩展 主要针对

Set @V_Point_Two = 10000; -- 二级排序扩展 主要针对区域 - 大仓 - 区域外门店

Set @V_Point_Three = 1000; -- 二级排序扩展 主要针对距离

Select Top 1 @V_StoreWarehouseId = ParentId

From Warehouse

Where ProvinceName= @P_ProvinceName And CityName = @P_CityName And CountyName = @P_CountyName

And WarehouseType = 5

INSERT INTO @V_Warehouse(WarehouseTemplateId, TemplateId, OrderId, WarehouseID, WarehouseCode, WarehouseName, ParentId, ParentCode, ParentName,

WarehouseDispatchType, DefalutCodExpressID, DefaultNoCodExpressId, IsOnlyPrePackage, SplitFirst)

SELECT A.TemplateWarehouseId, A.TemplateId, A.OrderId, A.WarehouseId, Code, WarehouseName, A.ParentId, A.ParentCode, A.ParentName,

A.WarehouseDispatchType, A.DefaultCodExpressId, A.DefaultNoCodeExpressId, A.IsOnlyPrePackage, A.SplitFirst

FROM (

SELECT DTW.TemplateWarehouseId, DTW.TemplateId, (DTW.OrderId + 1) * @V_Point_One + 5 * @V_Point_Two AS OrderId, DTW.WarehouseId, wh.Code, wh.Name AS WarehouseName, wh.ParentId,

WHP.Code AS ParentCode, WHP.Name AS ParentName, DTW.WarehouseDispatchType, DT.DefaultCodExpressId AS DefaultCodExpressId,

DT.DefaultExpressId AS DefaultNoCodeExpressId, DTW.IsOnlyPrePackage, DTW.SplitFirst

FROM dbo.DispatchTemplate DT

INNER JOIN dbo.DispatchTemplateWarehouse DTW ON DT.Id = DTW.TemplateId

INNER JOIN dbo.Warehouse WH ON DTW.WarehouseId = WH.Id

INNER JOIN dbo.Warehouse WHP ON WH.ParentId = WHP.Id

WHERE DTW.IsDisabled = 0

AND DT.IsDisabled = 0

AND WHP.WarehouseType = 1

AND DT.Id = @P_DispatchTemplateId

And (WHP.IsRegion = 0 Or EXISTS (SELECT 1 FROM dbo.WarehouseRegion WR WHERE WR.ProvinceName = @P_ProvinceName AND WR.CityName = @P_CityName

AND WR.CountyName = @P_CountyName AND WH.ParentId = WR.WarehouseId))

UNION ALL

SELECT DTW.TemplateWarehouseId, DTW.TemplateId,

(DTW.OrderId + 1) * @V_Point_One +

Case when WHC.ParentId = @V_StoreWarehouseId Then 1 * @V_Point_Two else 9 * @V_Point_Two End +

Case When WHC.ProvinceName = @P_ProvinceName And WHC.CityName = @P_CityName And WHC.CountyName = @P_CountyName Then 1 * @V_Point_Three

When WHC.ProvinceName = @P_ProvinceName And WHC.CityName = @P_CityName Then 2 * @V_Point_Three

When WHC.ProvinceName = @P_ProvinceName Then 3 * @V_Point_Three

Else 4 * @V_Point_Three + dbo.F_GetAddressDistance(WHC.ProvinceName, WHC.CityName, WHC.CountyName, @P_ProvinceName, @P_CityName, @P_CountyName)

End as OrderId,

whc.id AS WarehouseId, whc.Code, whc.Name AS WarehouseName, wh.ID AS ParentId,

WH.Code AS ParentCode, WH.Name AS ParentName, DTW.WarehouseDispatchType, DT.DefaultCodExpressId AS DefaultCodExpressId,

DT.DefaultExpressId AS DefaultNoCodeExpressId,

DTW.IsOnlyPrePackage, DTW.SplitFirst

FROM dbo.DispatchTemplate DT

INNER JOIN dbo.DispatchTemplateWarehouse DTW ON DT.Id = DTW.TemplateId

INNER JOIN dbo.Warehouse WH ON DTW.WarehouseId = WH.Id

INNER JOIN dbo.Warehouse WHC ON WH.ID = WHC.ParentId

WHERE DTW.IsDisabled = 0

AND DT.IsDisabled = 0

AND WH.WarehouseType = 4

AND WHC.IsDisabled = 0

And Isnull(WHC.IsO2O, 0) = 1

AND DT.Id = @P_DispatchTemplateId

And (isnull(WH.IsRegion, 0) = 0 Or EXISTS (SELECT 1 FROM dbo.WarehouseRegion WR WHERE WR.ProvinceName = @P_ProvinceName AND WR.CityName = @P_CityName

AND WR.CountyName = @P_CountyName AND WH.Id = WR.WarehouseId))

Union ALL

SELECT DTW.TemplateWarehouseId, DTW.TemplateId,

99 * @V_Point_One +

dbo.F_GetAddressDistance(WHP.ProvinceName, WHP.CityName, WHP.CountyName, @P_ProvinceName, @P_CityName, @P_CountyName) AS OrderId,

DTW.WarehouseId, wh.Code, wh.Name AS WarehouseName, wh.ParentId,

WHP.Code AS ParentCode, WHP.Name AS ParentName, DTW.WarehouseDispatchType, DT.DefaultCodExpressId AS DefaultCodExpressId,

DT.DefaultExpressId AS DefaultNoCodeExpressId, DTW.IsOnlyPrePackage, DTW.SplitFirst

FROM dbo.DispatchTemplate DT

JOIN dbo.DispatchTemplateWarehouse DTW ON DT.Id = DTW.TemplateId

JOIN dbo.Warehouse WH ON DTW.WarehouseId = WH.Id

JOIN dbo.Warehouse WHP ON WH.ParentId = WHP.Id

WHERE DTW.IsDisabled = 0

And DT.WarehouseNotRangeDelivery = 1

AND DT.IsDisabled = 0

AND WHP.WarehouseType = 1

AND DT.Id = @P_DispatchTemplateId

And (WHP.IsRegion = 1 And Not EXISTS (SELECT 1 FROM dbo.WarehouseRegion WR WHERE WR.ProvinceName = @P_ProvinceName AND WR.CityName = @P_CityName

AND WR.CountyName = @P_CountyName AND WH.ParentId = WR.WarehouseId))

) A

ORDER BY a.OrderId;

RETURN;

END;

go

