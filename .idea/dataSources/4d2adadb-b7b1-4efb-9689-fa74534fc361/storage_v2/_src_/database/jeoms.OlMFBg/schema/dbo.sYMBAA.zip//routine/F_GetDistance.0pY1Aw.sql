

-- =============================================
-- Author:		Qiaoni
-- Create date: 2017-05-09
-- Description:	计算坐标距离
-- =============================================
CREATE FUNCTION [dbo].[F_GetDistance]
(
	@lat DECIMAL(12,4),
	@lag DECIMAL(12,4),
	@lat1 DECIMAL(12,4),
	@lag1 DECIMAL(12,4)
)
RETURNS int
AS
BEGIN
	DECLARE @EARTH_RADIUS DECIMAL(12, 4)
	DECLARE @radLat1 DECIMAL(12, 4)
	DECLARE @radLat2 DECIMAL(12, 4)
	DECLARE @a DECIMAL(12, 4) 
	DECLARE @b DECIMAL(12, 4)
	DECLARE @s DECIMAL(12, 4);
	
	SET @EARTH_RADIUS = 6378.137;
	 
	Set @radLat1 = @lat * PI() / 180.0
	SET @radLat2 = @lat1 * PI() / 180.0
	set @a = @radLat1 - @radLat2;
	set @b = @lag * PI() / 180.0 - @lag1 * PI() / 180.0;
	set @s = 2 * asin(sqrt( power(sin(@a/2),2) + cos(@radLat1)*cos(@radLat2) * power(sin(@b/2),2)));
	
	set @s = @s * @EARTH_RADIUS; 
	RETURN @s;
END

go

