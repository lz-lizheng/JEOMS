

/**
*create date : 2020-08-21
*create modify：拓斗
*remark ：可配数过滤暂停配货策略
*/ 
CREATE FUNCTION [dbo].[F_GetAllCanDispatch]
(
@SkuId UNIQUEIDENTIFIER, --规格ID
@storeId UNIQUEIDENTIFIER, --规格ID
@payTime DATETIME--支付时间

)
RETURNS INT
AS
BEGIN
DECLARE @inventory INT
DECLARE @occupation INT

SELECT @inventory = ISNULL(SUM(iv.Quantity),0)
FROM InventoryVirtual(NOLOCK)iv
JOIN (
 Select TemplateId, case WHen a.WarehouseType != 4 then WarehouseId Else b.Id End as WarehouseId
 From DispatchTemplateWarehouse a
 left Join Warehouse b on a.WarehouseType = 4 and b.ParentId = a.WarehouseId
 where isnull(a.IsDisabled,0)=0
) dtw on iv.WarehouseId=dtw.WarehouseId
JOIN StoreSetting ss on dtw.TemplateId=ss.DispatchTemplateId
WHERE iv.SkuId = @SkuId and ss.StoreId=@storeId and iv.IsLockStock = 0

SELECT @occupation = ISNULL(SUM(ioc.Quantity),0)
FROM InventoryOccupation(NOLOCK)ioc
JOIN (
 Select TemplateId, case WHen a.WarehouseType != 4 then WarehouseId Else b.Id End as WarehouseId
 From DispatchTemplateWarehouse a
 left Join Warehouse b on a.WarehouseType = 4 and b.ParentId = a.WarehouseId
 where isnull(a.IsDisabled,0)=0
) dtw on ioc.WarehouseId=dtw.WarehouseId
JOIN StoreSetting ss on dtw.TemplateId=ss.DispatchTemplateId
WHERE ioc.SkuId = @SkuId 
and ss.StoreId=@storeId 
AND (ioc.Type in (2,3,4,5,6) 
OR ioc.IsDispatched=1 
OR(
	ioc.Type=1 and ((ioc.IsAppointDateDelivery = 0 and ioc.PayDate<@payTime )
					or 
					(ioc.IsAppointDateDelivery = 1 and ioc.PreDeliveryDate <= getdate() and ioc.PayDate < @payTime)	
	)));
 
RETURN @inventory-@occupation;
END


go

