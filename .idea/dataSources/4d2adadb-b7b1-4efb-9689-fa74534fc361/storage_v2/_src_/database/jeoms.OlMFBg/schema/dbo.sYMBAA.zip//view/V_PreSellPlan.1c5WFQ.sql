

/**********************
*create by：QiaoNi 20180420
-remark   ：预售视图修改
***********************/  
CREATE View [dbo].[V_PreSellPlan] as 
Select Ps.*, psd.TotalPreSellQuantity, psd.TotalSalesQty
From PreSellPlan PS
Join (Select PreSellPlanId, Sum(PreSellQuantity) as TotalPreSellQuantity, Sum(SalesQty) as TotalSalesQty From PreSellPlanDetail psd Group By PreSellPlanId) as Psd on ps.id = psd.PreSellPlanId

go

