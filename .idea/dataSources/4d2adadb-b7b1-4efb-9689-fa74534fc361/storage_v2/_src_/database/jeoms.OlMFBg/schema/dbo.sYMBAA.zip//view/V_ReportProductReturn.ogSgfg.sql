

------------------------- 2016-04-14 -------------------------
CREATE VIEW [dbo].[V_ReportProductReturn] AS 
SELECT CAST(ro.ApproveDate AS DATE) AS ApproveDate,
	   CAST(so.PayDate AS DATE) AS PayDate, 
	   ro.StoreId,
	   ro.StoreName,
	   rod.ProductCode,
	   rod.ProductName,
	   rod.SkuCode,
	   rod.SkuName,
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color, 
	   SUM(rod.Quantity) AS Quantity,
	   SUM(rod.ActualAmount) AS AmountActual,
	   SUM((ROD.Quantity * ps.CostPrice)) AS FirstCost  
FROM dbo.ReturnOrder(NOLOCK) RO
LEFT JOIN dbo.ReturnOrderDetail(NOLOCK) ROD ON ro.Id = rod.ReturnOrderId
LEFT JOIN dbo.SalesOrderDetail(NOLOCK) sod ON sod.DetailId = rod.SalesOrderDetailId
LEFT JOIN dbo.SalesOrder(NOLOCK) so ON so.OrderId = sod.SalesOrderId 
LEFT JOIN Product(NOLOCK) pd ON rod.ProductId = pd.ProductId
LEFT JOIN dbo.ProductSku(NOLOCK) ps ON rod.SkuId = ps.SkuId
WHERE ro.IsObsolete = 0
GROUP BY CAST(ro.ApproveDate AS DATE),
	   CAST(so.PayDate AS DATE), 
	   ro.StoreId,
	   ro.StoreName,
	   rod.ProductCode,
	   rod.ProductName,
	   rod.SkuCode,
	   rod.SkuName, 
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color



go

