create
    definer = jeoms@`%` procedure create_sap_report_vip_dispatch(IN beginTime datetime, IN endTime datetime)
BEGIN
	INSERT IGNORE INTO `aty_sap_report_detail` (
		`created_time`,
		`oms_order_id`,
		`oms_order_code`,
		`trade_id`,
		`store_id`,
		`oms_order_detail_id`,
		`order_type`,
		`product_id`,
		`product_code`,
		`product_name`,
		`quantity`,
		`sku_id`,
		`sku_code`,
		`sku_name`,
		`settlement_price`,
		`settlement_amount`,
		`distribution_price`,
		`selling_amount`,
		`warehouse_operation_point`,
		`delivery_return_time`,
		`virtual_warehouse_id`,
		`unique_code` 
	) SELECT
	now(),
	ovd.vip_dispatch_id AS oms_order_id,
  ovd.vip_dispatch_code AS oms_order_code,
	ovd.picking_code as trade_id,
	ovd.store_id,
	ovdd.vip_dispatch_detail_id AS oms_order_detail_id,
	401,
	ovdd.product_id AS product_id,
	ovdd.product_code AS product_code,
	ovdd.product_name AS product_name,
	ovdd.out_quantity AS quantity,
	ovdd.sku_id AS sku_id,
	ovdd.sku_code AS sku_code,
	ovdd.sku_name AS sku_name,
	ovdd.selling_price AS settlement_price,
	ovdd.selling_price * ovdd.out_quantity AS settlement_amount,
	0 AS distribution_price,
	ovdd.selling_price * ovdd.out_quantity AS selling_amount,
	0 AS warehouse_operation_point,
	ovd.last_out_time,
	ovd.virtual_warehouse_id AS virtual_warehouse_id,
	    CONCAT('VIP_DISPATCH_ORDER',ovdd.vip_dispatch_detail_id ) as unique_code 
	FROM
		oms_vip_dispatch ovd
    INNER JOIN oms_vip_dispatch_detail ovdd ON ovd.vip_dispatch_id = ovdd.vip_dispatch_id
    INNER JOIN oms_product_sku sku ON sku.sku_id = ovdd.sku_id
	WHERE
		ovd.out_status IN (2,3)
		AND ovd.last_out_time >= beginTime 
	  AND ovd.last_out_time < endTime;
	
	INSERT IGNORE INTO aty_sap_report_check
	SELECT
	a.order_type `单据类型`,
	a.oms_order_id `单据ID`,
	a.oms_order_code `单据编码`,
	a.oms_order_detail_id `单据明细ID`,
	a.sku_code 规格编码,
	b.store_name 店铺,
	d.warehouse_name 仓库,
  null as 店铺分销类型,
CASE
		w_company.distribute_type 
		WHEN 1 THEN
		'直营' 
		WHEN 2 THEN
		'联营' ELSE '分销' 
	END 仓库分销类型,
	d.sales_type 仓库销售类型,
	null as  分销销售类型,
	s_company.company_name AS 店铺公司,
	w_company.company_name AS 仓库公司,
	a.warehouse_operation_point 仓库扣点,
  null as 平台类型,
	a.delivery_return_time as 业务确认时间,
	a.quantity 数量,
	a.distribution_price 分销价,
	a.distribution_price * a.quantity 分销金额,
	a.settlement_price 电商结算价,
	a.settlement_amount 电商结算金额,
	a.settlement_price AS 仓库结算价,
	a.settlement_price * a.quantity AS 仓库结算金额,
	a.settlement_price * a.quantity AS 销售金额,
	a.unique_code
FROM
	aty_sap_report_detail a,
	oms_store b,
	oms_virtual_warehouse c,
	oms_warehouse d,
	oms_company s_company,
	oms_company w_company
WHERE
  a.store_id=b.store_id
	AND a.virtual_warehouse_id = c.virtual_warehouse_id 
	AND c.warehouse_id = d.warehouse_id 	
	AND b.company_id = s_company.company_id 
	AND d.company_id = w_company.company_id 
	AND order_type = 401;
END;

