create
    definer = jeoms@`%` procedure create_sap_report_b2c_sales(IN beginTime datetime, IN endTime datetime)
BEGIN

Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1003 Begin SalesOrder', 5, 'aty_sap_report_detail', now());

	INSERT IGNORE INTO `aty_sap_report_detail` (
		`created_time`,
		`oms_order_id`,
		`oms_order_code`,
		`store_id`,
		`trade_id`,
		`oms_order_detail_id`,
		`order_type`,
		`distribute_price_adjust_order_code`,
		`distribute_price_adjust_order_name`,
		`product_id`,
		`product_code`,
		`product_name`,
		`quantity`,
		`sku_id`,
		`sku_code`,
		`sku_name`,
		`settlement_price`,
		`settlement_amount`,
		`distribution_price`,
		`cost_price`,
		`selling_amount`,
		`warehouse_operation_point`,
		`delivery_return_time`,
		`virtual_warehouse_id`,
		`unique_code`
	) SELECT
	now(),
	dod.dispatch_order_id AS oms_order_id,
	doo.dispatch_order_code AS oms_order_code,
	so.store_id,
	so.trade_id AS trade_id,
	dod.dispatch_order_delivery_id AS oms_order_detail_id,
	101,
	dpo.distribute_price_adjust_order_code,
	dpo.distribute_price_adjust_order_name,
	dod.product_id AS product_id,
	dod.product_code AS product_code,
	dod.product_name AS product_name,
	dod.quantity AS quantity,
	dod.sku_id AS sku_id,
	dod.sku_code AS sku_code,
	dod.sku_name AS sku_name,
	sod.settlement_price AS settlement_price,
	sod.settlement_amount AS settlement_amount,
	sod.distribution_price AS distribution_price,
	IFNULL( sod.cost_price, 0 ) AS cost_price,
	sod.selling_amount AS selling_amount,
	IFNULL( dwa.operation_point, 0 ) AS warehouse_operation_point,
	dod.delivery_time AS delivery_return_time,
	dot.virtual_warehouse_id AS virtual_warehouse_id,
	CONCAT('B2C_DISPATCH_ORDER',dod.dispatch_order_delivery_id) as unique_code 
	FROM
		oms_sales_order_detail sod
		INNER JOIN oms_sales_order so ON so.sales_order_id = sod.sales_order_id
		INNER JOIN oms_dispatch_order_delivery dod ON sod.sales_order_detail_id = dod.sales_order_detail_id
		INNER JOIN oms_dispatch_order_detail dot ON dot.dispatch_order_detail_id = dod.dispatch_order_detail_id
		INNER JOIN oms_dispatch_order doo ON dod.dispatch_order_id = doo.dispatch_order_id
		LEFT JOIN oms_shop_group_relation sgr ON doo.warehouse_id = sgr.warehouse_id
		LEFT JOIN oms_distribute_price_adjust_order_detail dpd ON dpd.distribute_price_adjust_order_detail_id = sod.distribute_price_adjust_order_detail_id
		LEFT JOIN oms_distribute_price_adjust_order dpo ON dpo.distribute_price_adjust_order_id = dpd.distribute_price_adjust_order_id
		LEFT JOIN oms_distribute_price_adjust_order_warehouse dwa ON dpd.distribute_price_adjust_order_id = dwa.distribute_price_adjust_order_id AND dwa.warehouse_id = IFNULL( sgr.shop_group_id, doo.warehouse_id )
	WHERE
		dod.delivery_time >= beginTime 
		AND dod.delivery_time < endTime;
	
Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1003 End SalesOrder', 6, 'aty_sap_report_detail', now());

Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1004 End SalesOrder Check', 7, 'aty_sap_report_check', now());

INSERT IGNORE INTO aty_sap_report_check
	SELECT
	a.order_type `单据类型`,
	a.oms_order_id `单据ID`,
	a.oms_order_code `单据编码`,
	a.oms_order_detail_id `单据明细ID`,
	a.sku_code 规格编码,
	b.store_name 店铺,
	d.warehouse_name 仓库,
CASE
		s_company.distribute_type 
		WHEN 1 THEN
		'直营' 
		WHEN 2 THEN
		'联营' ELSE '分销' 
	END 店铺分销类型,
CASE
		w_company.distribute_type 
		WHEN 1 THEN
		'直营' 
		WHEN 2 THEN
		'联营' ELSE '分销' 
	END 仓库分销类型,
	d.sales_type 仓库销售类型,
	f.sales_type 分销销售类型,
	s_company.company_name AS 店铺公司,
	w_company.company_name AS 仓库公司,
	a.warehouse_operation_point 仓库扣点,
CASE
		b.mall_type 
		WHEN 1201 THEN
		'唯品' ELSE '非唯品' 
	END 平台类型,
	a.delivery_return_time as 业务确认时间,
	a.quantity 数量,
	a.distribution_price 分销价,
	a.distribution_price * a.quantity 分销金额,
	a.settlement_price 电商结算价,
	a.settlement_price * a.quantity 电商结算金额,
	calc_warehouse_settlement_price (
		f.sales_type,
		d.sales_type,
		s_company.distribute_type,
		w_company.distribute_type,
		s_company.company_id,
		w_company.company_id,
		a.warehouse_operation_point,
		b.mall_type,
		a.settlement_price,
		a.cost_price,
		a.distribution_price 
	) AS 仓库结算价,
	calc_warehouse_settlement_price (
		f.sales_type,
		d.sales_type,
		s_company.distribute_type,
		w_company.distribute_type,
		s_company.company_id,
		w_company.company_id,
		a.warehouse_operation_point,
		b.mall_type,
		a.settlement_price,
		a.cost_price,
		a.distribution_price 
	)* a.quantity AS 仓库结算金额,
	calc_selling_price(s_company.distribute_type,a.settlement_price,a.distribution_price)*a.quantity 销售金额,
	a.unique_code
FROM
	aty_sap_report_detail a,
	oms_store b,
	oms_virtual_warehouse c,
	oms_warehouse d,
	oms_company s_company,
	oms_company w_company,
	oms_distributor_store e,
	oms_distributor f 
WHERE
	a.store_id = b.store_id 
	AND a.virtual_warehouse_id = c.virtual_warehouse_id 
	AND c.warehouse_id = d.warehouse_id 
	AND b.company_id = s_company.company_id 
	AND d.company_id = w_company.company_id 
	AND b.store_id = e.store_id 
	AND e.distributor_id = f.distributor_id 
	AND order_type = 101;
	
	Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1004 End SalesOrder Check', 8, 'aty_sap_report_check', now());
	
END;

