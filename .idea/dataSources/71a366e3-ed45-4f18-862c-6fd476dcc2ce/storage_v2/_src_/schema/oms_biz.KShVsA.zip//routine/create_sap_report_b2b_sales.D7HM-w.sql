create
    definer = jeoms@`%` procedure create_sap_report_b2b_sales(IN beginTime datetime, IN endTime datetime)
BEGIN

Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1003 Begin B2BSalesOrder', 5, 'aty_sap_report_detail', now());

	INSERT IGNORE INTO `aty_sap_report_detail` (
		`created_time`,
		`oms_order_id`,
		`oms_order_code`,
		`store_id`,
		`trade_id`,
		`oms_order_detail_id`,
		`order_type`,
		`distribute_price_adjust_order_code`,
		`distribute_price_adjust_order_name`,
		`product_id`,
		`product_code`,
		`product_name`,
		`quantity`,
		`sku_id`,
		`sku_code`,
		`sku_name`,
		`settlement_price`,
		`settlement_amount`,
		`distribution_price`,
		`cost_price`,
		`selling_amount`,
		`warehouse_operation_point`,
		`delivery_return_time`,
		`virtual_warehouse_id`,
		`is_return`,
		`unique_code`
	) SELECT
	now(),
	obso.b2b_sales_order_id AS oms_order_id,
	obso.b2b_sales_order_code AS oms_order_code,
	obso.store_id,
	null AS trade_id,
	obsod.b2b_sales_order_detail_id AS oms_order_detail_id,
	803,
	null as distribute_price_adjust_order_code,
	null as distribute_price_adjust_order_name,
	obsod.product_id AS product_id,
	obsod.product_code AS product_code,
	obsod.product_name AS product_name,
	obsod.quantity AS quantity,
	obsod.sku_id AS sku_id,
	obsod.sku_code AS sku_code,
	obsod.sku_name AS sku_name,
	obsod.price AS settlement_price,
	IF(obso.b2b_sales_order_type=1,obsod.amount,-obsod.amount) AS settlement_amount,
	0 AS distribution_price,
	IFNULL( sku.cost_price, 0 ) AS cost_price,
	IF(obso.b2b_sales_order_type=1,obsod.amount,-obsod.amount) AS selling_amount,
	0 AS warehouse_operation_point,
	obso.sold_time AS delivery_return_time,
	obso.virtual_warehouse_id AS virtual_warehouse_id,
	IF(obso.b2b_sales_order_type=1,0,1) as is_return,
	    CONCAT('B2B_SALES_ORDER',obsod.b2b_sales_order_detail_id) as unique_code
	FROM
		oms_b2b_sales_order obso
    INNER JOIN oms_b2b_sales_order_detail obsod ON obso.b2b_sales_order_id = obsod.b2b_sales_order_id
    INNER JOIN oms_product_sku sku ON obsod.sku_id = sku.sku_id
	WHERE
		obso.audited_time >= beginTime 
		AND obso.audited_time < endTime
		AND obso.order_status=2;
	
Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1003 End SalesOrder', 6, 'aty_sap_report_detail', now());

Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1004 End SalesOrder Check', 7, 'aty_sap_report_check', now());

INSERT IGNORE INTO aty_sap_report_check
	SELECT
	a.order_type `单据类型`,
	a.oms_order_id `单据ID`,
	a.oms_order_code `单据编码`,
	a.oms_order_detail_id `单据明细ID`,
	a.sku_code 规格编码,
	b.store_name 店铺,
	d.warehouse_name 仓库,
CASE
		s_company.distribute_type 
		WHEN 1 THEN
		'直营' 
		WHEN 2 THEN
		'联营' ELSE '分销' 
	END 店铺分销类型,
CASE
		w_company.distribute_type 
		WHEN 1 THEN
		'直营' 
		WHEN 2 THEN
		'联营' ELSE '分销' 
	END 仓库分销类型,
	d.sales_type 仓库销售类型,
	f.sales_type 分销销售类型,
	s_company.company_name AS 店铺公司,
	w_company.company_name AS 仓库公司,
	a.warehouse_operation_point 仓库扣点,
CASE
		b.mall_type 
		WHEN 1201 THEN
		'唯品' ELSE '非唯品' 
	END 平台类型,
	a.delivery_return_time as 业务确认时间,
	a.quantity 数量,
	a.distribution_price 分销价,
	a.distribution_price * a.quantity 分销金额,
	a.settlement_price 电商结算价,
	a.settlement_price * a.quantity 电商结算金额,
	calc_warehouse_settlement_price (
		f.sales_type,
		d.sales_type,
		s_company.distribute_type,
		w_company.distribute_type,
		s_company.company_id,
		w_company.company_id,
		a.warehouse_operation_point,
		b.mall_type,
		a.settlement_price,
		a.cost_price,
		a.distribution_price 
	) AS 仓库结算价,
	IF(a.is_return=0,
	calc_warehouse_settlement_price (
		f.sales_type,
		d.sales_type,
		s_company.distribute_type,
		w_company.distribute_type,
		s_company.company_id,
		w_company.company_id,
		a.warehouse_operation_point,
		b.mall_type,
		a.settlement_price,
		a.cost_price,
		a.distribution_price 
	)* a.quantity,
	-calc_warehouse_settlement_price (
		f.sales_type,
		d.sales_type,
		s_company.distribute_type,
		w_company.distribute_type,
		s_company.company_id,
		w_company.company_id,
		a.warehouse_operation_point,
		b.mall_type,
		a.settlement_price,
		a.cost_price,
		a.distribution_price 
	)* a.quantity)  AS 仓库结算金额,
	IF(a.is_return=0,
	calc_selling_price(s_company.distribute_type,a.settlement_price,a.distribution_price)*a.quantity,
	-calc_selling_price(s_company.distribute_type,a.settlement_price,a.distribution_price)*a.quantity) 销售金额,
		a.unique_code 
FROM
	aty_sap_report_detail a,
	oms_store b,
	oms_virtual_warehouse c,
	oms_warehouse d,
	oms_company s_company,
	oms_company w_company,
	oms_distributor_store e,
	oms_distributor f 
WHERE
	a.store_id = b.store_id 
	AND a.virtual_warehouse_id = c.virtual_warehouse_id 
	AND c.warehouse_id = d.warehouse_id 
	AND b.company_id = s_company.company_id 
	AND d.company_id = w_company.company_id 
  and b.store_id=e.store_id
	and e.distributor_id=f.distributor_id
	AND order_type = 803;
	
	Insert into qn_execute_record(batchno, stepNo, tableName, createDate) values('1004 End SalesOrder Check', 8, 'aty_sap_report_check', now());
	
END;

