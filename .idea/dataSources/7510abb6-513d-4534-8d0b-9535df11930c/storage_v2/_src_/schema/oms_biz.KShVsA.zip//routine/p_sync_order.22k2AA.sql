create
    definer = jusrrrtdkuk8@`%` procedure p_sync_order(IN v_create_time varchar(100))
begin
	declare v_temp_sync_row int; 
 
  Create Table history_sales_order_id (sales_order_id bigint PRIMARY key);
  CREATE TEMPORARY TABLE history_sales_order_temp_id(sales_order_id bigint PRIMARY key);
 

	-- 1.2 记录要归档的所有单据Id 
	Insert Into history_sales_order_id Select Sales_order_id From oms_biz.oms_sales_order Where created_time < v_create_time;
	
	-- 1.3 遍历1.2表单 每次10000 条记录遍历进行处理直到全部归档完成
	Insert into history_sales_order_temp_id Select sales_order_id From history_sales_order_id Limit 10000;

	-- 当前批次待同步数据 
	Select Count(*) as rowCnt into v_temp_sync_row From history_sales_order_temp_id;

	while v_temp_sync_row > 0 do   
	-- ========================================================================================================================================================
			
			-- 处理订单发票
			Insert Into oms_biz_history.oms_sales_order_discount Select * from oms_sales_order_discount so where so.sales_order_id in (Select * From history_sales_order_temp_id) and not exists (Select 1 From oms_biz_history.oms_sales_order_discount hod where so.sales_order_discount_id = hod.sales_order_discount_id);
			-- 删除已经归档的订单发票
			Delete  dd From oms_sales_order_discount dd join history_sales_order_temp_id tmp where dd.sales_order_id = tmp.sales_order_id; 
			 
		  -- 处理订单商品详情
			Insert Into oms_biz_history.oms_sales_order_invoice Select * from oms_sales_order_invoice so where so.sales_order_id in (Select * From history_sales_order_temp_id) and not exists (Select 1 From oms_biz_history.oms_sales_order_invoice hod where so.sales_order_invoice_id = hod.sales_order_invoice_id);
			-- 删除已经归档的订单商品详情 
			Delete  dd From oms_sales_order_invoice dd join history_sales_order_temp_id tmp where dd.sales_order_id = tmp.sales_order_id; 
			
			
			-- 处理订单活动
			Insert Into oms_biz_history.oms_sales_order_marketing Select * from oms_sales_order_marketing so where so.sales_order_id in (Select * From history_sales_order_temp_id) and not exists (Select 1 From oms_biz_history.oms_sales_order_marketing hod where so.sales_order_marketing_id = hod.sales_order_marketing_id);
			-- 删除已经归档的订单活动
			Delete  dd From oms_sales_order_marketing dd join history_sales_order_temp_id tmp where dd.sales_order_id = tmp.sales_order_id;  
			  
			-- 处理订单商支付
			Insert Into oms_biz_history.oms_sales_order_payment Select * from oms_sales_order_payment so where so.sales_order_id in (Select * From history_sales_order_temp_id) and not exists (Select 1 From oms_biz_history.oms_sales_order_payment hod where so.sales_order_payment_id = hod.sales_order_payment_id);
			-- 删除已经归档的订单支付
			Delete  dd From oms_sales_order_payment dd join history_sales_order_temp_id tmp where dd.sales_order_id = tmp.sales_order_id;   
			
			-- 处理订单商品详情
			Insert Into oms_biz_history.oms_sales_order_detail 
			Select * from oms_sales_order_detail so where so.sales_order_id in (Select * From history_sales_order_temp_id) and not exists (Select 1 From oms_biz_history.oms_sales_order_detail hod where so.sales_order_detail_id = hod.sales_order_detail_id);			
			-- 删除已经归档的订单商品详情
			Delete  dd From oms_sales_order_detail dd join history_sales_order_temp_id tmp where dd.sales_order_id = tmp.sales_order_id;   
			
			
		    -- 处理订单子表
			Insert Into oms_biz_history.oms_sales_order_sub Select * from oms_sales_order_sub so where so.sales_order_id in (Select * From history_sales_order_temp_id) and not exists (Select 1 From oms_biz_history.oms_sales_order_sub hod where so.sales_order_id = hod.sales_order_id);
			-- 删除已经归档的订单子表
			Delete  dd From oms_sales_order_sub dd join history_sales_order_temp_id tmp where dd.sales_order_id = tmp.sales_order_id;    

			-- 处理订单
			Insert Into oms_biz_history.oms_sales_order Select * from oms_sales_order so where so.sales_order_id in (Select * From history_sales_order_temp_id) and not exists (Select 1 From oms_biz_history.oms_sales_order hod where so.sales_order_id = hod.sales_order_id);
			
			-- 删除已经归档的订单
			Delete  dd From oms_sales_order dd join history_sales_order_temp_id tmp where dd.sales_order_id = tmp.sales_order_id;     
			-- ========================================================================================================================================================

			-- --------------------------------------------------------------------------------------------------------------------------------------------------------
			-- 删除当前已经归档的订单
			delete DD from history_sales_order_id dd JOin history_sales_order_temp_id tmp Where dd.sales_order_id = tmp.sales_order_id;
			
			-- 删除当前临时订单Id
			truncate table history_sales_order_temp_id;			
			-- --------------------------------------------------------------------------------------------------------------------------------------------------------
			
			-- 获取下一批次待处理的订单
			Insert into history_sales_order_temp_id Select sales_order_id From history_sales_order_id Limit 10000;
			
			-- 获取是否仍有订单
			Select Count(*) as rowCnt into v_temp_sync_row From history_sales_order_temp_id;
			
			select CURTime();#结束循环后，打印结果 			
	end while;

	Drop table history_sales_order_id;
	Drop table history_sales_order_temp_id; 

end;

