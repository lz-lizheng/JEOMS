create view aaaa_price as
select `b`.`sku_id`       AS `sku_id`,
       `b`.`active_price` AS `active_price`,
       `c`.`audited_time` AS `audited_time`,
       `e`.`store_id`     AS `store_id`
from (((`oms_biz`.`oms_distribute_price_adjust_order_detail` `b` join `oms_biz`.`oms_distribute_price_adjust_order` `c` on ((
        `b`.`distribute_price_adjust_order_id` =
        `c`.`distribute_price_adjust_order_id`))) join `oms_biz`.`oms_distribute_price_adjust_order_distributor` `d` on ((
        `c`.`distribute_price_adjust_order_id` = `d`.`distribute_price_adjust_order_id`)))
         join `oms_biz`.`oms_distributor_store` `e` on ((`d`.`distributor_id` = `e`.`distributor_id`)))
where (`c`.`status` = 21);

