create
    definer = dev@`%` function getRefundableAmount(sid bigint, did bigint) returns decimal(15, 2)
BEGIN
	DECLARE
		r DECIMAL ( 15, 2 );
	SELECT
	CASE
		WHEN
			rd1.quantity = sd1.quantity THEN
				sd1.settlement_amount 
				WHEN rd1.quantity IS NOT NULL THEN
				rd1.quantity * sd1.settlement_price ELSE 0 
			END AS refundableAmount 
		FROM
			oms_return_order_detail rd1
			LEFT JOIN oms_sales_order_detail sd1 ON rd1.sales_order_detail_id = sd1.sales_order_detail_id 
		WHERE
		sid = rd1.sales_order_detail_id AND did = rd1.return_order_detail_id INTO r;
RETURN r;
END;

