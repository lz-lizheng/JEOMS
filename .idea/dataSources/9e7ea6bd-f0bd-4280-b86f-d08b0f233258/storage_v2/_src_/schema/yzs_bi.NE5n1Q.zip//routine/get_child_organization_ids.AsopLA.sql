create
    definer = yzs@`%` function get_child_organization_ids(in_id varchar(36)) returns text
begin 
 declare ids text default ''; 
 declare tempids text; 
 
 set tempids = in_id; 
 while tempids is not null do 
	If in_id <> tempids then
		set ids = CONCAT_WS(',',ids,tempids); 
	end if;
  select GROUP_CONCAT(organization_id) into tempids from organizations where FIND_IN_SET(organization_parent_id,tempids)>0;  
 end while; 
 return ids; 
end;

