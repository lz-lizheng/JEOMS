create
    definer = oms@`%` procedure p_sync_dispatch_order(IN v_create_time varchar(100))
begin
	declare v_temp_sync_row int; 

	-- 1.1 记录要删除的订单Id
	Create Table history_dispatch_order_id (dispatch_order_id bigint PRIMARY key);
	CREATE TABLE history_dispatch_order_temp_id(dispatch_order_id bigint PRIMARY key);

	-- 1.2 记录要归档的所有单据Id 
	-- Select dispatch_order_id From oms_biz.oms_dispatch_order Where created_time < '2019-08-13' limit 10;
	INSERT INTO history_dispatch_order_id SELECT dispatch_order_id  FROM oms_biz.oms_dispatch_order 
	WHERE created_time < v_create_time;
-- 		AND dispatch_order_id = 14379949618856960;
	
	-- 1.3 遍历1.2表单 每次20000 条记录遍历进行处理直到全部归档完成
	Insert into history_dispatch_order_temp_id Select dispatch_order_id From history_dispatch_order_id Limit 20000;

	-- 当前批次待同步数据 
	Select Count(*) as rowCnt into v_temp_sync_row From history_dispatch_order_temp_id;

	while v_temp_sync_row > 0 do   
	-- ========================================================================================================================================================
			  
			
		  -- 处理配货单明细
			Insert Into oms_biz_history_new.oms_dispatch_order_detail Select so.* from oms_dispatch_order_detail so Join history_dispatch_order_temp_id tmp on so.dispatch_order_id = tmp.dispatch_order_id
			where not exists (Select 1 From oms_biz_history_new.oms_dispatch_order_detail hod where so.dispatch_order_detail_id = hod.dispatch_order_detail_id);			
			-- 删除已经归档的配货单明细
			Delete dd From oms_dispatch_order_detail dd join history_dispatch_order_temp_id tmp where dd.dispatch_order_id = tmp.dispatch_order_id;			
			
			
			
			-- 处理配货单发货记录
			Insert Into oms_biz_history_new.oms_dispatch_order_delivery Select so.* from oms_dispatch_order_delivery so Join history_dispatch_order_temp_id tmp on so.dispatch_order_id = tmp.dispatch_order_id
			where not exists (Select 1 From oms_biz_history_new.oms_dispatch_order_delivery hod where so.dispatch_order_delivery_id = hod.dispatch_order_delivery_id);
			
			-- 删除已经归档的配货单发货记录 
			Delete dd From oms_dispatch_order_delivery dd join history_dispatch_order_temp_id tmp where dd.dispatch_order_id = tmp.dispatch_order_id;			
			
			
			
			
			-- 处理配货单明细
			Insert Into oms_biz_history_new.oms_dispatch_order Select so.* from oms_dispatch_order so Join history_dispatch_order_temp_id tmp on so.dispatch_order_id = tmp.dispatch_order_id
			where not exists (Select 1 From oms_biz_history_new.oms_dispatch_order hod where so.dispatch_order_id = hod.dispatch_order_id);
			
			-- 删除已经归档的配货单明细 
			Delete dd From oms_dispatch_order dd join history_dispatch_order_temp_id tmp where dd.dispatch_order_id = tmp.dispatch_order_id;					
			-- ========================================================================================================================================================

					
			-- --------------------------------------------------------------------------------------------------------------------------------------------------------
			-- 删除当前已经归档的订单 
			Delete dd From history_dispatch_order_id dd join history_dispatch_order_temp_id tmp on dd.dispatch_order_id = tmp.dispatch_order_id;		
			
			-- 删除当前临时订单Id
			truncate table history_dispatch_order_temp_id;			
			-- --------------------------------------------------------------------------------------------------------------------------------------------------------
			
			-- 获取下一批次待处理的订单
			Insert into history_dispatch_order_temp_id Select dispatch_order_id From history_dispatch_order_id Limit 20000;
			 					
			-- 当前批次待同步数据 
			Select Count(*) as rowCnt into v_temp_sync_row From history_dispatch_order_temp_id;
	
			
			select CURTime();#结束循环后，打印结果 			
			
	end while;

	Drop table history_dispatch_order_id;
	Drop table history_dispatch_order_temp_id; 
end;

