create
    definer = oms@`%` procedure mall_order_clean(IN lastDate varchar(20))
BEGIN
	DECLARE id BIGINT;
	DECLARE total INT;
	DECLARE page INT;
	DECLARE pageSize INT DEFAULT 500;
	DECLARE current INT DEFAULT 1;

	SET id=(unix_timestamp(STR_TO_DATE(lastDate,'%Y-%m-%d'))*1000-687888001020)<<14;
	SELECT count(*) into total from oms_mall_sales_order where mall_sales_order_id<id;
	SET page = (total+1)/pageSize;
	WHILE current<=page DO
		DELETE FROM oms_mall_sales_order WHERE mall_sales_order_id<ID LIMIT pageSize;
	  SET current=current+1;
	END WHILE;
	SELECT CONCAT('DELETE oms_mall_sales_order----->',total);
	
	SET current=1;
	SET page=0;
	SELECT count(*) into total from oms_mall_refund_order where mall_refund_order_id<id;
	SET page = (total+1)/pageSize;
	WHILE current<=page DO
		DELETE FROM oms_mall_refund_order WHERE mall_refund_order_id<ID LIMIT pageSize;
	  SET current=current+1;
	END WHILE;
	SELECT CONCAT('DELETE oms_mall_refund_order----->',total);

	SET current=1;
	SET page=0;
	SELECT count(*) into total from oms_mall_exchange_order where mall_exchange_order_id<id;
	SET page = (total+1)/pageSize;
	WHILE current<=page DO
		DELETE FROM oms_mall_exchange_order WHERE mall_exchange_order_id<ID LIMIT pageSize;
	  SET current=current+1;
	END WHILE;
	SELECT CONCAT('DELETE oms_mall_exchange_order----->',total);
END;

