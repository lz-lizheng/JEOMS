CREATE PROCEDURE P_ClearAndBakUploadLog
AS
INSERT INTO InventoryUploadLogBak
SELECT * FROM InventoryUploadLog WHERE CreateDate<DATEADD(DAY,-30,GETDATE())
go

