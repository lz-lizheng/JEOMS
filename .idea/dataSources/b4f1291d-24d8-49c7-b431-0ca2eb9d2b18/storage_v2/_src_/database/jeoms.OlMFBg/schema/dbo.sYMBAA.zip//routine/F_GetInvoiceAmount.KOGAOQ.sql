
CREATE Function [dbo].[F_GetInvoiceAmount]
(
	@storeId Uniqueidentifier,
	@tradeId nvarchar(50)
)
RETURNS Decimal(12, 2)
AS
	BEGIN
	Declare @V_Result Decimal(12, 2);
	
	Select @V_Result = Sum(PayAmount) 
	From (
		--Select Sum(PayAmount) as PayAmount
		--From SalesOrder
		--Where TradeId = @tradeId -- '59204245199'
		--And StoreId = @storeId
		--And IsObsolete = 0
		--Union ALL
		Select isnull(Sum(sod.AmountActual), 0) + Max(so.ExpressFee) as PayAmount
		From SalesOrder so(nolock), SalesOrderDetail sod(nolock)
		Where TradeId = @tradeId --'59204245199'
		And StoreId = @storeId
		And IsObsolete = 0
		And SO.orderId = sod.SalesOrderId
		And sod.IsDeleted = 0
		Union ALL
		Select Isnull(Sum(ActualAmount),0) * -1 as ReturnAmount
		From ReturnOrder ro(nolock), ReturnOrderDetail rod(nolock) 
		Where Ro.Id = Rod.ReturnOrderId
		And StoreId = @storeId
		And ROD.TradeId = @tradeId --'59204245199'
		And Ro.IsObsolete = 0
		) A

	Return @V_Result;
End;
go

