


CREATE VIEW [dbo].[V_Region] AS 
SELECT	Ct.Id AS CountryId, ct.Name AS CountryName, ct.Code AS CountryCode, Pro.Id AS ProvinceId, 
		pro.Name AS ProvinceName, pro.code AS ProvinceCode, Pro.Lng as ProvinceLng, Pro.Lat as ProvinceLat,
		City.id AS CityId, city.name AS CityName, city.code AS CityCode, City.Lng as CityLng, City.lat as CityLat,
		Dt.Id AS DistrictId,  dt.name AS DistrictName, dt.code AS DistrictCode, dt.Lng as DistrictLng, dt.Lat as DistrictLat
FROM Region AS ct(nolock)
Left Join Region AS Pro(nolock) On ct.Id = pro.ParentId
Left Join  Region AS City(nolock) on pro.Id = City.ParentId 
Left Join  Region AS dt(nolock)ON City.id = dt.ParentId
WHERE ct.RegionLevel = 1


go

