
Create View V_ReturnOrderScan as 
Select Cast(ScanTime as Date) as ScanTime, ScanUser, Count(distinct ro.Code ) as OrderQty, Sum(rod.Quantity) as ReturnProductQty
From ReturnOrder ro, ReturnOrderDetail rod
where ro.Id = rod.ReturnOrderId
Group by Cast(ScanTime as Date), ScanUser
go

