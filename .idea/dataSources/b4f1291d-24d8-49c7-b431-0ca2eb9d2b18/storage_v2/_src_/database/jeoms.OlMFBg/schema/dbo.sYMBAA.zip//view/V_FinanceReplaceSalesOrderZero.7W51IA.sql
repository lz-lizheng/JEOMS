
Create View V_FinanceReplaceSalesOrderZero as
Select SO.StoreId, SO.TradeId, Max(SO.ExpressFee) as ExpressFee,
	Max(SO.ExpressFee) + Sum(SOD.AmountActual) as OrderAmountActual
From SalesOrder SO(nolock)
Left Join SalesOrderDetail SOD(nolock) on SO.OrderId = SOD.SalesOrderId
Where SOD.IsDeleted = 0
And SO.TransType = 4
And IsNull(SO.IsAccounted, 0) = 0
Group by SO.StoreId, SO.TradeId
go

