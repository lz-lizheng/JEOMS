CREATE VIEW [dbo].[V_Distribution] AS 
SELECT    d.*,dp.*
      FROM      Distribution d
      JOIN      DistributionProduct dp ON d.Id=dp.DistributionId;


go

