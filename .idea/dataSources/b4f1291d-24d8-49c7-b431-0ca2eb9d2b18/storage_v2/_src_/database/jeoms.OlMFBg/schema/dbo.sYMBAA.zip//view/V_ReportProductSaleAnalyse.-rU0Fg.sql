

CREATE View [dbo].[V_ReportProductSaleAnalyse] as  
	Select so.StoreId, so.Storename, Cast(so.CreateDate as DATE) as CreateDate, sod.ProductCode, sod.SkuCode, so.IsPrepay, Sum(Sod.Quantity) as SaleQty, Sum(sod.AmountActual) as SaleAmount,
		0 as CancelQty, 0 as CancelAmount, 0 as RtnQty, 0 as RtnAmount
	From SalesOrder so(nolock)
	join SalesOrderDetail sod(nolock) on so.OrderId = sod.SalesOrderId
	group by so.StoreId, so.Storename, Cast(so.CreateDate as DATE), sod.ProductCode, sod.SkuCode, so.IsPrepay
	Union All
	Select so.StoreId, so.Storename, Cast(so.CreateDate as DATE) as CreateDate, sod.ProductCode, sod.SkuCode, so.IsPrepay, 0 as SaleQty, 0 as SaleAmount,
			Sum(Sod.Quantity) as Quantity, Sum(sod.AmountActual) as AmountActual, 0 as RtnQty, 0 as RtnAmount
	From SalesOrder so(nolock)
	join SalesOrderDetail sod(nolock) on so.OrderId = sod.SalesOrderId
	group by so.StoreId, so.Storename, Cast(so.CreateDate as DATE), sod.ProductCode, sod.SkuCode, so.IsPrepay
	Union All
	Select ro.StoreId, ro.Storename, Cast(ro.AuditDate as DATE) as CreateDate, rod.ProductCode, rod.SkuCode, so.IsPrepay,0 as SaleQty, 0 as SaleAmount,
		0 as CancelQty, 0 as CancelAmount,
		Sum(rod.Quantity) as Quantity, Sum(Rod.RefundAmount) as AmountActual
	From ReturnOrder ro(nolock)
	join ReturnOrderDetail rod(nolock) on ro.Id = rod.ReturnOrderId
	Left Join SalesOrder so(nolock) on so.OrderId = rod.SalesOrderId
	group by ro.StoreId, ro.Storename, Cast(ro.AuditDate as DATE), rod.ProductCode, rod.SkuCode, so.IsPrepay


go

