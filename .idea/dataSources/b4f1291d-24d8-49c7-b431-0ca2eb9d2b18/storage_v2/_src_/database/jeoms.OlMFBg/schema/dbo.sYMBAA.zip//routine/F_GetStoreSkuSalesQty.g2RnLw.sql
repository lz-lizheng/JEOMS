

--[dbo].[P_GetStoreSkuSalesQty] '69018D14-EC32-483A-B670-81022AA8FBA0', '4E8BA195-F26F-4318-A39E-1E83B587F805'
 
CREATE FUNCTION [dbo].[F_GetStoreSkuSalesQty]
(
	@SkuId VARCHAR(50), --规格ID
	@StoreId VARCHAR(50) --店铺Id
)
RETURNS INT
AS
BEGIN

	DECLARE @V_SalesQty INT

	--根据店铺ID获取该店铺关联的所有仓库，并写入零时表#wareHouseId 
	DECLARE @Warehouse TABLE(WarehouseId UNIQUEIDENTIFIER);

	INSERT INTO @Warehouse(WarehouseId)
	SELECT DTW.WarehouseId 
	FROM dbo.StoreSetting SS(NOLOCK)
	INNER JOIN dbo.DispatchTemplateWarehouse DTW(NOLOCK) ON ss.DispatchTemplateId = DTW.TemplateId
	WHERE ss.StoreId = @StoreId AND dtw.IsDisabled = 0;
	     
	-- 所有库存 - 所有占用
	SELECT @V_SalesQty = ISNULL(SUM(A.Quantity), 0)
	FROM (
		SELECT SUM(IV.Quantity) Quantity
		FROM dbo.InventoryVirtual IV
		INNER JOIN @Warehouse WH ON IV.WarehouseId = WH.WarehouseId AND iv.SkuId = @SkuId
		UNION ALL
		SELECT SUM(IOC.Quantity) * -1
		FROM dbo.InventoryOccupation IOC
		INNER JOIN @Warehouse WH ON IOC.WarehouseId = WH.WarehouseId AND ioc.SkuId = @SkuId
		Where IOC.Type <> 6
		) A;  

	RETURN @V_SalesQty;
END



go

