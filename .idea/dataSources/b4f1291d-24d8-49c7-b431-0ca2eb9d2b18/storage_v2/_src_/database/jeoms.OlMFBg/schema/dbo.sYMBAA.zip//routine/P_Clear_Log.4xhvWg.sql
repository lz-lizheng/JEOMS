CREATE Procedure [dbo].[P_Clear_Log] as
Begin
  Print 'Insert PlatformOrder_Created ***** SyncStatus = 0'
	  INSERT INTO jeods.dbo.PlatformOrder_Created(Id, CreateDate, StoreId, Tid)
	  select cast(Convert(Varchar(10), getDate(), 12) as decimal(10)) * 1000000 + ROW_NUMBER() over (order by rd.Id) as Id, getdate(), rd.StoreId, rd.Tid from (
			Select row_number() over (partition by pr.RefundCode order by RecordDate desc) RowId,pr.Id, pr.StoreId, pr.Tid, pr.RecordDate, pr.RefundCode, st.Name
			From jeods.dbo.PlatformRefund Pr left join jeoms.dbo.Store st on pr.StoreId = st.Id
			Where Pr.SyncStatus = 0 and st.PlatformType in (2, 4, 22, 23, 61)
			And Not Exists (Select 1 From jeods.dbo.PlatformOrder_Created Prc where pr.StoreId = Prc.StoreId and pr.tid = Prc.Tid)
			And Exists (Select 1 From jeoms.dbo.SalesOrder so where pr.StoreId = so.StoreId and pr.Tid = so.TradeId and so.IsAutoDownload = 1 )) rd
	  where rd.RowId = 1;
end;
go

