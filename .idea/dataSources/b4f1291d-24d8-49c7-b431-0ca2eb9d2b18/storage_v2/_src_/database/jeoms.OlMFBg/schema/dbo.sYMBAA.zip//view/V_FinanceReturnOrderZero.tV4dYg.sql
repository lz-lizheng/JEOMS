
Create View V_FinanceReturnOrderZero as
Select RO.StoreId, RO.TradeId, RO.TradeStatus, Max(RO.ApproveDate) as ApproveDate, Sum(Isnull(ARO.RefundFee, ROD.ActualAmount)) as ActualRefundFee
From ReturnOrder RO(nolock)
Left JOin ReturnOrderDetail ROD(nolock) on ro.Id = ROD.ReturnOrderId
Left JOin ApplyRefundOrder ARO(nolock) on ROD.ApplyRefundCode = ARO.Code And Isnull(ARO.IsObsoleted, 0) = 0
Where RO.TradeStatus = 1
--And RO.TradeId in ('43504443362871216', '59988733576')
And RO.IsObsolete = 0 
And Ro.IsAccounted = 0
And RO.IsReplace = 0
Group by RO.StoreId, RO.TradeId, RO.TradeStatus
go

