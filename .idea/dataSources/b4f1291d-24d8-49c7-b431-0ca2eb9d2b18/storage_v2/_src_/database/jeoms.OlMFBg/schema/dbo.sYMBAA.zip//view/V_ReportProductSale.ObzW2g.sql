








CREATE VIEW [dbo].[V_ReportProductSale] AS 
SELECT '销售订单' AS DateType,
	   CAST(so.CreateDate AS DATE) AS CreateDate,
	   CAST(so.PayDate AS DATE) AS PayDate, 
	   CAST(so.DeliveryDate AS DATE) AS DeliveryDate, 
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.SkuCode,
	   sod.SkuName,
	   sod.IsDeleted,
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color, 
	   SUM(sod.Quantity) AS Quantity,
	   SUM(sod.AmountActual) AS AmountActual,
	   SUM((sod.Quantity * sod.FirstCost)) AS FirstCost  
FROM dbo.SalesOrder(NOLOCK) so
LEFT JOIN dbo.SalesOrderDetail(NOLOCK) sod ON so.OrderId = sod.SalesOrderId
LEFT JOIN Product(NOLOCK) pd ON sod.ProductId = pd.ProductId
LEFT JOIN dbo.ProductSku(NOLOCK) ps ON sod.ProductSkuId = ps.SkuId
WHERE sod.IsDeleted = 0
GROUP BY CAST(so.CreateDate AS DATE),
	   CAST(so.PayDate AS DATE), 
	   CAST(so.DeliveryDate AS DATE), 
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.SkuCode,
	   sod.SkuName,
	   sod.IsDeleted,
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color

UNION ALL

SELECT '取消订单' AS DateType,
	   CAST(so.CreateDate AS DATE) AS CreateDate,
	   CAST(sod.DeletedDate AS DATE) AS PayDate, 
	   CAST(NULL AS DATE) AS DeliveryDate, 
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.SkuCode,
	   sod.SkuName,
	   sod.IsDeleted,
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color, 
	   SUM(sod.Quantity) AS Quantity,
	   SUM(sod.AmountActual ) AS AmountActual,
	   SUM((sod.Quantity * sod.FirstCost)) AS FirstCost  
FROM dbo.SalesOrder(NOLOCK) so
LEFT JOIN dbo.SalesOrderDetail(NOLOCK) sod ON so.OrderId = sod.SalesOrderId
LEFT JOIN Product(NOLOCK) pd ON sod.ProductId = pd.ProductId
LEFT JOIN dbo.ProductSku(NOLOCK) ps ON sod.ProductSkuId = ps.SkuId
WHERE sod.IsDeleted = 1
GROUP BY CAST(so.CreateDate AS DATE),
	   CAST(sod.DeletedDate AS DATE),  
	   so.StoreId,
	   so.StoreName,
	   sod.ProductCode,
	   sod.ProductName,
	   sod.SkuCode,
	   sod.SkuName,
	   sod.IsDeleted,
	   pd.Season,
	   pd.Year,
	   pd.CategoryName,
	   ps.Size,
	   ps.Color



go

