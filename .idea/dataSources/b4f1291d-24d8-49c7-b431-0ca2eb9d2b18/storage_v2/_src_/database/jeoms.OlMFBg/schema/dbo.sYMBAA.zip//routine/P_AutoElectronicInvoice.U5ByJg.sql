 
-- CreateUser : JE
-- CreateDate : 2016-04-11 
-- Description: 自动创建需要开票的信息, 上线时需要设置开票单据的起始时间点，　否则可能存在重复开票问题 
-- 需要设定起始开票时间点，　用来控制重复开票  ???????????????????????????????????????????????????????
CREATE PROC [dbo].[P_AutoElectronicInvoice]
AS
BEGIN
	DECLARE @V_BeginDate DATE 
	SET @V_BeginDate = DATEADD(DAY, -700, GETDATE())
	PRINT @V_BeginDate
	DECLARE @V_ElectronicInvoiceConfig nvarchar(max), @V_EmailAddr nvarchar(100)
	SELECT @V_ElectronicInvoiceConfig = Content FROM dbo.SystemConfiguration WHERE name = 'ElectronicInvoiceConfig'
	
	SELECT * INTO #Tmp01
	FROM dbo.f_parseJSON(@V_ElectronicInvoiceConfig)
	  
	DECLARE @V_IndustryClassificationCode NVARCHAR(50), @V_IndustryClassificationName NVARCHAR(50), @V_CrateUser NVARCHAR(50)
	DECLARE @V_GoodsName NVARCHAR(50), @V_TaxRate NUMERIC(12, 6), @V_Status NVARCHAR(10), @V_InvoiceType NVARCHAR(10)
	DECLARE @V_BuyerTypes NVARCHAR(10), @V_InvoiceLineNatureName NVARCHAR(50), @V_InvoiceLineNature NVARCHAR(50)

	SELECT @V_IndustryClassificationCode = StringValue FROM dbo.#Tmp01 WHERE Name = 'Hylx'
	SELECT @V_InvoiceLineNature = StringValue FROM dbo.#Tmp01 WHERE Name = 'FphXz'
	SELECT @V_TaxRate = CAST(StringValue AS NUMERIC(12, 6)) * 1.0 / 100 FROM dbo.#Tmp01 WHERE Name = 'Sl'
	SELECT @V_CrateUser = StringValue FROM dbo.#Tmp01 WHERE Name= 'Kpr'
	SELECT @V_GoodsName = StringValue FROM dbo.#Tmp01 WHERE Name = 'XmMc' 
	SELECT @V_IndustryClassificationName = StringValue FROM dbo.#Tmp01 WHERE Name = 'HylxName' 
	SET @V_Status = 2;
	SET @V_InvoiceType = 0;	
	Set @V_EmailAddr = 'fapiao@elfsack.com'
   
	-- 销售订单开票.
	BEGIN 
		INSERT INTO ElectronicInvoice(ElectronicInvoiceId,Code,StoreId,StoreName,TradeId,Status,AuditUser,AuditDate,InvoiceType,
										BuyerName,BuyerMobile,InvoiceCreateUser,InvoiceAmount,InvoiceAmountWithOutTax,InvoiceTax,
										Remark,IndustryClassificationCode,IndustryClassificationCodeName,InvoiceLineNature,GoodsName,
										Unit,GoodsUnitPrice,GoodsQty,
										TaxRate,CreateDate,CreateUser, EmailAddress, IsReded, SalesOrderId) 
		SELECT NEWID(), SOI.Code, SOI.StoreId, SOI.StoreName, SOI.TradeId, 2 AS Status, @V_CrateUser AS AuditUser, GETDATE() AS AuditDate,
			@V_InvoiceType, soi.Title AS buyerName, '' as Telephone, @V_CrateUser, soi.Amount AS InvocieAmount, 
			ROUND(soi.Amount / (1 + @V_TaxRate), 2) AS InvocieAmountWithOutTax, (soi.Amount - ROUND(soi.Amount / (1 + @V_TaxRate), 2)) AS InvoiceTax, 
			NULL AS Remark, @V_IndustryClassificationCode, 
			@V_IndustryClassificationName, @V_InvoiceLineNature, @V_GoodsName, NULL AS Unit, 
			ROUND(soi.Amount / (1 + @V_TaxRate), 2) AS GoodsUnitPrice, 1 as GoodsQty,
			@V_TaxRate * 100, GETDATE(), @V_CrateUser, @V_EmailAddr, 0, SOI.OrderId
		FROM (
				SELECT Distinct So.Code, So.StoreId, So.StoreName, so.TradeId, 
					case when so.HasInvoice = 1 then soi.Amount else so.PayAmount End as Amount,
					case when so.HasInvoice = 1 then soi.Title else '个人' End as Title,
					isnull(sos.Mobile, '') as Telephone, so.OrderId
				FROM dbo.SalesOrder so 
				LEFT JOIN dbo.SalesOrderInvoice soi ON so.OrderId = soi.SalesOrderId
				LEFT JOIN dbo.SalesOrderSub sos ON so.OrderId = sos.SubId
				WHERE 1 = 1
				AND so.PlatformStatus = 2 -- 全部发货
				--AND so.HasInvoice = 1 
				AND so.DeliveryDate >= @V_BeginDate
				AND so.TransType = 0 
				and case when so.HasInvoice = 1 then soi.Amount else so.PayAmount End > 0
				AND NOT EXISTS (SELECT 1 FROM dbo.ElectronicInvoice EI WHERE so.StoreId = ei.StoreId AND so.TradeId = ei.TradeId AND ei.InvoiceType = 0)
			) SOI;
	End
		 
	
	-- 退货单开票 @V_BeginDate
	BEGIN
		SELECT ID, TradeId, SalesOrderCode, SalesOrderId INTO #TMPRtn FROM dbo.ReturnOrder WHERE IsReplace = 0 AND IsElectronicInvoiceCreated = 0 AND AuditDate >= @V_BeginDate; 
		  
		--订单金额－退货商品金额  如果金额> 0 则开票　否则不开票
		SELECT Sale.TradeId, Sale.Code, (Sale.SaleAmt - Rtn.RtnAmt) AS NewInvAmt
		INTO #TMPRtnInv
		FROM (
				SELECT so.TradeId, MIN(so.Code) Code, SUM(sod.AmountActual) SaleAmt
				FROM dbo.SalesOrder so(NOLOCK), dbo.SalesOrderDetail sod(NOLOCK)
				WHERE so.OrderId = sod.SalesOrderId 
				AND TradeId IN (SELECT TradeId FROM #TMPRtn) 
				AND sod.Status = 2
				AND sod.IsDeleted = 0
				GROUP BY so.TradeId
			) Sale
			LEFT JOIN ( 
				SELECT ro.TradeId, SUM(sod.AmountActual) AS RtnAmt
				FROM ReturnOrder ro(NOLOCK), dbo.ReturnOrderDetail rod(NOLOCK), dbo.SalesOrderDetail sod(NOLOCK)
				WHERE ro.Id = rod.ReturnOrderId
				AND rod.SalesOrderDetailId = sod.DetailId
				AND ro.id IN (SELECT id FROM #TMPRtn)
				GROUP BY ro.TradeId
				) Rtn ON Sale.TradeId = Rtn.TradeId;
				 

		-- 销售订单开票
		INSERT INTO ElectronicInvoice(ElectronicInvoiceId,Code,StoreId,StoreName,TradeId,Status,AuditUser,AuditDate,InvoiceType,
										BuyerName,BuyerMobile,InvoiceCreateUser,InvoiceAmount,InvoiceAmountWithOutTax,InvoiceTax,
										Remark,IndustryClassificationCode,IndustryClassificationCodeName,InvoiceLineNature,GoodsName,
										Unit,GoodsUnitPrice,GoodsQty,
										TaxRate,CreateDate,CreateUser, EmailAddress, IsReded, SalesOrderId) 
		SELECT NEWID(), SOI.Code, SOI.StoreId, SOI.StoreName, SOI.TradeId, 2 AS Status, @V_CrateUser AS AuditUser, GETDATE() AS AuditDate,
			@V_InvoiceType, soi.Title AS buyerName, '' as Telephone, @V_CrateUser, soi.Amount AS InvocieAmount, 
			ROUND(soi.Amount / (1 + @V_TaxRate), 2) AS InvocieAmountWithOutTax, (soi.Amount - ROUND(soi.Amount / (1 + @V_TaxRate), 2)) AS InvoiceTax, 
			NULL AS Remark, @V_IndustryClassificationCode, 
			@V_IndustryClassificationName, @V_InvoiceLineNature, @V_GoodsName, NULL AS Unit, 
			ROUND(soi.Amount / (1 + @V_TaxRate), 2) AS GoodsUnitPrice, 1 as GoodsQty,
			@V_TaxRate * 100, GETDATE(), @V_CrateUser, @V_EmailAddr, 0, soi.OrderId
		FROM (
				SELECT Distinct So.Code, So.StoreId, So.StoreName, so.TradeId, 
					NewAmt.NewInvAmt  as Amount,
					case when so.HasInvoice = 1 then soi.Title else '个人' End as Title,
					isnull(sos.Mobile, '') as Telephone, so.OrderId
				FROM #TMPRtnInv NewAmt
				LEFT JOIN dbo.SalesOrder so ON so.Code = NewAmt.Code
				LEFT JOIN dbo.SalesOrderInvoice soi ON so.OrderId = soi.SalesOrderId
				LEFT JOIN dbo.SalesOrderSub sos ON so.OrderId = sos.SubId
				WHERE so.PlatformStatus = 2 -- 全部发货 
				AND so.TransType = 0 
				AND NewAmt.NewInvAmt > 0
			) SOI;

		UPDATE dbo.ReturnOrder SET IsElectronicInvoiceCreated = 1 WHERE ID IN (SELECT ID FROM #TMPRtn);
	END

	-- 换货单开票
	BEGIN	
		-- 换货单已发货未开票的订单信息
		SELECT So.Code, So.StoreId, So.StoreName, so.TradeId 
		INTO #TMPChangeOrder
		FROM dbo.SalesOrder so  
		WHERE so.PlatformStatus = 2 -- 全部发货
		AND so.DeliveryDate >= @V_BeginDate
		AND so.TransType = 4 
		AND NOT EXISTS (SELECT 1 FROM dbo.ElectronicInvoice EI WHERE so.StoreId = ei.StoreId AND so.Code = ei.Code AND ei.InvoiceType = 0);
		 
		SELECT So.TradeId, (Sale.SaleAmt - Rtn.RtnAmt) AS NewInvAmt
		INTO #TmpChangeAmt
		FROM (
				SELECT so.TradeId, SUM(sod.AmountActual) AS SaleAmt
				FROM dbo.SalesOrder so(NOLOCK), dbo.SalesOrderDetail sod(NOLOCK)
				WHERE so.OrderId = sod.SalesOrderId 
				AND so.TradeId IN (SELECT TradeId FROM #TMPChangeOrder)
				AND so.TransType IN (0, 4)
				AND so.IsObsolete = 0
				GROUP BY so.TradeId
			) Sale
			LEFT JOIN ( 
				SELECT ro.TradeId, SUM(Sod.AmountActual) AS RtnAmt
				FROM dbo.ReturnOrder ro(NOLOCK), dbo.ReturnOrderDetail rod(NOLOCK), dbo.SalesOrderDetail sod(NOLOCK)
				WHERE ro.Id = rod.ReturnOrderId
				AND rod.SalesOrderDetailId = sod.DetailId
				AND ro.TradeId IN (SELECT ro.TradeId FROM #TMPChangeOrder)
				AND ro.Status = 2
				GROUP BY ro.TradeId
			) Rtn ON Rtn.TradeId = Sale.TradeId;


		-- 订单金额（销售，换货)　－　退货商品金额，　如果金额　> 0 则开票，　否则不开票
		INSERT INTO ElectronicInvoice(ElectronicInvoiceId,Code,StoreId,StoreName,TradeId,Status,AuditUser,AuditDate,InvoiceType,
										BuyerName,BuyerMobile,InvoiceCreateUser,InvoiceAmount,InvoiceAmountWithOutTax,InvoiceTax,
										Remark,IndustryClassificationCode,IndustryClassificationCodeName,InvoiceLineNature,GoodsName,
										Unit,GoodsUnitPrice,GoodsQty,
										TaxRate,CreateDate,CreateUser, EmailAddress, IsReded, SalesOrderId) 
		SELECT NEWID(), SOI.Code, SOI.StoreId, SOI.StoreName, SOI.TradeId, 2 AS Status, @V_CrateUser AS AuditUser, GETDATE() AS AuditDate,
			@V_InvoiceType, soi.Title AS buyerName, '' as Telephone, @V_CrateUser, soi.Amount AS InvocieAmount, 
			ROUND(soi.Amount / (1 + @V_TaxRate), 2) AS InvocieAmountWithOutTax, (soi.Amount - ROUND(soi.Amount / (1 + @V_TaxRate), 2)) AS InvoiceTax, 
			NULL AS Remark, @V_IndustryClassificationCode, 
			@V_IndustryClassificationName, @V_InvoiceLineNature, @V_GoodsName, NULL AS Unit, 
			ROUND(soi.Amount / (1 + @V_TaxRate), 2) AS GoodsUnitPrice, 1 as GoodsQty,
			@V_TaxRate * 100, GETDATE(), @V_CrateUser, @V_EmailAddr, 0, SOI.OrderId
		FROM (
				SELECT Distinct So.Code, So.StoreId, So.StoreName, so.TradeId, 
					changeAmt.NewInvAmt as Amount,
					case when so.HasInvoice = 1 then soi.Title else '个人' End as Title,
					isnull(sos.Mobile, '') as Telephone, so.OrderId
				FROM #TMPChangeOrder changeOrder
				LEFT JOIN #TmpChangeAmt changeAmt ON changeAmt.TradeId = changeOrder.TradeId
				LEFT JOIN dbo.SalesOrder so ON so.Code = changeOrder.Code
				LEFT JOIN dbo.SalesOrderInvoice soi ON so.OrderId = soi.SalesOrderId
				LEFT JOIN dbo.SalesOrderSub sos ON so.OrderId = sos.SubId
				WHERE so.PlatformStatus = 2 -- 全部发货 
				AND so.TransType = 4
				AND so.DeliveryDate >= @V_BeginDate
				and changeAmt.NewInvAmt > 0
			) SOI

	END;
	 
	DROP TABLE #Tmp01, #TMPRtnInv, #TMPChangeOrder, #TmpChangeAmt;

END;



go

