  
CREATE FUNCTION [dbo].[F_GetWarehouseExpressRegionExpressFee](
	@P_WarehouseId	UNIQUEIDENTIFIER,
	@P_ExpressId	UNIQUEIDENTIFIER,
	@P_ProvinceName	Nvarchar(20),
	@P_Weight		Decimal(15, 3)
)
RETURNS Decimal(15, 2)
BEGIN
	DECLARE @P_Fee DECIMAL(15, 2)

	SELECT @P_Fee = SUM(CASE WHEN BeginWeight < @P_Weight AND EndWeight >= @P_Weight THEN CEILING((@P_Weight - BeginWeight) / Unit * 1000) * Price
							 ELSE ((EndWeight - BeginWeight) / Unit * 1000 * Price) END)
	FROM ExpressRegionCost
	WHERE WarehouseId = @P_WarehouseId
	AND ExpressId = @P_ExpressId
	AND ProvinceName = @P_ProvinceName
	AND (EndWeight <= @P_Weight OR (BeginWeight < @P_Weight AND EndWeight >= @P_Weight))


	RETURN ISNULL(@P_Fee, 0);
END;



go

