

/**
*create date: 2016-07-15
*create by：乔尼
*remark ：库存异动报表 商品编码查询异常
**/
CREATE VIEW [dbo].[V_ApiInventoryChange] AS 
SELECT APIT.*, PS.ProductCode
FROM dbo.ApiInventoryChange APIT(NOLOCK)
LEFT JOIN ProductSku PS(NOLOCK) ON APIT.Sku = PS.Code
WHERE ps.Status = 1



go

