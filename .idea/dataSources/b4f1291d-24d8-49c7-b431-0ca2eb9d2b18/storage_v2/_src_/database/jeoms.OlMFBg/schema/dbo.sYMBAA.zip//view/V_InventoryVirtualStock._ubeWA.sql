

/**********************
*create by：乔尼
*remark ：库存信息
***********************/
CREATE VIEW [dbo].[V_InventoryVirtualStock]
AS
      SELECT    iv.WarehouseId, iv.SkuId, iv.Quantity, ios.LockedQuantity, ios.DispatchedQuantity, ios.UnDispatchedQuantity, ios.AllotQuantity, ios.VipQuantity, 
		(ISNULL(iv.Quantity, 0)-ISNULL(ios.LockedQuantity, 0)) AS CanSaleQuantity, 
		(ISNULL(iv.Quantity, 0)-ISNULL(ios.DispatchedQuantity, 0)-ISNULL(ios.AllotQuantity, 0)-ISNULL(ios.VipQuantity, 0)) AS CanUseQuantity 
	  From InventoryVirtual iv(NOLOCK)
      LEFT JOIN V_InventoryOccupationSum ios(NOLOCK) ON ios.SkuId=iv.SkuId AND ios.WarehouseId=iv.WarehouseId;



go

