CREATE View [dbo].[V_ApplyRefundOrder] as
Select Aro.*, sod.Status as OrderDetailStatus, sod.IsDeleted as OrderDetailIsDeleted, SOS.Mobile
From ApplyRefundOrder ARO(nolock)
left Join SalesOrderDetail sod(nolock) on aro.SalesOrderDetailId = sod.DetailId
Left Join SalesOrderSub SOS(nolock) on Sod.SalesOrderId = SOS.SubId
go

