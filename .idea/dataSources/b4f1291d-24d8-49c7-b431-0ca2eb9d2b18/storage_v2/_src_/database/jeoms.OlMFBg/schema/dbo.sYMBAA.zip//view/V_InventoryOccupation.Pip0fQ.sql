
CREATE VIEW [dbo].[V_InventoryOccupation]
AS
       SELECT    ios.WarehouseId, ISNULL(iv.Quantity,0) Quantity, ios.LockedQuantity, ios.DispatchedQuantity, ios.UnDispatchedQuantity, ios.AllotQuantity, ios.VipQuantity, (ISNULL(iv.Quantity, 0)-ISNULL(ios.LockedQuantity, 0)) AS CanSaleQuantity, (ISNULL(iv.Quantity, 0)-ISNULL(ios.DispatchedQuantity, 0)-ISNULL(ios.AllotQuantity, 0)-ISNULL(ios.VipQuantity, 0)) AS CanUseQuantity, TransitTotalQuantity, p.Brand, sku.ProductId, sku.ProductCode, sku.ProductName, sku.SkuId, sku.Code, sku.Description,iv.IsLock
       FROM     ProductSku sku
       JOIN     Product p ON sku.ProductId=p.ProductId
       JOIN     V_InventoryOccupationSum ios ON ios.SkuId=sku.SkuId
       LEFT JOIN InventoryVirtual iv ON ios.SkuId=iv.SkuId AND iv.WarehouseId=ios.WarehouseId;



go

