

Create Function dbo.F_Get_CheckWarehouseIsArange
(
	@P_WarehouseId nvarchar(100),
	@P_ProvinceName nvarchar(100),
	@P_CityName nvarchar(100),
	@P_CountyName nvarchar(100)
)
Returns nvarchar(1)
As
Begin
	
	If EXISTS (SELECT 1 FROM dbo.WarehouseRegion WR WHERE WR.ProvinceName = @P_ProvinceName AND WR.CityName = @P_CityName AND WR.CountyName = @P_CountyName AND @P_WarehouseId = WR.WarehouseId)
		Begin
			Return 'Y';
		End;

	Return 'N'; 
End;
go

