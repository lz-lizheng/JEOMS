
 
CREATE VIEW [dbo].[V_ReportLackSalesOrderDetail] AS 
SELECT so.StoreId, so.PayDate, sod.ProductCode, sod.ProductName, SkuCode, SkuName, sod.Quantity, sod.ShippingDateClerk,
	   CASE WHEN sod.ShippingDateClerk IS NOT NULL THEN sod.Quantity ELSE 0 END AS PreSellQauntity
FROM dbo.SalesOrder so, dbo.SalesOrderDetail sod, dbo.ProductSku ps
WHERE so.OrderId = sod.SalesOrderId
AND sod.IsOutOfStock = 1
AND sod.ProductSkuId = ps.SkuId
AND sod.IsDeleted = 0



go

