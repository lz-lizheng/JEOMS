
CREATE Procedure [dbo].[P_AddexTendedProperty] (
@Table nvarchar(1000),
@ColumnName nvarchar(1000), 
@Description nvarchar(1000))
As
Begin
	EXEC sys.sp_addextendedproperty @name=N'MsDescription', @value=@Description, @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',
@level1name=@Table, @level2type=N'COLUMN',@level2name=@ColumnName
	

End

go

