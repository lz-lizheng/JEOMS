


/**
	预售链接不上传库存
*/
CREATE PROCEDURE [dbo].[P_QueryNeedUploadTrigger] (@top INT)
AS
      BEGIN	
            SELECT  d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, 
					dbo.F_CalcSkuUploadQuantity(d.ProductSkuId, uc.StoreId, d.PresellPlanId, 
												SUM(case when iv.IsLock = 1 then 0 else dbo.F_CalcSkuWarehouseUploadQuantity(iv.Quantity, ios.LockedQuantity, uc.Scale) end)) Quantity
            FROM    V_Distribution d
            JOIN    V_UploadConfig uc ON d.StoreId=uc.StoreId
			JOIN (SELECT DISTINCT SkuId,StoreId FROM InventoryTrigger WHERE [Status]=1) A ON A.SkuId=d.ProductSkuId AND (A.StoreId = d.StoreId OR A.StoreId IS NULL)
            LEFT JOIN dbo.InventoryVirtual iv ON d.ProductSkuId=iv.SkuId AND uc.WarehouseId=iv.WarehouseId
            LEFT JOIN dbo.V_InventoryOccupationSum ios ON uc.WarehouseId=ios.WarehouseId AND d.ProductSkuId=ios.SkuId
			Where d.IsAutoUploadInventory=1 AND uc.IsUpload=1
			And Not Exists (Select * From V_ProcessingPreSellPlan ppsp Where ppsp.StoreId = d.StoreId and ppsp.PlatformSkuId = d.PlatformId)
            GROUP BY d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, uc.StoreId, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformOutCode, d.PlatformSkuCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId
            
			UNION ALL

            SELECT  d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, 
					dbo.F_CalcSkuUploadQuantity(sku.SkuId, uc.StoreId, d.PresellPlanId, 
												SUM(case when iv.IsLock = 1 then 0 else dbo.F_CalcSkuWarehouseUploadQuantity(iv.Quantity, ios.LockedQuantity, uc.Scale) end))/sku.Quantity Quantity
            FROM    V_Distribution d
            JOIN    V_UploadConfig uc ON d.StoreId=uc.StoreId
			JOIN (SELECT DISTINCT SkuId,StoreId FROM InventoryTrigger WHERE [Status]=1) A ON A.SkuId=d.ProductSkuId AND (A.StoreId = d.StoreId OR a.StoreId IS NULL)
            JOIN    CombinedProductDetail sku ON d.ProductSkuId=sku.CombinedProductId
            LEFT JOIN dbo.InventoryVirtual iv ON sku.SkuId=iv.SkuId AND uc.WarehouseId=iv.WarehouseId
            LEFT JOIN dbo.V_InventoryOccupationSum ios ON uc.WarehouseId=ios.WarehouseId AND sku.SkuId=ios.SkuId
            WHERE  d.IsAutoUploadInventory=1 AND d.ProductType=1 AND sku.IsMainSku=1 AND uc.IsUpload=1
			And Not Exists (Select * From V_ProcessingPreSellPlan ppsp Where ppsp.StoreId = d.StoreId and ppsp.PlatformSkuId = d.PlatformId)
            GROUP BY d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, uc.StoreId, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformOutCode, d.PlatformSkuCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, sku.SkuId, sku.Quantity;
      END;



go

