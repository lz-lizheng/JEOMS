

CREATE View [dbo].[V_PlatStoreInventoryVirtual] as
Select A.StoreId, St.Name as StoreName, A.ProductSkuId, A.PlatformSkuCode, A.PlatformCode, A.ProductSkuCode, A.ProductCode, Sum(invs.Quantity) as StockQty, 
	Sum(invs.CanUseQuantity) as CanUseQty,
	Sum(Floor( invs.CanSaleQuantity * b.Scale / 100.0)) as CanSaleQty 
From V_Distribution A
Left join V_UploadConfig B On A.StoreId = B.StoreId
left join V_InventoryVirtualStock invs on b.WarehouseId = invs.WarehouseId and invs.SkuId = a.ProductSkuId
left join Store st on a.StoreId = st.Id
Group By A.StoreId, St.Name, A.ProductSkuId, A.PlatformSkuCode, A.PlatformCode, A.ProductSkuCode, A.ProductCode
go

