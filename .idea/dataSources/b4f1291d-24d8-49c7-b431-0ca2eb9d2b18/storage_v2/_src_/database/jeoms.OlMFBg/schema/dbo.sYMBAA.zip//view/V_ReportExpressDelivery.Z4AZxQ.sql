CREATE VIEW [dbo].[V_ReportExpressDelivery] AS 
SELECT 
	DO.Id,
	DOD.DeliveryDate,
	DO.SuggestExpressName, 
	DOD.ExpressId AS ActualExpressId,
	DOD.ExpressName AS ActualExpressName,
	DOD.ExpressNo as ActualExpressNo,
	DO.Code,
	DO.StoreId, 
	DO.StoreCode,
	DO.StoreName,
	DO.Province,
	DO.City,
	DO.County,
	DO.Weight,
	DO.Consignee,
	DO.Mobile,
	DO.WarehouseName,
	DO.WarehouseId ,
	DO.Address,
	DO.ReceivableAmounts,
	DOD.Quantity, 
	DO.LogisticsCost
FROM dbo.DispatchOrder(NOLOCK) DO 
LEFT JOIN ( 
	SELECT DOD.DispatchOrderId, 
		DODE.ExpressId,
		DODE.ExpressCode,
		DODE.ExpressName,
		DODE.ExpressNO,
		DODE.DeliveryDate,
		SUM(DODE.Quantity) Quantity 
	FROM dbo.DispatchOrderDetail(NOLOCK) DOD
	INNER JOIN dbo.DispatchOrderDetailExpress(NOLOCK) DODE ON dod.Id = DODE.DetailId
	GROUP BY DOD.DispatchOrderId, 
		DODE.ExpressId,
		DODE.ExpressCode,
		DODE.ExpressName,
		DODE.ExpressNO,
		DODE.DeliveryDate
) DOD ON do.id = dod.DispatchOrderId

go

