CREATE VIEW [dbo].[V_AbnormalDistribution]
AS
SELECT
  sku.ProductId,
  ProductCode,
  ProductName,
  sku.SkuId,
  sku.Code        SkuCode,
  sku.Description SkuName
FROM ProductSku sku
WHERE sku.Status = 1
AND exists(select 1 from InventoryVirtual iv where iv.SkuId=sku.SkuId and iv.Quantity>0)
AND NOT exists(SELECT 1 FROM DistributionProduct dp WHERE dp.ProductSkuId = sku.SkuId)


go

