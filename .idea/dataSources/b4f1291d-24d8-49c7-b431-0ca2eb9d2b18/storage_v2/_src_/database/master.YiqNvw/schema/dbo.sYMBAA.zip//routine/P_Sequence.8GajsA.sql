
/*
 *获取序列号，序列名称为表名+Sequence，如果不存在会新增一个
 *最小值默认为100000000000，可以不传
 *最大值默认为-1（不限制），可以不传
 *****************/
CREATE PROCEDURE [dbo].[P_Sequence]
    @sequence_name AS VARCHAR(50) ,--序列名称
    @minValue BIGINT = 100000000000 ,--最小值
    @maxValue BIGINT = -1 ,--最大值
    @range_size INT ,--取值数量
    @range_first_value BIGINT OUTPUT ,--返回的最小值
    @range_last_value BIGINT OUTPUT--返回的最大值
AS
    BEGIN TRANSACTION; 

    IF NOT EXISTS ( SELECT  1 FROM    dbo.Sequence WHERE   Name = @sequence_name )--如果不存在序列就新增一个
        BEGIN 
            INSERT  dbo.Sequence ( Name, MinValue, MaxValue, CurrentValue )
            VALUES  ( @sequence_name, @minValue, @maxValue, @minValue );
        END;

    SELECT  @range_first_value = CurrentValue,
            @range_last_value = CurrentValue + @range_size - 1,
            @maxValue = MaxValue
    FROM    dbo.Sequence WHERE Name=@sequence_name;
    IF @maxValue <> -1
        AND @maxValue < @range_last_value
        BEGIN 
			SELECT 0 AS rangefirstvalue, 0 AS rangelastvalue;
            RAISERROR ('Exceeds the maximum value' , 16, 1) WITH NOWAIT;
            RETURN 1;
        END;
    ELSE  
		SELECT @range_first_value AS rangefirstvalue, @range_last_value AS rangelastvalue;

        UPDATE  Sequence
        SET     CurrentValue = @range_last_value + 1
        WHERE   Name = @sequence_name;
    COMMIT TRANSACTION;
    IF @@ERROR <> 0 
        ROLLBACK TRANSACTION;

go

