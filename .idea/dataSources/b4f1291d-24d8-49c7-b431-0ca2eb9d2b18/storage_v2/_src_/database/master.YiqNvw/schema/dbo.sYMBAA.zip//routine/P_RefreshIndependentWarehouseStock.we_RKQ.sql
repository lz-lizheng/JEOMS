
 
/**********************
*create date : 2016-09-08
*create by：qiaoni 
*remark ：平负库存增加异动
***********************/
-- =============================================
-- Author:		QiaoNi
-- Create date: 2016-08-09
-- Description:	在共享仓可销库存足够的情况下, 更新独立仓负库存至共享仓
-- =============================================
CREATE PROCEDURE [dbo].[P_RefreshIndependentWarehouseStock] 
AS
BEGIN
	DECLARE @Id BIGINT
	DECLARE @SkuId UNIQUEIDENTIFIER, @ParentId UNIQUEIDENTIFIER
	DECLARE @Quantity INT, @VirQuantity INT, @UpdateQuantity INT

	declare updateIV cursor for 
		SELECT IV.Id , IV.SkuId, IV.Quantity ,WH.ParentId
		FROM dbo.InventoryVirtual IV(NOLOCK)
		LEFT JOIN dbo.Warehouse WH(NOLOCK) ON iv.WarehouseId = wh.Id
		WHERE wh.WarehouseType = 3
		AND iv.Quantity < 0;
	open updateIV    --打开游标
	fetch next from updateIV into @Id, @SkuId, @Quantity, @ParentId;
	while(@@fetch_status=0)    
	begin
		IF EXISTS (SELECT IV.Quantity  
				   FROM V_InventoryVirtual IV(NOLOCK)
				   LEFT JOIN dbo.Warehouse wh(NOLOCK) ON iv.WarehouseId = wh.Id AND wh.ParentId = @ParentId 
				   WHERE iv.SkuId = @SkuId AND wh.WarehouseType = 2 AND IV.CanSaleQuantity > 0)
			BEGIN
				SELECT @VirQuantity = IV.CanSaleQuantity FROM dbo.V_InventoryVirtual IV(NOLOCK) 
				LEFT JOIN dbo.Warehouse wh(NOLOCK) ON iv.WarehouseId = wh.Id AND wh.ParentId = @ParentId
				WHERE iv.SkuId = @SkuId AND wh.WarehouseType = 2 AND IV.Quantity > 0;

				IF @VirQuantity + @Quantity > 0
					BEGIN
						SET @UpdateQuantity = -@Quantity;
					END
                ELSE 
					BEGIN
						SET @UpdateQuantity = @VirQuantity
					End
					 
				-- 更新独立仓库存量
				UPDATE dbo.InventoryVirtual SET Quantity = Quantity + @UpdateQuantity WHERE Id = @Id;

				-- 更新共享仓库存量 
				Update InventoryVirtual 
				SET Quantity = Quantity - @UpdateQuantity
				FROM Warehouse wh
				WHERE InventoryVirtual.WarehouseId = wh.Id 
				AND wh.ParentId = @ParentId
				AND InventoryVirtual.SkuId = @SkuId
				AND wh.WarehouseType = 2;

				INSERT INTO dbo.InventoryTrigger( SkuId, CreateDate, Status ) VALUES(@SkuId, GETDATE(), 0);
			END 
	fetch next from updateIV into @Id, @SkuId, @Quantity, @ParentId;
	end
	close updateIV 
	deallocate updateIV  
END


go

