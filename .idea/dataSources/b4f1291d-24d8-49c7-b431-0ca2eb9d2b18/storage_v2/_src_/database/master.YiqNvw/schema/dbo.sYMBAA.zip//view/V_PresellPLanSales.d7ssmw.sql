
Create View [dbo].[V_PresellPLanSales] as 
Select PreSellPlanId, ProductSkuId, Sum(Quantity) as Quantity
From SalesOrderDetail
Where IsDeleted = 0
And PreSellPlanId Is Not Null
Group by PreSellPlanId, ProductSkuId
go

