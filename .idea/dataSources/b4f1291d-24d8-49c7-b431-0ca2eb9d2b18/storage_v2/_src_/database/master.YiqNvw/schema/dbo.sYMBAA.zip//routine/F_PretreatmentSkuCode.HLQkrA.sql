CREATE FUNCTION [dbo].[F_PretreatmentSkuCode] ( @skuCode VARCHAR(200) )
RETURNS VARCHAR(200)
AS
    BEGIN
        DECLARE @index INT;
        DECLARE @flag INT;
        SET @flag = CHARINDEX('YS',@skuCode);
        WHILE @flag > 0
            BEGIN
                SET @index = @flag;
                SET @flag = CHARINDEX('YS',@skuCode, @index + 1);
            END;
        IF @index > 0
            RETURN SUBSTRING(@skuCode,0,@index);
	 RETURN @skuCode;
    END;
go

