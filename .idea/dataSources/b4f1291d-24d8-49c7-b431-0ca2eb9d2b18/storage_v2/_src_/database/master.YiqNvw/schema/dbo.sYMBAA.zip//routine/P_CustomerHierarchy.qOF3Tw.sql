      
    
-- 加多系统配置参数：73,  用于记录会员清洗到的日期，该记录设定为不能人工编辑，只能通过系统作业更新。 系统作业记录添加到SysAutoJob
--CustomerHierarchy
--<会员清洗 20150717>
--<1. 统计会员店铺购物次数（会员ID）， 全网购物次数(手机号)>
CREATE Procedure [dbo].[P_CustomerHierarchy]  
As
Begin   
	Declare @V_RecordDate nVarchar(10), @V_Value nVarchar(100)   
	SELECT @V_Value = MAX(HierarchyDate) FROM dbo.CustomerHierarchy;  -- 清洗截止日期，　当次清洗开始日期
	Set @V_RecordDate = Convert(Varchar, DateAdd( Day, -1, GetDate()), 112)					  -- 当次清洗结束日期
	
	If @V_Value = ''
		Begin
			-- 初始信息提取到昨天为止制单的订单情况, 会员购买次数初始化
			Begin Try
				Begin Transaction		
					Print '会员分层初始化截止日期：' + @V_RecordDate
					------------------------------------------------------------------------------------------------------------
					-- 历史数据
					------------------------------------------------------------------------------------------------------------
					---- 店铺购物次数
					--PRINT '归档数据'
					--Update Customer
					--Set BuyTimes = ISNULL(A.BuyTimes, 0)
					--From ( 
					--	Select CustomerID, Count(1) as BuyTimes
					--	From dbo.History_SalesOrder
					--	Where Convert(Varchar, RecordDate, 112) <= @V_RecordDate
					--	Group By CustomerID
					--	) A
					--where Customer.Customer_Id = A.CustomerID;

					---- 全网购物次数
					--Update Customer
					--Set PlatformBuyTimes = ISNULL(A.PlatformBuyTimes, 0)
					--From ( 
					--	Select  Mobile, Count(1) as PlatformBuyTimes
					--	From History_SalesOrder
					--	Where Convert(Varchar, RecordDate, 112) <= @V_RecordDate
					--	Group By Mobile 
					--	) A
					--where Customer.Mobile = A.Mobile;

					------------------------------------------------------------------------------------------------------------
					-- 业务数据
					------------------------------------------------------------------------------------------------------------
					-- 店铺购物次数
					PRINT '业务数据'
					Update Customer
					Set BuyTimes = Isnull(Customer.BuyTimes, 0) +  ISNULL(A.BuyTimes, 0)
					From (
				
						Select CustomerID, Count(1) as BuyTimes
						From SalesOrder(NOLOCK)
						Where Convert(Varchar, CreateDate, 112) <= @V_RecordDate
						Group By CustomerID
						) A
					where Customer.CustomerId = A.CustomerID;
  
					-- 全网购物次数
					Update Customer
					Set PlatformBuyTimes = Isnull(Customer.PlatformBuyTimes, 0) +  ISNULL(A.PlatformBuyTimes, 0)
					From ( 
						Select  Mobile, Count(1) as PlatformBuyTimes
						From SalesOrder So(nolock), SalesOrderSub sos(nolock)
						Where Convert(Varchar, CreateDate, 112) <= @V_RecordDate
						and so.OrderId = sos.SubId
						Group By Mobile 
						) A
					where Customer.Mobile = A.Mobile;
 
					Update CustomerHierarchy Set HierarchyDate = @V_RecordDate;
					--Update SystemParameters Set Value = @V_RecordDate Where ParametersType = '73'
				Commit Transaction 
			End Try
			Begin Catch			
				Rollback Transaction 				
				Print '--**会员分层初始化出错 Rollback At: ' + Convert(Varchar, GetDate(), 20)												
				Print '--**Error Msg : ' +  error_message()
			End Catch 
		End
	Else
		Begin
			-- 每日会员清洗
			Begin Try
				Begin Transaction		
					Print '每日会员分层日期：' + @V_RecordDate
					-- 店铺购物次数
					Update Customer
					Set BuyTimes = ISNULL(BuyTimes, 0) + ISNULL(A.CalcBuyTimes, 0)
					From (
				
						Select CustomerID, Count(1) as CalcBuyTimes
						From SalesOrder So(nolock)
						Where Convert(Varchar, CreateDate, 112) > @V_Value And Convert(Varchar, CreateDate, 112) <= @V_RecordDate
						Group By CustomerID
						) A
					where Customer.CustomerId = A.CustomerID;

					-- 全网购物次数
					Update Customer
					Set PlatformBuyTimes = ISNULL(PlatformBuyTimes, 0) + ISNULL(A.CalcPlatformBuyTimes, 0)
					From ( 
						Select  Mobile, Count(1) as CalcPlatformBuyTimes
						From SalesOrder So(nolock), SalesOrderSub sos(nolock)
						Where Convert(Varchar, CreateDate, 112) > @V_Value And Convert(Varchar, CreateDate, 112) <= @V_RecordDate
						And so.OrderId = sos.SubId
						Group By Mobile
						) A
					where Customer.Mobile = A.Mobile;

					Update CustomerHierarchy Set HierarchyDate = @V_RecordDate;
				Commit Transaction 
			End Try
			Begin Catch			
				Rollback Transaction 				
				Print '--**每日会员分层出错 Rollback At: ' + Convert(Varchar, GetDate(), 20)												
				Print '--**Error Msg : ' +  error_message()
			End Catch 
		End 
End



go

