 
CREATE FUNCTION [dbo].[F_SplitString](@SourceData VARCHAR(MAX),@StrSeprate VARCHAR(10))
RETURNS @temp TABLE(ColData VARCHAR(100))
AS BEGIN 
 
DECLARE @i INT  
SET @SourceData=RTRIM(LTRIM(@SourceData))
SET @i=CHARINDEX(@StrSeprate,@SourceData)
 
WHILE @i>1
BEGIN
	INSERT @temp 
	VALUES(LEFT(@SourceData,@i-1))
	SET @SourceData=SUBSTRING(@SourceData,@i+1,LEN(@SourceData)-@i)
	SET @i=CHARINDEX(@StrSeprate,@SourceData) 
END 

IF @SourceData <> ''
	BEGIN
		INSERT @temp VALUES(@SourceData)
	END;
   RETURN;
END

go

