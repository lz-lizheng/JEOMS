CREATE VIEW [dbo].[V_UploadInfoByStoreWarehouse]
AS
SELECT
  iuc.StoreId,
  iuc.BrandName,
  iuw.WarehouseId,
  iuw.Scale,
  iv.SkuId,
  ISNULL(iv.Quantity, 0)        Quantity,
  ISNULL(ios.LockedQuantity, 0) LockedQuantity
FROM InventoryUploadConfig iuc
  JOIN InventoryUploadWarehouse iuw ON iuc.StoreId = iuw.StoreId
  LEFT JOIN InventoryVirtual iv ON iuw.WarehouseId = iuw.WarehouseId
  LEFT JOIN V_InventoryOccupationSum ios ON iuw.WarehouseId = ios.WarehouseId AND iv.SkuId = ios.SkuId
go

