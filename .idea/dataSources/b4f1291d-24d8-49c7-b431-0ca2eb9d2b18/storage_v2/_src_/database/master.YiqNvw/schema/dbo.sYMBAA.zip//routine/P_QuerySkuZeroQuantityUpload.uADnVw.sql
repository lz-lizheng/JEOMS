

/** 临时处理记录 PresellDate -> PresellPlanId  QiaoNi*/
CREATE PROCEDURE [dbo].[P_QuerySkuZeroQuantityUpload]
(
 @skuIds VARCHAR(MAX) ,
 @storeIds VARCHAR(MAX)
)
AS
      BEGIN
            DECLARE @skuList TABLE (id VARCHAR(100));
            DECLARE @storeList TABLE (id VARCHAR(100));
            INSERT  INTO @skuList
            SELECT  *
            FROM    dbo.F_SplitString(@skuIds, ','); 
            INSERT  INTO @storeList
            SELECT  *
            FROM    dbo.F_SplitString(@storeIds, ','); 

            SELECT  d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, 0 Quantity
            FROM    V_Distribution d
            LEFT JOIN    V_UploadConfig uc ON d.StoreId=uc.StoreId
            WHERE   d.ProductSkuId IN (SELECT   *
                                       FROM     @skuList) AND d.StoreId IN (SELECT  *
                                                                            FROM    @storeList) 
            GROUP BY d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, uc.StoreId, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformOutCode, d.PlatformSkuCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId
            UNION ALL
            SELECT  d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformSkuCode, d.PlatformOutCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, 0 Quantity
            FROM    V_Distribution d
            LEFT JOIN    V_UploadConfig uc ON d.StoreId=uc.StoreId
            LEFT JOIN CombinedProductDetail sku ON d.ProductSkuId=sku.CombinedProductId
            WHERE   sku.SkuId IN (SELECT    *
                                  FROM      @skuList) AND d.StoreId IN (SELECT  *
                                                                        FROM    @storeList) AND d.ProductType=1 AND sku.IsMainSku=1
            GROUP BY d.ProductSkuId, d.StoreId, d.Brand, uc.StoreBrand, d.PlatformId, uc.StoreId, uc.StoreBrand, d.PlatformId, d.PlatformSkuId, d.PlatformCode, d.PlatformOutCode, d.PlatformSkuCode, d.ProductCode, d.ProductSkuCode, d.PlatformSkuOutCode, d.IsAutoListing, d.IsAutoDeListing, d.ListingThreshold, d.DeListingThreshold, d.PresellPlanId, sku.SkuId;
      END;


go

