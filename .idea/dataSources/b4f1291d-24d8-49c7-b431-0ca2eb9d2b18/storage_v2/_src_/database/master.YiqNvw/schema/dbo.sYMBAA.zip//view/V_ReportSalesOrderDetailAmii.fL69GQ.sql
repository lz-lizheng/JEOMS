/**********************
*create by：Creoa
*remark ：AMII报表视图
***********************/
CREATE VIEW [dbo].[V_ReportSalesOrderDetailAmii] AS 
SELECT 
	so.StoreId,
    so.Code,
    so.StoreName,
    so.TradeId,
    dp.Code DispatchCode,
    dp.ActualExpressName,
    dp.ActualExpressNo,
    so.IsCod,
    so.ExpressFeeIsCod,
    so.IsHold,
    so.IsManual,
    so.CustomerCode,
    so.CustomerName,
    sl.IsOutOfStock,
    so.HasInvoice,
    sub.Consignee,
    so.PlatFromDate,
    so.CreateDate,
    sl.ShippingDateClerk,
    dp.DeliveryDate,
    dp.WarehouseName,
    so.SpeedDelivery,
    so.PreSaleType,
    so.PlatformType,
    so.Status,
    so.TransType,
    sub.Contacter,
    sub.ProvinceName,
    pro.Brand,
    pro.CategoryName,
    sub.Address,
    sub.Mobile,
    sl.ProductCode,
    sl.ProductName,
    sl.SkuCode,
    sl.SkuName,
    sl.Quantity,
    ISNULL(sl.PriceSelling,0) AS PriceSelling,
    ISNULL(sl.PriceOriginal,0) AS PriceOriginal,
    ISNULL(sl.Amount,0) AS Amount,
    ISNULL(sl.DiscountAmount,0) AS DiscountAmount,
    sl.DistributionAmount,
     
      
	(SELECT TOP 1 Price FROM dbo.ProductPriceChange(NOLOCK) WHERE ProductId=sl.ProductId AND BeginDate<=sl.CreateDate ) AS FirstCost,
    (SELECT TOP 1 Price FROM dbo.ProductPriceChange(NOLOCK) WHERE ProductId=sl.ProductId AND BeginDate<=sl.CreateDate )*sl.Quantity as ProductFirstCost,
    so.ExpressFee,
    so.IsObsolete,
	(SELECT TOP 1 AlipayRecord.CreateDate FROM dbo.AlipayRecord WHERE OrderNo=so.TradeId) AS ActulDate,
   (SELECT TOP 1 InAmount FROM dbo.AlipayRecord WHERE OrderNo=so.TradeId AND InAmount>0) AS ActulCollection,
    dpl.outer_iid,
    dpl.title,
    dpl.outer_sku_id,
    dpl.sku_properties_name,
    dpl.num,
    sl.DetailType,
    so.TagName,
    sl.TagName as SlTagName
    FROM dbo.SalesOrder(nolock) so
    INNER JOIN dbo.SalesOrderSub(NOLOCK) sub ON sub.SubId=so.OrderId
    INNER JOIN dbo.SalesOrderDetail(NOLOCK) sl ON sl.SalesOrderId=so.OrderId
    left JOIN dbo.DispatchOrderDetail(NOLOCK) dl ON dl.SalesOrderDetailId=sl.DetailId
    LEFT JOIN dbo.SalesOrderDetailPlatformProduct(NOLOCK) dpl ON dl.Id=sl.DetailId
    left JOIN dbo.DispatchOrder(NOLOCK) dp ON dp.Id=dl.DispatchOrderId
    LEFT JOIN dbo.Product(NOLOCK) pro ON pro.ProductId=sl.ProductId

go

