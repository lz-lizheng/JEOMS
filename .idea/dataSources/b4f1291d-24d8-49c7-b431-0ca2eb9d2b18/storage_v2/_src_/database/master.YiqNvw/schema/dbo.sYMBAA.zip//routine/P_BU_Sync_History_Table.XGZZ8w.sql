
  
CREATE Procedure [dbo].[P_BU_Sync_History_Table] 
As
Begin
	Print ' 1.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] SalesOrderLog

	Print ' 2.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] SalesOrderOutofStock

	Print ' 3.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] SalesOrderInvoice

	Print ' 4.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] SalesOrderDiscount

	Print ' 5.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] SalesOrderPayMent

	Print ' 6.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] SalesOrderActivity

	Print ' 7.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] SalesOrderDeliveryInfo

	Print ' 8.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] SalesOrderDetailPlatformProduct

	Print ' 9.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] SalesOrderDetail

	Print ' 10.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] SalesOrderSub

	Print ' 11.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] SalesOrder
	  
	------------------------------------------------------------
	------------------------------------------------------------ 
	Print ' 2.1 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] DispatchOrderDetailExpress
	 
	Print ' 2.2 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] DispatchOrderDetail
	  
	Print ' 2.3 同步表结构: ' + Convert(Varchar, GetDate(), 20)
	Exec [dbo].[P_BU_Check_History_Table] DispatchOrder
	 
End;


go

