

 /**********************
*create date : 2016-12-14
*create by：qiaoni 
*remark ： 增加次品数量
***********************/
CREATE VIEW [dbo].[V_ReportPurchaseOrder] AS 
SELECT PO.Code,
	   PNO.Code AS PnoCode,
	   PO.PurchaseDate,
	   PO.RequestDeliveryDate,
	   PO.SupplierCode,
	   po.SupplierName, 
	   PNO.WarehouseID,
	   PNO.WarehouseName,
	   PO.Status,
	   POD.ProductCode,
	   POD.ProductName,
	   POD.SkuCode, 
	   POD.SkuName,
	   POD.Color, 
	   POD.Size,
	   POD.PurchaseQty, 
	   POD.CurrentPrice AS OriginalPrice,
	   PNO.Remark,
	   PNO.Status AS PnoStatus,
	   PNOD.NoticeQty, 
	   PNOD.StockInQty,
	   PNOD.WarehousingTime,
	   pd.Year,
	   pd.Season,
	   pd.Brand,
	   pd.CategoryName,
	   PO.ContractNo,
	   SSP.SupplierSettlementType,
	   PNO.ArriveBatchNo,
	   PNOD.DefectiveQuantity
FROM PurchaseOrder PO(NOLOCK)
LEFT JOIN PurchaseOrderDetail POD(NOLOCK) ON PO.Id = pod.PurchaseOrderId
LEFT JOIN PurchaseNoticeOrder PNO(NOLOCK) ON po.Id = PNO.PurchaseOrderId
LEFT JOIN PurchaseNoticeOrderdetail PNOD(NOLOCK) ON PNO.Id = PNOD.PurchaseNoticeOrderId AND POD.SkuId = PNOD.SkuId
LEFT JOIN dbo.Product PD(NOLOCK) ON POD.ProductId = pd.ProductId
LEFT JOIN dbo.Supplier SSP(NOLOCK) ON po.SupplierCode = ssp.Code 
WHERE pnod.DetailId IS NOT null


 go

 exec sp_addextendedproperty 'MS_Description', '?????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'Code'
 go

 exec sp_addextendedproperty 'MS_Description', '??????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'PnoCode'
 go

 exec sp_addextendedproperty 'MS_Description', '??', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'PurchaseDate'
 go

 exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'RequestDeliveryDate'
 go

 exec sp_addextendedproperty 'MS_Description', '?????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'SupplierCode'
 go

 exec sp_addextendedproperty 'MS_Description', '?????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'SupplierName'
 go

 exec sp_addextendedproperty 'MS_Description', '??ID', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'WarehouseID'
 go

 exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'WarehouseName'
 go

 exec sp_addextendedproperty 'MS_Description', '??????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'Status'
 go

 exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'ProductCode'
 go

 exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'ProductName'
 go

 exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'SkuCode'
 go

 exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'SkuName'
 go

 exec sp_addextendedproperty 'MS_Description', '??', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN', 'Color'
 go

 exec sp_addextendedproperty 'MS_Description', '??', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN', 'Size'
 go

 exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'PurchaseQty'
 go

 exec sp_addextendedproperty 'MS_Description', '???', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'OriginalPrice'
 go

 exec sp_addextendedproperty 'MS_Description', '??', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'Remark'
 go

 exec sp_addextendedproperty 'MS_Description', '???????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'PnoStatus'
 go

 exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'NoticeQty'
 go

 exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'StockInQty'
 go

 exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_ReportPurchaseOrder', 'COLUMN',
      'WarehousingTime'
 go

