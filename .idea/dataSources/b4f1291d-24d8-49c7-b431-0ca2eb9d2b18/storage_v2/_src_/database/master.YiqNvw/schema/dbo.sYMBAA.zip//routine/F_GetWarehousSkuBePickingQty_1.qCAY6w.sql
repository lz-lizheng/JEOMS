



CREATE FUNCTION [dbo].[F_GetWarehousSkuBePickingQty_1]
(
	@SkuId UNIQUEIDENTIFIER,		--规格ID
	@payTime DATETIME,				--支付时间
	@WarehousId NVARCHAR(max)		--仓库Id
)
RETURNS INT
AS
BEGIN
	DECLARE @V_BePickingQty INT
      
	SELECT @V_BePickingQty = ISNULL(SUM(a.Quantity), 0)
	FROM (
		-- 现有库存
		SELECT SUM(iv.Quantity) AS Quantity
		FROM dbo.InventoryVirtual IV(NOLOCK)
		WHERE IV.WarehouseId in (SELECT * FROM dbo.F_SplitString(@WarehousId, ','))
		AND IV.SkuId=@SkuId  
		UNION ALL 
        SELECT ISNULL(SUM(ioc.Quantity),0) * -1 AS LockQuantity
		FROM InventoryOccupation(NOLOCK)ioc 
		WHERE ioc.SkuId = @SkuId
		AND (ioc.IsDispatched=1 
			OR ioc.Type in (3,4,5)  
			OR (ioc.Type IN (1, 2) AND ioc.IsDispatched = 0 and ioc.PayDate<@payTime)
			)
		AND ioc.WarehouseId IN (SELECT * FROM dbo.F_SplitString(@WarehousId, ','))
		 
		--UNION ALL
		---- 订单占用(未配货占用 同实体仓下所有占用)  
		--SELECT SUM(iocc.Quantity) * -1 AS Quantity
		--FROM dbo.InventoryOccupation iocc(NOLOCK)
		--WHERE iocc.SkuId = @SkuId 
		--AND iocc.WarehouseId IN (SELECT WHNew.Id 
		--							FROM dbo.Warehouse WhOrig, dbo.Warehouse WHNew 
		--							WHERE WhOrig.Id = @WarehousId AND WhOrig.ParentId = WhNew.ParentId)
		--AND iocc.PayDate < @payTime AND iocc.Type = 1 AND IsDispatched = 0 
		--UNION ALL
		---- 换货订单占用(未配货占用)  
		--SELECT SUM(iocc.Quantity) * -1 AS Quantity
		--FROM dbo.InventoryOccupation iocc(NOLOCK)
		--WHERE iocc.SkuId = @SkuId 
		--AND iocc.WarehouseId = @WarehousId AND iocc.PayDate < @payTime AND iocc.Type = 2 AND IsDispatched = 0 
		---- 订单、换货订单占用(已配货占用)
		--UNION ALL
		--SELECT SUM(iocc.Quantity) * -1 AS Quantity
		--FROM dbo.InventoryOccupation iocc(NOLOCK)
		--WHERE iocc.SkuId = @SkuId AND iocc.WarehouseId = @WarehousId AND iocc.Type IN (1, 2) AND IsDispatched = 1
		--UNION ALL
		---- 调拨占用
		--SELECT SUM(iocc.Quantity) * -1 AS Quantity
		--FROM dbo.InventoryOccupation iocc(NOLOCK)
		--WHERE iocc.SkuId = @SkuId AND iocc.WarehouseId = @WarehousId AND iocc.Type IN (3, 4,5)
		) A;
		 
		RETURN @V_BePickingQty;
END



go

