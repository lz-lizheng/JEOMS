
-- 库存上传增加比例
CREATE FUNCTION [dbo].[F_GetPreSellBeUploadQty]
(
	@SkuId UNIQUEIDENTIFIER,		--规格ID 
	@StoreId UNIQUEIDENTIFIER	--店铺Id
)
RETURNS INT
AS
BEGIN
	DECLARE @V_BeUploadQty INT
    
	DECLARE @Table TABLE(BeginDate DATETIME, EndDate DATETIME, PreSellQty INT, ID UNIQUEIDENTIFIER, Rate INT);

	INSERT INTO @Table(BeginDate, EndDate, PreSellQty, ID, Rate)
	SELECT TOP 1 psl.BeginDate, psl.EndDate, PDtl.PreSellQuantity, psl.Id, detail.Rate
	FROM PreSellPlanStoreDetail(NOLOCK) detail  
	INNER JOIN dbo.PreSellPlanDetail (NOLOCK) PDtl ON detail.DetailId = PDtl.Id
	INNER JOIN PreSellPlan(NOLOCK) psl ON psl.id=detail.PreSellPlanId 
	WHERE detail.status= 2
	AND psl.status= 2
	AND detail.StoreId = @StoreId
	AND psl.endDate > GETDATE()
	AND detail.SkuId=@SkuId;
	  

	IF(NOT EXISTS(SELECT 1 FROM @Table))
		BEGIN
			RETURN -99999;
        END
	ELSE
		BEGIN
			SELECT @V_BeUploadQty = ISNULL(SUM(A.PreSellQty), 0)
			FROM ( 
				SELECT (PreSellQty - A.Quantity) * Rate / 100 AS PreSellQty 
				FROM @Table
				CROSS JOIN (
					SELECT ISNULL(SUM(SOD.Quantity), 0) AS Quantity 
					FROM @Table Orig
					INNER JOIN dbo.SalesOrderDetail(NOLOCK) SOD ON SOD.ShippingDateClerk >= Orig.BeginDate
					INNER JOIN dbo.SalesOrder(NOLOCK) SO ON so.OrderId = sod.SalesOrderId AND so.PayDate >= Orig.BeginDate
					WHERE SOD.ProductSkuId = @SkuId
					AND sod.IsDeleted = 0
					AND so.StoreId IN (SELECT StoreId FROM dbo.PreSellPlanStore WHERE PreSellPlanId IN (SELECT ID FROM @Table))) A
				) A
        END
		    
	RETURN @V_BeUploadQty;
END


go

