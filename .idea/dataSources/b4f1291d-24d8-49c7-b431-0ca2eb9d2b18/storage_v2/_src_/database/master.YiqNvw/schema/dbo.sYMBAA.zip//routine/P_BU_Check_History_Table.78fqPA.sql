
CREATE Procedure [dbo].[P_BU_Check_History_Table]
(
	@P_FromTblName	nVarchar(100)
)
As
Begin
	print '[P_BU_Check_History_Table]'
	Declare @V_ToTblName nVarchar(100), @V_CreateSQL nVarchar(1000), @V_Truncate nVarchar(1000)
	print '[P_BU_Check_History_Table]   1'
	If not exists (select 1 from sys.sysobjects where name= @P_FromTblName and type in (N'U'))
		Return
	
	PRINT '[P_BU_Check_History_Table]   2'

	Set @V_ToTblName = @P_FromTblName 
	if exists (select 1 from [jehistory].sys.sysobjects where name= @V_ToTblName and type in (N'U'))
		begin
			Print '-- ** Sync History Table Structure, Table Name : ' + @V_ToTblName;			
			Exec P_BU_Sync_History_Table_Structure @P_FromTblName; 
		end
	else
		begin
			Print '-- ** Create History Table, Table Name : ' + @V_ToTblName
			Set @V_CreateSQL = 'Select Top 0 * Into [jehistory].DBO.' + @V_ToTblName + ' From ' + @P_FromTblName;			
			print @V_CreateSQL 
			Exec SP_EXECUTESQL @V_CreateSQL
		end

		
End;

go

