CREATE VIEW [dbo].[V_SalesOrderActivity] AS 
SELECT ActivityId, SOD.ProductSkuId, Sum(Quantity) as SalesQty From SalesOrderActivity SOA(nolock) LEFT join SalesOrderDetail SOD(nolock) on SOA.SalesOrderId = SOD.SalesOrderId GROUP by ActivityId, SOD.ProductSkuId

go

