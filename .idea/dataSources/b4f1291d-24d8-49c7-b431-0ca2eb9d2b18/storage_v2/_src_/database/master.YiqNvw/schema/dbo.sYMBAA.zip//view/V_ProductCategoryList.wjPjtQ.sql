
Create View [dbo].[V_ProductCategoryList] As
Select PC1.Id as Category1_Id, --品牌ID
	   PC1.Name as Name1,				--品牌名称
	   PC2.Id as Category2_Id, --大类ID
	   PC2.Name as Name2,				--大类名称
	   PC3.Id as Category3_Id, --子类ID
	   PC3.Name as Name3,				--子类名称
	   PC4.Id as Category4_Id, --分类ID
	   PC4.Name as Name4				--分类名称
From ProductCategory pc1 
Left Join ProductCategory pc2 on pc1.Id = pc2.ParentId
Left Join ProductCategory pc3 on pc2.Id = pc3.ParentId
Left Join ProductCategory pc4 on pc3.Id = pc4.ParentId
Where PC1.ParentId Is Null


go

