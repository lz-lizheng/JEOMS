

CREATE VIEW [dbo].[V_VipReturnOrder] AS 
SELECT VRO.CreateDate,
	Status,ReturnOrderCode,VipReturnOrderCode,
	ReturnType,ReturnSignType,
	WarehouseId, WarehouseName,
	InWarehouseId,InWarehouseName,
	OutDate, TotalCases,
	TotalSkus,TotalQtys,
	SignDate,SignUserName,
	Note,
	PoCode,BoxNo,
	ReturnOrderId,ProductId,
	ProductCode,ProductName,
	SkuId,SkuCode,
	SkuName,VipSkuCode,
	ReturnQty,InQty
FROM dbo.VipReturnOrder VRO
LEFT JOIN dbo.VipReturnOrderDetail VROD ON VROD.ReturnOrderId = VRO.Id


go

