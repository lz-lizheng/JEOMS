

/**********************
*create date: 2016-07-11
*create by：乔尼
*remark ：唯品退货通知单报表加制单时间
***********************/
CREATE VIEW [dbo].[V_VipReturnOrderNotice] AS 
SELECT VRO.VipReturnOrderCode,
	   VRON.ReturnOrderCode, 
	   VRON.VipReturnOrderNoticeCode,
	   VRO.InWarehouseId,
	   VRO.InWarehouseName,
	   VROND.ProductCode,
	   VROND.ProductName,
	   VROND.SkuCode,
	   VROND.SkuName,
	   VROND.NoticeQty,
	   VROND.InQty,
	   VROND.WarehousingTime,
	   VRON.CreateDate 
FROM dbo.VipReturnOrderNotice VRON(NOLOCK)
LEFT JOIN dbo.VipReturnOrderNoticeDetail VROND(NOLOCK) ON VROND.ReturnOrderNoticeId = VRON.Id
LEFT JOIN dbo.VipReturnOrder VRO(NOLOCK) ON VRO.ReturnOrderCode = VRON.ReturnOrderCode


go

exec sp_addextendedproperty 'MS_Description', '??????', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'VipReturnOrderCode'
go

exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ReturnOrderCode'
go

exec sp_addextendedproperty 'MS_Description', '??????', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'VipReturnOrderNoticeCode'
go

exec sp_addextendedproperty 'MS_Description', '????ID', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InWarehouseId'
go

exec sp_addextendedproperty 'MS_Description', '??????', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InWarehouseName'
go

exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ProductCode'
go

exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'ProductName'
go

exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'SkuCode'
go

exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'SkuName'
go

exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'NoticeQty'
go

exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'InQty'
go

exec sp_addextendedproperty 'MS_Description', '????', 'SCHEMA', 'dbo', 'VIEW', 'V_VipReturnOrderNotice', 'COLUMN',
     'WarehousingTime'
go

