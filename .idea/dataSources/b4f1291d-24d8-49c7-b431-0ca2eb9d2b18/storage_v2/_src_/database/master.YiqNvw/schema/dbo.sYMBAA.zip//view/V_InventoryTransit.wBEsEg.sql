



CREATE VIEW [dbo].[V_InventoryTransit] AS 
SELECT A.SkuId, A.WarehouseId, SUM(A.TransitTotalQuantity) AS TransitTotalQuantity
FROM (
	SELECT SkuId, WarehouseId, TransitTotalQuantity
	FROM dbo.InventoryVirtual A
	WHERE A.TransitTotalQuantity > 0
	UNION ALL
	SELECT pod.SkuId, wh.Id AS warehouseId, (pod.PurchaseQty - pod.InStockQty) AS TransitTotalQuantity
	FROM PurchaseOrder PO(NOLOCK)
	LEFT JOIN PurchaseOrderDetail POD(NOLOCK) ON po.Id = POD.PurchaseOrderId
	LEFT JOIN Warehouse WH(NOLOCK) ON wh.ParentId = po.WarehouseID AND wh.WarehouseType = 2
	WHERE po.Status = 1 
	AND pod.PurchaseQty > pod.InStockQty
	) A
GROUP BY A.SkuId, A.WarehouseId



go

