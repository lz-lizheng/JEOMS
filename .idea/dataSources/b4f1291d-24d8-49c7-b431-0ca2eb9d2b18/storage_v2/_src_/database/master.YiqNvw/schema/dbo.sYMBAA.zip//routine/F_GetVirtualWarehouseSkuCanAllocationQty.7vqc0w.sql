

 /**********************
*create date : 2016-09-05
*create by：qiaoni 
*remark ：实体调拨可调计算逻辑
***********************/
-- =============================================
-- Author:		<郭瑞华>
-- Create date: <2015-12-21>
-- Description:	<计算仓库 Sku可调拨数量>
-- =============================================
CREATE FUNCTION [dbo].[F_GetVirtualWarehouseSkuCanAllocationQty]
(
	@P_WarehouseID	UNIQUEIDENTIFIER,	--共享/独立仓库
	@P_SkuId		UNIQUEIDENTIFIER	--SKU ID 
)
RETURNS INT
AS
BEGIN
	DECLARE @V_Rlt INT
	  
	DECLARE @V_EntityWarehouse UNIQUEIDENTIFIER 
	SELECT @V_EntityWarehouse = ParentId FROM dbo.Warehouse WHERE id = @P_WarehouseID;
	  
	SELECT @V_Rlt = SUM(AC.TotalQuantity)
	FROM (
		-- 仓库库存(共享仓:只能从共享仓调拨到其他仓库)
		SELECT SUM(IV.Quantity) AS TotalQuantity
		FROM dbo.InventoryVirtual IV
		WHERE IV.WarehouseId = @P_WarehouseID
		AND IV.SkuId = @P_SkuId 
		-- 1.1 同虚拟仓下可销
		UNION 
		SELECT SUM(LockedQuantity) * -1 AS LockedQty
		FROM V_InventoryOccupationSum
		WHERE WarehouseId = @P_WarehouseID
		AND SkuId = @P_SkuId
		--1.2 同实体仓下其他共享/独立负可销
		UNION 
		SELECT ISNULL(SUM(CanSaleQuantity), 0) AS OthersWarehouseQty
		FROM (
				SELECT ios.WarehouseId, ios.SkuId, SUM(ios.CanSaleQuantity) AS CanSaleQuantity 
				FROM V_InventoryVirtualStock ios 
				LEFT JOIN dbo.Warehouse wh ON ios.WarehouseId = wh.Id
				WHERE ios.WarehouseId = wh.Id
				AND wh.ParentId = @V_EntityWarehouse
				AND ios.WarehouseId <> @P_WarehouseID
				and ios.SkuId = @P_SkuId
				GROUP BY ios.WarehouseId, ios.SkuId
			) ios
		LEFT JOIN dbo.InventoryVirtual iv ON ios.WarehouseId = iv.WarehouseId AND iv.SkuId = ios.SkuId
		HAVING SUM(CanSaleQuantity) < 0
		) AC

	-- 返回可销
	RETURN ISNULL(@V_Rlt, 0); 
END


 go

