CREATE FUNCTION [dbo].[F_GetAllCanDispatch]
  (
    @SkuId   UNIQUEIDENTIFIER, --规格ID
    @storeId   UNIQUEIDENTIFIER, --规格ID
    @payTime DATETIME        --支付时间
  
  )
  RETURNS INT
AS
  
  BEGIN
    DECLARE @inventory INT
    DECLARE @occupation INT
    
    SELECT @inventory = ISNULL(SUM(iv.Quantity),0)
    FROM InventoryVirtual(NOLOCK)iv
    JOIN DispatchTemplateWarehouse dtw on iv.WarehouseId=dtw.WarehouseId
    JOIN DispatchTemplate dt on dtw.TemplateId=dt.Id
    JOIN StoreSetting ss on dt.Id=ss.DispatchTemplateId
    WHERE iv.SkuId = @SkuId and ss.StoreId=@storeId

    SELECT @occupation = ISNULL(SUM(ioc.Quantity),0)
    FROM InventoryOccupation(NOLOCK)ioc
      JOIN DispatchTemplateWarehouse dtw on ioc.WarehouseId=dtw.WarehouseId
      JOIN DispatchTemplate dt on dtw.TemplateId=dt.Id
      JOIN StoreSetting ss on dt.Id=ss.DispatchTemplateId
    WHERE ioc.SkuId = @SkuId and ss.StoreId=@storeId AND (ioc.Type in (2,3,4,5) OR ioc.IsDispatched=1 OR(ioc.Type=1 and ioc.PayDate<@payTime))

    RETURN @inventory-@occupation;
  END
go

