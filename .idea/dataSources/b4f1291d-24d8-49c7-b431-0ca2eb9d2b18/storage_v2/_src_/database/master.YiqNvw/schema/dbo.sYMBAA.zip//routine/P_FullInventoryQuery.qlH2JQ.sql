

CREATE PROCEDURE [dbo].[P_FullInventoryQuery]
(
 @warehouseIds AS VARCHAR(MAX)=NULL ,
 @productCodes AS VARCHAR(1000)=NULL ,
 @skuCodes AS VARCHAR(1000)=NULL ,
 @brandCodes AS VARCHAR(1000)=NULL ,
 @productNames AS VARCHAR(1000)=NULL ,
 @quantity AS INT=0 ,
 @showTransit AS INT=0 ,
 @pageIndex AS INT=1 ,
 @pageSize AS INT=50 ,
 @total AS INT OUTPUT
)
AS
       DECLARE @countSql NVARCHAR(MAX);
       DECLARE @pageSql NVARCHAR(MAX);
       DECLARE @startIndex INT;
       DECLARE @endIndex INT;

       SET @startIndex=(@pageIndex-1)*@pageSize;
       SET @endIndex=@pageIndex*@pageSize;

       DECLARE @warehouseSql NVARCHAR(MAX);
       IF @warehouseIds IS NOT NULL AND @warehouseIds<>''
          SET @warehouseIds=' WHERE WarehouseId IN('+@warehouseIds+')';

       DECLARE @sql NVARCHAR(MAX)= 'SELECT  p.WarehouseId,p.Quantity ,p.LockedQuantity ,p.DispatchedQuantity ,p.UnDispatchedQuantity ,p.AllotQuantity ,p.VipQuantity ,p.CanSaleQuantity ,p.CanUseQuantity ,p.TransitQuantity,
	   sku.ProductBrand Brand, sku.ProductId, sku.ProductCode, sku.ProductName, sku.SkuId, sku.SkuCode Code, sku.SkuName Description FROM (';
       DECLARE @skuSql NVARCHAR(1000)= ' SELECT * FROM  V_ProductSku WHERE 1=1 ';
       IF @productCodes IS NOT NULL AND @productCodes<>''
          SET @skuSql=@skuSql+' AND ProductCode IN ('+@productCodes+')';
       IF @productNames IS NOT NULL AND @productNames<>''
          SET @skuSql=@skuSql+' AND ProductName IN ('+@productNames+')';
       IF @skuCodes IS NOT NULL AND @skuCodes<>''
          SET @skuSql=@skuSql+' AND SkuCode IN ('+@skuCodes+')';
       IF @brandCodes IS NOT NULL AND @brandCodes<>''
          SET @skuSql=@skuSql+' AND ProductBrandCode IN ('+@brandCodes+')';

       SET @sql=@sql+@skuSql+') sku JOIN (SELECT ';
       IF @showTransit>0
          SET @sql=@sql+'WarehouseId = CASE WHEN iv.WarehouseId IS NOT NULL THEN iv.WarehouseId WHEN ios.WarehouseId IS NOT NULL THEN ios.WarehouseId ELSE it.WarehouseId END ,
								SkuId = CASE WHEN iv.SkuId IS NOT NULL THEN iv.SkuId WHEN ios.SkuId IS NOT NULL THEN ios.SkuId ELSE it.SkuId END ,
                                iv.Quantity ,ios.LockedQuantity ,ios.DispatchedQuantity ,ios.UnDispatchedQuantity ,ios.AllotQuantity ,ios.VipQuantity ,
                                (ISNULL(iv.Quantity, 0)-ISNULL(ios.LockedQuantity, 0)) AS CanSaleQuantity ,
                                (ISNULL(iv.Quantity, 0)-ISNULL(ios.DispatchedQuantity, 0)-ISNULL(ios.AllotQuantity, 0)-ISNULL(ios.VipQuantity, 0)) AS CanUseQuantity,it.TransitTotalQuantity TransitQuantity';
       ELSE
          SET @sql=@sql+'WarehouseId = CASE WHEN iv.WarehouseId IS NOT NULL THEN iv.WarehouseId ELSE ios.WarehouseId END ,
								SkuId = CASE WHEN iv.SkuId IS NOT NULL THEN iv.SkuId ELSE ios.SkuId END ,
                                iv.Quantity ,ios.LockedQuantity ,ios.DispatchedQuantity ,ios.UnDispatchedQuantity ,ios.AllotQuantity ,ios.VipQuantity ,
                                (ISNULL(iv.Quantity, 0)-ISNULL(ios.LockedQuantity, 0)) AS CanSaleQuantity ,
                                (ISNULL(iv.Quantity, 0)-ISNULL(ios.DispatchedQuantity, 0)-ISNULL(ios.AllotQuantity, 0)-ISNULL(ios.VipQuantity, 0)) AS CanUseQuantity,TransitQuantity=0';
       SET @sql=@sql+' FROM   (SELECT * FROM   InventoryVirtual '+@warehouseIds;
       IF @quantity>0
          SET @sql=@sql+' AND Quantity>0';
       ELSE
          IF @quantity<0
             SET @sql=@sql+' AND Quantity<=0';
       SET @sql=@sql+') iv FULL JOIN (SELECT * FROM V_InventoryOccupationSum '+@warehouseIds+') ios ON iv.SkuId=ios.SkuId AND iv.WarehouseId=ios.SkuId';
       IF @showTransit>0
          SET @sql=@sql+' FULL JOIN (SELECT * FROM InventoryTransit it '+@warehouseIds+') it ON (iv.SkuId=it.SkuId OR ios.SkuId=it.SkuId) AND (iv.WarehouseId=it.WarehouseId OR ios.WarehouseId=it.WarehouseId)) p ON sku.SkuId=p.SkuId';
       ELSE
          SET @sql=@sql+') p ON sku.SkuId=p.SkuId';
       SET @countSql='SELECT @total=COUNT(1) FROM ('+@sql+') T';
       SET @pageSql='SELECT * FROM (SELECT *, Row_Number() OVER (ORDER BY SkuId) AS NUM FROM ('+@sql+') T) TEMP  WHERE NUM>'+CONVERT(VARCHAR(10), @startIndex)+' AND NUM<='+CONVERT(VARCHAR(10), @endIndex);
       PRINT @countSql;
       PRINT @pageSql;

       EXEC sp_executesql @countSql, N'@total int out', @total OUT;
       EXEC (@pageSql);
go

