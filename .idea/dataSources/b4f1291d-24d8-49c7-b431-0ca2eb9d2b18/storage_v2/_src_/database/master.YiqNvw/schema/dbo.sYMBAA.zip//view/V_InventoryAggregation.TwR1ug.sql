CREATE VIEW [dbo].[V_InventoryAggregation]
AS
       SELECT   WarehouseId = CASE WHEN iv.WarehouseId IS NOT NULL THEN iv.WarehouseId
                                   WHEN ios.WarehouseId IS NOT NULL THEN ios.WarehouseId
                                   ELSE it.WarehouseId
                              END, SkuId = CASE WHEN iv.SkuId IS NOT NULL THEN iv.SkuId
                                                WHEN ios.SkuId IS NOT NULL THEN ios.SkuId
                                                ELSE it.SkuId
                                           END, iv.Quantity, ios.LockedQuantity, ios.DispatchedQuantity, ios.UnDispatchedQuantity, ios.AllotQuantity, ios.VipQuantity, (ISNULL(iv.Quantity, 0)-ISNULL(ios.LockedQuantity, 0)) AS CanSaleQuantity, (ISNULL(iv.Quantity, 0)-ISNULL(ios.DispatchedQuantity, 0)-ISNULL(ios.AllotQuantity, 0)-ISNULL(ios.VipQuantity, 0)) AS CanUseQuantity, it.TransitTotalQuantity TransitQuantity
       FROM     InventoryVirtual iv
	   FULL OUTER JOIN V_InventoryTransit it ON iv.SkuId=it.SkuId AND iv.WarehouseId=it.WarehouseId
       FULL OUTER JOIN V_InventoryOccupationSum ios ON (ios.SkuId=iv.SkuId OR ios.SkuId=it.SkuId) AND (iv.WarehouseId=it.WarehouseId OR ios.WarehouseId=it.WarehouseId)


go

