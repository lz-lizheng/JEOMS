

CREATE FUNCTION [dbo].[F_CalcSkuUploadQuantity]
(
  @skuId       UNIQUEIDENTIFIER,
  @storeId     UNIQUEIDENTIFIER,
  @presellPlanId UNIQUEIDENTIFIER,
  @quantity    INT
)
RETURNS INT
AS
BEGIN
  DECLARE @sumQuantity INT = -99999;
  DECLARE @sumInventory INT;
  DECLARE @sumOccupation INT;
  IF @presellPlanId IS NOT NULL
    SET @sumQuantity = dbo.F_GetPreSellBeUploadQty(@SkuId, @StoreId);
  IF @sumQuantity = -99999
    BEGIN
      SELECT @sumInventory = ISNULL(SUM(Quantity), 0)
      FROM InventoryVirtual
      WHERE WarehouseId IN (SELECT WarehouseId
                            FROM InventoryUploadWarehouse iuw
                              JOIN InventoryUploadConfig iuc ON iuw.StoreId = iuc.StoreId AND (iuc.IsUpload = 1 OR iuc.IsManualUpload=1)) AND
            SkuId = @skuId
      SELECT @sumOccupation = ISNULL(SUM(Quantity), 0)
      FROM InventoryOccupation
      WHERE WarehouseId IN (SELECT WarehouseId
                            FROM InventoryUploadWarehouse iuw
                              JOIN InventoryUploadConfig iuc ON iuw.StoreId = iuc.StoreId AND (iuc.IsUpload = 1 OR iuc.IsManualUpload=1)) AND
            SkuId = @skuId
      SET @sumQuantity = @sumInventory - @sumOccupation
      IF @sumQuantity > @quantity
        RETURN @quantity;
      ELSE
        RETURN @sumQuantity;
    END
  ELSE
    RETURN @sumQuantity;
  RETURN @quantity;
END


go

