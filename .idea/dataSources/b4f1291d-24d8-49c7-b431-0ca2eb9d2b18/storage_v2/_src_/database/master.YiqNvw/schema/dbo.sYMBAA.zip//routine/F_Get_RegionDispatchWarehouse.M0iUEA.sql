CREATE FUNCTION [dbo].[F_Get_RegionDispatchWarehouse]
( 
	@P_DispatchTemplateId		UNIQUEIDENTIFIER,
	@P_ProvinceName				NVARCHAR(50),
	@P_CityName					NVARCHAR(50),
	@P_CountyName				NVARCHAR(50)
)
RETURNS @V_Warehouse TABLE(WarehouseTemplateId UNIQUEIDENTIFIER, TemplateId UNIQUEIDENTIFIER, OrderId INT, WarehouseID VARCHAR(36), 
						   WarehouseCode NVARCHAR(20), WarehouseName NVARCHAR(50), ParentId UNIQUEIDENTIFIER, ParentCode NVARCHAR(50), ParentName NVARCHAR(50),
						   WarehouseDispatchType INT, DefalutCodExpressId UNIQUEIDENTIFIER, DefaultNoCodExpressId UNIQUEIDENTIFIER
						   )
AS
BEGIN 
	--2. 建议仓库获取 问题点：a. 如果不设置仓库范围则为全部都到 
	-- 转换需要注意的点： 更新配货模板时需要重启
	 
	--SQL 1:
	--SET STATISTICS IO ON  
	INSERT INTO @V_Warehouse(WarehouseTemplateId, TemplateId, OrderId, WarehouseID, WarehouseCode, WarehouseName, ParentId, ParentCode, ParentName,
							 WarehouseDispatchType, DefalutCodExpressID, DefaultNoCodExpressId)  
	SELECT A.TemplateWarehouseId, A.TemplateId, A.OrderId, A.WarehouseId, Code, WarehouseName, A.ParentId, A.ParentCode, A.ParentName,
		A.WarehouseDispatchType, A.DefaultCodExpressId, A.DefaultNoCodeExpressId
	FROM ( 
		SELECT DTW.TemplateWarehouseId, DTW.TemplateId, DTW.OrderId, DTW.WarehouseId, wh.Code, wh.Name AS WarehouseName, wh.ParentId,
			   WHP.Code AS ParentCode, WHP.Name AS ParentName, DTW.WarehouseDispatchType, DT.DefaultCodExpressId AS DefaultCodExpressId,
			   DT.DefaultExpressId AS DefaultNoCodeExpressId
		FROM dbo.DispatchTemplate DT
		INNER JOIN dbo.DispatchTemplateWarehouse DTW ON DT.Id = DTW.TemplateId
		INNER JOIN dbo.Warehouse WH ON DTW.WarehouseId = WH.Id
		INNER JOIN dbo.Warehouse WHP ON WH.ParentId = WHP.Id
		WHERE DTW.IsDisabled = 0
		AND DT.IsDisabled = 0
		AND DT.Id = @P_DispatchTemplateId
		AND EXISTS (SELECT 1 FROM dbo.WarehouseRegion WR WHERE WR.ProvinceName = @P_ProvinceName AND WR.CityName = @P_CityName AND WR.CountyName = @P_CountyName AND WH.ParentId = WR.WarehouseId)
		UNION ALL 
		SELECT DTW.TemplateWarehouseId, DTW.TemplateId, DTW.OrderId, DTW.WarehouseId, wh.Code, wh.Name AS WarehouseName, wh.ParentId,
			   WHP.Code AS ParentCode, WHP.Name AS ParentName, DTW.WarehouseDispatchType, DT.DefaultCodExpressId AS DefaultCodExpressId,
			   DT.DefaultExpressId AS DefaultNoCodeExpressId
		FROM dbo.DispatchTemplate DT
		INNER JOIN dbo.DispatchTemplateWarehouse DTW ON DT.Id = DTW.TemplateId
		INNER JOIN dbo.Warehouse WH ON DTW.WarehouseId = WH.Id
		INNER JOIN dbo.Warehouse WHP ON WH.ParentId = WHP.Id
		WHERE DTW.IsDisabled = 0
		AND DT.IsDisabled = 0
		AND DT.Id = @P_DispatchTemplateId
		AND NOT EXISTS (SELECT 1 FROM WarehouseRegion wr WHERE WH.ParentId = WR.WarehouseId) 
		) A
	ORDER BY a.OrderId;
	--SET STATISTICS IO OFF
	 

	RETURN;
END;


go

