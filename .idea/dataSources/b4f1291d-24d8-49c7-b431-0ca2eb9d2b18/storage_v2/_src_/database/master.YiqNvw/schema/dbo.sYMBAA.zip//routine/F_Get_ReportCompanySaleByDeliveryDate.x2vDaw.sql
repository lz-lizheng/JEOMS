 
--  JE
-- 公司经营报表
CREATE FUNCTION [dbo].[F_Get_ReportCompanySaleByDeliveryDate]
(
	@P_ReturnType		INT, -- 1: 按时间统计, 2: 按店铺统计
	@P_BeginDate		DATETIME,	-- 开始时间
	@P_EndDate			DATETIME,	-- 结束时间
	@P_StoreId			NVARCHAR(max)-- 店铺ID 
)
RETURNS @V_OrderScheme TABLE(
						   DateKey DATE,
						   StoreId UNIQUEIDENTIFIER,
						   OrdQty INT,
						   SaleQty INT,
						   SaleAmt DECIMAL(15, 2), 
							 DistributionAmount DECIMAL(15, 2),
						   SaleCost DECIMAL(15, 2),  
						   ExpressFee DECIMAL(15, 2), 
  
						   RtnQty INT,
						   RtnAmt DECIMAL(15, 2), 
						   RtnCost DECIMAL(15, 2),
						   RtnDistributionAmount DECIMAL(15, 2),     --退款分销金额	
							 ActualQty 	DECIMAL(15, 2)	--经营销量 SaleQty-CancelQty-RtnQty
						   )   
AS
BEGIN  
	DECLARE @SO Table(DateKey DATETIME, StoreId UNIQUEIDENTIFIER, OrderQty INT, SaleQty INT,SaleAmt DECIMAL(15, 2),SaleCost DECIMAL(15, 2), SaleAmtOrg DECIMAL(15, 2),DistributionAmount DECIMAL(15, 2));  
	DECLARE @Exp Table(DateKey DATETIME, StoreId UNIQUEIDENTIFIER, ExpressFee DECIMAL(15, 2));  
	DECLARE @Rtn Table(DateKey DATETIME, StoreId UNIQUEIDENTIFIER, RtnQty INT, RtnAmt DECIMAL(15, 2),RtnCost DECIMAL(15, 2),RtnDistributionAmount DECIMAL(15, 2));  
	 		    
	
	INSERT INTO @SO(DateKey , StoreId ,OrderQty ,SaleQty ,SaleAmt ,SaleCost ,SaleAmtOrg ,DistributionAmount)--,SaleAmtOrg,DistributionAmount
	SELECT CONVERT(VARCHAR(10),DOD.DeliveryDate,20) as DateKey,SO.StoreID, Count(Distinct SO.OrderId) as OrdQty,
	SUM(SOD.Quantity) as SaleQty, Sum(SOD.AmountActual) as SaleAmt, Sum(SOD.Quantity * SOD.FirstCost) as SaleCost, Sum(SOD.Amount) as SaleAmtOrg, Sum(SOD.DistributionAmount) as DistributionAmount
	From SalesOrder(nolock) SO
	INNER JOIN SalesOrderDetail(nolock) SOD on SO.OrderId = SOD.SalesOrderId 
	INNER JOIN DispatchOrderDetail dpd on dpd.SalesOrderDetailId=sod.DetailId
	INNER JOIN DispatchOrderDetailExpress dod on dod.DetailId=dpd.Id
	Where DOD.DeliveryDate >= @P_BeginDate 
	And DOD.DeliveryDate < @P_EndDate
	AND (@P_StoreId IS NULL OR so.StoreId IN (SELECT * FROM dbo.F_SplitString(@P_StoreId, ',')))
	Group By Convert(Varchar(10), DOD.DeliveryDate, 20), SO.StoreID
		  
	--运费收入
	INSERT INTO @Exp( DateKey, StoreId, ExpressFee ) 
	Select  Convert(Varchar(10), SO.DeliveryDate, 20) as DateKey,SO.StoreID, Sum(So.ExpressFee) as ExpressFee
	From SalesOrder(nolock) SO 
	Where SO.DeliveryDate >= @P_BeginDate 
	And SO.DeliveryDate < @P_EndDate
	And SO.IsObsolete = 0
	AND (@P_StoreId IS NULL OR so.StoreId IN (SELECT * FROM dbo.F_SplitString(@P_StoreId, ',')))
	Group By  Convert(Varchar(10), SO.DeliveryDate, 20), SO.StoreID

	-- 退货数量、金额
	INSERT INTO @Rtn( DateKey ,StoreId ,RtnQty ,RtnAmt ,RtnCost,RtnDistributionAmount) 
	Select Convert(Varchar(10), RO.AuditDate, 20) as PayDate, ro.StoreId as StoreID, 
		SUM(ROPI.Quantity) as RtnQty, Sum(ROPI.ActualAmount) as RtnAmt, Sum(ROPI.Quantity * PD.FirstCost) as RtnCost,Sum(ROPI.Quantity * SOD.DistributionAmount) as RtnDistributionAmount
	From dbo.ReturnOrder(nolock) RO
	Left Join dbo.ReturnOrderDetail(nolock) ROPI on RO.Id = ROPI.ReturnOrderId
	Left Join Product(nolock) pd on ROPI.ProductId = PD.ProductId
	Left join SalesOrder(nolock) so on ROPI.SalesOrderId = so.OrderId
  Left Join SalesOrderDetail(nolock) SOD on ropi.SalesorderDetailId = SOD.Detailid
	Where Convert(Varchar(10), RO.AuditDate, 20) >= @P_BeginDate 
	And Convert(Varchar(10), RO.AuditDate, 20) < @P_EndDate 
	AND (@P_StoreId IS NULL OR ro.StoreId IN (SELECT * FROM dbo.F_SplitString(@P_StoreId, ',')))
	and ro.StoreId is not null
	Group By Convert(Varchar(10), RO.AuditDate, 20), ro.StoreId

	--　分店铺+时间，　店铺两个去提取数据
	IF @P_ReturnType = 1
		BEGIN
			INSERT INTO @V_OrderScheme( DateKey ,StoreId ,OrdQty ,SaleQty ,SaleAmt ,SaleCost ,ExpressFee ,RtnQty ,RtnAmt ,RtnCost,DistributionAmount,RtnDistributionAmount,ActualQty)
			SELECT PayD.DateKey AS DateKey, PayD.StoreId, ISNULL(Sale.OrderQty, 0) AS OrdQty, ISNULL(Sale.SaleQty, 0) AS SaleQty,
				ISNULL(Sale.SaleAmt, 0) AS SaleAmt, ISNULL(Sale.SaleCost, 0) AS SaleCost, ISNULL(Expr.ExpressFee, 0) AS ExpressFee,
			    ISNULL(Rtn.RtnQty, 0) AS RtnQty, ISNULL(Rtn.RtnAmt, 0) AS RtnAmt, ISNULL(Rtn.RtnCost, 0) AS RtnCost ,ISNULL(Sale.DistributionAmount, 0) AS DistributionAmount,
				ISNULL(Rtn.RtnDistributionAmount, 0) AS RtnDistributionAmount,
				(ISNULL(Sale.SaleQty, 0)-ISNULL(Rtn.RtnQty, 0)) AS ActualQty
			FROM (
				SELECT DateKey, StoreID FROM @SO 
				UNION 
				SELECT DateKey, StoreID FROM @Exp 
				UNION 
				SELECT DateKey, StoreID FROM @Rtn 
				) PayD 
			LEFT JOIN @SO Sale ON Sale.DateKey = PayD.DateKey AND Sale.StoreID = PayD.StoreID
			LEFT JOIN @Exp Expr ON Expr.DateKey = PayD.DateKey AND Expr.StoreID = PayD.StoreID
			LEFT JOIN @Rtn Rtn ON Rtn.DateKey = PayD.DateKey AND Rtn.StoreID = PayD.StoreID
			ORDER BY PayD.DateKey, PayD.StoreId
		END
	ELSE
		BEGIN 
			INSERT INTO @V_OrderScheme( StoreId ,OrdQty ,SaleQty ,SaleAmt ,SaleCost ,ExpressFee,RtnQty ,RtnAmt ,RtnCost ,DistributionAmount,RtnDistributionAmount,ActualQty)
			SELECT PayD.StoreId, ISNULL(SUM(Sale.OrderQty), 0) AS OrdQty, ISNULL(SUM(Sale.SaleQty), 0) AS SaleQty, 
				ISNULL(SUM(Sale.SaleAmt), 0) AS SaleAmt, ISNULL(SUM(Sale.SaleCost), 0) AS SaleCost, ISNULL(SUM(Expr.ExpressFee), 0) AS ExpressFee, ISNULL(SUM(Rtn.RtnQty), 0) AS RtnQty, 				 
				ISNULL(SUM(Rtn.RtnAmt), 0) AS RtnAmt, ISNULL(SUM(Rtn.RtnCost), 0) AS RtnCost,ISNULL(SUM(Sale.DistributionAmount), 0) AS DistributionAmount,
				ISNULL(SUM(Rtn.RtnDistributionAmount), 0) AS RtnDistributionAmount,(ISNULL(SUM(Sale.SaleQty), 0)-ISNULL(SUM(Rtn.RtnQty), 0)) AS ActualQty
			FROM (
				SELECT StoreID, DateKey FROM @SO 
				UNION 
				SELECT StoreID, DateKey FROM @Exp 
				UNION
				SELECT StoreID, DateKey FROM @Rtn 
				) PayD 
			LEFT JOIN @SO Sale ON Sale.StoreID = PayD.StoreID and Sale.DateKey = PayD.DateKey
			LEFT JOIN @Exp Expr ON Expr.StoreID = PayD.StoreID and Expr.DateKey = PayD.DateKey
			LEFT JOIN @Rtn Rtn ON Rtn.StoreID = PayD.StoreID and Rtn.DateKey = PayD.DateKey
			GROUP BY PayD.StoreId
			ORDER BY SUM(Sale.OrderQty) DESC
		END
		 
	RETURN; 
END;

go

