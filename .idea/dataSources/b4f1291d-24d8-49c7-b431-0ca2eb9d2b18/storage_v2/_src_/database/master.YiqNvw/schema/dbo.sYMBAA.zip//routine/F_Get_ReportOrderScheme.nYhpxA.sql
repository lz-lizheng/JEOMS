
/**
*
* 订单流转统计　增加按发货
*/
/************20161010***************************************************************************************************/
CREATE FUNCTION [dbo].[F_Get_ReportOrderScheme]
(
	@P_ReturnType		INT, -- 1: 按时间统计, 2: 按店铺统计, 3: 按仓库统计
	@P_BeginDate		DATETIME,	-- 开始时间
	@P_EndDate			DATETIME,	-- 结束时间
	@P_StoreId			NVARCHAR(max),-- 店铺ID
	@P_WarehouseId		NVARCHAR(max)-- 仓库ID
)
RETURNS @V_OrderScheme TABLE(
						   StoreId UNIQUEIDENTIFIER,
						   WarehouseId UNIQUEIDENTIFIER,
						   DateKey NVARCHAR(20),
						   OrderQty INT,
						   OrderNoAuditQty INT, 
						   OrderDispatchedQty INT,
						   OrderShippedQty INT,
						   DispatchQty INT,
						   DispatchNoticedQty INT,
						   DispatchShippedQty INT
						   )
AS
BEGIN 
	
	DECLARE @SO Table(StoreId UNIQUEIDENTIFIER, DateKey NVARCHAR(20), OrderQty INT, OrderNoAuditQty INT,OrderDispatchedQty INT,OrderShippedQty INT);  
	DECLARE @DPO Table(StoreId UNIQUEIDENTIFIER, WarehouseId UNIQUEIDENTIFIER, DateKey NVARCHAR(20), DispatchQty INT, DispatchNoticedQty INT,DispatchShippedQty INT);  
  
	IF @P_ReturnType IN (1, 2)
		BEGIN  
			INSERT @SO(StoreId, DateKey, OrderQty, OrderNoAuditQty, OrderDispatchedQty, OrderShippedQty)
			SELECT  SO.StoreId, 
					CONVERT(Varchar(13), PayDate, 20) as DateKey, 
					COUNT(1) as OrderQty,
					Sum(Case When AuditDate is null then 1 else 0 end) as OrderNoAuditQty,
					SUM(CASE WHEN DispatchTypeStatus = 0 THEN 0 ELSE 1 END) AS OrderDispatchedQty,
					Sum(CASE WHEN so.status in (31, 32) THEN 1 ELSE 0 End) as OrderShippedQty 
			From SalesOrder so(nolock)
			Where so.IsObsolete = 0
			AND (@P_StoreId IS NULL OR so.StoreId IN (SELECT * FROM dbo.F_SplitString(@P_StoreId, ',')))
			AND so.PayDate BETWEEN @P_BeginDate AND @P_EndDate
			Group by SO.StoreId, CONVERT(Varchar(13), PayDate, 20) 
		END 
		 
	--4. 已配货单 :  选择时间段内已经生成的配货通知单数量, --0	  -- 已生成 --1	  -- 推送中 --2	  -- 已通知 --3	  -- 已取消 --4	  --已发货
	IF @P_ReturnType in (1, 2, 3)
		BEGIN
			INSERT @DPO( StoreId ,WarehouseId ,DateKey ,DispatchQty ,DispatchNoticedQty ,DispatchShippedQty) 
			Select  dpo.StoreId, 
					dpo.WarehouseId,
					CONVERT(Varchar(13), CreateDate, 20) as DateKey, 
					COUNT(1) as DispatchQty,
					Sum(Case When Status in (2, 4) Then 1 End) as DispatchNoticedQty,
					Sum(Case When Status in (4) Then 1 End) as DispatchShippedQty 
			From dbo.DispatchOrder dpo(nolock)
			Where dpo.Status in (0, 1, 2, 4)
			AND (@P_StoreId IS NULL OR dpo.StoreId IN (SELECT * FROM dbo.F_SplitString(@P_StoreId, ',')))
			AND (@P_WarehouseId IS NULL OR dpo.WarehouseId IN (SELECT * FROM dbo.F_SplitString(@P_WarehouseId, ',')))
			AND dpo.CreateDate BETWEEN @P_BeginDate AND @P_EndDate
			Group By dpo.StoreId, dpo.WarehouseId,Convert(Varchar(13), dpo.CreateDate, 20);
		END
        
	IF @P_ReturnType = 4
		BEGIN
			INSERT @DPO( StoreId ,WarehouseId ,DateKey ,DispatchQty ,DispatchNoticedQty ,DispatchShippedQty) 
			Select  dpo.StoreId, 
					dpo.WarehouseId,
					CONVERT(Varchar(13), PushDate, 20) as DateKey, 
					COUNT(1) as DispatchQty,
					Sum(Case When Status in (2, 4) Then 1 End) as DispatchNoticedQty,
					Sum(Case When Status in (4) Then 1 End) as DispatchShippedQty 
			From dbo.DispatchOrder dpo(nolock)
			Where dpo.Status in (0, 1, 2, 4)
			AND (@P_StoreId IS NULL OR dpo.StoreId IN (SELECT * FROM dbo.F_SplitString(@P_StoreId, ',')))
			AND (@P_WarehouseId IS NULL OR dpo.WarehouseId IN (SELECT * FROM dbo.F_SplitString(@P_WarehouseId, ',')))
			AND dpo.PushDate BETWEEN @P_BeginDate AND @P_EndDate
			Group By dpo.StoreId, dpo.WarehouseId,Convert(Varchar(13), dpo.PushDate, 20);
		END
        
         
	--返回结果
	-- 1: 按时间统计, 2: 按店铺统计, 3: 按仓库统计
	IF @P_ReturnType = 1
		BEGIN
			INSERT INTO @V_OrderScheme(DateKey,OrderQty,OrderNoAuditQty, OrderDispatchedQty,OrderShippedQty,DispatchQty,DispatchNoticedQty,DispatchShippedQty)
			SELECT rm.DateKey, OrderQty, OrderNoAuditQty, OrderDispatchedQty, OrderShippedQty, DispatchQty ,DispatchNoticedQty ,DispatchShippedQty
			FROM (SELECT DISTINCT DateKey FROM @SO UNION SELECT DateKey FROM @DPO) RM
			LEFT JOIN (SELECT DateKey ,
                              SUM(OrderQty) AS OrderQty,
                              SUM(OrderNoAuditQty) AS OrderNoAuditQty,
                              SUM(OrderDispatchedQty) AS  OrderDispatchedQty,
                              SUM(OrderShippedQty) AS  OrderShippedQty
						FROM @SO 
						GROUP BY DateKey
					  ) so ON rm.DateKey = so.DateKey
			LEFT JOIN (SELECT DateKey, 
							  SUM(DispatchQty) AS DispatchQty,
							  SUM(DispatchNoticedQty) AS DispatchNoticedQty,
							  SUM(DispatchShippedQty) AS DispatchShippedQty
					   FROM @DPO 
					   GROUP BY DateKey 
						) dpo ON dpo.DateKey = rm.DateKey
			ORDER BY RM.DateKey 
		END
	
	IF @P_ReturnType = 2
		BEGIN
			INSERT INTO @V_OrderScheme(StoreId,OrderQty,OrderNoAuditQty, OrderDispatchedQty,OrderShippedQty,DispatchQty,DispatchNoticedQty,DispatchShippedQty)
			SELECT rm.StoreId, OrderQty, OrderNoAuditQty, OrderDispatchedQty, OrderShippedQty, DispatchQty ,DispatchNoticedQty ,DispatchShippedQty
			FROM (SELECT DISTINCT StoreId FROM @SO UNION SELECT StoreId FROM @DPO) RM
			LEFT JOIN (SELECT StoreId ,
                              SUM(OrderQty) AS OrderQty,
                              SUM(OrderNoAuditQty) AS OrderNoAuditQty,
                              SUM(OrderDispatchedQty) AS  OrderDispatchedQty,
                              SUM(OrderShippedQty) AS  OrderShippedQty
						FROM @SO 
						GROUP BY StoreId
					  ) so ON rm.StoreId = so.StoreId
			LEFT JOIN (SELECT StoreId, 
							  SUM(DispatchQty) AS DispatchQty,
							  SUM(DispatchNoticedQty) AS DispatchNoticedQty,
							  SUM(DispatchShippedQty) AS DispatchShippedQty
					   FROM @DPO 
					   GROUP BY StoreId 
						) dpo ON dpo.StoreId = rm.StoreId
			ORDER BY RM.StoreId 
		END
			   
	IF @P_ReturnType IN (3, 4)
		BEGIN
			INSERT INTO @V_OrderScheme(WarehouseId,DispatchQty,DispatchNoticedQty,DispatchShippedQty)
			SELECT WarehouseId, 
					SUM(DispatchQty) AS DispatchQty,
					SUM(DispatchNoticedQty) AS DispatchNoticedQty,
					SUM(DispatchShippedQty) AS DispatchShippedQty
			FROM @DPO 
			GROUP BY WarehouseId 
		END  
		
	IF @P_ReturnType = 5
		BEGIN 
			INSERT INTO @V_OrderScheme(WarehouseId, DispatchQty,DispatchShippedQty)
			Select  dpo.WarehouseId,
					COUNT(1) as DispatchQty, 
					Sum(Case When Status in (4) Then 1 End) as DispatchShippedQty 
			From dbo.DispatchOrder dpo(nolock)
			Where dpo.Status in (0, 1, 2, 4)
			AND (@P_StoreId IS NULL OR dpo.StoreId IN (SELECT * FROM dbo.F_SplitString(@P_StoreId, ',')))
			AND (@P_WarehouseId IS NULL OR dpo.WarehouseId IN (SELECT * FROM dbo.F_SplitString(@P_WarehouseId, ',')))
			AND dpo.DeliveryDate BETWEEN @P_BeginDate AND @P_EndDate
			Group By dpo.WarehouseId
			 
		END  	 	 

	RETURN; 
END;
go

