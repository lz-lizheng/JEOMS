-- JE 20160218
-- 库存上传按上传配置上传库存, 只用店铺上传比例 及所有库存上传仓库的可销计算上传量
Create FUNCTION [dbo].[F_Get_StoreSkuUploadQty]
(
	@P_SkuID		UNIQUEIDENTIFIER, 
	@P_StoreID		UNIQUEIDENTIFIER,
	@P_CalcType		NVARCHAR(20)		-- AUTO: 所有店铺, 按上传配置上传库存, MANUAL: 手工上传, 单店铺
)
RETURNS @V_StoreSkuQty TABLE(StoreId VARCHAR(40), WarehouseType VARCHAR(5), WarehouseRate INT, CanSaleQty INT, ZCanSaleQty INT, BrandCode NVARCHAR(50)) 
-- 店铺ID, 店铺上传比例, 共享仓可销数量, 独立仓可销数量
AS
BEGIN     
 
	IF @P_CalcType = 'AUTO'
		BEGIN 
			INSERT INTO @V_StoreSkuQty(StoreId, WarehouseType, WarehouseRate, BrandCode, CanSaleQty) 
			SELECT sw.StoreId, WarehouseType, sw.WarehouseRate, SW.BrandCode, 
				   ISNULL(ISNULL(SW.WarehouseQty, 0) - ISNULL(sw.LockQty, 0), 0) AS CanSaleQty
			FROM (
					SELECT SW.StoreId, SW.WarehouseId, SW.WarehouseRate, SW.WarehouseType, IV.Quantity AS WarehouseQty, SW.BrandCode, SUM(IOCC.Quantity) AS LockQty
					FROM (   
						 SELECT IUC.StoreId, IUW.WarehouseId AS WarehouseId, CASE WHEN IUW.WarehouseType = 2 THEN 'GX' ELSE 'DL' END WarehouseType,
							IUW.Scale AS WarehouseRate, IUC.BrandName AS BrandCode
						 FROM dbo.InventoryUploadConfig IUC(NOLOCK)
						 LEFT JOIN dbo.InventoryUploadWarehouse IUW(NOLOCK) ON IUW.StoreId = IUC.StoreId
						 Where IUC.IsUpload = 1 
						 ) SW
					LEFT JOIN dbo.InventoryVirtual IV ON SW.WarehouseId = IV.WarehouseId AND IV.SkuId = @P_SkuID
					LEFT JOIN dbo.InventoryOccupation IOCC ON SW.WarehouseId  = IOCC.WarehouseId AND IOCC.SkuId = @P_SkuID
					GROUP BY SW.StoreId, SW.WarehouseId, SW.WarehouseRate,IV.Quantity, SW.WarehouseType, SW.BrandCode 
				) SW 
		END
    ELSE
		BEGIN 
			INSERT INTO @V_StoreSkuQty(StoreId, WarehouseType, WarehouseRate, BrandCode, CanSaleQty) 
			SELECT sw.StoreId, WarehouseType, sw.WarehouseRate, SW.BrandCode, 
				   ISNULL(ISNULL(SW.WarehouseQty, 0) - ISNULL(sw.LockQty, 0), 0) AS CanSaleQty
			FROM (
					SELECT SW.StoreId, SW.WarehouseId, SW.WarehouseRate, SW.WarehouseType, IV.Quantity AS WarehouseQty, SW.BrandCode, SUM(IOCC.Quantity) AS LockQty
					FROM (
						  SELECT IUC.StoreId, IUW.WarehouseId AS WarehouseId, CASE WHEN IUW.WarehouseType = 2 THEN 'GX' ELSE 'DL' END WarehouseType,
							IUW.Scale AS WarehouseRate, IUC.BrandName AS BrandCode
						  FROM dbo.InventoryUploadConfig IUC(NOLOCK)
						  LEFT JOIN dbo.InventoryUploadWarehouse IUW(NOLOCK) ON IUW.StoreId = IUC.StoreId
						  WHERE IUC.IsUpload = 1 
						  AND IUC.StoreId = @P_StoreID 
						 ) SW
					LEFT JOIN dbo.InventoryVirtual IV ON SW.WarehouseId = IV.WarehouseId AND IV.SkuId = @P_SkuID
					LEFT JOIN dbo.InventoryOccupation IOCC ON SW.WarehouseId  = IOCC.WarehouseId AND IOCC.SkuId = @P_SkuID
					GROUP BY SW.StoreId, SW.WarehouseId, SW.WarehouseRate,IV.Quantity, SW.WarehouseType, SW.BrandCode
				) SW  
		END 
		  
	-- 按库存上传配置计算上传仓库的总可销.
	UPDATE @V_StoreSkuQty 
	SET ZCanSaleQty = (	SELECT ISNULL(SUM(A.Quantity), 0)
						FROM (
							SELECT SUM(iv.Quantity) AS Quantity
							FROM (SELECT DISTINCT WarehouseId AS WarehouseId FROM dbo.InventoryUploadWarehouse) WH
							LEFT JOIN dbo.InventoryVirtual IV ON WH.WarehouseID = IV.WarehouseId AND IV.SkuId = @P_SkuID
							UNION ALL
							SELECT SUM(iocc.Quantity) * -1 AS Quantity
							FROM (SELECT DISTINCT WarehouseId AS WarehouseId FROM dbo.InventoryUploadWarehouse) WH
							INNER JOIN dbo.InventoryOccupation IOCC ON WH.WarehouseId = IOCC.WarehouseId AND IOCC.SkuId = @P_SkuID
							) A
						); 
	RETURN;
	  
END;

go

